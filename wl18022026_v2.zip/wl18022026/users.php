<?php
/**
 * Zarządzanie użytkownikami
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

// Tylko admin może zarządzać użytkownikami
if (!canManageUsers()) {
    header('Location: index.php?msg=noperm');
    exit;
}

$currentUser = getCurrentUser();
$errors = [];
$success = '';

// Obsługa akcji
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Dodawanie użytkownika
    if ($action === 'add') {
        $login = trim($_POST['login'] ?? '');
        $name = trim($_POST['name'] ?? '');
        $password = $_POST['password'] ?? '';
        $role = $_POST['role'] ?? 'viewer';
        
        // Walidacja roli
        if (!in_array($role, ['admin', 'moderator', 'rekruter', 'viewer'])) {
            $role = 'viewer';
        }
        
        if (empty($login)) $errors[] = 'Login jest wymagany.';
        if (empty($name)) $errors[] = 'Imię i nazwisko jest wymagane.';
        if (empty($password)) $errors[] = 'Hasło jest wymagane.';
        if (strlen($password) < 6) $errors[] = 'Hasło musi mieć minimum 6 znaków.';
        
        // Sprawdź unikalność loginu
        if (empty($errors)) {
            $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE login = ?");
            $stmt->execute([$login]);
            if ($stmt->fetchColumn() > 0) {
                $errors[] = 'Użytkownik o takim loginie już istnieje.';
            }
        }
        
        if (empty($errors)) {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (login, password, name, role) VALUES (?, ?, ?, ?)");
            $stmt->execute([$login, $hash, $name, $role]);
            
            logChange($db, 'CREATE', 'users', $db->lastInsertId(), "Dodano użytkownika: {$login} ({$name}), rola: {$role}");
            $success = 'Użytkownik został dodany.';
        }
    }
    
    // Zmiana statusu (aktywny/nieaktywny)
    if ($action === 'toggle') {
        $id = (int)$_POST['id'];
        if ($id != $currentUser['id']) {
            $db->prepare("UPDATE users SET active = CASE WHEN active = 1 THEN 0 ELSE 1 END WHERE id = ?")->execute([$id]);
            logChange($db, 'UPDATE', 'users', $id, "Zmieniono status aktywności użytkownika");
            $success = 'Status użytkownika został zmieniony.';
        }
    }
    
    // Zmiana roli
    if ($action === 'change_role') {
        $id = (int)$_POST['id'];
        $newRole = $_POST['new_role'] ?? 'viewer';
        
        if (!in_array($newRole, ['admin', 'moderator', 'rekruter', 'viewer'])) {
            $newRole = 'viewer';
        }
        
        if ($id != $currentUser['id']) {
            $db->prepare("UPDATE users SET role = ? WHERE id = ?")->execute([$newRole, $id]);
            logChange($db, 'UPDATE', 'users', $id, "Zmieniono rolę użytkownika na: {$newRole}");
            $success = 'Rola użytkownika została zmieniona.';
        } else {
            $errors[] = 'Nie możesz zmienić własnej roli.';
        }
    }
    
    // Reset hasła
    if ($action === 'reset_password') {
        $id = (int)$_POST['id'];
        $new_password = $_POST['new_password'] ?? '';
        
        if (strlen($new_password) < 6) {
            $errors[] = 'Hasło musi mieć minimum 6 znaków.';
        } else {
            $hash = password_hash($new_password, PASSWORD_DEFAULT);
            $db->prepare("UPDATE users SET password = ? WHERE id = ?")->execute([$hash, $id]);
            logChange($db, 'UPDATE', 'users', $id, "Zresetowano hasło użytkownika");
            $success = 'Hasło zostało zmienione.';
        }
    }
    
    // Usuwanie użytkownika
    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        if ($id != $currentUser['id']) {
            $stmt = $db->prepare("SELECT login, name FROM users WHERE id = ?");
            $stmt->execute([$id]);
            $delUser = $stmt->fetch();
            
            $db->prepare("DELETE FROM users WHERE id = ?")->execute([$id]);
            logChange($db, 'DELETE', 'users', $id, "Usunięto użytkownika: {$delUser['login']} ({$delUser['name']})");
            $success = 'Użytkownik został usunięty.';
        }
    }
}

// Pobierz wszystkich użytkowników
$users = $db->query("SELECT * FROM users ORDER BY name")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zarządzanie użytkownikami - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .role-badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .role-admin { background: #fee2e2; color: #dc2626; }
        .role-moderator { background: #fef3c7; color: #d97706; }
        .role-rekruter { background: #ede9fe; color: #7c3aed; }
        .role-viewer { background: #dbeafe; color: #2563eb; }
        .badge-active { background: #dcfce7; color: #166534; }
        .badge-inactive { background: #fee2e2; color: #991b1b; }
        
        .add-user-form {
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            margin-bottom: 25px;
        }
        .add-user-form h2 { margin-bottom: 20px; font-size: 1.1rem; }
        
        .role-info {
            background: #f8fafc;
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }
        .role-info h4 { margin-bottom: 10px; }
        .role-info ul { margin: 0; padding-left: 20px; }
        .role-info li { margin: 5px 0; }
        
        .role-select { padding: 5px 10px; border-radius: 4px; border: 1px solid #e2e8f0; font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <span>👤 <?php echo sanitize($currentUser['name']); ?></span>
            <div class="nav-links">
                <?php if (canViewHistory()): ?><a href="historia.php">📜 Historia</a><?php endif; ?>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>👥 Zarządzanie użytkownikami</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <?php if (!empty($errors)): ?>
            <div class="alert error">
                <?php foreach ($errors as $e): ?><p><?php echo $e; ?></p><?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <!-- Info o rolach -->
        <div class="role-info">
            <h4>📋 Role i uprawnienia:</h4>
            <ul>
                <li><span class="role-badge role-admin">Administrator</span> - pełny dostęp, historia zmian, zarządzanie użytkownikami</li>
                <li><span class="role-badge role-moderator">Moderator</span> - dodawanie, edycja, usuwanie pracowników (bez historii i użytkowników)</li>
                <li><span class="role-badge role-rekruter">Rekruter</span> - dostęp jak Moderator, po zalogowaniu trafia na panel Kandydatów z task managerem</li>
                <li><span class="role-badge role-viewer">Podgląd</span> - przeglądanie i dodawanie pracowników (bez usuwania)</li>
            </ul>
        </div>
        
        <!-- Formularz dodawania -->
        <div class="add-user-form">
            <h2>➕ Dodaj nowego użytkownika</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="login">Login *</label>
                        <input type="text" id="login" name="login" required pattern="[a-z0-9_]+" title="Tylko małe litery, cyfry i podkreślnik">
                    </div>
                    <div class="form-group">
                        <label for="name">Imię i nazwisko *</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Hasło * (min. 6 znaków)</label>
                        <input type="password" id="password" name="password" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label for="role">Rola *</label>
                        <select id="role" name="role" required>
                            <option value="viewer">Podgląd</option>
                            <option value="rekruter">Rekruter</option>
                            <option value="moderator">Moderator</option>
                            <option value="admin">Administrator</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary" style="margin-top: 15px;">💾 Dodaj użytkownika</button>
            </form>
        </div>
        
        <!-- Lista użytkowników -->
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Login</th>
                        <th>Imię i nazwisko</th>
                        <th>Rola</th>
                        <th>Status</th>
                        <th>Ostatnie logowanie</th>
                        <th>Akcje</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                        <?php $userRole = $u['role'] ?? 'viewer'; ?>
                        <tr>
                            <td><code><?php echo sanitize($u['login']); ?></code></td>
                            <td>
                                <?php echo sanitize($u['name']); ?>
                                <?php if ($u['id'] == $currentUser['id']): ?>
                                    <small class="muted">(Ty)</small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($u['id'] != $currentUser['id']): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="change_role">
                                        <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                                        <select name="new_role" class="role-select" onchange="this.form.submit()">
                                            <option value="viewer" <?php echo $userRole === 'viewer' ? 'selected' : ''; ?>>Podgląd</option>
                                            <option value="rekruter" <?php echo $userRole === 'rekruter' ? 'selected' : ''; ?>>Rekruter</option>
                                            <option value="moderator" <?php echo $userRole === 'moderator' ? 'selected' : ''; ?>>Moderator</option>
                                            <option value="admin" <?php echo $userRole === 'admin' ? 'selected' : ''; ?>>Administrator</option>
                                        </select>
                                    </form>
                                <?php else: ?>
                                    <span class="role-badge role-<?php echo $userRole; ?>"><?php echo getRoleName($userRole); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="role-badge <?php echo $u['active'] ? 'badge-active' : 'badge-inactive'; ?>">
                                    <?php echo $u['active'] ? 'Aktywny' : 'Nieaktywny'; ?>
                                </span>
                            </td>
                            <td>
                                <?php echo $u['last_login'] ? date('d.m.Y H:i', strtotime($u['last_login'])) : '<span class="muted">Nigdy</span>'; ?>
                            </td>
                            <td class="actions">
                                <?php if ($u['id'] != $currentUser['id']): ?>
                                    <!-- Toggle aktywności -->
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="toggle">
                                        <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                                        <button type="submit" class="btn btn-small" title="<?php echo $u['active'] ? 'Dezaktywuj' : 'Aktywuj'; ?>">
                                            <?php echo $u['active'] ? '🚫' : '✅'; ?>
                                        </button>
                                    </form>
                                    
                                    <!-- Reset hasła -->
                                    <button type="button" class="btn btn-small" onclick="resetPassword(<?php echo $u['id']; ?>, '<?php echo sanitize($u['login']); ?>')" title="Resetuj hasło">🔑</button>
                                    
                                    <!-- Usuń -->
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Na pewno usunąć użytkownika <?php echo sanitize($u['login']); ?>?')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                                        <button type="submit" class="btn btn-small btn-danger" title="Usuń">🗑️</button>
                                    </form>
                                <?php else: ?>
                                    <span class="muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        
        <footer>
            <p>Work Land © <?php echo date('Y'); ?> | System Ewidencji Pracowników | v<?= WORKLAND_VERSION ?> (<?= WORKLAND_VERSION_DATE ?>)</p>
        </footer>
    </div>
    
    <!-- Modal resetowania hasła -->
    <div id="resetModal" class="modal" style="display: none;">
        <div class="modal-content">
            <h3>🔑 Resetuj hasło</h3>
            <p>Użytkownik: <strong id="resetUserLogin"></strong></p>
            <form method="POST">
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="id" id="resetUserId">
                <div class="form-group">
                    <label for="new_password">Nowe hasło (min. 6 znaków)</label>
                    <input type="password" id="new_password" name="new_password" required minlength="6">
                </div>
                <div class="modal-actions">
                    <button type="submit" class="btn btn-primary">Zmień hasło</button>
                    <button type="button" class="btn btn-secondary" onclick="closeResetModal()">Anuluj</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function resetPassword(id, login) {
            document.getElementById('resetUserId').value = id;
            document.getElementById('resetUserLogin').textContent = login;
            document.getElementById('resetModal').style.display = 'flex';
            document.getElementById('new_password').focus();
        }
        
        function closeResetModal() {
            document.getElementById('resetModal').style.display = 'none';
        }
        
        document.getElementById('resetModal').addEventListener('click', function(e) {
            if (e.target === this) closeResetModal();
        });
    </script>
</body>
</html>
