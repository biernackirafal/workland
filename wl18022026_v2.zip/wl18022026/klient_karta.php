<?php
/**
 * CRM - Karta potencjalnego klienta v2
 * 
 * Nowe funkcje:
 * - Wyświetlanie KRS
 * - Linki do zewnętrznych serwisów (LinkedIn, KRS online, Google Maps)
 * - Przycisk wyszukiwania na LinkedIn
 * 
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

$id = intval($_GET['id'] ?? 0);
$tab = $_GET['tab'] ?? 'info';

if (!$id) {
    header('Location: klienci.php');
    exit;
}

// Pobierz klienta
$stmt = $db->prepare("
    SELECT k.*, u.name as przypisany_nazwa, c.name as created_by_name
    FROM crm_klienci k
    LEFT JOIN users u ON k.przypisany_do = u.id
    LEFT JOIN users c ON k.created_by = c.id
    WHERE k.id = ?
");
$stmt->execute([$id]);
$klient = $stmt->fetch();

if (!$klient) {
    header('Location: klienci.php');
    exit;
}

// Pobierz osoby kontaktowe
$stmt = $db->prepare("SELECT * FROM crm_osoby WHERE klient_id = ? ORDER BY glowny_kontakt DESC, nazwisko");
$stmt->execute([$id]);
$osoby = $stmt->fetchAll();

// Pobierz zadania
$stmt = $db->prepare("
    SELECT z.*, u.name as przypisany_nazwa
    FROM crm_zadania z
    LEFT JOIN users u ON z.przypisany_do = u.id
    WHERE z.klient_id = ?
    ORDER BY 
        CASE z.status WHEN 'nowe' THEN 1 WHEN 'w_trakcie' THEN 2 ELSE 3 END,
        z.termin_data ASC
");
$stmt->execute([$id]);
$zadania = $stmt->fetchAll();

// Pobierz pliki
$stmt = $db->prepare("
    SELECT p.*, u.name as uploaded_by_name
    FROM crm_pliki p
    LEFT JOIN users u ON p.uploaded_by = u.id
    WHERE p.klient_id = ?
    ORDER BY p.created_at DESC
");
$stmt->execute([$id]);
$pliki = $stmt->fetchAll();

// Pobierz użytkowników
$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();

$crmStatusy = getCrmStatusy();
$crmPriorytety = getCrmPriorytety();
$typyZadan = getCrmTypyZadan();
$statusyZadan = getCrmStatusyZadan();

$status = $crmStatusy[$klient['status']] ?? $crmStatusy['nowy'];

$msg = $_GET['msg'] ?? '';

// Funkcja do generowania URL wyszukiwania LinkedIn
function getLinkedInSearchUrl($companyName) {
    $cleanName = preg_replace('/\s*(sp\.\s*z\s*o\.?\s*o\.?|s\.?\s*a\.?|spółka.*)\s*$/ui', '', $companyName);
    $cleanName = trim(str_replace(['"', "'"], '', $cleanName));
    return 'https://www.linkedin.com/search/results/companies/?keywords=' . urlencode($cleanName);
}

function getGoogleLinkedInSearchUrl($companyName) {
    $cleanName = preg_replace('/\s*(sp\.\s*z\s*o\.?\s*o\.?|s\.?\s*a\.?|spółka.*)\s*$/ui', '', $companyName);
    $cleanName = trim(str_replace(['"', "'"], '', $cleanName));
    return 'https://www.google.com/search?q=' . urlencode('site:linkedin.com/company/ "' . $cleanName . '"');
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($klient['nazwa']); ?> - CRM - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .crm-nav { background: #1e40af; padding: 10px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .crm-nav a { color: rgba(255,255,255,0.85); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; }
        .crm-nav a:hover, .crm-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .crm-nav .nav-title { color: white; font-weight: 600; margin-right: 20px; }
        
        .client-header { background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%); color: white; padding: 30px; border-radius: 12px 12px 0 0; }
        .client-header h1 { margin: 0 0 10px 0; font-size: 1.75rem; }
        .client-header .meta { opacity: 0.9; font-size: 0.95rem; }
        
        .tabs { display: flex; background: white; border-bottom: 2px solid #e2e8f0; }
        .tabs a { padding: 15px 25px; text-decoration: none; color: #64748b; font-weight: 500; border-bottom: 2px solid transparent; margin-bottom: -2px; }
        .tabs a:hover { color: #374151; }
        .tabs a.active { color: #2563eb; border-bottom-color: #2563eb; }
        
        .card { background: white; border-radius: 0 0 12px 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .card-body { padding: 25px; }
        
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; }
        @media (max-width: 768px) { .info-grid { grid-template-columns: 1fr; } }
        
        .info-section h3 { margin: 0 0 15px 0; font-size: 1rem; color: #374151; display: flex; align-items: center; gap: 8px; }
        .info-table { width: 100%; }
        .info-table td { padding: 8px 0; vertical-align: top; }
        .info-table td:first-child { width: 140px; color: #64748b; font-size: 0.9rem; }
        .info-table a { color: #2563eb; text-decoration: none; }
        .info-table .mono { font-family: monospace; font-size: 0.95rem; letter-spacing: 0.5px; }
        
        .badge { display: inline-block; padding: 4px 12px; border-radius: 50px; font-size: 0.8rem; font-weight: 600; }
        
        .external-links { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 15px; }
        .ext-link { display: inline-flex; align-items: center; gap: 6px; padding: 8px 14px; background: #f1f5f9; border-radius: 8px; text-decoration: none; color: #475569; font-size: 0.85rem; font-weight: 500; transition: all 0.2s; }
        .ext-link:hover { background: #e2e8f0; color: #1e293b; }
        .ext-link.linkedin { background: #0077b5; color: white; }
        .ext-link.linkedin:hover { background: #005e8c; }
        .ext-link.krs { background: #dc2626; color: white; }
        .ext-link.krs:hover { background: #b91c1c; }
        .ext-link.maps { background: #34a853; color: white; }
        .ext-link.maps:hover { background: #2d8544; }
        
        .contact-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
        .contact-card { border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; display: flex; gap: 15px; }
        .contact-avatar { width: 50px; height: 50px; background: #2563eb; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 600; font-size: 1.1rem; flex-shrink: 0; }
        .contact-info h4 { margin: 0 0 5px 0; font-size: 1rem; }
        .contact-info .position { color: #64748b; font-size: 0.85rem; }
        .contact-details { font-size: 0.85rem; margin-top: 10px; }
        .contact-details a { color: #2563eb; text-decoration: none; }
        .contact-actions { margin-left: auto; display: flex; gap: 8px; }
        
        .task-item { display: flex; gap: 15px; padding: 15px; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 12px; align-items: flex-start; }
        .task-item:hover { border-color: #2563eb; }
        .task-item.completed { opacity: 0.6; background: #f8fafc; }
        .task-checkbox { width: 22px; height: 22px; cursor: pointer; accent-color: #2563eb; margin-top: 2px; }
        .task-content { flex: 1; }
        .task-content h4 { margin: 0 0 8px 0; font-size: 0.95rem; }
        .task-meta { font-size: 0.8rem; color: #64748b; display: flex; gap: 15px; flex-wrap: wrap; }
        .task-overdue { color: #dc2626 !important; font-weight: 600; }
        
        .file-item { display: flex; align-items: center; gap: 15px; padding: 12px 15px; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 10px; }
        .file-icon { width: 42px; height: 42px; background: #f1f5f9; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.3rem; }
        .file-info { flex: 1; }
        .file-name { font-weight: 500; }
        .file-meta { font-size: 0.8rem; color: #64748b; }
        
        .dropzone { border: 2px dashed #cbd5e1; border-radius: 10px; padding: 40px; text-align: center; cursor: pointer; margin-bottom: 20px; }
        .dropzone:hover, .dropzone.dragover { border-color: #2563eb; background: #eff6ff; }
        .dropzone p { margin: 0; color: #64748b; }
        
        .empty-state { text-align: center; padding: 50px; color: #64748b; }
        .empty-state .icon { font-size: 3rem; margin-bottom: 15px; }
        
        .modal-backdrop { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 2000; opacity: 0; visibility: hidden; transition: all 0.2s; }
        .modal-backdrop.active { opacity: 1; visibility: visible; }
        .modal { background: white; border-radius: 12px; max-width: 550px; width: 90%; max-height: 90vh; overflow-y: auto; }
        .modal-header { padding: 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
        .modal-header h3 { margin: 0; }
        .modal-close { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #64748b; }
        .modal-body { padding: 20px; }
        .modal-footer { padding: 15px 20px; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 10px; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; font-size: 0.9rem; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px 12px; border: 2px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem; box-sizing: border-box; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #2563eb; outline: none; }
        
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert.success { background: #dcfce7; color: #166534; }
        
        .section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .section-header h3 { margin: 0; }
        
        .krs-badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; background: #fef3c7; color: #92400e; border-radius: 6px; font-size: 0.8rem; font-weight: 500; }
        .linkedin-badge { display: inline-flex; align-items: center; gap: 4px; padding: 2px 8px; background: #dbeafe; color: #1e40af; border-radius: 4px; font-size: 0.75rem; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?php echo sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../klienci.php">🏢 Klienci</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <div class="crm-nav">
            <span class="nav-title">🎯 CRM</span>
            <a href="./">Dashboard</a>
            <a href="klienci.php" class="active">Potencjalni Klienci</a>
            <a href="zadania.php">Zadania</a>
            <a href="kalendarz.php">Kalendarz</a>
        </div>
        
        <?php if ($msg === 'created'): ?>
            <div class="alert success">Klient został dodany. Uzupełnij osoby kontaktowe i zaplanuj pierwsze zadania.</div>
        <?php endif; ?>
        
        <!-- Nagłówek klienta -->
        <div class="client-header">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                    <h1><?php echo htmlspecialchars($klient['nazwa']); ?></h1>
                    <div class="meta">
                        <?php if ($klient['miasto']): ?>📍 <?php echo htmlspecialchars($klient['miasto']); ?><?php if ($klient['wojewodztwo']): ?> (<?php echo htmlspecialchars($klient['wojewodztwo']); ?>)<?php endif; ?> · <?php endif; ?>
                        <?php if ($klient['nip']): ?>NIP: <?php echo htmlspecialchars($klient['nip']); ?> · <?php endif; ?>
                        <?php if (!empty($klient['krs_numer'])): ?>KRS: <?php echo htmlspecialchars($klient['krs_numer']); ?> · <?php endif; ?>
                        <?php if ($klient['branza']): ?><?php echo htmlspecialchars($klient['branza']); ?><?php endif; ?>
                    </div>
                </div>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <span class="badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>; font-size: 0.9rem; padding: 8px 16px;">
                        <?php echo $status['label']; ?>
                    </span>
                    <a href="klient_dodaj.php?id=<?php echo $id; ?>" class="btn">✏️ Edytuj</a>
                </div>
            </div>
        </div>
        
        <!-- Zakładki -->
        <div class="tabs">
            <a href="?id=<?php echo $id; ?>&tab=info" class="<?php echo $tab === 'info' ? 'active' : ''; ?>">📋 Informacje</a>
            <a href="?id=<?php echo $id; ?>&tab=osoby" class="<?php echo $tab === 'osoby' ? 'active' : ''; ?>">👥 Osoby kontaktowe (<?php echo count($osoby); ?>)</a>
            <a href="?id=<?php echo $id; ?>&tab=zadania" class="<?php echo $tab === 'zadania' ? 'active' : ''; ?>">✅ Zadania (<?php echo count($zadania); ?>)</a>
            <a href="?id=<?php echo $id; ?>&tab=pliki" class="<?php echo $tab === 'pliki' ? 'active' : ''; ?>">📁 Pliki (<?php echo count($pliki); ?>)</a>
        </div>
        
        <div class="card">
            <div class="card-body">
                
                <?php if ($tab === 'info'): ?>
                    <!-- INFORMACJE -->
                    <div class="info-grid">
                        <div class="info-section">
                            <h3>📞 Dane kontaktowe</h3>
                            <table class="info-table">
                                <tr><td>Telefon:</td><td><?php echo $klient['telefon'] ? '<a href="tel:'.$klient['telefon'].'">'.htmlspecialchars($klient['telefon']).'</a>' : '-'; ?></td></tr>
                                <tr><td>E-mail:</td><td><?php echo $klient['email'] ? '<a href="mailto:'.$klient['email'].'">'.htmlspecialchars($klient['email']).'</a>' : '-'; ?></td></tr>
                                <tr><td>WWW:</td><td><?php if ($klient['www']): ?><a href="<?php echo (strpos($klient['www'], 'http') === 0 ? '' : 'https://') . htmlspecialchars($klient['www']); ?>" target="_blank" style="display: inline-flex; align-items: center; gap: 5px;">🌐 <?php echo htmlspecialchars($klient['www']); ?></a><?php else: ?>-<?php endif; ?></td></tr>
                            </table>
                            
                            <h3 style="margin-top: 25px;">📍 Adres</h3>
                            <?php if ($klient['adres'] || $klient['kod_pocztowy'] || $klient['miasto']): ?>
                            <div style="background: #f8fafc; padding: 15px; border-radius: 8px; border-left: 4px solid #2563eb;">
                                <?php if ($klient['adres']): ?>
                                    <div style="font-weight: 500;"><?php echo htmlspecialchars($klient['adres']); ?></div>
                                <?php endif; ?>
                                <?php if ($klient['kod_pocztowy'] || $klient['miasto']): ?>
                                    <div><?php echo htmlspecialchars(trim($klient['kod_pocztowy'] . ' ' . $klient['miasto'])); ?></div>
                                <?php endif; ?>
                                <?php if ($klient['wojewodztwo']): ?>
                                    <div style="color: #64748b; font-size: 0.9rem;">woj. <?php echo htmlspecialchars($klient['wojewodztwo']); ?></div>
                                <?php endif; ?>
                            </div>
                            <?php else: ?>
                            <p style="color: #64748b;">Brak danych adresowych</p>
                            <?php endif; ?>
                            
                            <h3 style="margin-top: 25px;">🏢 Informacje o firmie</h3>
                            <table class="info-table">
                                <tr><td>NIP:</td><td><span class="mono"><?php echo htmlspecialchars($klient['nip'] ?: '-'); ?></span></td></tr>
                                <tr><td>REGON:</td><td><span class="mono"><?php echo htmlspecialchars($klient['regon'] ?: '-'); ?></span></td></tr>
                                <tr>
                                    <td>KRS:</td>
                                    <td>
                                        <?php if (!empty($klient['krs_numer'])): ?>
                                            <span class="mono"><?php echo htmlspecialchars($klient['krs_numer']); ?></span>
                                            <a href="https://ekrs.ms.gov.pl/web/wyszukiwarka-krs/strona-glowna/index.html?t:lb=t&q=<?php echo $klient['krs_numer']; ?>" 
                                               target="_blank" 
                                               style="margin-left: 8px; font-size: 0.8rem; color: #dc2626;">
                                                🔗 eKRS
                                            </a>
                                        <?php else: ?>
                                            <span style="color: #9ca3af;">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr><td>Branża:</td><td><?php echo htmlspecialchars($klient['branza'] ?: '-'); ?></td></tr>
                                <tr><td>Pracownicy:</td><td><?php echo htmlspecialchars($klient['ilosc_pracownikow'] ?: '-'); ?></td></tr>
                                <tr><td>Źródło:</td><td><?php echo htmlspecialchars($klient['zrodlo_pozyskania'] ?: '-'); ?></td></tr>
                                <?php if ($klient['zrodlo_pozyskania'] === 'Polecenie' && !empty($klient['polecenie_od_kogo'])): ?>
                                <tr><td>Od kogo:</td><td><?php echo htmlspecialchars($klient['polecenie_od_kogo']); ?></td></tr>
                                <?php endif; ?>
                            </table>
                            
                            <!-- Linki zewnętrzne -->
                            <h3 style="margin-top: 25px;">🔗 Linki zewnętrzne</h3>
                            <div class="external-links">
                                <!-- CRM LinkedIn - wewnętrzne narzędzie -->
                                <a href="crm_linkedin.php?klient_id=<?php echo $id; ?>" class="ext-link" style="background: #7c3aed; color: white;" title="Otwórz narzędzie CRM LinkedIn">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                                    🎯 CRM LinkedIn
                                </a>
                                
                                <!-- LinkedIn -->
                                <a href="<?php echo getLinkedInSearchUrl($klient['nazwa']); ?>" target="_blank" class="ext-link linkedin" title="Szukaj na LinkedIn">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                                    Szukaj na LinkedIn
                                </a>
                                
                                <a href="<?php echo getGoogleLinkedInSearchUrl($klient['nazwa']); ?>" target="_blank" class="ext-link" title="Szukaj LinkedIn przez Google">
                                    🔍 Google → LinkedIn
                                </a>
                                
                                <!-- KRS online -->
                                <?php if (!empty($klient['krs_numer'])): ?>
                                <a href="https://ekrs.ms.gov.pl/web/wyszukiwarka-krs/strona-glowna/index.html?t:lb=t&q=<?php echo $klient['krs_numer']; ?>" target="_blank" class="ext-link krs">
                                    📋 Sprawdź w eKRS
                                </a>
                                <a href="https://rejestr.io/krs/<?php echo $klient['krs_numer']; ?>" target="_blank" class="ext-link" title="Rejestr.io">
                                    📊 Rejestr.io
                                </a>
                                <?php endif; ?>
                                
                                <!-- Google Maps -->
                                <?php if ($klient['miasto'] || $klient['adres']): ?>
                                <?php 
                                    $mapQuery = trim($klient['adres'] . ', ' . $klient['kod_pocztowy'] . ' ' . $klient['miasto']);
                                ?>
                                <a href="https://www.google.com/maps/search/?api=1&query=<?php echo urlencode($mapQuery); ?>" target="_blank" class="ext-link maps">
                                    📍 Google Maps
                                </a>
                                <?php endif; ?>
                                
                                <!-- Panorama Firm -->
                                <a href="https://panoramafirm.pl/szukaj?k=<?php echo urlencode($klient['nazwa']); ?>" target="_blank" class="ext-link">
                                    🏢 Panorama Firm
                                </a>
                            </div>
                        </div>
                        
                        <div class="info-section">
                            <h3>📊 Status i przypisanie</h3>
                            <table class="info-table">
                                <tr><td>Status:</td><td><span class="badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;"><?php echo $status['label']; ?></span></td></tr>
                                <tr><td>Priorytet:</td><td><?php $pr = $crmPriorytety[$klient['priorytet']] ?? $crmPriorytety['normalny']; ?><span class="badge" style="background: <?php echo $pr['bg']; ?>; color: <?php echo $pr['color']; ?>;"><?php echo $pr['label']; ?></span></td></tr>
                                <tr><td>Przypisany do:</td><td><?php echo htmlspecialchars($klient['przypisany_nazwa'] ?: 'Nieprzypisany'); ?></td></tr>
                                <tr><td>Dodany:</td><td><?php echo date('d.m.Y H:i', strtotime($klient['created_at'])); ?><?php if ($klient['created_by_name']): ?> przez <?php echo htmlspecialchars($klient['created_by_name']); ?><?php endif; ?></td></tr>
                            </table>
                            
                            <?php if (!empty($klient['notatka_firma'])): ?>
                                <h3 style="margin-top: 25px;">📋 O firmie</h3>
                                <div style="background: #eff6ff; padding: 15px; border-radius: 8px; border-left: 4px solid #2563eb;">
                                    <?php echo nl2br(htmlspecialchars($klient['notatka_firma'])); ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($klient['notatka_kontakt'])): ?>
                                <h3 style="margin-top: 25px;">💬 Notatki kontaktowe</h3>
                                <div style="background: #fef3c7; padding: 15px; border-radius: 8px; border-left: 4px solid #f59e0b;">
                                    <?php echo nl2br(htmlspecialchars($klient['notatka_kontakt'])); ?>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Statystyki audytu -->
                            <?php if (!empty($klient['audyt_status'])): ?>
                            <h3 style="margin-top: 25px;">🔍 Audyt danych</h3>
                            <div style="background: <?php echo $klient['audyt_status'] === 'ok' ? '#dcfce7' : ($klient['audyt_status'] === 'error' ? '#fee2e2' : '#f1f5f9'); ?>; padding: 15px; border-radius: 8px;">
                                <div style="font-weight: 500; margin-bottom: 5px;">
                                    <?php if ($klient['audyt_status'] === 'ok'): ?>
                                        ✅ Dane zweryfikowane
                                    <?php elseif ($klient['audyt_status'] === 'error'): ?>
                                        ❌ Wykryto problem
                                    <?php else: ?>
                                        ⚠️ Wymaga uwagi
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($klient['audyt_nazwa_gus'])): ?>
                                <div style="font-size: 0.85rem; color: #64748b;">
                                    Nazwa w GUS: <?php echo htmlspecialchars($klient['audyt_nazwa_gus']); ?>
                                </div>
                                <?php endif; ?>
                                <?php if (!empty($klient['audyt_problemy'])): ?>
                                <div style="font-size: 0.85rem; color: #dc2626; margin-top: 5px;">
                                    <?php echo htmlspecialchars($klient['audyt_problemy']); ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            
                            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0;">
                                <button onclick="deleteKlient(<?php echo $id; ?>)" class="btn btn-danger" style="background: #fee2e2; color: #dc2626; border: none;">
                                    🗑️ Usuń klienta
                                </button>
                            </div>
                        </div>
                    </div>
                
                <?php elseif ($tab === 'osoby'): ?>
                    <!-- OSOBY KONTAKTOWE -->
                    <div class="section-header">
                        <h3>👥 Osoby kontaktowe</h3>
                        <button class="btn btn-primary" onclick="showModal('modal-osoba')">+ Dodaj osobę</button>
                    </div>
                    
                    <?php if (empty($osoby)): ?>
                        <div class="empty-state">
                            <div class="icon">👤</div>
                            <p>Brak osób kontaktowych. Dodaj pierwszą osobę.</p>
                        </div>
                    <?php else: ?>
                        <div class="contact-grid">
                            <?php foreach ($osoby as $osoba): ?>
                            <div class="contact-card">
                                <div class="contact-avatar">
                                    <?php echo mb_strtoupper(mb_substr($osoba['imie'], 0, 1) . mb_substr($osoba['nazwisko'], 0, 1)); ?>
                                </div>
                                <div class="contact-info">
                                    <h4>
                                        <?php echo htmlspecialchars($osoba['imie'] . ' ' . $osoba['nazwisko']); ?>
                                        <?php if ($osoba['glowny_kontakt']): ?><span class="badge" style="background: #dcfce7; color: #166534; font-size: 0.7rem; margin-left: 5px;">Główny</span><?php endif; ?>
                                    </h4>
                                    <?php if ($osoba['stanowisko']): ?>
                                        <div class="position"><?php echo htmlspecialchars($osoba['stanowisko']); ?></div>
                                    <?php endif; ?>
                                    <div class="contact-details">
                                        <?php if ($osoba['telefon']): ?><div>📞 <a href="tel:<?php echo $osoba['telefon']; ?>"><?php echo htmlspecialchars($osoba['telefon']); ?></a></div><?php endif; ?>
                                        <?php if ($osoba['email']): ?><div>✉️ <a href="mailto:<?php echo $osoba['email']; ?>"><?php echo htmlspecialchars($osoba['email']); ?></a></div><?php endif; ?>
                                        <?php if ($osoba['linkedin_url']): ?><div><a href="<?php echo htmlspecialchars($osoba['linkedin_url']); ?>" target="_blank" class="linkedin-badge">🔗 LinkedIn</a></div><?php endif; ?>
                                    </div>
                                </div>
                                <div class="contact-actions">
                                    <button class="btn btn-sm" onclick='editOsoba(<?php echo json_encode($osoba); ?>)'>✏️</button>
                                    <button class="btn btn-sm" onclick="deleteOsoba(<?php echo $osoba['id']; ?>)">🗑️</button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                
                <?php elseif ($tab === 'zadania'): ?>
                    <!-- ZADANIA -->
                    <div class="section-header">
                        <h3>✅ Zadania</h3>
                        <button class="btn btn-primary" onclick="showModal('modal-zadanie')">+ Nowe zadanie</button>
                    </div>
                    
                    <?php if (empty($zadania)): ?>
                        <div class="empty-state">
                            <div class="icon">📝</div>
                            <p>Brak zadań. Zaplanuj pierwsze działanie dla tego klienta.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($zadania as $z): 
                            $isOverdue = $z['status'] !== 'zakonczone' && $z['termin_data'] && $z['termin_data'] < date('Y-m-d');
                            $typ = $typyZadan[$z['typ']] ?? 'Zadanie';
                            $statusZ = $statusyZadan[$z['status']] ?? $statusyZadan['nowe'];
                        ?>
                        <div class="task-item <?php echo $z['status'] === 'zakonczone' ? 'completed' : ''; ?>">
                            <input type="checkbox" class="task-checkbox" <?php echo $z['status'] === 'zakonczone' ? 'checked' : ''; ?> onchange="completeTask(<?php echo $z['id']; ?>)">
                            <div class="task-content">
                                <h4><?php echo htmlspecialchars($z['tytul']); ?></h4>
                                <?php if ($z['opis']): ?><p style="font-size: 0.9rem; color: #64748b; margin: 5px 0;"><?php echo nl2br(htmlspecialchars($z['opis'])); ?></p><?php endif; ?>
                                <div class="task-meta">
                                    <span class="badge" style="background: <?php echo $statusZ['bg']; ?>; color: <?php echo $statusZ['color']; ?>;"><?php echo $statusZ['label']; ?></span>
                                    <span><?php echo $typ; ?></span>
                                    <?php if ($z['termin_data']): ?><span class="<?php echo $isOverdue ? 'task-overdue' : ''; ?>">📅 <?php echo date('d.m.Y', strtotime($z['termin_data'])); ?><?php if ($z['termin_godzina']): ?> <?php echo substr($z['termin_godzina'], 0, 5); ?><?php endif; ?></span><?php endif; ?>
                                    <?php if ($z['przypisany_nazwa']): ?><span>👤 <?php echo htmlspecialchars($z['przypisany_nazwa']); ?></span><?php endif; ?>
                                </div>
                            </div>
                            <div style="display: flex; gap: 5px;">
                                <button class="btn btn-sm" onclick='editZadanie(<?php echo json_encode($z); ?>)'>✏️</button>
                                <button class="btn btn-sm" onclick="deleteZadanie(<?php echo $z['id']; ?>)">🗑️</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                
                <?php elseif ($tab === 'pliki'): ?>
                    <!-- PLIKI -->
                    <div class="section-header">
                        <h3>📁 Pliki</h3>
                    </div>
                    
                    <form action="api/plik_upload.php" method="POST" enctype="multipart/form-data" id="upload-form">
                        <input type="hidden" name="klient_id" value="<?php echo $id; ?>">
                        <div class="dropzone" id="dropzone" onclick="document.getElementById('file-input').click()">
                            <p>📤 Przeciągnij pliki tutaj lub kliknij aby wybrać</p>
                            <input type="file" name="plik" id="file-input" style="display: none;" onchange="this.form.submit()">
                        </div>
                    </form>
                    
                    <?php if (empty($pliki)): ?>
                        <div class="empty-state">
                            <div class="icon">📄</div>
                            <p>Brak plików</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($pliki as $p): 
                            $ext = strtolower(pathinfo($p['nazwa'], PATHINFO_EXTENSION));
                            $icons = ['pdf' => '📕', 'doc' => '📘', 'docx' => '📘', 'xls' => '📗', 'xlsx' => '📗', 'jpg' => '🖼️', 'jpeg' => '🖼️', 'png' => '🖼️'];
                            $icon = $icons[$ext] ?? '📄';
                        ?>
                        <div class="file-item">
                            <div class="file-icon"><?php echo $icon; ?></div>
                            <div class="file-info">
                                <div class="file-name"><a href="../data/uploads/crm/<?php echo $p['sciezka']; ?>" target="_blank"><?php echo htmlspecialchars($p['nazwa']); ?></a></div>
                                <div class="file-meta"><?php echo date('d.m.Y H:i', strtotime($p['created_at'])); ?><?php if ($p['uploaded_by_name']): ?> · <?php echo htmlspecialchars($p['uploaded_by_name']); ?><?php endif; ?></div>
                            </div>
                            <button class="btn btn-sm" onclick="deletePlik(<?php echo $p['id']; ?>)">🗑️</button>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                
                <?php endif; ?>
                
            </div>
        </div>
    </div>
    
    <!-- MODAL: Osoba -->
    <div class="modal-backdrop" id="modal-osoba">
        <div class="modal">
            <div class="modal-header">
                <h3 id="modal-osoba-title">Dodaj osobę kontaktową</h3>
                <button class="modal-close" onclick="hideModal('modal-osoba')">&times;</button>
            </div>
            <form action="api/osoba_save.php" method="POST">
                <input type="hidden" name="klient_id" value="<?php echo $id; ?>">
                <input type="hidden" name="osoba_id" id="osoba_id" value="">
                <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group"><label>Imię *</label><input type="text" name="imie" id="osoba_imie" required></div>
                        <div class="form-group"><label>Nazwisko *</label><input type="text" name="nazwisko" id="osoba_nazwisko" required></div>
                    </div>
                    <div class="form-group"><label>Stanowisko</label><input type="text" name="stanowisko" id="osoba_stanowisko"></div>
                    <div class="form-row">
                        <div class="form-group"><label>Telefon</label><input type="text" name="telefon" id="osoba_telefon"></div>
                        <div class="form-group"><label>E-mail</label><input type="email" name="email" id="osoba_email"></div>
                    </div>
                    <div class="form-group"><label>LinkedIn URL</label><input type="url" name="linkedin_url" id="osoba_linkedin" placeholder="https://linkedin.com/in/..."></div>
                    <div class="form-group"><label><input type="checkbox" name="glowny_kontakt" id="osoba_glowny" value="1"> Główny kontakt</label></div>
                    <div class="form-group"><label>Uwagi</label><textarea name="uwagi" id="osoba_uwagi" rows="2"></textarea></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="hideModal('modal-osoba')">Anuluj</button>
                    <button type="submit" class="btn btn-primary">Zapisz</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- MODAL: Zadanie -->
    <div class="modal-backdrop" id="modal-zadanie">
        <div class="modal">
            <div class="modal-header">
                <h3 id="modal-zadanie-title">Dodaj zadanie</h3>
                <button class="modal-close" onclick="hideModal('modal-zadanie')">&times;</button>
            </div>
            <form action="api/zadanie_save.php" method="POST">
                <input type="hidden" name="klient_id" value="<?php echo $id; ?>">
                <input type="hidden" name="zadanie_id" id="zadanie_id" value="">
                <div class="modal-body">
                    <div class="form-group"><label>Tytuł *</label><input type="text" name="tytul" id="zadanie_tytul" required></div>
                    <div class="form-group"><label>Opis</label><textarea name="opis" id="zadanie_opis" rows="3"></textarea></div>
                    <div class="form-row">
                        <div class="form-group"><label>Typ</label><select name="typ" id="zadanie_typ">
                            <?php foreach ($typyZadan as $key => $label): ?><option value="<?php echo $key; ?>"><?php echo $label; ?></option><?php endforeach; ?>
                        </select></div>
                        <div class="form-group"><label>Priorytet</label><select name="priorytet" id="zadanie_priorytet">
                            <?php foreach ($crmPriorytety as $key => $p): ?><option value="<?php echo $key; ?>"><?php echo $p['label']; ?></option><?php endforeach; ?>
                        </select></div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label>Termin (data)</label><input type="date" name="termin_data" id="zadanie_termin_data"></div>
                        <div class="form-group"><label>Godzina</label><input type="time" name="termin_godzina" id="zadanie_termin_godzina"></div>
                    </div>
                    <div class="form-group"><label>Przypisz do</label><select name="przypisany_do" id="zadanie_przypisany">
                        <option value="">-- nieprzypisane --</option>
                        <?php foreach ($users as $u): ?><option value="<?php echo $u['id']; ?>" <?php echo $u['id'] == $currentUser['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($u['name']); ?></option><?php endforeach; ?>
                    </select></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="hideModal('modal-zadanie')">Anuluj</button>
                    <button type="submit" class="btn btn-primary">Zapisz</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    const klientId = <?php echo $id; ?>;
    
    function showModal(id) { document.getElementById(id).classList.add('active'); }
    function hideModal(id) { 
        document.getElementById(id).classList.remove('active');
        if (id === 'modal-osoba') {
            document.getElementById('osoba_id').value = '';
            document.getElementById('osoba_imie').value = '';
            document.getElementById('osoba_nazwisko').value = '';
            document.getElementById('osoba_stanowisko').value = '';
            document.getElementById('osoba_telefon').value = '';
            document.getElementById('osoba_email').value = '';
            document.getElementById('osoba_linkedin').value = '';
            document.getElementById('osoba_glowny').checked = false;
            document.getElementById('osoba_uwagi').value = '';
            document.getElementById('modal-osoba-title').textContent = 'Dodaj osobę kontaktową';
        }
        if (id === 'modal-zadanie') {
            document.getElementById('zadanie_id').value = '';
            document.getElementById('zadanie_tytul').value = '';
            document.getElementById('zadanie_opis').value = '';
            document.getElementById('zadanie_typ').value = 'zadanie';
            document.getElementById('zadanie_priorytet').value = 'normalny';
            document.getElementById('zadanie_termin_data').value = '';
            document.getElementById('zadanie_termin_godzina').value = '';
            document.getElementById('modal-zadanie-title').textContent = 'Dodaj zadanie';
        }
    }
    
    function editOsoba(o) {
        document.getElementById('osoba_id').value = o.id;
        document.getElementById('osoba_imie').value = o.imie || '';
        document.getElementById('osoba_nazwisko').value = o.nazwisko || '';
        document.getElementById('osoba_stanowisko').value = o.stanowisko || '';
        document.getElementById('osoba_telefon').value = o.telefon || '';
        document.getElementById('osoba_email').value = o.email || '';
        document.getElementById('osoba_linkedin').value = o.linkedin_url || '';
        document.getElementById('osoba_glowny').checked = o.glowny_kontakt == 1;
        document.getElementById('osoba_uwagi').value = o.uwagi || '';
        document.getElementById('modal-osoba-title').textContent = 'Edytuj osobę';
        showModal('modal-osoba');
    }
    
    function deleteOsoba(id) {
        if (confirm('Usunąć tę osobę kontaktową?')) {
            fetch('api/osoba_delete.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: id}) }).then(() => location.reload());
        }
    }
    
    function editZadanie(z) {
        document.getElementById('zadanie_id').value = z.id;
        document.getElementById('zadanie_tytul').value = z.tytul || '';
        document.getElementById('zadanie_opis').value = z.opis || '';
        document.getElementById('zadanie_typ').value = z.typ || 'zadanie';
        document.getElementById('zadanie_priorytet').value = z.priorytet || 'normalny';
        document.getElementById('zadanie_termin_data').value = z.termin_data || '';
        document.getElementById('zadanie_termin_godzina').value = z.termin_godzina || '';
        document.getElementById('zadanie_przypisany').value = z.przypisany_do || '';
        document.getElementById('modal-zadanie-title').textContent = 'Edytuj zadanie';
        showModal('modal-zadanie');
    }
    
    function completeTask(id) {
        fetch('api/zadanie_complete.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: id}) }).then(() => location.reload());
    }
    
    function deleteZadanie(id) {
        if (confirm('Usunąć to zadanie?')) {
            fetch('api/zadanie_delete.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: id}) }).then(() => location.reload());
        }
    }
    
    function deletePlik(id) {
        if (confirm('Usunąć ten plik?')) {
            fetch('api/plik_delete.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: id}) }).then(() => location.reload());
        }
    }
    
    function deleteKlient(id) {
        if (confirm('UWAGA: Usunięcie klienta usunie wszystkie powiązane dane. Kontynuować?')) {
            fetch('api/klient_delete.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: id}) }).then(r => r.json()).then(d => { if (d.success) window.location.href = 'klienci.php'; });
        }
    }
    
    // Drag & drop
    const dropzone = document.getElementById('dropzone');
    if (dropzone) {
        dropzone.addEventListener('dragover', e => { e.preventDefault(); dropzone.classList.add('dragover'); });
        dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
        dropzone.addEventListener('drop', e => {
            e.preventDefault(); dropzone.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                document.getElementById('file-input').files = e.dataTransfer.files;
                document.getElementById('upload-form').submit();
            }
        });
    }
    
    // Zamknij modal kliknięciem w tło
    document.querySelectorAll('.modal-backdrop').forEach(m => m.addEventListener('click', e => { if (e.target === m) m.classList.remove('active'); }));
    </script>
</body>
</html>
