<?php
/**
 * CompanyEnricher - Narzędzie do wzbogacania danych firm
 * Integracja z kadry.work-land.pl
 * 
 * Źródła danych:
 * - rejestr.io (scraping) - dla spółek z KRS
 * - CEIDG API - dla JDG i spółek cywilnych
 */

class CompanyEnricher
{
    private $pdo;
    private $ceidgApiKey;
    private $delay = 2; // sekundy między requestami
    private $timeout = 15;
    
    // Formy prawne w KRS
    private $krsLegalForms = [
        'spółki z ograniczoną odpowiedzialnością',
        'spółki akcyjne',
        'spółki komandytowe',
        'spółki jawne',
        'spółki komandytowo-akcyjne',
        'proste spółki akcyjne'
    ];
    
    // Formy prawne w CEIDG
    private $ceidgLegalForms = [
        'osoby fizyczne prowadzące działalność gospodarczą',
        'spółki cywilne prowadzące działalność na podstawie umowy zawartej zgodnie z Kodeksem cywilnym'
    ];

    public function __construct(?PDO $pdo = null, ?string $ceidgApiKey = null)
    {
        $this->pdo = $pdo;
        $this->ceidgApiKey = $ceidgApiKey;
    }
    
    /**
     * Wzbogacanie pojedynczej firmy
     */
    public function enrichCompany(string $companyName, string $legalForm): array
    {
        $result = [
            'nazwa' => $companyName,
            'forma_prawna' => $legalForm,
            'adres' => null,
            'www' => null,
            'email' => null,
            'telefon' => null,
            'nip' => null,
            'regon' => null,
            'krs' => null,
            'zarzad' => null,
            'zrodlo' => null,
            'status' => 'pending',
            'error' => null
        ];
        
        try {
            if (in_array($legalForm, $this->krsLegalForms)) {
                $result = $this->enrichFromKRS($companyName, $result);
            } elseif (in_array($legalForm, $this->ceidgLegalForms)) {
                $result = $this->enrichFromCEIDG($companyName, $result);
            } else {
                // Próbuj najpierw KRS, potem CEIDG
                $result = $this->enrichFromKRS($companyName, $result);
                if ($result['status'] !== 'success') {
                    $result = $this->enrichFromCEIDG($companyName, $result);
                }
            }
        } catch (Exception $e) {
            $result['status'] = 'error';
            $result['error'] = $e->getMessage();
        }
        
        return $result;
    }
    
    /**
     * Scraping rejestr.io
     */
    private function enrichFromKRS(string $companyName, array $result): array
    {
        // Normalizuj nazwę do wyszukiwania
        $searchName = $this->normalizeCompanyName($companyName);
        $searchUrl = 'https://rejestr.io/szukaj?q=' . urlencode($searchName);
        
        // Pobierz stronę wyników wyszukiwania
        $html = $this->fetchUrl($searchUrl);
        if (!$html) {
            $result['status'] = 'not_found';
            $result['error'] = 'Nie można pobrać wyników wyszukiwania';
            return $result;
        }
        
        // Znajdź link do pierwszego wyniku
        if (preg_match('/<a[^>]+href="(\/krs\/\d+\/[^"]+)"[^>]*>/i', $html, $matches)) {
            $detailUrl = 'https://rejestr.io' . $matches[1];
            
            sleep($this->delay); // Opóźnienie między requestami
            
            $detailHtml = $this->fetchUrl($detailUrl);
            if ($detailHtml) {
                $result = $this->parseRejestrIoPage($detailHtml, $result);
                $result['zrodlo'] = 'rejestr.io';
            }
        } else {
            $result['status'] = 'not_found';
            $result['error'] = 'Nie znaleziono firmy w rejestr.io';
        }
        
        return $result;
    }
    
    /**
     * Parsowanie strony rejestr.io
     */
    private function parseRejestrIoPage(string $html, array $result): array
    {
        // NIP
        if (preg_match('/NIP[^<]*<[^>]*>(\d{10})/i', $html, $m)) {
            $result['nip'] = $m[1];
        }
        
        // REGON
        if (preg_match('/REGON[^<]*<[^>]*>(\d{9,14})/i', $html, $m)) {
            $result['regon'] = $m[1];
        }
        
        // KRS
        if (preg_match('/KRS[^<]*<[^>]*>(\d{10})/i', $html, $m)) {
            $result['krs'] = $m[1];
        }
        
        // Adres siedziby
        if (preg_match('/Adres siedziby[^<]*<[^>]*>([^<]+)/i', $html, $m)) {
            $result['adres'] = trim(strip_tags($m[1]));
        }
        
        // Alternatywny pattern dla adresu
        if (!$result['adres'] && preg_match('/<dd[^>]*>([^<]*\d{2}-\d{3}[^<]*)<\/dd>/i', $html, $m)) {
            $result['adres'] = trim($m[1]);
        }
        
        // Zarząd - szukamy członków zarządu
        $zarzad = [];
        if (preg_match_all('/(PREZES ZARZĄDU|CZŁONEK ZARZĄDU|WICEPREZES)[^<]*<[^>]*>([^<]+)/i', $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $m) {
                $funkcja = trim($m[1]);
                $osoba = trim($m[2]);
                if ($osoba && !in_array($osoba, ['Zobacz', 'więcej'])) {
                    $zarzad[] = "$funkcja: $osoba";
                }
            }
        }
        
        // Alternatywny pattern - lista osób
        if (empty($zarzad) && preg_match_all('/<td[^>]*>([A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+ [A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+)<\/td>/u', $html, $matches)) {
            $zarzad = array_slice(array_unique($matches[1]), 0, 5);
        }
        
        if (!empty($zarzad)) {
            $result['zarzad'] = implode('; ', array_unique($zarzad));
        }
        
        // WWW i email - często nie ma w rejestr.io, ale spróbujmy
        if (preg_match('/www[^<]*<[^>]*href="([^"]+)"/i', $html, $m)) {
            $result['www'] = $m[1];
        }
        
        if (preg_match('/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/i', $html, $m)) {
            $result['email'] = $m[1];
        }
        
        $result['status'] = $result['nip'] || $result['adres'] ? 'success' : 'partial';
        
        return $result;
    }
    
    /**
     * CEIDG API
     */
    private function enrichFromCEIDG(string $companyName, array $result): array
    {
        if (!$this->ceidgApiKey) {
            $result['status'] = 'error';
            $result['error'] = 'Brak klucza API CEIDG';
            return $result;
        }
        
        // Wyszukaj po nazwie firmy
        $searchName = $this->normalizeCompanyName($companyName);
        $url = 'https://dane.biznes.gov.pl/api/ceidg/v2/firmy?nazwa=' . urlencode($searchName);
        
        $response = $this->fetchUrl($url, [
            'Authorization: Bearer ' . $this->ceidgApiKey,
            'Accept: application/json'
        ]);
        
        if (!$response) {
            $result['status'] = 'not_found';
            $result['error'] = 'Nie można połączyć z CEIDG API';
            return $result;
        }
        
        $data = json_decode($response, true);
        
        if (!empty($data['firmy'][0])) {
            $firma = $data['firmy'][0];
            
            $result['nip'] = $firma['wlasciciel']['nip'] ?? null;
            $result['regon'] = $firma['wlasciciel']['regon'] ?? null;
            
            // Adres
            if (!empty($firma['adresDzialalnosci'])) {
                $adr = $firma['adresDzialalnosci'];
                $parts = array_filter([
                    $adr['ulica'] ?? null,
                    $adr['budynek'] ?? null,
                    $adr['lokal'] ?? null,
                    $adr['kod'] ?? null,
                    $adr['miasto'] ?? null
                ]);
                $result['adres'] = implode(' ', $parts);
            }
            
            // Kontakt
            $result['email'] = $firma['email'] ?? null;
            $result['telefon'] = $firma['telefon'] ?? null;
            $result['www'] = $firma['www'] ?? null;
            
            // Właściciel
            if (!empty($firma['wlasciciel'])) {
                $wl = $firma['wlasciciel'];
                $result['zarzad'] = trim(($wl['imie'] ?? '') . ' ' . ($wl['nazwisko'] ?? ''));
            }
            
            $result['zrodlo'] = 'CEIDG';
            $result['status'] = 'success';
        } else {
            $result['status'] = 'not_found';
            $result['error'] = 'Nie znaleziono w CEIDG';
        }
        
        return $result;
    }
    
    /**
     * Normalizacja nazwy firmy do wyszukiwania
     */
    private function normalizeCompanyName(string $name): string
    {
        // Usuń typowe przyrostki
        $name = preg_replace('/\s+(sp\.?\s*z\s*o\.?\s*o\.?|sp\.?\s*j\.?|s\.?\s*a\.?|sp\.?\s*k\.?|s\.?\s*c\.?)$/iu', '', $name);
        // Usuń cudzysłowy
        $name = str_replace(['"', '„', '"', '«', '»'], '', $name);
        // Usuń "w upadłości", "w likwidacji" itp.
        $name = preg_replace('/\s+(w\s+upadłości|w\s+likwidacji|w\s+restrukturyzacji)$/iu', '', $name);
        
        return trim($name);
    }
    
    /**
     * Pobieranie URL z cURL
     */
    private function fetchUrl(string $url, array $headers = []): ?string
    {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        if (!empty($headers)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        }
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return ($httpCode >= 200 && $httpCode < 300) ? $response : null;
    }
    
    /**
     * Przetwarzanie partiami z pliku CSV/Excel
     */
    public function processBatch(array $companies, int $offset = 0, int $limit = 20): array
    {
        $results = [];
        $processed = 0;
        
        $batch = array_slice($companies, $offset, $limit);
        
        foreach ($batch as $index => $company) {
            $companyName = $company['nazwa'] ?? $company['Firma (nazwa)'] ?? '';
            $legalForm = $company['forma_prawna'] ?? $company['Forma prawna'] ?? '';
            
            if (empty($companyName)) continue;
            
            $result = $this->enrichCompany($companyName, $legalForm);
            $result['original_index'] = $offset + $index;
            $results[] = $result;
            $processed++;
            
            // Delay między requestami
            if ($processed < count($batch)) {
                sleep($this->delay);
            }
        }
        
        return [
            'results' => $results,
            'processed' => $processed,
            'offset' => $offset,
            'next_offset' => $offset + $processed,
            'total' => count($companies),
            'remaining' => max(0, count($companies) - $offset - $processed)
        ];
    }
    
    /**
     * Zapis wyników do CSV
     */
    public function saveToCSV(array $results, string $filepath, bool $append = false): bool
    {
        $mode = $append ? 'a' : 'w';
        $fp = fopen($filepath, $mode);
        
        if (!$fp) return false;
        
        // Nagłówki tylko przy nowym pliku
        if (!$append) {
            fputcsv($fp, [
                'Firma (nazwa)', 'Forma prawna', 'Adres', 'WWW', 'Email', 
                'Telefon', 'NIP', 'REGON', 'KRS', 'Zarząd/Dyrekcja', 
                'Źródło', 'Status', 'Błąd'
            ], ';');
        }
        
        foreach ($results as $r) {
            fputcsv($fp, [
                $r['nazwa'],
                $r['forma_prawna'],
                $r['adres'],
                $r['www'],
                $r['email'],
                $r['telefon'],
                $r['nip'],
                $r['regon'],
                $r['krs'],
                $r['zarzad'],
                $r['zrodlo'],
                $r['status'],
                $r['error']
            ], ';');
        }
        
        fclose($fp);
        return true;
    }
    
    /**
     * Zapis do bazy danych
     */
    public function saveToDatabase(array $results, string $tableName = 'enriched_companies'): int
    {
        if (!$this->pdo) {
            throw new Exception('Brak połączenia z bazą danych');
        }
        
        $sql = "INSERT INTO {$tableName} 
                (nazwa, forma_prawna, adres, www, email, telefon, nip, regon, krs, zarzad, zrodlo, status, error, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
                ON DUPLICATE KEY UPDATE 
                adres = VALUES(adres), www = VALUES(www), email = VALUES(email),
                telefon = VALUES(telefon), nip = VALUES(nip), regon = VALUES(regon),
                krs = VALUES(krs), zarzad = VALUES(zarzad), zrodlo = VALUES(zrodlo),
                status = VALUES(status), error = VALUES(error), updated_at = NOW()";
        
        $stmt = $this->pdo->prepare($sql);
        $saved = 0;
        
        foreach ($results as $r) {
            $stmt->execute([
                $r['nazwa'], $r['forma_prawna'], $r['adres'], $r['www'],
                $r['email'], $r['telefon'], $r['nip'], $r['regon'],
                $r['krs'], $r['zarzad'], $r['zrodlo'], $r['status'], $r['error']
            ]);
            $saved++;
        }
        
        return $saved;
    }
    
    // Settery
    public function setDelay(int $seconds): void { $this->delay = $seconds; }
    public function setTimeout(int $seconds): void { $this->timeout = $seconds; }
    public function setCeidgApiKey(string $key): void { $this->ceidgApiKey = $key; }
}
