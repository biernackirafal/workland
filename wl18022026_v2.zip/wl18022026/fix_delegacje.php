<?php
/**
 * FIX DELEGACJE - przywracanie danych delegacji
 * Uruchom przez przeglądarkę: http://twoja-strona/fix_delegacje.php
 */

require_once 'includes/db.php';

// Sprawdź czy użytkownik jest zalogowany jako admin
session_start();
if (!isset($_SESSION['user_id'])) {
    die('Musisz być zalogowany. <a href="login.php">Zaloguj się</a>');
}

$message = '';
$messageType = '';

if (isset($_POST['action'])) {
    $action = $_POST['action'];
    
    try {
        $db->beginTransaction();
        
        if ($action === 'restore_lokalizacje') {
            // Przywróć lokalizacje
            $sql = "INSERT OR REPLACE INTO delegacje_lokalizacje (id, nazwa, km_od_bazy, active, created_at) VALUES 
                (1, 'Czeladź', 410, 1, '2026-01-17 18:13:29'),
                (2, 'Gdańsk', 320, 1, '2026-01-17 18:13:29'),
                (3, 'Nysa', 264, 1, '2026-01-17 18:13:29'),
                (4, 'Rzeszów', 620, 1, '2026-01-17 18:13:29'),
                (5, 'Warszawa', 320, 1, '2026-01-17 18:13:29'),
                (6, 'Berlin-Poczdam', 350, 1, '2026-01-19 15:09:44')";
            $db->exec($sql);
            $message = "✅ Przywrócono 6 lokalizacji delegacji!";
            $messageType = 'success';
        }
        
        if ($action === 'restore_all') {
            // Przywróć lokalizacje
            $db->exec("INSERT OR REPLACE INTO delegacje_lokalizacje (id, nazwa, km_od_bazy, active, created_at) VALUES 
                (1, 'Czeladź', 410, 1, '2026-01-17 18:13:29'),
                (2, 'Gdańsk', 320, 1, '2026-01-17 18:13:29'),
                (3, 'Nysa', 264, 1, '2026-01-17 18:13:29'),
                (4, 'Rzeszów', 620, 1, '2026-01-17 18:13:29'),
                (5, 'Warszawa', 320, 1, '2026-01-17 18:13:29'),
                (6, 'Berlin-Poczdam', 350, 1, '2026-01-19 15:09:44')");
            
            // Przywróć delegację
            $db->exec("INSERT OR REPLACE INTO delegacje (id, nr_delegacji, pracownik_id, miesiac, rok, lokalizacja_id, cel_wyjazdu, transport_samochod, data_zlecenia, typ_delegacji, kurs_eur, dieta_kraj, dieta_stawka, stawka_km, noclegi_stawka, inne_wydatki, zaliczka, status, created_by, created_at, updated_at) VALUES 
                (2, '01/2025', 40, 1, 2025, 6, 'Praca - Administracja', 1, '2025-01-01', 'zagraniczna', '[{\"data_wyjazdu\":\"2026-01-12\",\"kurs\":4.2097,\"data_kursu\":\"2026-01-12\"},{\"data_wyjazdu\":\"2026-01-19\",\"kurs\":4.2231,\"data_kursu\":\"2026-01-19\"},{\"data_wyjazdu\":\"2026-01-26\",\"kurs\":4.2118,\"data_kursu\":\"2026-01-26\"}]', 'Niemcy', 49, 1.15, 170, 0, 0, 'draft', 6, '2026-02-09 15:27:19', '2026-02-09 15:27:19')");
            
            // Przywróć zakresy dat
            $db->exec("INSERT OR REPLACE INTO delegacje_zakresy (id, delegacja_id, data_od, data_do, created_at) VALUES 
                (1, 1, '2026-01-05', '2026-01-08', '2026-01-29 17:33:10'),
                (2, 1, '2026-01-12', '2026-01-14', '2026-01-29 17:33:11'),
                (3, 1, '2026-01-26', '2026-01-28', '2026-01-29 17:33:11'),
                (4, 2, '2026-01-12', '2026-01-14', '2026-02-09 15:27:19'),
                (5, 2, '2026-01-19', '2026-01-22', '2026-02-09 15:27:19'),
                (6, 2, '2026-01-26', '2026-01-29', '2026-02-09 15:27:19')");
            
            $message = "✅ Przywrócono wszystkie dane delegacji (lokalizacje, delegacje, zakresy)!";
            $messageType = 'success';
        }
        
        if ($action === 'create_tables') {
            // Utwórz tabele jeśli nie istnieją
            $db->exec("CREATE TABLE IF NOT EXISTS delegacje_lokalizacje (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nazwa VARCHAR(100) NOT NULL,
                km_od_bazy INTEGER DEFAULT 0,
                active INTEGER DEFAULT 1,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
            
            $db->exec("CREATE TABLE IF NOT EXISTS delegacje (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nr_delegacji VARCHAR(20),
                pracownik_id INTEGER,
                miesiac INTEGER,
                rok INTEGER,
                lokalizacja_id INTEGER,
                cel_wyjazdu TEXT,
                transport_samochod INTEGER DEFAULT 0,
                data_zlecenia DATE,
                typ_delegacji VARCHAR(20) DEFAULT 'krajowa',
                kurs_eur DECIMAL(10,4),
                dieta_kraj VARCHAR(50),
                dieta_stawka DECIMAL(10,2),
                stawka_km DECIMAL(10,2) DEFAULT 1.15,
                noclegi_stawka DECIMAL(10,2),
                inne_wydatki DECIMAL(10,2) DEFAULT 0,
                zaliczka DECIMAL(10,2) DEFAULT 0,
                status VARCHAR(20) DEFAULT 'draft',
                created_by INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )");
            
            $db->exec("CREATE TABLE IF NOT EXISTS delegacje_zakresy (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                delegacja_id INTEGER,
                data_od DATE,
                data_do DATE,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (delegacja_id) REFERENCES delegacje(id) ON DELETE CASCADE
            )");
            
            $message = "✅ Utworzono tabele delegacji!";
            $messageType = 'success';
        }
        
        $db->commit();
    } catch (Exception $e) {
        $db->rollBack();
        $message = "❌ Błąd: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Pobierz statystyki
$stats = [];
try {
    $stats['lokalizacje'] = $db->query("SELECT COUNT(*) FROM delegacje_lokalizacje")->fetchColumn();
} catch (Exception $e) {
    $stats['lokalizacje'] = 'BRAK TABELI';
}
try {
    $stats['delegacje'] = $db->query("SELECT COUNT(*) FROM delegacje")->fetchColumn();
} catch (Exception $e) {
    $stats['delegacje'] = 'BRAK TABELI';
}
try {
    $stats['zakresy'] = $db->query("SELECT COUNT(*) FROM delegacje_zakresy")->fetchColumn();
} catch (Exception $e) {
    $stats['zakresy'] = 'BRAK TABELI';
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Delegacje - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .fix-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
        }
        .fix-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .fix-card h2 {
            margin-top: 0;
            color: #1e40af;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
            margin: 20px 0;
        }
        .stat-box {
            background: #f0f9ff;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-box .number {
            font-size: 2rem;
            font-weight: 700;
            color: #1e40af;
        }
        .stat-box .label {
            color: #64748b;
            font-size: 0.9rem;
        }
        .stat-box.error {
            background: #fef2f2;
        }
        .stat-box.error .number {
            color: #dc2626;
            font-size: 1rem;
        }
        .btn-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
        }
        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            transition: all 0.2s;
        }
        .btn-primary {
            background: #059669;
            color: white;
        }
        .btn-primary:hover {
            background: #047857;
        }
        .btn-warning {
            background: #f59e0b;
            color: white;
        }
        .btn-warning:hover {
            background: #d97706;
        }
        .btn-info {
            background: #3b82f6;
            color: white;
        }
        .btn-info:hover {
            background: #2563eb;
        }
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .alert.success {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #86efac;
        }
        .alert.error {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fca5a5;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #3b82f6;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="fix-container">
        <a href="delegacje/" class="back-link">← Powrót do delegacji</a>
        
        <div class="fix-card">
            <h2>🔧 Fix Delegacje</h2>
            <p>Narzędzie do przywracania danych delegacji z backupu z dnia 09.02.2026</p>
            
            <?php if ($message): ?>
                <div class="alert <?= $messageType ?>"><?= $message ?></div>
            <?php endif; ?>
            
            <h3>📊 Aktualny stan bazy:</h3>
            <div class="stats-grid">
                <div class="stat-box <?= is_numeric($stats['lokalizacje']) ? '' : 'error' ?>">
                    <div class="number"><?= $stats['lokalizacje'] ?></div>
                    <div class="label">Lokalizacje</div>
                </div>
                <div class="stat-box <?= is_numeric($stats['delegacje']) ? '' : 'error' ?>">
                    <div class="number"><?= $stats['delegacje'] ?></div>
                    <div class="label">Delegacje</div>
                </div>
                <div class="stat-box <?= is_numeric($stats['zakresy']) ? '' : 'error' ?>">
                    <div class="number"><?= $stats['zakresy'] ?></div>
                    <div class="label">Zakresy dat</div>
                </div>
            </div>
            
            <h3>🛠️ Akcje naprawcze:</h3>
            <div class="btn-group">
                <form method="post" style="display: inline;">
                    <input type="hidden" name="action" value="create_tables">
                    <button type="submit" class="btn btn-info" onclick="return confirm('Utworzyć tabele delegacji?')">
                        📋 Utwórz tabele
                    </button>
                </form>
                
                <form method="post" style="display: inline;">
                    <input type="hidden" name="action" value="restore_lokalizacje">
                    <button type="submit" class="btn btn-warning" onclick="return confirm('Przywrócić lokalizacje?')">
                        📍 Przywróć lokalizacje
                    </button>
                </form>
                
                <form method="post" style="display: inline;">
                    <input type="hidden" name="action" value="restore_all">
                    <button type="submit" class="btn btn-primary" onclick="return confirm('Przywrócić WSZYSTKIE dane delegacji (lokalizacje + delegacje + zakresy)?')">
                        ✅ Przywróć wszystko
                    </button>
                </form>
            </div>
            
            <div style="margin-top: 30px; padding: 15px; background: #fef3c7; border-radius: 8px;">
                <strong>💡 Wskazówki:</strong>
                <ol style="margin: 10px 0 0 20px;">
                    <li>Jeśli widzisz "BRAK TABELI" - kliknij najpierw "Utwórz tabele"</li>
                    <li>Jeśli lokalizacje są puste - kliknij "Przywróć lokalizacje"</li>
                    <li>Jeśli wszystko jest puste - kliknij "Przywróć wszystko"</li>
                </ol>
            </div>
        </div>
        
        <footer style="text-align: center; color: #64748b; padding: 20px;">
            Work Land © <?= date('Y') ?> | v<?= WORKLAND_VERSION ?>
        </footer>
    </div>
</body>
</html>
