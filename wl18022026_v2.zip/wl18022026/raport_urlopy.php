<?php
/**
 * Raport urlopów i nieobecności
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Wybór miesiąca i roku
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

if ($month < 1) $month = 1;
if ($month > 12) $month = 12;
if ($year < 2000) $year = 2000;
if ($year > 2100) $year = 2100;

// Pierwszy i ostatni dzień miesiąca
$firstDay = sprintf('%04d-%02d-01', $year, $month);
$lastDay = date('Y-m-t', strtotime($firstDay));

// Pobierz urlopy w danym miesiącu
$sql = "SELECT u.*, p.kod, p.imie, p.nazwisko, p.stanowisko
        FROM urlopy u
        JOIN pracownicy p ON u.pracownik_id = p.id
        WHERE (u.data_od <= ? AND (u.data_do >= ? OR u.data_do IS NULL))
        ORDER BY u.data_od, p.nazwisko, p.imie";
$stmt = $db->prepare($sql);
$stmt->execute([$lastDay, $firstDay]);
$urlopy = $stmt->fetchAll();

// Statystyki po typie urlopu
$statystyki = [];
foreach ($urlopy as $u) {
    $typ = $u['typ'] ?: 'inny';
    if (!isset($statystyki[$typ])) {
        $statystyki[$typ] = ['count' => 0, 'days' => 0];
    }
    $statystyki[$typ]['count']++;
    
    // Oblicz dni w danym miesiącu
    $start = max(strtotime($firstDay), strtotime($u['data_od']));
    $end = min(strtotime($lastDay), strtotime($u['data_do'] ?: $lastDay));
    $days = max(0, floor(($end - $start) / 86400) + 1);
    $statystyki[$typ]['days'] += $days;
}

// Nazwy miesięcy po polsku
$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];

// Export do CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="urlopy_' . $year . '_' . str_pad($month, 2, '0', STR_PAD_LEFT) . '.csv"');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // UTF-8 BOM
    
    fputcsv($output, ['Kod', 'Imię', 'Nazwisko', 'Typ urlopu', 'Od', 'Do', 'Uwagi'], ';');
    
    foreach ($urlopy as $u) {
        fputcsv($output, [
            $u['kod'],
            $u['imie'],
            $u['nazwisko'],
            $u['typ'],
            formatDate($u['data_od']),
            formatDate($u['data_do']),
            $u['uwagi']
        ], ';');
    }
    
    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raport urlopów - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .month-selector { background: white; padding: 20px; border-radius: 8px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .month-selector form { display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }
        .month-selector select { padding: 10px 15px; border: 2px solid #e2e8f0; border-radius: 6px; font-size: 1rem; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 25px; }
        .stat-card { background: white; padding: 20px; border-radius: 8px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .stat-card .number { font-size: 2rem; font-weight: 700; color: #2563eb; }
        .stat-card .label { color: #64748b; font-size: 0.85rem; margin-top: 5px; }
        .stat-card.wypoczynkowy { border-left: 4px solid #22c55e; }
        .stat-card.chorobowy { border-left: 4px solid #ef4444; }
        .stat-card.bezpłatny { border-left: 4px solid #f59e0b; }
        .stat-card.macierzyński { border-left: 4px solid #ec4899; }
        .stat-card.total { border-left: 4px solid #2563eb; }
        .urlop-badge { padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; font-weight: 500; }
        .urlop-wypoczynkowy { background: #dcfce7; color: #166534; }
        .urlop-chorobowy { background: #fee2e2; color: #dc2626; }
        .urlop-bezpłatny { background: #fef3c7; color: #92400e; }
        .urlop-macierzyński { background: #fce7f3; color: #be185d; }
        .urlop-ojcowski { background: #dbeafe; color: #1d4ed8; }
        .urlop-wychowawczy { background: #f3e8ff; color: #7c3aed; }
        .urlop-okolicznościowy { background: #e0e7ff; color: #4338ca; }
        .urlop-inny { background: #f1f5f9; color: #475569; }
        .report-actions { display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }
        @media print {
            .no-print { display: none !important; }
            .container { max-width: 100%; }
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav no-print">
            <div class="logo-section">
                <img src="assets/logo.png" alt="Work Land">
                <div class="user-info">👤 <?php echo sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="index.php">📋 Pracownicy</a>
                <a href="raport.php">📊 Raport zatrudnienia</a>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>🏖️ Raport urlopów i nieobecności</h1>
            <a href="index.php" class="btn btn-secondary no-print">← Powrót do listy</a>
        </header>
        
        <!-- Wybór miesiąca -->
        <div class="month-selector no-print">
            <form method="GET">
                <label><strong>Wybierz okres:</strong></label>
                <select name="month">
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo $m; ?>" <?php echo $m == $month ? 'selected' : ''; ?>><?php echo $miesiacNazwy[$m]; ?></option>
                    <?php endfor; ?>
                </select>
                <select name="year">
                    <?php for ($y = date('Y') - 5; $y <= date('Y') + 1; $y++): ?>
                        <option value="<?php echo $y; ?>" <?php echo $y == $year ? 'selected' : ''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
                <button type="submit" class="btn btn-primary">📊 Generuj raport</button>
            </form>
        </div>
        
        <h2>📅 <?php echo $miesiacNazwy[$month]; ?> <?php echo $year; ?></h2>
        
        <!-- Statystyki -->
        <div class="stats-grid">
            <div class="stat-card total">
                <div class="number"><?php echo count($urlopy); ?></div>
                <div class="label">Wszystkich nieobecności</div>
            </div>
            <?php 
            $typyKolory = [
                'wypoczynkowy' => 'wypoczynkowy',
                'chorobowy' => 'chorobowy',
                'bezpłatny' => 'bezpłatny',
                'macierzyński' => 'macierzyński'
            ];
            foreach ($statystyki as $typ => $data): 
                $klasa = $typyKolory[$typ] ?? '';
            ?>
                <div class="stat-card <?php echo $klasa; ?>">
                    <div class="number"><?php echo $data['count']; ?></div>
                    <div class="label"><?php echo ucfirst($typ); ?> (<?php echo $data['days']; ?> dni)</div>
                </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Akcje -->
        <div class="report-actions no-print">
            <a href="?month=<?php echo $month; ?>&year=<?php echo $year; ?>&export=csv" class="btn">📥 Pobierz CSV</a>
            <button onclick="window.print()" class="btn">🖨️ Drukuj</button>
        </div>
        
        <?php if (empty($urlopy)): ?>
            <div class="empty-state">
                <p>Brak urlopów i nieobecności w wybranym okresie.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Kod</th>
                            <th>Pracownik</th>
                            <th>Typ</th>
                            <th>Od</th>
                            <th>Do</th>
                            <th>Dni</th>
                            <th>Uwagi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($urlopy as $u): 
                            $start = max(strtotime($firstDay), strtotime($u['data_od']));
                            $end = min(strtotime($lastDay), strtotime($u['data_do'] ?: $lastDay));
                            $days = max(0, floor(($end - $start) / 86400) + 1);
                            $typClass = 'urlop-' . strtolower(str_replace(['ą','ę','ó','ś','ł','ż','ź','ć','ń'], ['a','e','o','s','l','z','z','c','n'], $u['typ'] ?? 'inny'));
                        ?>
                            <tr>
                                <td><code><?php echo sanitize($u['kod']); ?></code></td>
                                <td>
                                    <strong><?php echo sanitize($u['imie'] . ' ' . $u['nazwisko']); ?></strong>
                                    <?php if ($u['stanowisko']): ?><br><small class="muted"><?php echo sanitize($u['stanowisko']); ?></small><?php endif; ?>
                                </td>
                                <td><span class="urlop-badge <?php echo $typClass; ?>"><?php echo sanitize($u['typ']); ?></span></td>
                                <td><?php echo formatDate($u['data_od']); ?></td>
                                <td><?php echo formatDate($u['data_do']); ?></td>
                                <td><strong><?php echo $days; ?></strong></td>
                                <td><?php echo sanitize($u['uwagi']) ?: '-'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        
        <footer class="no-print">
            <p>Work Land © <?php echo date('Y'); ?> | v<?= WORKLAND_VERSION ?> | Raport urlopów</p>
        </footer>
    </div>
</body>
</html>
