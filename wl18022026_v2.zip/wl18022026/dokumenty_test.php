<?php
// Test - czy w ogóle PHP działa
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

echo "<h1>Test dokumentów</h1>";

require_once 'includes/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
echo "<p>ID: $id</p>";

if ($id) {
    $stmt = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
    $stmt->execute([$id]);
    $p = $stmt->fetch();
    
    if ($p) {
        echo "<p>Pracownik: " . htmlspecialchars($p['imie'] . ' ' . $p['nazwisko']) . "</p>";
        echo "<p>PESEL: " . htmlspecialchars($p['pesel']) . "</p>";
        
        // Test oddelegowania
        $stmt2 = $db->prepare("SELECT o.*, k.nazwa as klient_nazwa FROM oddelegowania o LEFT JOIN klienci k ON o.klient_id = k.id WHERE o.pracownik_id = ? LIMIT 1");
        $stmt2->execute([$id]);
        $odd = $stmt2->fetch();
        if ($odd) {
            echo "<p>Oddelegowanie: " . htmlspecialchars($odd['stanowisko'] ?? 'brak') . " @ " . htmlspecialchars($odd['klient_nazwa'] ?? 'brak') . "</p>";
        } else {
            echo "<p>Brak oddelegowania</p>";
        }
    } else {
        echo "<p>Nie znaleziono pracownika</p>";
    }
}

echo "<p>Plik działa poprawnie!</p>";
