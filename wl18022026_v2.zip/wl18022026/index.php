<?php
/**
 * Lista pracowników - Strona główna
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Parametry filtrowania
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filterNarodowosc = isset($_GET['narodowosc']) ? trim($_GET['narodowosc']) : '';
$filterStatus = isset($_GET['status']) ? trim($_GET['status']) : '';
$filterZezwolenie = isset($_GET['zezwolenie']) ? trim($_GET['zezwolenie']) : '';
$filterBHP = isset($_GET['bhp']) ? trim($_GET['bhp']) : '';
$filterBadania = isset($_GET['badania']) ? trim($_GET['badania']) : '';
$filterKlient = isset($_GET['klient']) ? (int)$_GET['klient'] : 0;

// Budowanie zapytania
$where = [];
$params = [];

if (!empty($search)) {
    $where[] = "(p.kod LIKE :search OR p.imie LIKE :search OR p.nazwisko LIKE :search OR p.pesel LIKE :search OR p.telefon LIKE :search)";
    $params[':search'] = "%{$search}%";
}

if (!empty($filterNarodowosc)) {
    $where[] = "p.narodowosc = :narodowosc";
    $params[':narodowosc'] = $filterNarodowosc;
}

if ($filterStatus === 'aktywni') {
    $where[] = "(p.data_zwolnienia IS NULL OR p.data_zwolnienia = '' OR p.data_zwolnienia > date('now'))";
} elseif ($filterStatus === 'zwolnieni') {
    $where[] = "(p.data_zwolnienia IS NOT NULL AND p.data_zwolnienia != '' AND p.data_zwolnienia <= date('now'))";
}

if ($filterZezwolenie === 'wygasle') {
    $where[] = "(p.zezwolenie_do IS NOT NULL AND p.zezwolenie_do != '' AND p.zezwolenie_do < date('now'))";
} elseif ($filterZezwolenie === 'wygasa30') {
    $where[] = "(p.zezwolenie_do IS NOT NULL AND p.zezwolenie_do != '' AND p.zezwolenie_do >= date('now') AND p.zezwolenie_do <= date('now', '+30 days'))";
} elseif ($filterZezwolenie === 'bezterminowe') {
    $where[] = "(p.zezwolenie_do IS NULL OR p.zezwolenie_do = '')";
}

if ($filterBHP === 'wygasle') {
    $where[] = "(p.szkolenie_bhp IS NOT NULL AND p.szkolenie_bhp != '' AND p.szkolenie_bhp < date('now'))";
} elseif ($filterBHP === 'wygasa30') {
    $where[] = "(p.szkolenie_bhp IS NOT NULL AND p.szkolenie_bhp != '' AND p.szkolenie_bhp >= date('now') AND p.szkolenie_bhp <= date('now', '+30 days'))";
}

if ($filterBadania === 'wygasle') {
    $where[] = "(p.badania_lekarskie IS NOT NULL AND p.badania_lekarskie != '' AND p.badania_lekarskie < date('now'))";
} elseif ($filterBadania === 'wygasa30') {
    $where[] = "(p.badania_lekarskie IS NOT NULL AND p.badania_lekarskie != '' AND p.badania_lekarskie >= date('now') AND p.badania_lekarskie <= date('now', '+30 days'))";
}

if ($filterKlient > 0) {
    $where[] = "o.klient_id = :klient_id AND o.active = 1";
    $params[':klient_id'] = $filterKlient;
}

$whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

// Pobierz pracowników z aktualnym oddelegowaniem
$sql = "SELECT p.*, k.nazwa as klient_nazwa, o.stanowisko as oddelegowanie_stanowisko
        FROM pracownicy p
        LEFT JOIN oddelegowania o ON p.id = o.pracownik_id AND o.active = 1 AND (o.data_do IS NULL OR o.data_do >= date('now'))
        LEFT JOIN klienci k ON o.klient_id = k.id
        {$whereClause} 
        GROUP BY p.id
        ORDER BY p.updated_at DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$pracownicy = $stmt->fetchAll();

// Pobierz listę narodowości do filtra
$narodowosci = $db->query("SELECT DISTINCT narodowosc FROM pracownicy WHERE narodowosc IS NOT NULL AND narodowosc != '' ORDER BY narodowosc")->fetchAll(PDO::FETCH_COLUMN);

// Pobierz listę klientów do filtra
$klienciLista = $db->query("SELECT id, nazwa FROM klienci WHERE active = 1 ORDER BY nazwa")->fetchAll();

// Statystyki
$totalCount = $db->query("SELECT COUNT(*) FROM pracownicy")->fetchColumn();
$activeCount = $db->query("SELECT COUNT(*) FROM pracownicy WHERE data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > date('now')")->fetchColumn();

// Komunikaty
$message = '';
if (isset($_GET['msg'])) {
    switch ($_GET['msg']) {
        case 'added': $message = '<div class="alert success">Pracownik został dodany pomyślnie.</div>'; break;
        case 'updated': $message = '<div class="alert success">Dane pracownika zostały zaktualizowane.</div>'; break;
        case 'deleted': $message = '<div class="alert success">Pracownik został usunięty.</div>'; break;
        case 'noperm': $message = '<div class="alert error">Brak uprawnień do tej operacji.</div>'; break;
    }
}

// Sprawdź czy są aktywne filtry
$hasFilters = !empty($search) || !empty($filterNarodowosc) || !empty($filterStatus) || !empty($filterZezwolenie) || !empty($filterBHP) || !empty($filterBadania) || $filterKlient > 0;
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ewidencja Pracowników - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .filters { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .filters-row { display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.85rem; color: #64748b; font-weight: 500; }
        .filter-group select, .filter-group input { padding: 8px 12px; border: 2px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem; }
        .filter-group select:focus, .filter-group input:focus { border-color: #2563eb; outline: none; }
        .filter-actions { display: flex; gap: 10px; }
        .stats-bar { display: flex; gap: 20px; margin-bottom: 15px; flex-wrap: wrap; }
        .stat-item { background: #f1f5f9; padding: 8px 15px; border-radius: 6px; font-size: 0.9rem; }
        .stat-item strong { color: #2563eb; }
        .role-badge { font-size: 0.75rem; padding: 2px 8px; border-radius: 4px; margin-left: 10px; }
        .role-admin { background: #fee2e2; color: #dc2626; }
        .role-moderator { background: #fef3c7; color: #d97706; }
        .role-rekruter { background: #ede9fe; color: #7c3aed; }
        .role-viewer { background: #dbeafe; color: #2563eb; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <img src="assets/logo.png" alt="Work Land">
                <div class="user-info">
                    👤 <?php echo sanitize($currentUser['name']); ?>
                    <span class="role-badge role-<?php echo $currentUser['role']; ?>"><?php echo getRoleName($currentUser['role']); ?></span>
                </div>
            </div>
            <div class="nav-links">
                <span class="current-date">📅 <?php echo date('d.m.Y'); ?></span>
                <a href="crm/">🎯 CRM</a>
                <a href="kandydaci/">👥 Kandydaci</a>
                <a href="delegacje/">🚗 Delegacje</a>
                <a href="lista_obecnosci_gen.php">📝 Lista obecności</a>
                <a href="skladki.php">📊 Składki</a>
                <a href="raport_pracownicy.php">📋 Raporty</a>
                <a href="rachunek_gen.php">💰 Rachunki</a>
                <?php if (canManageUsers()): ?><a href="users.php">👤 Użytkownicy</a><?php endif; ?>
                <?php if (canViewHistory()): ?><a href="historia.php">📜 Historia</a><?php endif; ?>
                <?php if (isAdmin()): ?><a href="powiadomienia.php">📧 Powiadomienia</a><?php endif; ?>
                <a href="klienci.php">🏢 Klienci</a>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>📋 Ewidencja Pracowników</h1>
            <p class="subtitle">Work Land - System zarządzania kadrami</p>
        </header>
        
        <?php echo $message; ?>
        
        <!-- Filtry -->
        <div class="filters">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group" style="flex: 2; min-width: 200px;">
                        <label>🔍 Szukaj</label>
                        <input type="text" name="search" placeholder="Kod, imię, nazwisko, PESEL, telefon..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label>🌍 Narodowość</label>
                        <select name="narodowosc">
                            <option value="">-- Wszystkie --</option>
                            <?php foreach ($narodowosci as $n): ?>
                                <option value="<?php echo htmlspecialchars($n); ?>" <?php echo $filterNarodowosc === $n ? 'selected' : ''; ?>><?php echo htmlspecialchars($n); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>📊 Status</label>
                        <select name="status">
                            <option value="">-- Wszyscy --</option>
                            <option value="aktywni" <?php echo $filterStatus === 'aktywni' ? 'selected' : ''; ?>>Aktywni</option>
                            <option value="zwolnieni" <?php echo $filterStatus === 'zwolnieni' ? 'selected' : ''; ?>>Zwolnieni</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>📄 Zezwolenie</label>
                        <select name="zezwolenie">
                            <option value="">-- Wszystkie --</option>
                            <option value="wygasle" <?php echo $filterZezwolenie === 'wygasle' ? 'selected' : ''; ?>>⛔ Wygasłe</option>
                            <option value="wygasa30" <?php echo $filterZezwolenie === 'wygasa30' ? 'selected' : ''; ?>>⚠️ Wygasa w 30 dni</option>
                            <option value="bezterminowe" <?php echo $filterZezwolenie === 'bezterminowe' ? 'selected' : ''; ?>>♾️ Bezterminowe</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>🦺 BHP</label>
                        <select name="bhp">
                            <option value="">-- Wszystkie --</option>
                            <option value="wygasle" <?php echo $filterBHP === 'wygasle' ? 'selected' : ''; ?>>⛔ Wygasłe</option>
                            <option value="wygasa30" <?php echo $filterBHP === 'wygasa30' ? 'selected' : ''; ?>>⚠️ Wygasa w 30 dni</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>🩺 Badania</label>
                        <select name="badania">
                            <option value="">-- Wszystkie --</option>
                            <option value="wygasle" <?php echo $filterBadania === 'wygasle' ? 'selected' : ''; ?>>⛔ Wygasłe</option>
                            <option value="wygasa30" <?php echo $filterBadania === 'wygasa30' ? 'selected' : ''; ?>>⚠️ Wygasa w 30 dni</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>🏢 Klient</label>
                        <select name="klient">
                            <option value="">-- Wszyscy --</option>
                            <?php foreach ($klienciLista as $k): ?>
                                <option value="<?php echo $k['id']; ?>" <?php echo $filterKlient == $k['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($k['nazwa']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-actions">
                        <button type="submit" class="btn btn-primary">🔍 Filtruj</button>
                        <?php if ($hasFilters): ?>
                            <a href="index.php" class="btn btn-secondary">✕ Wyczyść</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Statystyki i akcje -->
        <div class="toolbar">
            <div class="stats-bar">
                <div class="stat-item">Wyświetlono: <strong><?php echo count($pracownicy); ?></strong></div>
                <div class="stat-item">Łącznie w bazie: <strong><?php echo $totalCount; ?></strong></div>
                <div class="stat-item">Aktywnych: <strong><?php echo $activeCount; ?></strong></div>
            </div>
            <div class="toolbar-actions">
                <a href="raport.php" class="btn">📊 Raport zatrudnienia</a>
                <a href="raport_nieobecnosci.php" class="btn">🏥 Raport nieobecności</a>
                <a href="import.php" class="btn">📥 Import</a>
                <a href="export.php" class="btn">📤 Export</a>
                <a href="add.php" class="btn btn-primary">➕ Dodaj pracownika</a>
            </div>
        </div>
        
        <?php if (empty($pracownicy)): ?>
            <div class="empty-state">
                <?php if ($hasFilters): ?>
                    <p>Brak pracowników spełniających kryteria wyszukiwania.</p>
                    <a href="index.php" class="btn btn-secondary">Wyczyść filtry</a>
                <?php else: ?>
                    <p>Brak pracowników w bazie danych.</p>
                    <a href="add.php" class="btn btn-primary">Dodaj pierwszego pracownika</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Kod</th>
                            <th>Imię i nazwisko</th>
                            <th>Klient</th>
                            <th>Data przyjęcia</th>
                            <th>Zezwolenie do</th>
                            <th>Badania</th>
                            <th>BHP</th>
                            <th>Akcje</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pracownicy as $p): ?>
                            <?php
                            $today = strtotime('today');
                            $warning30 = strtotime('+30 days');
                            
                            $zezwolenieClass = '';
                            if (!empty($p['zezwolenie_do'])) {
                                $zezwDate = strtotime($p['zezwolenie_do']);
                                if ($zezwDate < $today) $zezwolenieClass = 'date-expired';
                                elseif ($zezwDate < $warning30) $zezwolenieClass = 'date-warning';
                            }
                            
                            $badaniaClass = '';
                            if (!empty($p['badania_lekarskie'])) {
                                $badDate = strtotime($p['badania_lekarskie']);
                                if ($badDate < $today) $badaniaClass = 'date-expired';
                                elseif ($badDate < $warning30) $badaniaClass = 'date-warning';
                            }
                            
                            $bhpClass = '';
                            if (!empty($p['szkolenie_bhp'])) {
                                $bhpDate = strtotime($p['szkolenie_bhp']);
                                if ($bhpDate < $today) $bhpClass = 'date-expired';
                                elseif ($bhpDate < $warning30) $bhpClass = 'date-warning';
                            }
                            
                            $isZwolniony = !empty($p['data_zwolnienia']) && strtotime($p['data_zwolnienia']) <= $today;
                            ?>
                            <tr <?php if ($isZwolniony): ?>style="opacity: 0.6;"<?php endif; ?>>
                                <td><code><?php echo sanitize($p['kod']); ?></code></td>
                                <td>
                                    <strong><?php echo sanitize($p['imie'] . ' ' . $p['nazwisko']); ?></strong>
                                    <?php if ($isZwolniony): ?><span class="badge" style="background:#fee2e2;color:#dc2626;font-size:0.7rem;padding:2px 6px;border-radius:3px;margin-left:5px;">zwolniony</span><?php endif; ?>
                                    <?php if ($p['narodowosc']): ?><br><small class="muted"><?php echo sanitize($p['narodowosc']); ?></small><?php endif; ?>
                                </td>
                                <td>
                                    <?php if (!empty($p['klient_nazwa'])): ?>
                                        <span style="background:#dbeafe;color:#1d4ed8;padding:2px 8px;border-radius:4px;font-size:0.85rem;">🏢 <?php echo sanitize($p['klient_nazwa']); ?></span>
                                        <?php if (!empty($p['oddelegowanie_stanowisko'])): ?><br><small class="muted"><?php echo sanitize($p['oddelegowanie_stanowisko']); ?></small><?php endif; ?>
                                    <?php else: ?>
                                        <span class="muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo formatDate($p['data_przyjecia']); ?></td>
                                <td class="<?php echo $zezwolenieClass; ?>"><?php echo formatDate($p['zezwolenie_do']); ?></td>
                                <td class="<?php echo $badaniaClass; ?>"><?php echo formatDate($p['badania_lekarskie']); ?></td>
                                <td class="<?php echo $bhpClass; ?>"><?php echo formatDate($p['szkolenie_bhp']); ?></td>
                                <td class="actions">
                                    <a href="view.php?id=<?php echo $p['id']; ?>" class="btn btn-small" title="Podgląd">👁️</a>
                                    <a href="edit.php?id=<?php echo $p['id']; ?>" class="btn btn-small" title="Edytuj">✏️</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        
        <footer>
            <p>Work Land © <?php echo date('Y'); ?> | System Ewidencji Pracowników | v<?= WORKLAND_VERSION ?> (<?= WORKLAND_VERSION_DATE ?>)</p>
        </footer>
    </div>
</body>
</html>
