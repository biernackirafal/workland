<?php
/**
 * Import pracowników z Excel (CSV)
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$errors = [];
$preview = [];

// Sprawdź czy są komunikaty z sesji
$success = '';
if (isset($_SESSION['import_success'])) {
    $success = $_SESSION['import_success'];
    unset($_SESSION['import_success']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'import' && isset($_POST['data'])) {
        $data = json_decode($_POST['data'], true);
        
        $imported = 0;
        $skipped = 0;
        
        foreach ($data as $row) {
            // Generuj UNIKALNY kod dla każdego rekordu
            $year = date('Y');
            $stmt = $db->query("SELECT MAX(CAST(SUBSTR(kod, 7) AS INTEGER)) as max_num FROM pracownicy WHERE kod LIKE 'WL{$year}%'");
            $result = $stmt->fetch();
            $nextNum = ($result['max_num'] ?? 0) + 1;
            $newKod = sprintf("WL%s%04d", $year, $nextNum);
            
            try {
                $stmt = $db->prepare("INSERT INTO pracownicy (
                    kod, imie, nazwisko, narodowosc, dane_personalne, dokument_tozsamosci,
                    data_urodzenia, pesel, nip, telefon, data_przyjecia, data_zwolnienia, 
                    zezwolenie_do, stawka_wynagrodzenia
                ) VALUES (
                    :kod, :imie, :nazwisko, :narodowosc, :dane_personalne, :dokument_tozsamosci,
                    :data_urodzenia, :pesel, :nip, :telefon, :data_przyjecia, :data_zwolnienia,
                    :zezwolenie_do, :stawka_wynagrodzenia
                )");
                
                $stmt->execute([
                    ':kod' => $newKod,
                    ':imie' => isset($row['imie']) ? $row['imie'] : '',
                    ':nazwisko' => isset($row['nazwisko']) ? $row['nazwisko'] : '',
                    ':narodowosc' => isset($row['narodowosc']) ? $row['narodowosc'] : '',
                    ':dane_personalne' => '',
                    ':dokument_tozsamosci' => isset($row['dokument_tozsamosci']) ? $row['dokument_tozsamosci'] : '',
                    ':data_urodzenia' => !empty($row['data_urodzenia']) ? $row['data_urodzenia'] : null,
                    ':pesel' => isset($row['pesel']) ? $row['pesel'] : '',
                    ':nip' => '',
                    ':telefon' => isset($row['telefon']) ? $row['telefon'] : '',
                    ':data_przyjecia' => !empty($row['data_przyjecia']) ? $row['data_przyjecia'] : null,
                    ':data_zwolnienia' => !empty($row['data_zwolnienia']) ? $row['data_zwolnienia'] : null,
                    ':zezwolenie_do' => !empty($row['zezwolenie_do']) ? $row['zezwolenie_do'] : null,
                    ':stawka_wynagrodzenia' => !empty($row['stawka']) ? $row['stawka'] : null,
                ]);
                
                $imported++;
            } catch (PDOException $e) {
                $skipped++;
            }
        }
        
        // Zapisz komunikat do sesji i przekieruj (zapobiega ponownemu importowi przy odświeżeniu)
        // Loguj import
        if ($imported > 0) {
            logChange($db, 'IMPORT', 'pracownicy', null, 
                "Zaimportowano $imported pracowników" . ($skipped > 0 ? ", pominięto $skipped" : ""));
        }
        
        $_SESSION['import_success'] = "Zaimportowano $imported pracowników." . ($skipped > 0 ? " Pominięto $skipped." : "");
        header("Location: import.php");
        exit;
        
    } elseif (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['csv_file']['tmp_name'];
        $content = file_get_contents($file);
        
        // Konwersja z Windows-1250 do UTF-8
        $content = @iconv('Windows-1250', 'UTF-8//IGNORE', $content);
        if ($content === false) {
            $content = file_get_contents($file);
            $content = mb_convert_encoding($content, 'UTF-8', 'Windows-1250');
        }
        
        // Usuń BOM i znaki \r
        $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
        $content = str_replace("\r", "", $content);
        
        $lines = explode("\n", $content);
        $separator = ';';
        
        // Nagłówek
        $header = str_getcsv($lines[0], $separator);
        
        // Mapowanie kolumn
        $colMap = [];
        foreach ($header as $idx => $col) {
            $col = mb_strtolower(trim($col));
            
            if (strpos($col, 'imię') !== false || strpos($col, 'imie') !== false) $colMap['imie'] = $idx;
            if ($col === 'nazwisko' || strpos($col, 'nazwisko') === 0) $colMap['nazwisko'] = $idx;
            if (strpos($col, 'narodow') !== false) $colMap['narodowosc'] = $idx;
            if (strpos($col, 'pesel') !== false) $colMap['pesel'] = $idx;
            if (strpos($col, 'paszport') !== false || strpos($col, 'dow') !== false) $colMap['dokument_tozsamosci'] = $idx;
            if (strpos($col, 'data ur') !== false) $colMap['data_urodzenia'] = $idx;
            if (strpos($col, 'przyjęcia') !== false || strpos($col, 'przyjecia') !== false) $colMap['data_przyjecia'] = $idx;
            if (strpos($col, 'zwolnienia') !== false || strpos($col, 'zwolnieni') !== false) $colMap['data_zwolnienia'] = $idx;
            if (strpos($col, 'zezwolenie') !== false) $colMap['zezwolenie_do'] = $idx;
            if (strpos($col, 'stawka') !== false || strpos($col, 'wynagrod') !== false) $colMap['stawka'] = $idx;
            if (strpos($col, 'telefon') !== false) $colMap['telefon'] = $idx;
        }
        
        // Mapowanie skrótów narodowości
        $narodowoscMap = [
            'PL' => 'Polska',
            'UKR' => 'Ukraina',
            'BY' => 'Białoruś',
            'BLR' => 'Białoruś',
            'RU' => 'Rosja',
            'RUS' => 'Rosja',
            'MD' => 'Mołdawia',
            'MDA' => 'Mołdawia',
            'GE' => 'Gruzja',
            'GEO' => 'Gruzja',
            'KZ' => 'Kazachstan',
            'KAZ' => 'Kazachstan',
            'KG' => 'Kirgistan',
            'KGZ' => 'Kirgistan',
            'TM' => 'Turkmenistan',
            'TKM' => 'Turkmenistan',
            'UZ' => 'Uzbekistan',
            'UZB' => 'Uzbekistan',
            'TJ' => 'Tadżykistan',
            'TJK' => 'Tadżykistan',
            'AZ' => 'Azerbejdżan',
            'AZE' => 'Azerbejdżan',
            'AM' => 'Armenia',
            'ARM' => 'Armenia',
            'IN' => 'Indie',
            'IND' => 'Indie',
            'NP' => 'Nepal',
            'NPL' => 'Nepal',
            'PH' => 'Filipiny',
            'PHL' => 'Filipiny',
            'BD' => 'Bangladesz',
            'BGD' => 'Bangladesz',
            'VN' => 'Wietnam',
            'VNM' => 'Wietnam',
        ];
        
        // Przetwórz dane
        for ($i = 1; $i < count($lines); $i++) {
            $line = trim($lines[$i]);
            if (empty($line)) continue;
            
            $row = str_getcsv($line, $separator);
            
            $hasData = false;
            foreach ($row as $cell) {
                if (!empty(trim($cell))) { $hasData = true; break; }
            }
            if (!$hasData) continue;
            
            $record = [];
            foreach ($colMap as $field => $idx) {
                $record[$field] = isset($row[$idx]) ? trim($row[$idx]) : '';
            }
            
            if (empty($record['imie']) && empty($record['nazwisko'])) continue;
            
            // Konwersja narodowości ze skrótu na pełną nazwę
            if (!empty($record['narodowosc'])) {
                $skrot = strtoupper(trim($record['narodowosc']));
                if (isset($narodowoscMap[$skrot])) {
                    $record['narodowosc'] = $narodowoscMap[$skrot];
                }
            }
            
            // Konwersja dat
            foreach (['data_urodzenia', 'data_przyjecia', 'data_zwolnienia'] as $dateField) {
                if (!empty($record[$dateField])) {
                    $d = $record[$dateField];
                    if (preg_match('/(\d{1,2})\.(\d{1,2})\.(\d{4})/', $d, $m)) {
                        $record[$dateField] = sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
                    } else {
                        $record[$dateField] = '';
                    }
                }
            }
            
            // Zezwolenie
            if (!empty($record['zezwolenie_do'])) {
                $z = $record['zezwolenie_do'];
                if (preg_match('/(\d{1,2})\.(\d{1,2})\.(\d{4})/', $z, $m)) {
                    $record['zezwolenie_do'] = sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
                } else {
                    $record['zezwolenie_do'] = '';
                }
            }
            
            // Stawka
            if (!empty($record['stawka'])) {
                $s = $record['stawka'];
                if (preg_match('/=\s*([\d\s,\.]+)\s*zł/i', $s, $m)) {
                    $record['stawka'] = preg_replace('/[^\d,.]/', '', $m[1]);
                } elseif (preg_match('/([\d\s,\.]+)\s*zł/i', $s, $m)) {
                    $record['stawka'] = preg_replace('/[^\d,.]/', '', $m[1]);
                } else {
                    $record['stawka'] = preg_replace('/[^\d,.]/', '', $s);
                }
                $record['stawka'] = str_replace(',', '.', $record['stawka']);
            }
            
            // PESEL
            if (!empty($record['pesel'])) {
                if (preg_match('/(\d{11})/', $record['pesel'], $m)) {
                    $record['pesel'] = $m[1];
                }
            }
            
            $preview[] = $record;
        }
        
        if (empty($preview)) {
            $errors[] = 'Nie znaleziono danych do importu.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import pracowników - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .upload-area { background: white; border: 3px dashed #e2e8f0; border-radius: 12px; padding: 40px; text-align: center; margin-bottom: 25px; }
        .upload-area:hover { border-color: #2563eb; }
        .upload-area input[type="file"] { display: none; }
        .upload-area label { cursor: pointer; display: block; }
        .upload-icon { font-size: 3rem; margin-bottom: 15px; }
        .preview-table { font-size: 0.85rem; }
        .template-info { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 15px 20px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>📥 Import pracowników</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <?php if (!empty($errors)): ?>
            <div class="alert error"><?php foreach ($errors as $e): ?><p><?php echo htmlspecialchars($e); ?></p><?php endforeach; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if (empty($preview)): ?>
            <div class="template-info">
                <strong>ℹ️ Format pliku:</strong> CSV ze średnikiem (;) jako separatorem<br>
                <strong>Kolumny:</strong> Imię pierwsze, Nazwisko, Narodowość, Pesel / NIP, Paszport/ Dow.osob., Data ur., Data przyjęcia, Data zwolnienia, Zezwolenie na pracę dat do, Stawka wynagrodzenia<br>
                <small>Narodowość: PL, UKR, BY, RU, KZ, KG, TM, UZ, GE, MD, AM, AZ, TJ (lub pełne nazwy)<br>
                Daty w formacie DD.MM.RRRR</small>
            </div>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="upload-area">
                    <label for="csv_file">
                        <div class="upload-icon">📄</div>
                        <h3>Kliknij aby wybrać plik CSV</h3>
                        <p class="muted">Akceptowane: .csv</p>
                        <input type="file" id="csv_file" name="csv_file" accept=".csv,.txt" required>
                    </label>
                </div>
                <button type="submit" class="btn btn-primary btn-large">📋 Wczytaj podgląd</button>
            </form>
            
        <?php else: ?>
            <div class="alert success">Znaleziono <strong><?php echo count($preview); ?></strong> rekordów do importu.</div>
            
            <form method="POST" id="importForm">
                <input type="hidden" name="action" value="import">
                <input type="hidden" name="data" value="<?php echo htmlspecialchars(json_encode($preview, JSON_UNESCAPED_UNICODE)); ?>">
                
                <div class="table-responsive" style="max-height: 450px; overflow: auto; margin-bottom: 20px;">
                    <table class="preview-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Imię</th>
                                <th>Nazwisko</th>
                                <th>Narodowość</th>
                                <th>PESEL</th>
                                <th>Paszport</th>
                                <th>Data ur.</th>
                                <th>Przyjęcie</th>
                                <th>Zwolnienie</th>
                                <th>Zezwolenie do</th>
                                <th>Stawka</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($preview as $idx => $row): ?>
                            <tr>
                                <td><?php echo $idx + 1; ?></td>
                                <td><?php echo htmlspecialchars(isset($row['imie']) ? $row['imie'] : ''); ?></td>
                                <td><?php echo htmlspecialchars(isset($row['nazwisko']) ? $row['nazwisko'] : ''); ?></td>
                                <td><?php echo htmlspecialchars(isset($row['narodowosc']) ? $row['narodowosc'] : ''); ?></td>
                                <td><code><?php echo htmlspecialchars(isset($row['pesel']) ? $row['pesel'] : ''); ?></code></td>
                                <td><?php echo htmlspecialchars(isset($row['dokument_tozsamosci']) ? $row['dokument_tozsamosci'] : ''); ?></td>
                                <td><?php echo htmlspecialchars(isset($row['data_urodzenia']) ? $row['data_urodzenia'] : ''); ?></td>
                                <td><?php echo htmlspecialchars(isset($row['data_przyjecia']) ? $row['data_przyjecia'] : ''); ?></td>
                                <td><?php echo htmlspecialchars(isset($row['data_zwolnienia']) ? $row['data_zwolnienia'] : ''); ?></td>
                                <td><?php echo htmlspecialchars(isset($row['zezwolenie_do']) ? $row['zezwolenie_do'] : ''); ?></td>
                                <td><?php echo htmlspecialchars(isset($row['stawka']) ? $row['stawka'] : ''); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <div style="display: flex; gap: 15px;">
                    <button type="button" onclick="confirmImport()" class="btn btn-primary btn-large">✅ Importuj <?php echo count($preview); ?> pracowników</button>
                    <a href="import.php" class="btn btn-secondary btn-large">❌ Anuluj</a>
                </div>
            </form>
            
            <script>
            function confirmImport() {
                if (confirm('Czy na pewno chcesz zaimportować <?php echo count($preview); ?> pracowników do bazy danych?')) {
                    document.getElementById('importForm').submit();
                }
            }
            </script>
        <?php endif; ?>
        
        <footer><p>Work Land © <?php echo date('Y'); ?> | v<?= WORKLAND_VERSION ?></p></footer>
    </div>
    
    <script>
    var fileInput = document.getElementById('csv_file');
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            if (this.files[0]) {
                document.querySelector('.upload-area h3').textContent = this.files[0].name;
            }
        });
    }
    </script>
</body>
</html>
