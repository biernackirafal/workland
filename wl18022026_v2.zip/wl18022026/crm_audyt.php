<?php
/**
 * CRM Audyt v2 - Sprawdzanie poprawności danych
 * 
 * Poprawki:
 * - Lepsze porównywanie nazw (ignoruje format sp. z o.o. vs SPÓŁKA Z OGRANICZONĄ...)
 * - Mniej fałszywych alarmów
 * 
 * WGRAJ DO: /kadry/crm_audyt.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('max_execution_time', 600);

require_once __DIR__ . '/includes/db.php';
requireLogin();

$db = initDatabase();

// Funkcja do normalizacji nazwy firmy
function normalizeName($name) {
    $name = mb_strtoupper($name);
    
    // Usuń cudzysłowy
    $name = str_replace(['"', "'", '„', '"', '"'], '', $name);
    
    // Zamień różne formy na jednolite
    $replacements = [
        '/SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ/ui' => '',
        '/SP\.\s*Z\s*O\.?\s*O\.?/ui' => '',
        '/SPÓŁKA AKCYJNA/ui' => '',
        '/S\.\s*A\.?$/ui' => '',
        '/SPÓŁKA KOMANDYTOWA/ui' => '',
        '/SP\.\s*K\.?/ui' => '',
        '/SPÓŁKA JAWNA/ui' => '',
        '/SP\.\s*J\.?/ui' => '',
        '/SPÓŁKA CYWILNA/ui' => '',
        '/S\.\s*C\.?/ui' => '',
        '/SPÓŁKA PARTNERSKA/ui' => '',
        '/\s+/u' => ' ',
    ];
    
    foreach ($replacements as $pattern => $replacement) {
        $name = preg_replace($pattern, $replacement, $name);
    }
    
    return trim($name);
}

// === GUS API ===
class GUSApi {
    private $apiKey = 'b0f0e889eff5497cbea4';
    private $url = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';
    private $sid = null;
    
    public function login() {
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $this->apiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->request($envelope);
        $this->sid = $this->extract($response, 'ZalogujResult');
        return !empty($this->sid);
    }
    
    public function logout() {
        if (!$this->sid) return;
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Wyloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Wyloguj>
            <ns:pIdentyfikatorSesji>' . $this->sid . '</ns:pIdentyfikatorSesji>
        </ns:Wyloguj>
    </soap:Body>
</soap:Envelope>';
        $this->request($envelope);
        $this->sid = null;
    }
    
    public function searchByNip($nip) {
        if (!$this->sid) return null;
        
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:Nip>' . $nip . '</dat:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->request($envelope);
        $result = $this->extract($response, 'DaneSzukajPodmiotyResult');
        
        if (empty($result)) return null;
        
        $xml = @simplexml_load_string($result);
        if (!$xml || !isset($xml->dane)) return null;
        
        $dane = $xml->dane;
        if (isset($dane->ErrorCode) && (string)$dane->ErrorCode !== '0') return null;
        
        return [
            'regon' => (string)($dane->Regon ?? ''),
            'nazwa' => (string)($dane->Nazwa ?? ''),
            'typ' => (string)($dane->Typ ?? ''),
            'silos' => (string)($dane->SilosID ?? ''),
            'miejscowosc' => (string)($dane->Miejscowosc ?? '')
        ];
    }
    
    private function request($envelope) {
        $headers = ['Content-Type: application/soap+xml; charset=utf-8'];
        if ($this->sid) $headers[] = 'sid: ' . $this->sid;
        
        $ch = curl_init($this->url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $envelope,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $headers
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
    
    private function extract($xml, $tag) {
        if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
            return html_entity_decode($m[1]);
        }
        return '';
    }
}

// === AKCJE ===
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'check_all') {
    header('Content-Type: application/json; charset=utf-8');
    
    try {
        $stmt = $db->query("
            SELECT k.id, k.nazwa, k.nip 
            FROM crm_klienci k 
            WHERE k.nip IS NOT NULL AND k.nip != ''
            AND (k.audyt_status IS NULL OR k.audyt_status = '')
            ORDER BY k.id
            LIMIT 1
        ");
        $firma = $stmt->fetch();
        
        if (!$firma) {
            echo json_encode(['done' => true]);
            exit;
        }
        
        $gus = new GUSApi();
        if (!$gus->login()) {
            // Oznacz jako sprawdzone ale z błędem
            $db->prepare("UPDATE crm_klienci SET audyt_status = 'error', audyt_problemy = 'Błąd połączenia z GUS' WHERE id = ?")
               ->execute([$firma['id']]);
            echo json_encode(['id' => $firma['id'], 'nazwa' => $firma['nazwa'], 'status' => 'error', 'problems' => ['Błąd GUS']]);
            exit;
        }
        
        $result = $gus->searchByNip($firma['nip']);
        
        $status = 'ok';
        $nazwaGus = '';
        $problems = [];
        
        if (!$result) {
            $status = 'not_found';
            $problems[] = 'NIP nie znaleziony w GUS';
        } else {
            $nazwaGus = $result['nazwa'];
            
            // Normalizuj nazwy do porównania
            $cleanGus = normalizeName($result['nazwa']);
            $cleanCrm = normalizeName($firma['nazwa']);
            
            // Oblicz podobieństwo
            similar_text($cleanGus, $cleanCrm, $similarity);
            
            // Dodatkowo sprawdź czy jedna nazwa zawiera drugą
            $containsMatch = (mb_strpos($cleanGus, $cleanCrm) !== false || mb_strpos($cleanCrm, $cleanGus) !== false);
            
            // Jeśli nazwy są bardzo podobne lub jedna zawiera drugą - OK
            if ($similarity >= 70 || $containsMatch) {
                // Nazwa OK
            } elseif ($similarity >= 50) {
                $status = 'warning';
                $problems[] = 'Sprawdź nazwę (' . round($similarity) . '%)';
            } else {
                $status = 'error';
                $problems[] = 'Nazwa nie pasuje (' . round($similarity) . '%)';
            }
            
            // Sprawdź problematyczne typy organizacji (TYLKO te)
            $problematyczne = [
                'ZWIĄZEK ZAWODOWY' => 'Związek zawodowy',
                'STOWARZYSZENIE' => 'Stowarzyszenie', 
                'FUNDACJA' => 'Fundacja',
                'WSPÓLNOTA MIESZKANIOWA' => 'Wspólnota mieszkaniowa',
                'PARAFIA' => 'Parafia',
                'KOŚCIÓŁ' => 'Organizacja religijna',
                'OCHOTNICZA STRAŻ POŻARNA' => 'OSP',
                'PARTIA' => 'Partia polityczna',
                'KOŁO ŁOWIECKIE' => 'Koło łowieckie',
                'KÓŁKO ROLNICZE' => 'Kółko rolnicze'
            ];
            
            foreach ($problematyczne as $fraza => $typ) {
                if (mb_stripos($result['nazwa'], $fraza) !== false) {
                    $status = 'error';
                    $problems[] = $typ;
                    break;
                }
            }
        }
        
        $gus->logout();
        
        $db->prepare("UPDATE crm_klienci SET audyt_status = ?, audyt_nazwa_gus = ?, audyt_problemy = ? WHERE id = ?")
           ->execute([$status, $nazwaGus, implode('; ', $problems), $firma['id']]);
        
        echo json_encode([
            'id' => $firma['id'],
            'nazwa' => $firma['nazwa'],
            'status' => $status,
            'nazwa_gus' => $nazwaGus,
            'problems' => $problems
        ], JSON_UNESCAPED_UNICODE);
        
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

if ($action === 'reset') {
    $db->exec("UPDATE crm_klienci SET audyt_status = NULL, audyt_nazwa_gus = NULL, audyt_problemy = NULL");
    header('Location: crm_audyt.php?msg=reset');
    exit;
}

// Migracja
try { $db->exec("ALTER TABLE crm_klienci ADD COLUMN audyt_status VARCHAR(20)"); } catch (PDOException $e) {}
try { $db->exec("ALTER TABLE crm_klienci ADD COLUMN audyt_nazwa_gus VARCHAR(255)"); } catch (PDOException $e) {}
try { $db->exec("ALTER TABLE crm_klienci ADD COLUMN audyt_problemy TEXT"); } catch (PDOException $e) {}

// Statystyki
$stats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN nip IS NOT NULL AND nip != '' THEN 1 ELSE 0 END) as z_nip,
        SUM(CASE WHEN audyt_status IS NOT NULL AND audyt_status != '' THEN 1 ELSE 0 END) as sprawdzone,
        SUM(CASE WHEN audyt_status = 'ok' THEN 1 ELSE 0 END) as ok,
        SUM(CASE WHEN audyt_status = 'warning' THEN 1 ELSE 0 END) as warning,
        SUM(CASE WHEN audyt_status = 'error' THEN 1 ELSE 0 END) as error,
        SUM(CASE WHEN audyt_status = 'not_found' THEN 1 ELSE 0 END) as not_found
    FROM crm_klienci
")->fetch();

// Firmy z problemami - tylko error i not_found (nie warning)
$problemy = $db->query("
    SELECT id, nazwa, nip, audyt_status, audyt_nazwa_gus, audyt_problemy
    FROM crm_klienci 
    WHERE audyt_status IN ('error', 'not_found')
    ORDER BY 
        CASE audyt_status WHEN 'error' THEN 1 WHEN 'not_found' THEN 2 ELSE 3 END,
        nazwa
    LIMIT 200
")->fetchAll();

$doSprawdzenia = $stats['z_nip'] - $stats['sprawdzone'];
$msgParam = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audyt CRM v2</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .card-header { padding: 20px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .card-header h2 { margin: 0; font-size: 20px; }
        .card-body { padding: 20px; }
        
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 15px; }
        .alert-success { background: #dcfce7; color: #166534; }
        
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .stat { background: #f8fafc; padding: 14px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 24px; font-weight: 700; color: #1e40af; }
        .stat-label { font-size: 10px; color: #6b7280; text-transform: uppercase; }
        .stat.green .stat-value { color: #16a34a; }
        .stat.orange .stat-value { color: #ea580c; }
        .stat.red .stat-value { color: #dc2626; }
        .stat.gray .stat-value { color: #6b7280; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-warning { background: #ea580c; color: white; }
        .btn-outline { background: white; border: 1px solid #d1d5db; color: #374151; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f9fafb; font-weight: 600; font-size: 11px; text-transform: uppercase; color: #6b7280; }
        tr:hover { background: #f9fafb; }
        tr.error { background: #fef2f2; }
        tr.not-found { background: #f1f5f9; }
        
        .badge { display: inline-block; padding: 3px 10px; border-radius: 9999px; font-size: 11px; font-weight: 500; }
        .badge-error { background: #fee2e2; color: #991b1b; }
        .badge-gray { background: #f1f5f9; color: #64748b; }
        
        .progress-bar { height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden; margin-bottom: 10px; }
        .progress-fill { height: 100%; background: linear-gradient(90deg, #16a34a, #22c55e); transition: width 0.3s; }
        
        .log { background: #1f2937; color: #e5e7eb; padding: 15px; border-radius: 8px; font-family: monospace; font-size: 11px; max-height: 200px; overflow-y: auto; margin-bottom: 20px; }
        .log-entry { padding: 2px 0; }
        .log-entry.error { color: #f87171; }
        .log-entry.success { color: #4ade80; }
        .log-entry.warning { color: #fbbf24; }
        
        .problem-tag { display: inline-block; padding: 2px 8px; background: #fee2e2; color: #991b1b; border-radius: 4px; font-size: 11px; margin: 2px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>🔍 Audyt CRM - Sprawdzanie NIP <small style="color:#6b7280">v2</small></h2>
                <div>
                    <a href="?action=reset" class="btn btn-warning btn-sm" onclick="return confirm('Zresetować?')">🔄 Reset</a>
                    <a href="crm/klienci.php" class="btn btn-outline btn-sm">← CRM</a>
                </div>
            </div>
            <div class="card-body">
                
                <?php if ($msgParam === 'reset'): ?>
                <div class="alert alert-success">✅ Zresetowano</div>
                <?php endif; ?>
                
                <div class="stats">
                    <div class="stat">
                        <div class="stat-value"><?= $stats['z_nip'] ?></div>
                        <div class="stat-label">Z NIP</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value"><?= $stats['sprawdzone'] ?></div>
                        <div class="stat-label">Sprawdzonych</div>
                    </div>
                    <div class="stat green">
                        <div class="stat-value"><?= $stats['ok'] ?></div>
                        <div class="stat-label">OK</div>
                    </div>
                    <div class="stat orange">
                        <div class="stat-value"><?= $stats['warning'] ?></div>
                        <div class="stat-label">Do sprawdzenia</div>
                    </div>
                    <div class="stat red">
                        <div class="stat-value"><?= $stats['error'] ?></div>
                        <div class="stat-label">Błędy</div>
                    </div>
                    <div class="stat gray">
                        <div class="stat-value"><?= $stats['not_found'] ?></div>
                        <div class="stat-label">Brak w GUS</div>
                    </div>
                </div>
                
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: <?= $stats['z_nip'] > 0 ? round($stats['sprawdzone'] / $stats['z_nip'] * 100) : 0 ?>%"></div>
                </div>
                
                <div style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center;">
                    <button class="btn btn-success" id="btnStart" onclick="startAudit()" <?= $doSprawdzenia <= 0 ? 'disabled' : '' ?>>
                        ▶️ Audyt (<?= max(0, $doSprawdzenia) ?>)
                    </button>
                    <button class="btn btn-outline" id="btnStop" onclick="stopAudit()" disabled>⏹️ Stop</button>
                    <span id="statusText" style="color: #6b7280;"></span>
                </div>
                
                <div class="log" id="log" style="display: none;"></div>
                
                <?php if (!empty($problemy)): ?>
                <h3 style="margin: 20px 0 15px; color: #dc2626;">⚠️ Firmy wymagające uwagi (<?= count($problemy) ?>)</h3>
                
                <table>
                    <thead>
                        <tr>
                            <th>Firma w CRM</th>
                            <th>NIP</th>
                            <th>Nazwa w GUS</th>
                            <th>Problem</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($problemy as $p): ?>
                        <tr class="<?= $p['audyt_status'] ?>">
                            <td>
                                <a href="crm/klient_karta.php?id=<?= $p['id'] ?>" style="color: #1e40af; text-decoration: none; font-weight: 500;">
                                    <?= htmlspecialchars($p['nazwa']) ?>
                                </a>
                            </td>
                            <td style="font-family: monospace; font-size: 12px;"><?= htmlspecialchars($p['nip']) ?></td>
                            <td style="font-size: 12px;">
                                <?= $p['audyt_nazwa_gus'] ? htmlspecialchars($p['audyt_nazwa_gus']) : '<span style="color:#9ca3af">—</span>' ?>
                            </td>
                            <td>
                                <?php foreach (explode('; ', $p['audyt_problemy']) as $prob): ?>
                                    <?php if (trim($prob)): ?>
                                    <span class="problem-tag"><?= htmlspecialchars($prob) ?></span>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </td>
                            <td>
                                <a href="crm/klient_dodaj.php?id=<?= $p['id'] ?>" class="btn btn-outline btn-sm">✏️</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php elseif ($stats['sprawdzone'] > 0 && $stats['error'] == 0): ?>
                <div style="text-align: center; padding: 40px; color: #16a34a;">
                    <div style="font-size: 48px;">✅</div>
                    <div style="font-size: 18px;">Brak poważnych problemów!</div>
                </div>
                <?php endif; ?>
                
            </div>
        </div>
    </div>
    
    <script>
    let running = false;
    let checked = <?= $stats['sprawdzone'] ?>;
    let total = <?= $stats['z_nip'] ?>;
    
    function addLog(msg, type = '') {
        const log = document.getElementById('log');
        log.style.display = 'block';
        const time = new Date().toLocaleTimeString();
        log.innerHTML = `<div class="log-entry ${type}">[${time}] ${msg}</div>` + log.innerHTML;
    }
    
    function updateProgress() {
        const pct = total > 0 ? (checked / total * 100) : 0;
        document.getElementById('progressFill').style.width = pct + '%';
        document.getElementById('statusText').textContent = `${checked} / ${total}`;
    }
    
    function startAudit() {
        running = true;
        document.getElementById('btnStart').disabled = true;
        document.getElementById('btnStop').disabled = false;
        addLog('▶️ Start...', 'success');
        checkNext();
    }
    
    function stopAudit() {
        running = false;
        document.getElementById('btnStart').disabled = false;
        document.getElementById('btnStop').disabled = true;
        addLog('⏹️ Stop', 'warning');
    }
    
    function checkNext() {
        if (!running) return;
        
        fetch(location.href, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=check_all'
        })
        .then(r => r.json())
        .then(data => {
            if (data.done) {
                addLog('🎉 Zakończono!', 'success');
                stopAudit();
                setTimeout(() => location.reload(), 1000);
                return;
            }
            
            if (data.error && !data.id) {
                addLog(`❌ ${data.error}`, 'error');
            } else {
                const icon = data.status === 'ok' ? '✅' : (data.status === 'error' ? '❌' : '⚠️');
                const problems = data.problems && data.problems.length > 0 ? ': ' + data.problems.join(', ') : '';
                addLog(`${icon} ${data.nazwa}${problems}`, data.status === 'ok' ? 'success' : (data.status === 'error' ? 'error' : 'warning'));
            }
            
            checked++;
            updateProgress();
            
            setTimeout(checkNext, 500);
        })
        .catch(e => {
            addLog(`❌ ${e.message}`, 'error');
            setTimeout(checkNext, 2000);
        });
    }
    </script>
</body>
</html>
