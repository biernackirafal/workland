<?php
/**
 * Generator dokumentów pracowniczych
 */
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'includes/db.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$doc = isset($_GET['doc']) ? $_GET['doc'] : '';

if (!$id || !$doc) {
    die('Brak wymaganych parametrów');
}

// Pobierz dane pracownika
$stmt = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) {
    die('Nie znaleziono pracownika');
}

// Pobierz aktualne oddelegowanie
$stmt = $db->prepare("SELECT o.*, k.nazwa as klient_nazwa FROM oddelegowania o LEFT JOIN klienci k ON o.klient_id = k.id WHERE o.pracownik_id = ? AND o.active = 1 ORDER BY o.data_od DESC LIMIT 1");
$stmt->execute([$id]);
$oddelegowanie = $stmt->fetch();

// Dane firmy
$firma_nazwa = 'WORK LAND Sp. z o. o.';
$firma_ulica = 'Kminkowa';
$firma_nr = '156D/1';
$firma_kod = '62-064';
$firma_miasto = 'Plewiska';
$firma_email = 'workland.eu@gmail.com';
$firma_rep = 'Dawid Nowak';

// Parsowanie adresu
$adres = $p['adres'] ?? '';
$ulica = ''; $nr_domu = ''; $nr_m = ''; $kod = ''; $miasto = '';
if (preg_match('/(\d{2}-\d{3})\s+(\S+)/', $adres, $m)) {
    $kod = $m[1]; $miasto = $m[2];
}
if (preg_match('/^(.*?)\s+(\d+[A-Za-z]?)(?:\/(\d+))?/', $adres, $m)) {
    $ulica = trim($m[1]); $nr_domu = $m[2]; $nr_m = $m[3] ?? '';
}

// Dane pracownika
$imie = htmlspecialchars($p['imie'] ?? '');
$nazwisko = htmlspecialchars($p['nazwisko'] ?? '');
$imie_nazwisko = $imie . ' ' . $nazwisko;
$pesel = htmlspecialchars($p['pesel'] ?? '');
$nip = htmlspecialchars($p['nip'] ?? '');
$data_zatr = $p['data_przyjecia'] ? date('d.m.Y', strtotime($p['data_przyjecia'])) : '';
$stanowisko = htmlspecialchars($oddelegowanie['stanowisko'] ?? ($p['stanowisko'] ?? ''));
$dok_typ = htmlspecialchars($p['dokument_typ'] ?? 'dowód osobisty');
$dok_nr = htmlspecialchars($p['dokument_numer'] ?? $p['dokument_tozsamosci'] ?? '');
$konto = htmlspecialchars($p['konto_bankowe'] ?? '');
$data_dzis = date('d.m.Y');
$okres_od = $p['okres_zatrudnienia_od'] ? date('d.m.Y', strtotime($p['okres_zatrudnienia_od'])) : $data_zatr;
$okres_do = $p['okres_zatrudnienia_do'] ? date('d.m.Y', strtotime($p['okres_zatrudnienia_do'])) : '';
$typ_zleceniobiorcy = $p['typ_zleceniobiorcy'] ?? 'standardowy';

// Wybierz szablon
$title = '';
$content = '';

switch ($doc) {
    case 'akta_a':
        $title = 'Akta Osobowe - Część A';
        $content = <<<HTML
<div class="header">
    <h1>AKTA OSOBOWE</h1>
    <h2>CZĘŚĆ A</h2>
    <p>Dokumenty związane z ubieganiem się o zatrudnienie</p>
</div>
<table class="info">
    <tr><td class="bold">Imię i Nazwisko:</td><td>{$imie_nazwisko}</td></tr>
    <tr><td class="bold">Dział / Funkcja:</td><td>{$stanowisko}</td></tr>
</table>
<table class="bordered">
    <thead><tr><th width="50">Lp.</th><th>OKREŚLENIE AKTU</th><th width="80">LICZBA</th></tr></thead>
    <tbody>
        <tr><td class="center">1</td><td>Kwestionariusz osobowy wraz z niezbędną liczbą fotografii / Paszport / Wiza</td><td></td></tr>
        <tr><td class="center">2</td><td>Świadectwo pracy z poprzedniego miejsca pracy</td><td></td></tr>
        <tr><td class="center">3</td><td>Dokumenty potwierdzające kwalifikacje zawodowe</td><td></td></tr>
        <tr><td class="center">4</td><td>Świadectwo ukończenia szkoły</td><td></td></tr>
        <tr><td class="center">5</td><td>Orzeczenie lekarskie</td><td></td></tr>
        <tr><td class="center">6</td><td>Inne dokumenty</td><td></td></tr>
    </tbody>
</table>
HTML;
        break;
        
    case 'akta_b':
        $title = 'Akta Osobowe - Część B';
        $content = <<<HTML
<div class="header">
    <h1>AKTA OSOBOWE</h1>
    <h2>CZĘŚĆ B</h2>
    <p>Dokumenty dotyczące nawiązania stosunku pracy oraz przebiegu zatrudnienia</p>
</div>
<table class="info">
    <tr><td class="bold">Imię i Nazwisko:</td><td>{$imie_nazwisko}</td></tr>
    <tr><td class="bold">Dział / Funkcja:</td><td>{$stanowisko}</td></tr>
</table>
<table class="bordered">
    <thead><tr><th width="50">Lp.</th><th>OKREŚLENIE AKTU</th><th width="80">LICZBA</th></tr></thead>
    <tbody>
        <tr><td class="center">1</td><td>Umowa o pracę, zakres czynności</td><td></td></tr>
        <tr><td class="center">2</td><td>Potwierdzenie zapoznania się z regulaminem pracy i BHP</td><td></td></tr>
        <tr><td class="center">3</td><td>Potwierdzenie zapoznania się z informacjami objętymi tajemnicą</td><td></td></tr>
        <tr><td class="center">4</td><td>Oświadczenie rodzica/opiekuna (art. 129, 178, 188 KP)</td><td></td></tr>
        <tr><td class="center">5</td><td>Dokumenty dot. powierzenia mienia</td><td></td></tr>
        <tr><td class="center">6</td><td>Dokumenty dot. podnoszenia kwalifikacji</td><td></td></tr>
    </tbody>
</table>
HTML;
        break;
        
    case 'akta_c':
        $title = 'Akta Osobowe - Część C';
        $content = <<<HTML
<div class="header">
    <h1>AKTA OSOBOWE</h1>
    <h2>CZĘŚĆ C</h2>
    <p>Dokumenty związane z ustaniem zatrudnienia</p>
</div>
<table class="info">
    <tr><td class="bold">Imię i Nazwisko:</td><td>{$imie_nazwisko}</td></tr>
    <tr><td class="bold">Dział / Funkcja:</td><td>{$stanowisko}</td></tr>
</table>
<table class="bordered">
    <thead><tr><th width="50">Lp.</th><th>OKREŚLENIE AKTU</th><th width="80">LICZBA</th></tr></thead>
    <tbody>
        <tr><td class="center">1</td><td>Oświadczenie o wypowiedzeniu lub rozwiązaniu umowy</td><td></td></tr>
        <tr><td class="center">2</td><td>Kopia świadectwa pracy</td><td></td></tr>
        <tr><td class="center">3</td><td>Potwierdzenie zajęcia wynagrodzenia (art. 884 KPC)</td><td></td></tr>
        <tr><td class="center">4</td><td>Umowa o zakazie konkurencji</td><td></td></tr>
        <tr><td class="center">5</td><td>Orzeczenie lekarskie po rozwiązaniu stosunku pracy</td><td></td></tr>
    </tbody>
</table>
HTML;
        break;
        
    case 'rowne_traktowanie':
        $title = 'Oświadczenie - Równe traktowanie';
        $content = <<<HTML
<div class="header">
    <h1>OŚWIADCZENIE</h1>
    <h2>Równe traktowanie w zatrudnieniu</h2>
</div>
<div class="section small" style="text-align: justify;">
    <p><strong>Art. 18³ᵃ.</strong> Pracownicy powinni być równo traktowani w zakresie nawiązania i rozwiązania stosunku pracy, warunków zatrudnienia, awansowania oraz dostępu do szkolenia w celu podnoszenia kwalifikacji zawodowych, w szczególności bez względu na płeć, wiek, niepełnosprawność, rasę, religię, narodowość, przekonania polityczne, przynależność związkową, pochodzenie etniczne, wyznanie, orientację seksualną, a także bez względu na zatrudnienie na czas określony lub nieokreślony albo w pełnym lub w niepełnym wymiarze czasu pracy.</p>
    <p>Równe traktowanie w zatrudnieniu oznacza niedyskryminowanie w jakikolwiek sposób, bezpośrednio lub pośrednio.</p>
    <p>Dyskryminowanie bezpośrednie istnieje wtedy, gdy pracownik był, jest lub mógłby być traktowany mniej korzystnie niż inni pracownicy.</p>
    <p>Przejawem dyskryminowania jest także molestowanie i molestowanie seksualne.</p>
</div>
<div class="signature" style="margin-top: 40px;">
    <p>Oświadczam, że zapoznałem/am się z powyższymi przepisami.</p>
    <br><br>
    <table width="100%">
        <tr>
            <td width="50%"><p>........................................</p><p class="small">miejscowość, data</p></td>
            <td width="50%" class="right"><p>........................................</p><p class="small">podpis pracownika</p></td>
        </tr>
    </table>
</div>
<div style="margin-top: 30px; border-top: 1px solid #ccc; padding-top: 10px;">
    <p><strong>Imię i nazwisko:</strong> {$imie_nazwisko}</p>
</div>
HTML;
        break;
        
    case 'rodo':
        $title = 'Oświadczenie RODO';
        $content = <<<HTML
<div class="section" style="text-align: justify; font-size: 10pt;">
    <p>W związku z wejściem w życie z dniem 25 maja 2018 roku Rozporządzenia RODO, <strong>{$firma_nazwa}</strong> z siedzibą w {$firma_miasto} informuje o zasadach przetwarzania Pani/Pana danych osobowych.</p>
    <ol>
        <li>Administratorem danych osobowych jest <strong>{$firma_nazwa}</strong> z siedzibą: ul. {$firma_ulica} {$firma_nr}, {$firma_kod} {$firma_miasto}, e-mail: {$firma_email}</li>
        <li>Dane przetwarzane są w celu zawarcia i realizacji umowy o pracę.</li>
        <li>Odbiorcami danych mogą być podmioty współpracujące oraz uprawnione na podstawie przepisów prawa.</li>
        <li>Dane przetwarzane będą przez okres realizacji umowy oraz wymagany przez przepisy prawa.</li>
        <li>Dane nie będą wykorzystane do profilowania.</li>
        <li>Przysługuje Pani/Panu prawo dostępu do danych, ich sprostowania, usunięcia lub ograniczenia przetwarzania.</li>
        <li>Przysługuje prawo wniesienia skargi do organu nadzorczego.</li>
        <li>Podanie danych w części jest obowiązkowe, w pozostałym zakresie dobrowolne.</li>
    </ol>
</div>
<div class="signature" style="margin-top: 30px;">
    <p><strong>Zapoznałem się z treścią i przyjąłem do wiadomości</strong></p>
    <br><br>
    <table width="100%">
        <tr>
            <td width="50%"><p>........................................</p><p class="small">miejscowość, data</p></td>
            <td width="50%" class="right"><p>........................................</p><p class="small">podpis pracownika</p></td>
        </tr>
    </table>
</div>
<div style="margin-top: 20px; border-top: 1px solid #ccc; padding-top: 10px;">
    <p><strong>Imię i nazwisko:</strong> {$imie_nazwisko}</p>
</div>
HTML;
        break;
        
    case 'ppk':
        $title = 'Deklaracja PPK';
        $imie_upper = mb_strtoupper($imie, 'UTF-8');
        $nazwisko_upper = mb_strtoupper($nazwisko, 'UTF-8');
        $content = <<<HTML
<div class="header">
    <h1 style="font-size: 12pt;">DEKLARACJA O REZYGNACJI Z DOKONYWANIA WPŁAT DO<br>PRACOWNICZYCH PLANÓW KAPITAŁOWYCH (PPK)</h1>
</div>
<p class="small">Deklarację należy wypełnić wielkimi literami.</p>
<div class="section">
    <p class="bold">1. Dane dotyczące uczestnika PPK</p>
    <table class="bordered">
        <tr><td width="50%">Imię (imiona)</td><td><strong>{$imie_upper}</strong></td></tr>
        <tr><td>Nazwisko</td><td><strong>{$nazwisko_upper}</strong></td></tr>
        <tr><td>PESEL / data urodzenia</td><td><strong>{$pesel}</strong></td></tr>
        <tr><td>Seria i numer dokumentu</td><td><strong>{$dok_nr}</strong></td></tr>
    </table>
</div>
<div class="section">
    <p class="bold">2. Nazwa podmiotu zatrudniającego</p>
    <table class="bordered"><tr><td><strong>{$firma_nazwa}</strong></td></tr></table>
</div>
<div class="section">
    <p class="bold">3. Oświadczenie uczestnika PPK</p>
    <p>Oświadczam, że rezygnuję z dokonywania wpłat do PPK oraz posiadam wiedzę o konsekwencjach:</p>
    <ol>
        <li>nieotrzymania wpłaty powitalnej 250 zł</li>
        <li>nieotrzymywania dopłat rocznych 240 zł</li>
        <li>nieotrzymywania wpłat podstawowych od pracodawcy (1,5% wynagrodzenia)</li>
    </ol>
</div>
<div class="signature">
    <table width="100%">
        <tr>
            <td width="50%"><p>........................................</p><p class="small">data i podpis uczestnika PPK</p></td>
            <td width="50%" class="right"><p>........................................</p><p class="small">data złożenia deklaracji</p></td>
        </tr>
    </table>
</div>
HTML;
        break;
        
    case 'umowa_zlecenie':
        $title = 'Umowa Zlecenie';
        $kod_prac = htmlspecialchars($p['kod'] ?? '');
        $rok_zatr = $p['data_przyjecia'] ? date('Y', strtotime($p['data_przyjecia'])) : date('Y');
        $nr_umowy = $kod_prac . '/' . $rok_zatr;
        $adres_pelny = $nr_m ? "{$nr_domu}/{$nr_m}" : $nr_domu;
        
        // Automatyczne zaznaczanie checkboxów na podstawie typu zleceniobiorcy
        $check_inny_pracodawca = ($typ_zleceniobiorcy === 'inny_tytul') ? '☑' : '☐';
        $check_dzialalnosc = '☐';
        $check_student = ($typ_zleceniobiorcy === 'student') ? '☑' : '☐';
        $check_standardowy = ($typ_zleceniobiorcy === 'standardowy' || $typ_zleceniobiorcy === 'standard_26') ? '☑' : '☐';
        $check_emeryt = ($typ_zleceniobiorcy === 'emeryt') ? '☑' : '☐';
        
        // Data końca umowy - z bazy lub do uzupełnienia
        $okres_do_display = $okres_do ?: '........................';
        
        $content = <<<HTML
<div class="header">
    <h1>UMOWA ZLECENIA</h1>
    <h2>Nr. {$nr_umowy}</h2>
</div>
<p>Zawarta w dniu <strong>{$data_zatr}</strong> pomiędzy <strong>ZLECENIODAWCĄ</strong>:</p>
<table class="info" style="margin: 15px 0;">
    <tr><td>Nazwa:</td><td><strong>{$firma_nazwa}</strong></td></tr>
    <tr><td>Adres:</td><td>ul. {$firma_ulica} {$firma_nr}, {$firma_kod} {$firma_miasto}</td></tr>
</table>
<p>reprezentowanym przez: <strong>{$firma_rep}</strong></p>

<p style="margin-top: 15px;">a <strong>ZLECENIOBIORCĄ</strong>:</p>
<table class="info" style="margin: 15px 0;">
    <tr><td>Imię i nazwisko:</td><td><strong>{$imie_nazwisko}</strong></td></tr>
    <tr><td>PESEL:</td><td>{$pesel}</td></tr>
    <tr><td>NIP:</td><td>{$nip}</td></tr>
    <tr><td>Dokument:</td><td>{$dok_typ}: {$dok_nr}</td></tr>
    <tr><td>Adres:</td><td>ul. {$ulica} {$adres_pelny}, {$kod} {$miasto}</td></tr>
</table>

<p>Zleceniodawca zleca wykonanie prac:</p>
<p style="border: 1px solid #000; padding: 10px; margin: 10px 0;"><strong>{$stanowisko}</strong></p>

<p>Umowa zawarta na okres od <strong>{$okres_od}</strong> do <strong>{$okres_do_display}</strong></p>
<p>Stawka: <strong>............</strong> zł netto/godzina</p>
<p>Nr konta: <strong>{$konto}</strong></p>

<div class="section">
    <p><strong>Oświadczam że:</strong></p>
    <p>{$check_inny_pracodawca} pozostaję w zatrudnieniu z innym pracodawcą (wynagrodzenie wyższe od minimalnego)</p>
    <p>{$check_dzialalnosc} prowadzę pozarolniczą działalność</p>
    <p>{$check_student} jestem uczniem/studentem do 26 roku życia</p>
    <p>{$check_standardowy} nie posiadam innego tytułu ubezpieczenia</p>
    <p>{$check_emeryt} jestem emerytem/rencistą</p>
</div>

<div class="signature" style="margin-top: 40px;">
    <table width="100%">
        <tr>
            <td width="50%" class="center"><p>........................................</p><p>Zleceniodawca</p></td>
            <td width="50%" class="center"><p>........................................</p><p>Zleceniobiorca</p></td>
        </tr>
    </table>
</div>
HTML;
        break;
        
    default:
        die('Nieznany typ dokumentu: ' . htmlspecialchars($doc));
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?> - <?= $imie_nazwisko ?></title>
    <style>
        @page { margin: 2cm; size: A4; }
        @media print { body { margin: 0; } .no-print { display: none !important; } }
        body { font-family: "Times New Roman", Times, serif; font-size: 11pt; line-height: 1.4; max-width: 21cm; margin: 0 auto; padding: 20px; background: #fff; }
        .header { text-align: center; margin-bottom: 20px; }
        .header h1 { font-size: 14pt; margin: 0; font-weight: bold; }
        .header h2 { font-size: 12pt; margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        table.bordered td, table.bordered th { border: 1px solid #000; padding: 5px 8px; }
        table.info td { padding: 3px 10px; vertical-align: top; }
        table.info td:first-child { width: 200px; }
        .bold { font-weight: bold; }
        .center { text-align: center; }
        .right { text-align: right; }
        .signature { margin-top: 50px; }
        .small { font-size: 9pt; }
        .section { margin: 15px 0; }
        .toolbar { position: fixed; top: 10px; right: 10px; background: #f0f0f0; padding: 10px; border-radius: 5px; box-shadow: 0 2px 10px rgba(0,0,0,0.2); z-index: 1000; }
        .toolbar button { padding: 8px 15px; margin: 0 5px; cursor: pointer; border: none; border-radius: 4px; font-size: 12pt; }
        .btn-print { background: #2563eb; color: white; }
        .btn-back { background: #64748b; color: white; }
    </style>
</head>
<body>
    <div class="toolbar no-print">
        <button class="btn-print" onclick="window.print()">🖨️ Drukuj</button>
        <button class="btn-back" onclick="history.back()">← Wróć</button>
    </div>
    <?= $content ?>
</body>
</html>
