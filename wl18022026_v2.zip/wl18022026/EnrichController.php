<?php
/**
 * EnrichController - Kontroler do integracji z kadry.work-land.pl
 * 
 * Endpointy:
 * - GET  ?action=status     - status przetwarzania
 * - POST ?action=upload     - upload pliku CSV/Excel
 * - POST ?action=process    - przetwórz następną partię
 * - GET  ?action=download   - pobierz wyniki
 * - POST ?action=reset      - resetuj sesję
 */

require_once __DIR__ . '/CompanyEnricher.php';

class EnrichController
{
    private $enricher;
    private $dataDir;
    private $sessionFile;
    private $inputFile;
    private $outputFile;
    
    public function __construct()
    {
        $this->dataDir = __DIR__ . '/data';
        $this->sessionFile = $this->dataDir . '/session.json';
        $this->inputFile = $this->dataDir . '/input.json';
        $this->outputFile = $this->dataDir . '/output.csv';
        
        if (!is_dir($this->dataDir)) {
            mkdir($this->dataDir, 0755, true);
        }
        
        // Konfiguracja - dostosuj do swoich ustawień
        $ceidgApiKey = defined('CEIDG_API_KEY') ? CEIDG_API_KEY : null;
        
        $this->enricher = new CompanyEnricher(null, $ceidgApiKey);
        $this->enricher->setDelay(2); // 2 sekundy między requestami
    }
    
    /**
     * Router
     */
    public function handle(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        
        $action = $_GET['action'] ?? $_POST['action'] ?? 'status';
        
        try {
            switch ($action) {
                case 'status':
                    $this->status();
                    break;
                case 'upload':
                    $this->upload();
                    break;
                case 'process':
                    $this->process();
                    break;
                case 'download':
                    $this->download();
                    break;
                case 'reset':
                    $this->reset();
                    break;
                default:
                    $this->jsonResponse(['error' => 'Unknown action'], 400);
            }
        } catch (Exception $e) {
            $this->jsonResponse(['error' => $e->getMessage()], 500);
        }
    }
    
    /**
     * Status przetwarzania
     */
    private function status(): void
    {
        $session = $this->loadSession();
        $this->jsonResponse($session);
    }
    
    /**
     * Upload pliku
     */
    private function upload(): void
    {
        // Akceptujemy plik lub dane JSON
        $companies = [];
        
        if (!empty($_FILES['file'])) {
            $file = $_FILES['file'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            
            if ($ext === 'csv') {
                $companies = $this->parseCSV($file['tmp_name']);
            } elseif (in_array($ext, ['xlsx', 'xls'])) {
                $this->jsonResponse(['error' => 'Przekonwertuj Excel do CSV przed uploadem lub użyj endpoint JSON'], 400);
                return;
            }
        } elseif (!empty($_POST['companies'])) {
            // JSON data
            $companies = json_decode($_POST['companies'], true);
        } else {
            $this->jsonResponse(['error' => 'Brak danych do przetworzenia'], 400);
            return;
        }
        
        if (empty($companies)) {
            $this->jsonResponse(['error' => 'Pusty plik lub nieprawidłowy format'], 400);
            return;
        }
        
        // Zapisz dane wejściowe
        file_put_contents($this->inputFile, json_encode($companies, JSON_UNESCAPED_UNICODE));
        
        // Resetuj wyniki
        if (file_exists($this->outputFile)) {
            unlink($this->outputFile);
        }
        
        // Zapisz sesję
        $session = [
            'status' => 'ready',
            'total' => count($companies),
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'offset' => 0,
            'started_at' => null,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        $this->saveSession($session);
        
        $this->jsonResponse([
            'success' => true,
            'message' => 'Załadowano ' . count($companies) . ' firm',
            'session' => $session
        ]);
    }
    
    /**
     * Przetwórz następną partię
     */
    private function process(): void
    {
        $session = $this->loadSession();
        
        if ($session['status'] === 'idle') {
            $this->jsonResponse(['error' => 'Najpierw załaduj plik'], 400);
            return;
        }
        
        if ($session['status'] === 'completed') {
            $this->jsonResponse(['message' => 'Przetwarzanie zakończone', 'session' => $session]);
            return;
        }
        
        // Wczytaj dane
        $companies = json_decode(file_get_contents($this->inputFile), true);
        
        // Ustaw status
        if ($session['status'] === 'ready') {
            $session['status'] = 'processing';
            $session['started_at'] = date('Y-m-d H:i:s');
        }
        
        // Przetwórz partię
        $batchSize = (int)($_POST['batch_size'] ?? 10);
        $result = $this->enricher->processBatch($companies, $session['offset'], $batchSize);
        
        // Zlicz sukcesy i błędy
        $batchSuccess = 0;
        $batchFailed = 0;
        foreach ($result['results'] as $r) {
            if ($r['status'] === 'success' || $r['status'] === 'partial') {
                $batchSuccess++;
            } else {
                $batchFailed++;
            }
        }
        
        // Zapisz wyniki do CSV
        $append = file_exists($this->outputFile);
        $this->enricher->saveToCSV($result['results'], $this->outputFile, $append);
        
        // Aktualizuj sesję
        $session['offset'] = $result['next_offset'];
        $session['processed'] += $result['processed'];
        $session['success'] += $batchSuccess;
        $session['failed'] += $batchFailed;
        $session['updated_at'] = date('Y-m-d H:i:s');
        
        if ($result['remaining'] === 0) {
            $session['status'] = 'completed';
            $session['completed_at'] = date('Y-m-d H:i:s');
        }
        
        $this->saveSession($session);
        
        $this->jsonResponse([
            'success' => true,
            'batch' => [
                'processed' => $result['processed'],
                'success' => $batchSuccess,
                'failed' => $batchFailed
            ],
            'session' => $session,
            'results' => $result['results'] // opcjonalnie - wyniki tej partii
        ]);
    }
    
    /**
     * Pobierz wyniki
     */
    private function download(): void
    {
        if (!file_exists($this->outputFile)) {
            $this->jsonResponse(['error' => 'Brak wyników do pobrania'], 404);
            return;
        }
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="wzbogacone_firmy_' . date('Y-m-d_His') . '.csv"');
        header('Content-Length: ' . filesize($this->outputFile));
        
        readfile($this->outputFile);
        exit;
    }
    
    /**
     * Reset sesji
     */
    private function reset(): void
    {
        $files = [$this->sessionFile, $this->inputFile, $this->outputFile];
        foreach ($files as $file) {
            if (file_exists($file)) {
                unlink($file);
            }
        }
        
        $this->jsonResponse(['success' => true, 'message' => 'Sesja zresetowana']);
    }
    
    /**
     * Parsowanie CSV
     */
    private function parseCSV(string $filepath): array
    {
        $companies = [];
        $handle = fopen($filepath, 'r');
        
        // Wykryj separator
        $firstLine = fgets($handle);
        rewind($handle);
        $separator = strpos($firstLine, ';') !== false ? ';' : ',';
        
        $headers = fgetcsv($handle, 0, $separator);
        
        while (($row = fgetcsv($handle, 0, $separator)) !== false) {
            if (count($row) >= 2) {
                $company = [];
                foreach ($headers as $i => $header) {
                    $company[$header] = $row[$i] ?? null;
                }
                $companies[] = $company;
            }
        }
        
        fclose($handle);
        return $companies;
    }
    
    /**
     * Pomocnicze metody
     */
    private function loadSession(): array
    {
        if (file_exists($this->sessionFile)) {
            return json_decode(file_get_contents($this->sessionFile), true);
        }
        return [
            'status' => 'idle',
            'total' => 0,
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'offset' => 0
        ];
    }
    
    private function saveSession(array $session): void
    {
        file_put_contents($this->sessionFile, json_encode($session, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    }
    
    private function jsonResponse(array $data, int $code = 200): void
    {
        http_response_code($code);
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }
}

// Uruchomienie
if (php_sapi_name() !== 'cli') {
    $controller = new EnrichController();
    $controller->handle();
}
