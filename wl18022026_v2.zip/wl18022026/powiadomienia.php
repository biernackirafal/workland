<?php
/**
 * Podgląd i wysyłanie powiadomień
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

if (!isAdmin()) {
    header('Location: index.php?msg=noperm');
    exit;
}

$currentUser = getCurrentUser();

// Konfiguracja
$daysWarning = 30;
$warningDate = date('Y-m-d', strtotime('+' . $daysWarning . ' days'));
$today = date('Y-m-d');

// Pobierz pracowników z kończącymi się terminami
$alerts = [];

// Badania lekarskie
$stmt = $db->prepare("SELECT id, kod, imie, nazwisko, badania_lekarskie as termin, 'Badania lekarskie' as typ 
    FROM pracownicy 
    WHERE badania_lekarskie IS NOT NULL AND badania_lekarskie != '' AND badania_lekarskie <= ? 
    AND (data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > ?)
    ORDER BY badania_lekarskie");
$stmt->execute([$warningDate, $today]);
$alerts = array_merge($alerts, $stmt->fetchAll());

// BHP
$stmt = $db->prepare("SELECT id, kod, imie, nazwisko, szkolenie_bhp as termin, 'Szkolenie BHP' as typ 
    FROM pracownicy 
    WHERE szkolenie_bhp IS NOT NULL AND szkolenie_bhp != '' AND szkolenie_bhp <= ? 
    AND (data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > ?)
    ORDER BY szkolenie_bhp");
$stmt->execute([$warningDate, $today]);
$alerts = array_merge($alerts, $stmt->fetchAll());

// Zezwolenie
$stmt = $db->prepare("SELECT id, kod, imie, nazwisko, zezwolenie_do as termin, 'Zezwolenie na pracę' as typ 
    FROM pracownicy 
    WHERE zezwolenie_do IS NOT NULL AND zezwolenie_do != '' AND zezwolenie_do <= ? 
    AND (data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > ?)
    ORDER BY zezwolenie_do");
$stmt->execute([$warningDate, $today]);
$alerts = array_merge($alerts, $stmt->fetchAll());

// Pobyt
$stmt = $db->prepare("SELECT id, kod, imie, nazwisko, data_zakonczenia_pobytu as termin, 'Zakończenie pobytu' as typ 
    FROM pracownicy 
    WHERE data_zakonczenia_pobytu IS NOT NULL AND data_zakonczenia_pobytu != '' AND data_zakonczenia_pobytu <= ? 
    AND (data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > ?)
    ORDER BY data_zakonczenia_pobytu");
$stmt->execute([$warningDate, $today]);
$alerts = array_merge($alerts, $stmt->fetchAll());

// Sortuj po terminie
usort($alerts, function($a, $b) {
    return strtotime($a['termin']) - strtotime($b['termin']);
});

// Obsługa wysyłki
$message = '';
if (isset($_POST['send_email'])) {
    $output = shell_exec('php ' . __DIR__ . '/cron_powiadomienia.php 2>&1');
    if (strpos($output, 'pomyślnie') !== false) {
        $message = '<div class="alert success">✅ Email został wysłany pomyślnie!</div>';
    } else {
        $message = '<div class="alert error">❌ Błąd wysyłania: ' . htmlspecialchars($output) . '</div>';
    }
}

function daysLeft($date) {
    $diff = strtotime($date) - strtotime('today');
    $days = floor($diff / 86400);
    if ($days < 0) return ['text' => 'WYGASŁO ' . abs($days) . ' dni temu', 'class' => 'danger'];
    if ($days == 0) return ['text' => 'DZISIAJ!', 'class' => 'danger'];
    if ($days <= 7) return ['text' => $days . ' dni', 'class' => 'warning'];
    return ['text' => $days . ' dni', 'class' => 'ok'];
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Powiadomienia - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .alert-card { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .alert-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .alert-count { font-size: 2.5rem; font-weight: 700; }
        .alert-count.danger { color: #dc2626; }
        .alert-count.warning { color: #f59e0b; }
        .alert-count.ok { color: #22c55e; }
        .days-badge { padding: 5px 12px; border-radius: 20px; font-weight: 600; font-size: 0.85rem; }
        .days-badge.danger { background: #fee2e2; color: #dc2626; }
        .days-badge.warning { background: #fef3c7; color: #92400e; }
        .days-badge.ok { background: #dcfce7; color: #166534; }
        .typ-badge { padding: 3px 10px; border-radius: 4px; font-size: 0.8rem; background: #e2e8f0; color: #475569; }
        .config-info { background: #f8fafc; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .config-info code { background: #e2e8f0; padding: 2px 6px; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <img src="assets/logo.png" alt="Work Land">
                <div class="user-info">👤 <?php echo sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="index.php">📋 Pracownicy</a>
                <a href="historia.php">📜 Historia</a>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>📧 Powiadomienia email</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <?php echo $message; ?>
        
        <!-- Podsumowanie -->
        <div class="alert-card">
            <div class="alert-header">
                <div>
                    <h2 style="margin:0;">⚠️ Kończące się terminy</h2>
                    <p class="muted">Pracownicy z terminami wygasającymi w ciągu <?php echo $daysWarning; ?> dni</p>
                </div>
                <div class="alert-count <?php echo count($alerts) > 10 ? 'danger' : (count($alerts) > 0 ? 'warning' : 'ok'); ?>">
                    <?php echo count($alerts); ?>
                </div>
            </div>
            
            <?php if (!empty($alerts)): ?>
                <form method="POST" style="margin-bottom: 20px;">
                    <button type="submit" name="send_email" class="btn btn-primary" onclick="return confirm('Wysłać email z powiadomieniami na biuro@work-land.pl?')">
                        📧 Wyślij powiadomienie email teraz
                    </button>
                </form>
            <?php endif; ?>
        </div>
        
        <!-- Konfiguracja CRON -->
        <div class="config-info">
            <h3>⏰ Automatyczne powiadomienia (CRON)</h3>
            <p>Aby otrzymywać codzienne powiadomienia email, dodaj do CRON:</p>
            <code style="display:block;padding:10px;background:#1e293b;color:#22c55e;border-radius:4px;margin:10px 0;">
                0 8 * * * php <?php echo realpath(__DIR__); ?>/cron_powiadomienia.php
            </code>
            <p class="muted">Powiadomienia będą wysyłane codziennie o 8:00 na adres: <strong>biuro@work-land.pl</strong></p>
        </div>
        
        <?php if (empty($alerts)): ?>
            <div class="empty-state">
                <p>🎉 Brak kończących się terminów w najbliższych <?php echo $daysWarning; ?> dniach.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Kod</th>
                            <th>Pracownik</th>
                            <th>Typ</th>
                            <th>Termin</th>
                            <th>Pozostało</th>
                            <th>Akcje</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($alerts as $a): 
                            $days = daysLeft($a['termin']);
                        ?>
                            <tr>
                                <td><code><?php echo sanitize($a['kod']); ?></code></td>
                                <td><strong><?php echo sanitize($a['imie'] . ' ' . $a['nazwisko']); ?></strong></td>
                                <td><span class="typ-badge"><?php echo sanitize($a['typ']); ?></span></td>
                                <td><?php echo formatDate($a['termin']); ?></td>
                                <td><span class="days-badge <?php echo $days['class']; ?>"><?php echo $days['text']; ?></span></td>
                                <td>
                                    <a href="view.php?id=<?php echo $a['id']; ?>" class="btn btn-small">👁️ Karta</a>
                                    <a href="edit.php?id=<?php echo $a['id']; ?>" class="btn btn-small">✏️ Edytuj</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        
        <footer><p>Work Land © <?php echo date('Y'); ?> | v<?= WORKLAND_VERSION ?></p></footer>
    </div>
</body>
</html>
