<?php
/**
 * Generator rachunków do umów zlecenie
 * Z uwzględnieniem różnych typów zleceniobiorców (student, standard do 26, emeryt, standardowy)
 * 
 * Regulacje 2025:
 * - Składka emerytalna (pracownik): 9,76%
 * - Składka rentowa (pracownik): 1,5%
 * - Składka chorobowa (dobrowolna): 2,45%
 * - Składka zdrowotna: 9%
 * - Podatek dochodowy: 12% (do 120.000 zł/rok)
 * - Koszty uzyskania przychodu: 20% (standardowo) lub 50% (prawa autorskie)
 */

require_once 'includes/db.php';
$db = initDatabase();
requireLogin();

// Pobierz pracowników
$pracownicy = $db->query("
    SELECT id, imie, nazwisko, kod, pesel, adres
    FROM pracownicy 
    WHERE data_zwolnienia IS NULL OR data_zwolnienia = ''
    ORDER BY nazwisko, imie
")->fetchAll();

// Dane firmy
define('FIRMA_NAZWA', 'WORK LAND SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ');
define('FIRMA_NIP', '7773379790');
define('FIRMA_ADRES', 'KMINKOWA 156D/1, 62-064 PLEWISKA');

// Stawki ZUS i podatków 2025
define('STAWKA_EMERYTALNA', 0.0976);    // 9,76%
define('STAWKA_RENTOWA', 0.015);        // 1,5%
define('STAWKA_CHOROBOWA', 0.0245);     // 2,45%
define('STAWKA_ZDROWOTNA', 0.09);       // 9%
define('STAWKA_PODATKU', 0.12);         // 12%
define('KOSZTY_STANDARDOWE', 0.20);     // 20%
define('KOSZTY_AUTORSKIE', 0.50);       // 50%

// Typy zleceniobiorców
$typyZleceniobiorcy = [
    'student' => [
        'nazwa' => 'Student/uczeń do 26 lat',
        'opis' => 'Bez składek ZUS, zdrowotnej i podatku',
        'zus' => false,
        'zdrowotna' => false,
        'podatek' => false,
        'ikona' => '🎓'
    ],
    'standard_26' => [
        'nazwa' => 'Standard do 26 lat (PIT-0)',
        'opis' => 'Składki ZUS + zdrowotna, bez podatku (ulga dla młodych)',
        'zus' => true,
        'zdrowotna' => true,
        'podatek' => false,
        'ikona' => '🧑'
    ],
    'standardowy' => [
        'nazwa' => 'Standardowy (>26 lat)',
        'opis' => 'Pełne składki ZUS + zdrowotna + podatek',
        'zus' => true,
        'zdrowotna' => true,
        'podatek' => true,
        'ikona' => '👤'
    ],
    'emeryt' => [
        'nazwa' => 'Emeryt/rencista',
        'opis' => 'Składki ZUS + zdrowotna (bez FP/FGŚP)',
        'zus' => true,
        'zdrowotna' => true,
        'podatek' => true,
        'ikona' => '👴'
    ],
    'inny_tytul' => [
        'nazwa' => 'Osoba z innym tytułem do ubezpieczenia',
        'opis' => 'Tylko składka zdrowotna (np. pracuje na etacie)',
        'zus' => false,
        'zdrowotna' => true,
        'podatek' => true,
        'ikona' => '💼'
    ],
    'bez_zus_zdrow' => [
        'nazwa' => 'Bez składek (inny tytuł, bez zdrowotnej)',
        'opis' => 'Tylko podatek (składki opłacane z innego tytułu)',
        'zus' => false,
        'zdrowotna' => false,
        'podatek' => true,
        'ikona' => '📋'
    ]
];

$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];

/**
 * Oblicza rachunek dla umowy zlecenie (od brutto)
 * @param bool $zChorobowym - czy naliczać dobrowolną składkę chorobową 2,45%
 */
function obliczRachunek($brutto, $typ, $kosztyTyp = 'standardowe', $zChorobowym = true) {
    global $typyZleceniobiorcy;
    
    $config = $typyZleceniobiorcy[$typ];
    $kosztyStawka = ($kosztyTyp === 'autorskie') ? KOSZTY_AUTORSKIE : KOSZTY_STANDARDOWE;
    
    $wynik = [
        'brutto' => $brutto,
        'typ' => $typ,
        'typ_nazwa' => $config['nazwa'],
        'z_chorobowym' => $zChorobowym,
        
        // Składki ZUS (pracownik)
        'emerytalne' => 0,
        'rentowe' => 0,
        'chorobowe' => 0,
        'zus_suma' => 0,
        
        // Zdrowotna
        'zdrowotna' => 0,
        'podstawa_zdrowotnej' => 0,
        
        // Podatek
        'koszty_stawka' => $kosztyStawka * 100,
        'koszty' => 0,
        'podstawa_opodatkowania' => 0,
        'podatek' => 0,
        
        // Netto
        'netto' => 0
    ];
    
    // 1. Składki ZUS (jeśli dotyczy)
    if ($config['zus']) {
        $wynik['emerytalne'] = round($brutto * STAWKA_EMERYTALNA, 2);
        $wynik['rentowe'] = round($brutto * STAWKA_RENTOWA, 2);
        // Składka chorobowa jest DOBROWOLNA - tylko jeśli zaznaczono
        if ($zChorobowym) {
            $wynik['chorobowe'] = round($brutto * STAWKA_CHOROBOWA, 2);
        }
        $wynik['zus_suma'] = round($wynik['emerytalne'] + $wynik['rentowe'] + $wynik['chorobowe'], 2);
    }
    
    // 2. Podstawa do składki zdrowotnej = brutto - składki ZUS
    $wynik['podstawa_zdrowotnej'] = round($brutto - $wynik['zus_suma'], 2);
    
    // 3. Składka zdrowotna (jeśli dotyczy)
    if ($config['zdrowotna']) {
        $wynik['zdrowotna'] = round($wynik['podstawa_zdrowotnej'] * STAWKA_ZDROWOTNA, 2);
    }
    
    // 4. Koszty uzyskania przychodu i podatek (tylko jeśli jest podatek)
    if ($config['podatek']) {
        // Koszty od podstawy (brutto - ZUS)
        $wynik['koszty'] = round($wynik['podstawa_zdrowotnej'] * $kosztyStawka, 2);
        
        // Podstawa opodatkowania (zaokrąglona do pełnych złotych)
        $wynik['podstawa_opodatkowania'] = round($wynik['podstawa_zdrowotnej'] - $wynik['koszty'], 0);
        
        // Zaliczka na podatek (ZAOKRĄGLONA DO PEŁNYCH ZŁOTYCH!)
        $wynik['podatek'] = round($wynik['podstawa_opodatkowania'] * STAWKA_PODATKU, 0);
    }
    // Dla studenta do 26 lat (bez podatku) - koszty i podstawa = 0
    
    // 5. Netto
    $wynik['netto'] = round($brutto - $wynik['zus_suma'] - $wynik['zdrowotna'] - $wynik['podatek'], 2);
    
    return $wynik;
}

/**
 * Oblicza brutto z netto (reverse calculation)
 * Używa iteracyjnego podejścia dla dokładności
 */
function obliczBruttoZNetto($netto, $typ, $kosztyTyp = 'standardowe', $zChorobowym = true) {
    global $typyZleceniobiorcy;
    
    $config = $typyZleceniobiorcy[$typ];
    
    // Dla typu bez żadnych potrąceń: brutto = netto
    if (!$config['zus'] && !$config['zdrowotna'] && !$config['podatek']) {
        return obliczRachunek($netto, $typ, $kosztyTyp, $zChorobowym);
    }
    
    $kosztyStawka = ($kosztyTyp === 'autorskie') ? KOSZTY_AUTORSKIE : KOSZTY_STANDARDOWE;
    
    // Współczynniki - składka chorobowa tylko jeśli zaznaczona
    $chorobowaRate = $zChorobowym ? STAWKA_CHOROBOWA : 0;
    $zusRate = $config['zus'] ? (STAWKA_EMERYTALNA + STAWKA_RENTOWA + $chorobowaRate) : 0;
    $zdrowRate = $config['zdrowotna'] ? STAWKA_ZDROWOTNA : 0;
    $podRate = $config['podatek'] ? STAWKA_PODATKU : 0;
    
    // Wzór matematyczny (przybliżony):
    // netto = brutto - zus - zdrowotna - podatek
    // netto = brutto - brutto*zusRate - (brutto - brutto*zusRate)*zdrowRate - floor((brutto - brutto*zusRate)*(1-koszty))*podRate
    // 
    // Uproszczenie dla iteracji:
    // podstawa = brutto * (1 - zusRate)
    // zdrowotna = podstawa * zdrowRate
    // koszty = podstawa * kosztyStawka
    // podatek = floor(podstawa - koszty) * podRate
    // netto = brutto - brutto*zusRate - zdrowotna - podatek
    // netto = podstawa - zdrowotna - podatek
    // netto = podstawa * (1 - zdrowRate) - floor(podstawa * (1 - kosztyStawka)) * podRate
    
    // Iteracyjne rozwiązanie (Newton-Raphson style)
    // Startujemy od przybliżenia
    $brutto = $netto * 1.3; // Początkowe przybliżenie
    
    for ($i = 0; $i < 100; $i++) {
        $wynik = obliczRachunek($brutto, $typ, $kosztyTyp, $zChorobowym);
        $diff = $wynik['netto'] - $netto;
        
        if (abs($diff) < 0.01) {
            break; // Wystarczająca dokładność
        }
        
        // Dostosuj brutto
        // Przybliżony współczynnik: ile brutto zmienia się na 1 zł netto
        $wspolczynnik = 1 - $zusRate - (1 - $zusRate) * $zdrowRate - (1 - $zusRate) * (1 - $kosztyStawka) * $podRate;
        if ($wspolczynnik > 0) {
            $brutto = $brutto - $diff / $wspolczynnik;
        } else {
            $brutto = $brutto - $diff;
        }
        
        // Zabezpieczenie przed ujemnym brutto
        if ($brutto < $netto) {
            $brutto = $netto;
        }
    }
    
    // Zaokrąglij do groszy
    $brutto = round($brutto, 2);
    
    // Oblicz finalny rachunek z obliczonym brutto
    return obliczRachunek($brutto, $typ, $kosztyTyp, $zChorobowym);
}

$error = '';
$rachunek = null;

// Parametry z GET (z modułu składek)
$preloadPracownik = isset($_GET['pracownik_id']) ? (int)$_GET['pracownik_id'] : 0;
$preloadKwota = isset($_GET['kwota']) ? floatval($_GET['kwota']) : 0;
$preloadTyp = isset($_GET['typ_zleceniobiorcy']) ? $_GET['typ_zleceniobiorcy'] : '';
$preloadMiesiac = isset($_GET['miesiac']) ? (int)$_GET['miesiac'] : (int)date('m');
$preloadRok = isset($_GET['rok']) ? (int)$_GET['rok'] : (int)date('Y');
$autoDrukuj = isset($_GET['drukuj']) && $_GET['drukuj'] == '1';

// Automatyczne generowanie i drukowanie rachunku (z modułu składek)
if ($autoDrukuj && $preloadPracownik && $preloadKwota > 0) {
    $stmt = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
    $stmt->execute([$preloadPracownik]);
    $pracownik = $stmt->fetch();
    
    if ($pracownik) {
        // Pobierz typ zleceniobiorcy i koszty z karty pracownika
        $typZleceniobiorcy = $preloadTyp ?: ($pracownik['typ_zleceniobiorcy'] ?? 'standardowy');
        $kosztyTyp = $pracownik['koszty_typ'] ?? 'standardowe';
        $zChorobowym = true; // domyślnie z chorobowym
        
        // Oblicz rachunek od brutto
        $rachunek = obliczRachunek($preloadKwota, $typZleceniobiorcy, $kosztyTyp, $zChorobowym);
        
        $rachunek['kierunek'] = 'brutto';
        $rachunek['pracownik'] = $pracownik;
        $rachunek['nr_rachunku'] = sprintf('%02d/%02d/%d', 1, $preloadMiesiac, $preloadRok);
        $rachunek['data_rachunku'] = date('Y-m-d');
        $rachunek['miesiac'] = $preloadMiesiac;
        $rachunek['rok'] = $preloadRok;
        $rachunek['okres'] = sprintf('%02d/%d', $preloadMiesiac, $preloadRok);
        
        // Od razu generuj dokument do druku
        generujDokumentRachunku($rachunek, true); // true = auto-print
        exit;
    }
}

// Generowanie rachunku
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pracownikId = (int)$_POST['pracownik_id'];
    $kwota = floatval(str_replace(',', '.', $_POST['kwota'] ?? '0'));
    $kierunek = $_POST['kierunek'] ?? 'brutto'; // 'brutto' lub 'netto'
    $typZleceniobiorcy = $_POST['typ_zleceniobiorcy'] ?? 'student';
    $kosztyTyp = $_POST['koszty_typ'] ?? 'standardowe';
    $zChorobowym = isset($_POST['z_chorobowym']); // Checkbox - true jeśli zaznaczony
    $nrRachunku = sanitize($_POST['nr_rachunku'] ?? '');
    $dataRachunku = $_POST['data_rachunku'] ?? date('Y-m-d');
    $miesiac = (int)$_POST['miesiac'];
    $rok = (int)$_POST['rok'];
    
    if (!$pracownikId) {
        $error = 'Wybierz pracownika';
    } elseif ($kwota <= 0) {
        $error = 'Podaj kwotę';
    } else {
        $stmt = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
        $stmt->execute([$pracownikId]);
        $pracownik = $stmt->fetch();
        
        if ($pracownik) {
            // Oblicz rachunek w zależności od kierunku
            if ($kierunek === 'netto') {
                $rachunek = obliczBruttoZNetto($kwota, $typZleceniobiorcy, $kosztyTyp, $zChorobowym);
            } else {
                $rachunek = obliczRachunek($kwota, $typZleceniobiorcy, $kosztyTyp, $zChorobowym);
            }
            
            $rachunek['kierunek'] = $kierunek;
            $rachunek['pracownik'] = $pracownik;
            $rachunek['nr_rachunku'] = $nrRachunku ?: sprintf('%02d/%02d/%d', 1, $miesiac, $rok);
            $rachunek['data_rachunku'] = $dataRachunku;
            $rachunek['miesiac'] = $miesiac;
            $rachunek['rok'] = $rok;
            $rachunek['okres'] = sprintf('%02d/%d', $miesiac, $rok);
            
            // Jeśli generowanie dokumentu
            if (isset($_POST['generuj_dokument'])) {
                generujDokumentRachunku($rachunek);
                exit;
            }
        }
    }
}

/**
 * Generuje dokument rachunku do druku/PDF
 * @param array $r Dane rachunku
 * @param bool $autoPrint Czy automatycznie otworzyć okno drukowania
 */
function generujDokumentRachunku($r, $autoPrint = false) {
    $p = $r['pracownik'];
    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Rachunek <?= htmlspecialchars($r['nr_rachunku']) ?></title>
    <style>
        @page { size: A4; margin: 15mm; }
        @media print { .no-print { display: none !important; } }
        body { font-family: Arial, sans-serif; font-size: 10pt; margin: 0; padding: 20px; }
        h1 { text-align: center; font-size: 16pt; margin: 0 0 5px 0; }
        h2 { text-align: center; font-size: 11pt; font-weight: normal; margin: 0 0 20px 0; color: #666; }
        .header-table { width: 100%; margin-bottom: 20px; }
        .header-table td { vertical-align: top; padding: 5px; }
        .box { border: 1px solid #333; padding: 10px; min-height: 80px; }
        .box-title { font-weight: bold; margin-bottom: 5px; font-size: 9pt; color: #666; }
        .box-content { font-size: 10pt; }
        .box-content strong { display: block; margin-bottom: 3px; }
        
        table.rachunek { width: 100%; border-collapse: collapse; margin: 20px 0; }
        table.rachunek th, table.rachunek td { border: 1px solid #333; padding: 8px; text-align: left; }
        table.rachunek th { background: #f0f0f0; width: 60%; }
        table.rachunek td { text-align: right; width: 40%; }
        table.rachunek tr.suma { background: #e8f5e9; font-weight: bold; }
        table.rachunek tr.netto { background: #c8e6c9; font-weight: bold; font-size: 12pt; }
        table.rachunek tr.sekcja td { background: #f5f5f5; text-align: left; font-weight: bold; }
        
        .footer { margin-top: 40px; }
        .footer table { width: 100%; }
        .footer td { width: 50%; text-align: center; padding-top: 50px; }
        .podpis { border-top: 1px solid #333; padding-top: 5px; font-size: 9pt; display: inline-block; min-width: 200px; }
        
        .info-box { background: #fff3e0; border: 1px solid #ffb74d; padding: 10px; margin: 15px 0; font-size: 9pt; }
        .print-btn { position: fixed; top: 20px; right: 20px; padding: 12px 24px; background: #2563eb; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 14px; }
        .back-btn { position: fixed; top: 20px; left: 20px; padding: 12px 24px; background: #64748b; color: white; border-radius: 8px; text-decoration: none; font-size: 14px; }
    </style>
    <?php if ($autoPrint): ?>
    <script>
        window.onload = function() {
            setTimeout(function() { window.print(); }, 500);
        };
    </script>
    <?php endif; ?>
</head>
<body>
    <a href="javascript:history.back()" class="back-btn no-print">← Powrót</a>
    <button onclick="window.print()" class="print-btn no-print">🖨️ Drukuj</button>
    
    <h1>RACHUNEK NR <?= htmlspecialchars($r['nr_rachunku']) ?></h1>
    <h2>z dnia <?= date('d.m.Y', strtotime($r['data_rachunku'])) ?></h2>
    
    <table class="header-table">
        <tr>
            <td width="50%">
                <div class="box">
                    <div class="box-title">Wystawił:</div>
                    <div class="box-content">
                        <strong><?= htmlspecialchars(mb_strtoupper($p['imie'] . ' ' . $p['nazwisko'])) ?></strong>
                        PESEL: <?= htmlspecialchars($p['pesel']) ?><br>
                        <?= htmlspecialchars($p['adres']) ?>
                    </div>
                </div>
            </td>
            <td width="50%">
                <div class="box">
                    <div class="box-title">Wystawiono dla: Zleceniodawca</div>
                    <div class="box-content">
                        <strong><?= FIRMA_NAZWA ?></strong>
                        NIP: <?= FIRMA_NIP ?><br>
                        <?= FIRMA_ADRES ?>
                    </div>
                </div>
            </td>
        </tr>
    </table>
    
    <div class="info-box">
        <strong>Typ zleceniobiorcy:</strong> <?= htmlspecialchars($r['typ_nazwa']) ?><br>
        <strong>Okres rozliczeniowy:</strong> <?= $r['okres'] ?>
    </div>
    
    <table class="rachunek">
        <tr class="sekcja"><td colspan="2">WYNAGRODZENIE</td></tr>
        <tr><th>Wynagrodzenie brutto</th><td><?= number_format($r['brutto'], 2, ',', ' ') ?> zł</td></tr>
        
        <tr class="sekcja"><td colspan="2">SKŁADKI ZUS (PRACOWNIK)</td></tr>
        <tr><th>Ubezpieczenie emerytalne (9,76%)</th><td><?= number_format($r['emerytalne'], 2, ',', ' ') ?> zł</td></tr>
        <tr><th>Ubezpieczenie rentowe (1,5%)</th><td><?= number_format($r['rentowe'], 2, ',', ' ') ?> zł</td></tr>
        <tr><th>Ubezpieczenie chorobowe (2,45%)</th><td><?= number_format($r['chorobowe'], 2, ',', ' ') ?> zł</td></tr>
        
        <tr class="sekcja"><td colspan="2">PODATEK DOCHODOWY</td></tr>
        <tr><th>Koszty uzyskania przychodu (<?= $r['koszty_stawka'] ?>%)</th><td><?= number_format($r['koszty'], 2, ',', ' ') ?> zł</td></tr>
        <tr><th>Podstawa opodatkowania</th><td><?= number_format($r['podstawa_opodatkowania'], 2, ',', ' ') ?> zł</td></tr>
        <tr><th>Podatek (12%)</th><td><?= number_format($r['podatek'], 2, ',', ' ') ?> zł</td></tr>
        
        <tr class="sekcja"><td colspan="2">SKŁADKA ZDROWOTNA</td></tr>
        <tr><th>Ubezpieczenie zdrowotne (9%)</th><td><?= number_format($r['zdrowotna'], 2, ',', ' ') ?> zł</td></tr>
        
        <tr class="sekcja"><td colspan="2">INNE SKŁADKI PRACODAWCY</td></tr>
        <tr><th>Fundusz Pracy, Fundusz Solidarnościowy</th><td>0,00 zł</td></tr>
        <tr><th>Fundusz Gwarantowanych Świadczeń Pracowniczych</th><td>0,00 zł</td></tr>
        
        <tr class="netto"><th>WYPŁATA NETTO</th><td><?= number_format($r['netto'], 2, ',', ' ') ?> zł</td></tr>
    </table>
    
    <p>Powyższą kwotę otrzymałem gotówką/<s>przelewem</s>:</p>
    
    <div class="footer">
        <table>
            <tr>
                <td><div class="podpis">podpis zleceniobiorcy</div></td>
                <td><div class="podpis">podpis zleceniodawcy</div></td>
            </tr>
        </table>
    </div>
</body>
</html>
    <?php
}

function fmtPLN($val) {
    return number_format($val, 2, ',', ' ');
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalkulator rachunków - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        .container { max-width: 1100px; margin: 0 auto; padding: 20px; }
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); flex-wrap: wrap; gap: 10px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #16a34a; color: white; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        header p { margin: 0; color: #64748b; }
        
        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 768px) { .grid-2 { grid-template-columns: 1fr; } }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 20px; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 600; color: #374151; font-size: 0.9rem; margin-bottom: 6px; }
        .form-group input, .form-group select { width: 100%; padding: 10px 12px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 1rem; }
        .form-group input:focus, .form-group select:focus { border-color: #2563eb; outline: none; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        
        .btn { padding: 12px 24px; border-radius: 8px; font-weight: 600; font-size: 1rem; border: none; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-group { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 15px; }
        
        .alert-error { background: #fee2e2; border-left: 4px solid #dc2626; color: #991b1b; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        
        .typ-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; margin-bottom: 15px; }
        .typ-btn { padding: 12px; border: 2px solid #e2e8f0; border-radius: 10px; cursor: pointer; text-align: center; transition: all 0.2s; background: white; }
        .typ-btn:hover { border-color: #93c5fd; background: #f0f9ff; }
        .typ-btn.active { border-color: #16a34a; background: #dcfce7; }
        .typ-btn .icon { font-size: 1.5rem; display: block; margin-bottom: 5px; }
        .typ-btn .title { font-weight: 600; font-size: 0.9rem; }
        .typ-btn .desc { font-size: 0.75rem; color: #64748b; margin-top: 3px; }
        
        .wynik-table { width: 100%; border-collapse: collapse; }
        .wynik-table th, .wynik-table td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
        .wynik-table th { background: #f8fafc; font-weight: 600; width: 60%; }
        .wynik-table td { text-align: right; font-family: 'Consolas', monospace; }
        .wynik-table tr.suma { background: #dcfce7; }
        .wynik-table tr.netto { background: #bbf7d0; font-size: 1.1rem; }
        .wynik-table tr.sekcja td { background: #f1f5f9; text-align: left; font-weight: 600; font-size: 0.85rem; color: #64748b; }
        .wynik-table .zero { color: #94a3b8; }
        
        .kierunek-btns { display: flex; gap: 8px; }
        .kierunek-btn { flex: 1; padding: 8px 12px; border: 2px solid #e2e8f0; border-radius: 8px; cursor: pointer; text-align: center; transition: all 0.2s; font-size: 0.85rem; }
        .kierunek-btn:hover { border-color: #93c5fd; background: #f0f9ff; }
        .kierunek-btn.active { border-color: #2563eb; background: #dbeafe; }
        .kierunek-btn input { display: none; }
        .kierunek-btn span { display: block; }
        
        .info-box { background: #dbeafe; padding: 15px; border-radius: 8px; margin-bottom: 15px; font-size: 0.9rem; }
        .info-box h4 { margin: 0 0 8px 0; color: #1e40af; }
        .info-box ul { margin: 0; padding-left: 20px; }
        
        .checkbox-container { display: flex; align-items: center; gap: 10px; padding: 10px 12px; background: #f8fafc; border-radius: 8px; cursor: pointer; border: 2px solid #e2e8f0; transition: all 0.2s; }
        .checkbox-container:hover { border-color: #16a34a; background: #f0fdf4; }
        .checkbox-container input[type="checkbox"] { width: 20px; height: 20px; cursor: pointer; accent-color: #16a34a; }
        .checkbox-container .checkbox-label { font-weight: normal; font-size: 0.9rem; color: #374151; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="index.php"><img src="assets/logo.png" alt="Work Land"></a>
            </div>
            <div class="nav-links">
                <a href="index.php">📋 Pracownicy</a>
                <a href="delegacje/">🚗 Delegacje</a>
                <a href="lista_obecnosci_gen.php">📝 Lista obecności</a>
                <a href="rachunek_gen.php" class="active">💰 Rachunki</a>
            </div>
        </nav>
        
        <header style="margin-bottom: 25px;">
            <h1>💰 Kalkulator rachunków</h1>
            <p>Generator rachunków do umów zlecenie</p>
        </header>
        
        <?php if ($error): ?>
            <div class="alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <div class="grid-2">
            <div>
                <form method="POST" id="rachunekForm">
                    <div class="card">
                        <div class="card-header">👤 Typ zleceniobiorcy</div>
                        <div class="card-body">
                            <div class="typ-grid">
                                <?php foreach ($typyZleceniobiorcy as $key => $typ): ?>
                                <div class="typ-btn <?= (!isset($_POST['typ_zleceniobiorcy']) && $key === 'standardowy') || (isset($_POST['typ_zleceniobiorcy']) && $_POST['typ_zleceniobiorcy'] === $key) ? 'active' : '' ?>" 
                                     onclick="wybierzTyp('<?= $key ?>')">
                                    <span class="icon"><?= $typ['ikona'] ?></span>
                                    <span class="title"><?= htmlspecialchars($typ['nazwa']) ?></span>
                                    <span class="desc"><?= htmlspecialchars($typ['opis']) ?></span>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <input type="hidden" name="typ_zleceniobiorcy" id="typ_zleceniobiorcy" value="<?= $_POST['typ_zleceniobiorcy'] ?? $preloadTyp ?: 'standardowy' ?>">
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-header">📋 Dane rachunku</div>
                        <div class="card-body">
                            <?php if ($preloadPracownik && $preloadKwota): ?>
                            <div style="background: #dbeafe; padding: 10px 15px; border-radius: 6px; margin-bottom: 15px; font-size: 0.9rem;">
                                📊 Dane załadowane z modułu składek za <?= $miesiacNazwy[$preloadMiesiac] ?> <?= $preloadRok ?>
                            </div>
                            <?php endif; ?>
                            
                            <div class="form-group">
                                <label>Pracownik *</label>
                                <select name="pracownik_id" required>
                                    <option value="">-- wybierz pracownika --</option>
                                    <?php foreach ($pracownicy as $pr): 
                                        $isSelected = (isset($_POST['pracownik_id']) && $_POST['pracownik_id'] == $pr['id']) || ($preloadPracownik == $pr['id']);
                                    ?>
                                        <option value="<?= $pr['id'] ?>" <?= $isSelected ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($pr['nazwisko'] . ' ' . $pr['imie']) ?> (<?= htmlspecialchars($pr['kod']) ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Kwota (zł) *</label>
                                    <input type="text" name="kwota" value="<?= $_POST['kwota'] ?? ($preloadKwota ? number_format($preloadKwota, 2, ',', '') : '') ?>" placeholder="np. 307,69" required>
                                </div>
                                <div class="form-group">
                                    <label>Oblicz od</label>
                                    <div class="kierunek-btns">
                                        <label class="kierunek-btn <?= ($_POST['kierunek'] ?? 'brutto') === 'brutto' ? 'active' : '' ?>">
                                            <input type="radio" name="kierunek" value="brutto" <?= ($_POST['kierunek'] ?? 'brutto') === 'brutto' ? 'checked' : '' ?>>
                                            <span>📤 Brutto → Netto</span>
                                        </label>
                                        <label class="kierunek-btn <?= ($_POST['kierunek'] ?? '') === 'netto' ? 'active' : '' ?>">
                                            <input type="radio" name="kierunek" value="netto" <?= ($_POST['kierunek'] ?? '') === 'netto' ? 'checked' : '' ?>>
                                            <span>📥 Netto → Brutto</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Koszty uzyskania</label>
                                    <select name="koszty_typ">
                                        <option value="standardowe" <?= ($_POST['koszty_typ'] ?? '') !== 'autorskie' ? 'selected' : '' ?>>20% - standardowe</option>
                                        <option value="autorskie" <?= ($_POST['koszty_typ'] ?? '') === 'autorskie' ? 'selected' : '' ?>>50% - prawa autorskie</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Składka chorobowa (2,45%)</label>
                                    <label class="checkbox-container">
                                        <input type="checkbox" name="z_chorobowym" value="1" <?= isset($_POST['z_chorobowym']) || !isset($_POST['typ_zleceniobiorcy']) ? 'checked' : '' ?>>
                                        <span class="checkbox-label">Dobrowolne ubezpieczenie chorobowe</span>
                                    </label>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Miesiąc</label>
                                    <select name="miesiac">
                                        <?php for ($m = 1; $m <= 12; $m++): ?>
                                            <option value="<?= $m ?>" <?= $m == ($_POST['miesiac'] ?? $preloadMiesiac) ? 'selected' : '' ?>><?= $miesiacNazwy[$m] ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Rok</label>
                                    <select name="rok">
                                        <?php for ($y = date('Y') - 1; $y <= date('Y') + 1; $y++): ?>
                                            <option value="<?= $y ?>" <?= $y == ($_POST['rok'] ?? $preloadRok) ? 'selected' : '' ?>><?= $y ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="form-row">
                                <div class="form-group">
                                    <label>Nr rachunku</label>
                                    <input type="text" name="nr_rachunku" value="<?= $_POST['nr_rachunku'] ?? '' ?>" placeholder="np. 01/01/2026">
                                </div>
                                <div class="form-group">
                                    <label>Data rachunku</label>
                                    <input type="date" name="data_rachunku" value="<?= $_POST['data_rachunku'] ?? date('Y-m-d') ?>">
                                </div>
                            </div>
                            
                            <div class="btn-group">
                                <button type="submit" class="btn btn-primary">🧮 Oblicz</button>
                                <?php if ($rachunek): ?>
                                <button type="submit" name="generuj_dokument" value="1" class="btn btn-success">🖨️ Generuj dokument</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            
            <div>
                <?php if ($rachunek): ?>
                <div class="card">
                    <div class="card-header">📊 Wynik obliczeń</div>
                    <div class="card-body">
                        <table class="wynik-table">
                            <tr class="sekcja"><td colspan="2">WYNAGRODZENIE</td></tr>
                            <tr><th>Wynagrodzenie brutto</th><td><?= fmtPLN($rachunek['brutto']) ?> zł</td></tr>
                            
                            <tr class="sekcja"><td colspan="2">SKŁADKI ZUS (PRACOWNIK)</td></tr>
                            <tr><th>Ubezpieczenie emerytalne (9,76%)</th><td class="<?= $rachunek['emerytalne'] == 0 ? 'zero' : '' ?>"><?= fmtPLN($rachunek['emerytalne']) ?> zł</td></tr>
                            <tr><th>Ubezpieczenie rentowe (1,5%)</th><td class="<?= $rachunek['rentowe'] == 0 ? 'zero' : '' ?>"><?= fmtPLN($rachunek['rentowe']) ?> zł</td></tr>
                            <tr><th>Ubezpieczenie chorobowe (2,45%) <?= !$rachunek['z_chorobowym'] ? '<span style="color:#94a3b8;font-weight:normal">[wyłączone]</span>' : '' ?></th><td class="<?= $rachunek['chorobowe'] == 0 ? 'zero' : '' ?>"><?= fmtPLN($rachunek['chorobowe']) ?> zł</td></tr>
                            
                            <tr class="sekcja"><td colspan="2">PODATEK DOCHODOWY</td></tr>
                            <tr><th>Koszty uzyskania (<?= $rachunek['koszty_stawka'] ?>%)</th><td><?= fmtPLN($rachunek['koszty']) ?> zł</td></tr>
                            <tr><th>Podstawa opodatkowania</th><td><?= fmtPLN($rachunek['podstawa_opodatkowania']) ?> zł</td></tr>
                            <tr><th>Podatek (12%)</th><td class="<?= $rachunek['podatek'] == 0 ? 'zero' : '' ?>"><?= fmtPLN($rachunek['podatek']) ?> zł</td></tr>
                            
                            <tr class="sekcja"><td colspan="2">SKŁADKA ZDROWOTNA</td></tr>
                            <tr><th>Ubezpieczenie zdrowotne (9%)</th><td class="<?= $rachunek['zdrowotna'] == 0 ? 'zero' : '' ?>"><?= fmtPLN($rachunek['zdrowotna']) ?> zł</td></tr>
                            
                            <tr class="netto"><th>💵 WYPŁATA NETTO</th><td><strong><?= fmtPLN($rachunek['netto']) ?> zł</strong></td></tr>
                        </table>
                    </div>
                </div>
                <?php else: ?>
                <div class="card">
                    <div class="card-header">ℹ️ Informacje</div>
                    <div class="card-body">
                        <div class="info-box">
                            <h4>Typy zleceniobiorców:</h4>
                            <ul>
                                <li><strong>Student/uczeń do 26 lat</strong> - zwolniony ze składek ZUS, zdrowotnej i podatku</li>
                                <li><strong>Standard do 26 lat (PIT-0)</strong> - składki ZUS + zdrowotna, bez podatku (ulga dla młodych)</li>
                                <li><strong>Standardowy (&gt;26 lat)</strong> - pełne składki ZUS + zdrowotna + podatek</li>
                                <li><strong>Emeryt/rencista</strong> - składki ZUS + zdrowotna</li>
                                <li><strong>Z innym tytułem</strong> - np. pracuje na etacie, tylko zdrowotna</li>
                            </ul>
                        </div>
                        
                        <div class="info-box" style="background: #fef3c7;">
                            <h4>📋 Stawki 2025:</h4>
                            <ul>
                                <li>Składka emerytalna: 9,76%</li>
                                <li>Składka rentowa: 1,5%</li>
                                <li>Składka chorobowa: 2,45% (dobrowolna)</li>
                                <li>Składka zdrowotna: 9%</li>
                                <li>Podatek dochodowy: 12%</li>
                                <li>Koszty uzyskania: 20% lub 50% (prawa autorskie)</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
    function wybierzTyp(typ) {
        document.getElementById('typ_zleceniobiorcy').value = typ;
        document.querySelectorAll('.typ-btn').forEach(btn => btn.classList.remove('active'));
        event.currentTarget.classList.add('active');
    }
    
    // Obsługa przycisków kierunku
    document.querySelectorAll('.kierunek-btn input').forEach(radio => {
        radio.addEventListener('change', function() {
            document.querySelectorAll('.kierunek-btn').forEach(btn => btn.classList.remove('active'));
            this.closest('.kierunek-btn').classList.add('active');
        });
    });
    
    // Auto-wybór typu z GET
    document.addEventListener('DOMContentLoaded', function() {
        const preloadTyp = '<?= $preloadTyp ?>';
        if (preloadTyp) {
            const btn = document.querySelector('.typ-btn[onclick*="' + preloadTyp + '"]');
            if (btn) {
                document.querySelectorAll('.typ-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
            }
        }
    });
    </script>
</body>
</html>
