<?php
/**
 * Sprawdzenie dostępnych narzędzi do automatyzacji
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h2>🔍 Sprawdzenie środowiska serwera</h2>";

// PHP
echo "<h3>PHP:</h3>";
echo "Wersja: " . phpversion() . "<br>";

// Python
echo "<h3>Python:</h3>";
$python = shell_exec('which python3 2>/dev/null') ?: shell_exec('which python 2>/dev/null');
echo "Python: " . ($python ? trim($python) : "❌ Brak") . "<br>";
if ($python) {
    echo "Wersja: " . shell_exec('python3 --version 2>&1') . "<br>";
    
    // Sprawdź selenium
    $selenium = shell_exec('python3 -c "import selenium; print(selenium.__version__)" 2>&1');
    echo "Selenium: " . (strpos($selenium, 'Error') === false ? "✅ " . trim($selenium) : "❌ Brak") . "<br>";
    
    // Sprawdź playwright
    $playwright = shell_exec('python3 -c "import playwright; print(\"installed\")" 2>&1');
    echo "Playwright: " . (strpos($playwright, 'installed') !== false ? "✅" : "❌ Brak") . "<br>";
    
    // Sprawdź PyPDF2
    $pypdf = shell_exec('python3 -c "import PyPDF2; print(PyPDF2.__version__)" 2>&1');
    echo "PyPDF2: " . (strpos($pypdf, 'Error') === false ? "✅ " . trim($pypdf) : "❌ Brak") . "<br>";
    
    // Sprawdź pdfplumber
    $pdfplumber = shell_exec('python3 -c "import pdfplumber; print(\"installed\")" 2>&1');
    echo "pdfplumber: " . (strpos($pdfplumber, 'installed') !== false ? "✅" : "❌ Brak") . "<br>";
}

// Node.js
echo "<h3>Node.js:</h3>";
$node = shell_exec('which node 2>/dev/null');
echo "Node: " . ($node ? trim($node) : "❌ Brak") . "<br>";
if ($node) {
    echo "Wersja: " . shell_exec('node --version 2>&1') . "<br>";
    
    // Sprawdź puppeteer
    $puppeteer = shell_exec('npm list puppeteer 2>&1');
    echo "Puppeteer: " . (strpos($puppeteer, 'puppeteer@') !== false ? "✅" : "❌ Brak") . "<br>";
}

// Chrome/Chromium
echo "<h3>Przeglądarka:</h3>";
$chrome = shell_exec('which google-chrome 2>/dev/null') ?: shell_exec('which chromium-browser 2>/dev/null') ?: shell_exec('which chromium 2>/dev/null');
echo "Chrome/Chromium: " . ($chrome ? "✅ " . trim($chrome) : "❌ Brak") . "<br>";

// Firefox
$firefox = shell_exec('which firefox 2>/dev/null');
echo "Firefox: " . ($firefox ? "✅ " . trim($firefox) : "❌ Brak") . "<br>";

// PDF tools
echo "<h3>Narzędzia PDF:</h3>";
$pdftotext = shell_exec('which pdftotext 2>/dev/null');
echo "pdftotext: " . ($pdftotext ? "✅ " . trim($pdftotext) : "❌ Brak") . "<br>";

$pdftk = shell_exec('which pdftk 2>/dev/null');
echo "pdftk: " . ($pdftk ? "✅ " . trim($pdftk) : "❌ Brak") . "<br>";

// Wget/Curl
echo "<h3>Inne:</h3>";
echo "curl: " . (shell_exec('which curl 2>/dev/null') ? "✅" : "❌") . "<br>";
echo "wget: " . (shell_exec('which wget 2>/dev/null') ? "✅" : "❌") . "<br>";

// Możliwość instalacji
echo "<h3>Możliwość instalacji:</h3>";
echo "pip: " . (shell_exec('which pip3 2>/dev/null') ? "✅" : "❌") . "<br>";
echo "npm: " . (shell_exec('which npm 2>/dev/null') ? "✅" : "❌") . "<br>";
echo "apt (sudo): " . (shell_exec('sudo -n apt --version 2>/dev/null') ? "✅" : "❌ Brak uprawnień") . "<br>";

echo "<hr>";
echo "<h3>💡 Podsumowanie:</h3>";

$canAutomate = $chrome || $firefox;
$canParsePdf = $pdftotext || strpos($pypdf ?? '', 'Error') === false;
$hasPython = !empty($python);
$hasNode = !empty($node);

if ($canAutomate && $canParsePdf && ($hasPython || $hasNode)) {
    echo "<p style='color:green'>✅ Serwer ma wszystko co potrzebne!</p>";
} else {
    echo "<p style='color:orange'>⚠️ Brakuje niektórych narzędzi. ";
    if (!$canAutomate) echo "Brak przeglądarki headless. ";
    if (!$canParsePdf) echo "Brak parsera PDF. ";
    if (!$hasPython && !$hasNode) echo "Brak Python/Node. ";
    echo "</p>";
}
?>
