#!/usr/bin/env php
<?php
/**
 * CLI Tool - Wzbogacanie danych firm
 * 
 * Użycie:
 *   php enrich_cli.php input.csv output.csv [--batch=20] [--delay=2] [--offset=0]
 * 
 * Przykład:
 *   php enrich_cli.php prywatne_WL.csv wzbogacone.csv --batch=10
 */

require_once __DIR__ . '/CompanyEnricher.php';

// Parsowanie argumentów
$args = parseArgs($argv);

if (empty($args['input']) || $args['help']) {
    showHelp();
    exit(0);
}

// Konfiguracja
$inputFile = $args['input'];
$outputFile = $args['output'] ?? str_replace('.csv', '_wzbogacone.csv', $inputFile);
$batchSize = (int)($args['batch'] ?? 20);
$delay = (int)($args['delay'] ?? 2);
$offset = (int)($args['offset'] ?? 0);
$ceidgKey = $args['ceidg-key'] ?? getenv('CEIDG_API_KEY') ?: null;

// Sprawdź plik wejściowy
if (!file_exists($inputFile)) {
    die("❌ Plik nie istnieje: $inputFile\n");
}

echo "═══════════════════════════════════════════════════════\n";
echo "  🏢 WZBOGACANIE DANYCH FIRM - Work Land\n";
echo "═══════════════════════════════════════════════════════\n\n";

// Wczytaj CSV
$companies = loadCSV($inputFile);
$total = count($companies);

echo "📁 Plik wejściowy:  $inputFile\n";
echo "📁 Plik wyjściowy:  $outputFile\n";
echo "📊 Liczba firm:     $total\n";
echo "📦 Rozmiar partii:  $batchSize\n";
echo "⏱️  Opóźnienie:      {$delay}s\n";
echo "🔑 CEIDG API:       " . ($ceidgKey ? 'TAK' : 'NIE') . "\n";

if ($offset > 0) {
    echo "⏩ Offset:          $offset\n";
}

echo "\n";

// Inicjalizacja enrichera
$enricher = new CompanyEnricher(null, $ceidgKey);
$enricher->setDelay($delay);

// Statystyki
$stats = [
    'processed' => 0,
    'success' => 0,
    'partial' => 0,
    'failed' => 0,
    'started' => time()
];

// Nagłówki do pliku wynikowego
$isNewFile = !file_exists($outputFile) || $offset === 0;

// Główna pętla
$currentOffset = $offset;

while ($currentOffset < $total) {
    $batch = array_slice($companies, $currentOffset, $batchSize);
    $batchNum = floor($currentOffset / $batchSize) + 1;
    $totalBatches = ceil($total / $batchSize);
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    echo "📦 Partia $batchNum / $totalBatches (firmy " . ($currentOffset + 1) . "-" . min($currentOffset + $batchSize, $total) . ")\n";
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n";
    
    $batchResults = [];
    
    foreach ($batch as $i => $company) {
        $companyName = $company['Firma (nazwa)'] ?? $company['nazwa'] ?? '';
        $legalForm = $company['Forma prawna'] ?? $company['forma_prawna'] ?? '';
        
        if (empty($companyName)) continue;
        
        // Skrócona nazwa do wyświetlenia
        $displayName = mb_strlen($companyName) > 50 
            ? mb_substr($companyName, 0, 47) . '...' 
            : $companyName;
        
        echo sprintf("  [%3d] %-50s ", $currentOffset + $i + 1, $displayName);
        
        $result = $enricher->enrichCompany($companyName, $legalForm);
        $result['original_data'] = $company;
        $batchResults[] = $result;
        
        // Status
        switch ($result['status']) {
            case 'success':
                echo "✅ OK";
                $stats['success']++;
                if ($result['zrodlo']) echo " [{$result['zrodlo']}]";
                break;
            case 'partial':
                echo "🔶 Częściowe";
                $stats['partial']++;
                break;
            default:
                echo "❌ Błąd";
                $stats['failed']++;
                if ($result['error']) echo " ({$result['error']})";
        }
        
        echo "\n";
        $stats['processed']++;
        
        // Delay między firmami (nie po ostatniej)
        if ($i < count($batch) - 1) {
            sleep($delay);
        }
    }
    
    // Zapisz wyniki partii
    saveResultsToCSV($batchResults, $outputFile, !$isNewFile || $currentOffset > $offset);
    $isNewFile = false;
    
    $currentOffset += $batchSize;
    
    // Podsumowanie partii
    $elapsed = time() - $stats['started'];
    $eta = $stats['processed'] > 0 
        ? round(($total - $stats['processed']) * $elapsed / $stats['processed'] / 60, 1)
        : '?';
    
    echo "\n";
    echo "📊 Postęp: {$stats['processed']}/$total | ";
    echo "✅ {$stats['success']} | 🔶 {$stats['partial']} | ❌ {$stats['failed']} | ";
    echo "ETA: {$eta} min\n\n";
}

// Podsumowanie końcowe
$totalTime = time() - $stats['started'];
$minutes = floor($totalTime / 60);
$seconds = $totalTime % 60;

echo "═══════════════════════════════════════════════════════\n";
echo "  ✅ ZAKOŃCZONO\n";
echo "═══════════════════════════════════════════════════════\n";
echo "📊 Przetworzone:    {$stats['processed']}/$total\n";
echo "✅ Sukces:          {$stats['success']}\n";
echo "🔶 Częściowe:       {$stats['partial']}\n";
echo "❌ Błędy:           {$stats['failed']}\n";
echo "⏱️  Czas:            {$minutes}m {$seconds}s\n";
echo "📁 Wyniki zapisane: $outputFile\n";
echo "\n";

// --- FUNKCJE POMOCNICZE ---

function loadCSV(string $filepath): array
{
    $companies = [];
    $handle = fopen($filepath, 'r');
    
    // Wykryj BOM i separator
    $firstLine = fgets($handle);
    $firstLine = preg_replace('/^\xEF\xBB\xBF/', '', $firstLine); // Usuń BOM
    rewind($handle);
    
    $separator = strpos($firstLine, ';') !== false ? ';' : ',';
    
    // Pomiń BOM jeśli jest
    $bom = fread($handle, 3);
    if ($bom !== "\xEF\xBB\xBF") {
        rewind($handle);
    }
    
    $headers = fgetcsv($handle, 0, $separator);
    $headers = array_map('trim', $headers);
    
    while (($row = fgetcsv($handle, 0, $separator)) !== false) {
        if (count($row) >= 2 && !empty(trim($row[0]))) {
            $company = [];
            foreach ($headers as $i => $header) {
                $company[$header] = isset($row[$i]) ? trim($row[$i]) : null;
            }
            $companies[] = $company;
        }
    }
    
    fclose($handle);
    return $companies;
}

function saveResultsToCSV(array $results, string $filepath, bool $append): void
{
    $mode = $append ? 'a' : 'w';
    $fp = fopen($filepath, $mode);
    
    // BOM dla Excel
    if (!$append) {
        fwrite($fp, "\xEF\xBB\xBF");
        fputcsv($fp, [
            'Firma (nazwa)', 'Forma prawna', 'Adres', 'WWW', 'Email',
            'Telefon', 'NIP', 'REGON', 'KRS', 'Zarząd/Dyrekcja',
            'Oryginalny telefon', 'Oryginalny faks', 'Wielkość zatrudnienia',
            'Źródło', 'Status'
        ], ';');
    }
    
    foreach ($results as $r) {
        $orig = $r['original_data'] ?? [];
        fputcsv($fp, [
            $r['nazwa'],
            $r['forma_prawna'],
            $r['adres'],
            $r['www'],
            $r['email'],
            $r['telefon'],
            $r['nip'],
            $r['regon'],
            $r['krs'],
            $r['zarzad'],
            $orig['Ogólny numer telefonu'] ?? '',
            $orig['Ogólny numer faksu'] ?? '',
            $orig['Wielkość zatrudnienia'] ?? '',
            $r['zrodlo'],
            $r['status']
        ], ';');
    }
    
    fclose($fp);
}

function parseArgs(array $argv): array
{
    $args = [
        'input' => null,
        'output' => null,
        'batch' => 20,
        'delay' => 2,
        'offset' => 0,
        'ceidg-key' => null,
        'help' => false
    ];
    
    for ($i = 1; $i < count($argv); $i++) {
        $arg = $argv[$i];
        
        if ($arg === '-h' || $arg === '--help') {
            $args['help'] = true;
        } elseif (preg_match('/^--(\w+(?:-\w+)*)=(.+)$/', $arg, $m)) {
            $args[$m[1]] = $m[2];
        } elseif (!str_starts_with($arg, '-')) {
            if (!$args['input']) {
                $args['input'] = $arg;
            } else {
                $args['output'] = $arg;
            }
        }
    }
    
    return $args;
}

function showHelp(): void
{
    echo <<<HELP
Użycie: php enrich_cli.php <input.csv> [output.csv] [opcje]

Opcje:
  --batch=N       Rozmiar partii (domyślnie: 20)
  --delay=N       Opóźnienie między requestami w sekundach (domyślnie: 2)
  --offset=N      Rozpocznij od N-tej firmy (domyślnie: 0)
  --ceidg-key=X   Klucz API CEIDG (lub ustaw CEIDG_API_KEY)
  -h, --help      Pokaż pomoc

Przykłady:
  php enrich_cli.php firmy.csv
  php enrich_cli.php firmy.csv wynik.csv --batch=10
  php enrich_cli.php firmy.csv --offset=100 --delay=3

HELP;
}
