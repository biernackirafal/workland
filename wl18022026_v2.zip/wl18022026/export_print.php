<?php
/**
 * Generator karty pracownika do HTML (do druku)
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Pobierz dane pracownika
$stmt = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) {
    header('Location: index.php');
    exit;
}

// Pobierz aktualne oddelegowanie
$stmt = $db->prepare("SELECT o.*, k.nazwa as klient_nazwa FROM oddelegowania o 
    LEFT JOIN klienci k ON o.klient_id = k.id 
    WHERE o.pracownik_id = ? AND o.active = 1 
    ORDER BY o.data_od DESC LIMIT 1");
$stmt->execute([$id]);
$oddelegowanie = $stmt->fetch();

// Pobierz historię oddelegowań
$stmt = $db->prepare("SELECT o.*, k.nazwa as klient_nazwa FROM oddelegowania o 
    LEFT JOIN klienci k ON o.klient_id = k.id 
    WHERE o.pracownik_id = ? 
    ORDER BY o.data_od DESC");
$stmt->execute([$id]);
$oddelegowania = $stmt->fetchAll();

// Pobierz historię stawek
$stmt = $db->prepare("SELECT * FROM historia_stawek WHERE pracownik_id = ? ORDER BY rok DESC, miesiac DESC LIMIT 12");
$stmt->execute([$id]);
$historiaStawek = $stmt->fetchAll();

$nazwyMiesiecy = [1=>'Sty',2=>'Lut',3=>'Mar',4=>'Kwi',5=>'Maj',6=>'Cze',7=>'Lip',8=>'Sie',9=>'Wrz',10=>'Paź',11=>'Lis',12=>'Gru'];

// Formatowanie daty
function fd($date) {
    if (empty($date)) return '-';
    return date('d.m.Y', strtotime($date));
}

// Sprawdzanie wartości
function dv($val) {
    return !empty($val) ? htmlspecialchars($val) : '-';
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karta Pracownika - <?= htmlspecialchars($p['kod']) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: Arial, sans-serif;
            font-size: 11pt;
            line-height: 1.4;
            color: #1e293b;
            background: #f1f5f9;
        }
        
        .print-controls {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary { background: #2563eb; color: white; }
        .btn-primary:hover { background: #1d4ed8; }
        .btn-secondary { background: #64748b; color: white; }
        .btn-secondary:hover { background: #475569; }
        
        .page {
            width: 210mm;
            min-height: 297mm;
            margin: 20px auto;
            padding: 15mm;
            background: white;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        
        .header {
            text-align: center;
            padding-bottom: 15px;
            border-bottom: 3px solid #2563eb;
            margin-bottom: 20px;
        }
        
        .logo-area {
            margin-bottom: 10px;
        }
        
        .logo-area img {
            height: 40px;
        }
        
        .header h1 {
            font-size: 22pt;
            color: #1e293b;
            margin: 10px 0 5px;
        }
        
        .header .employee-code {
            font-size: 16pt;
            color: #2563eb;
            font-weight: 700;
        }
        
        .header .employee-name {
            font-size: 18pt;
            color: #1e293b;
            margin-top: 10px;
        }
        
        .section {
            margin-bottom: 20px;
            page-break-inside: avoid;
        }
        
        .section-title {
            font-size: 12pt;
            font-weight: 700;
            color: #2563eb;
            padding: 8px 12px;
            background: #eff6ff;
            border-left: 4px solid #2563eb;
            margin-bottom: 10px;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .data-table td {
            padding: 8px 10px;
            border-bottom: 1px solid #e2e8f0;
            vertical-align: top;
        }
        
        .data-table .label {
            width: 35%;
            font-weight: 600;
            color: #64748b;
            background: #f8fafc;
        }
        
        .data-table .value {
            color: #1e293b;
        }
        
        .two-columns {
            display: flex;
            gap: 20px;
        }
        
        .two-columns .section {
            flex: 1;
        }
        
        .badge {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 4px;
            font-size: 10pt;
            font-weight: 600;
        }
        
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-danger { background: #fee2e2; color: #dc2626; }
        .badge-info { background: #dbeafe; color: #1d4ed8; }
        
        .qualifications {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .qual-item {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            background: #f1f5f9;
            border-radius: 6px;
            font-size: 10pt;
        }
        
        .qual-item.yes { background: #dcfce7; color: #166534; }
        .qual-item.no { background: #f1f5f9; color: #94a3b8; }
        
        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #e2e8f0;
            text-align: center;
            color: #94a3b8;
            font-size: 9pt;
        }
        
        .notes-box {
            background: #fefce8;
            border: 1px solid #fde047;
            border-radius: 6px;
            padding: 12px;
            margin-top: 10px;
        }
        
        .delegation-current {
            background: #dcfce7;
            border: 1px solid #86efac;
            border-radius: 6px;
            padding: 12px;
            margin-bottom: 10px;
        }
        
        @media print {
            body { background: white; }
            .print-controls { display: none; }
            .page { 
                width: 100%; 
                margin: 0; 
                padding: 10mm;
                box-shadow: none;
            }
            .section { page-break-inside: avoid; }
        }
        
        @page {
            size: A4;
            margin: 10mm;
        }
    </style>
</head>
<body>
    <div class="print-controls">
        <button class="btn btn-primary" onclick="window.print()">🖨️ Drukuj / Zapisz PDF</button>
        <a href="view.php?id=<?= $id ?>" class="btn btn-secondary">← Powrót</a>
    </div>
    
    <div class="page">
        <div class="header">
            <div class="logo-area">
                <img src="assets/logo.png" alt="Work Land" onerror="this.style.display='none'">
            </div>
            <h1>KARTA PRACOWNIKA</h1>
            <div class="employee-code"><?= htmlspecialchars($p['kod']) ?></div>
            <div class="employee-name"><?= htmlspecialchars($p['imie'] . ' ' . $p['nazwisko']) ?></div>
        </div>
        
        <div class="two-columns">
            <!-- Dane podstawowe -->
            <div class="section">
                <div class="section-title">📋 Dane podstawowe</div>
                <table class="data-table">
                    <tr><td class="label">Imię</td><td class="value"><?= dv($p['imie']) ?></td></tr>
                    <tr><td class="label">Nazwisko</td><td class="value"><?= dv($p['nazwisko']) ?></td></tr>
                    <tr><td class="label">Narodowość</td><td class="value"><?= dv($p['narodowosc']) ?></td></tr>
                    <tr><td class="label">Data urodzenia</td><td class="value"><?= fd($p['data_urodzenia']) ?></td></tr>
                    <tr><td class="label">PESEL</td><td class="value"><?= dv($p['pesel']) ?></td></tr>
                    <tr><td class="label">NIP</td><td class="value"><?= dv($p['nip']) ?></td></tr>
                    <tr><td class="label">Dokument</td><td class="value"><?= dv($p['dokument_tozsamosci']) ?></td></tr>
                    <tr><td class="label">Telefon</td><td class="value"><?= dv($p['telefon']) ?></td></tr>
                </table>
            </div>
            
            <!-- Zatrudnienie -->
            <div class="section">
                <div class="section-title">💼 Zatrudnienie</div>
                <table class="data-table">
                    <tr><td class="label">Data przyjęcia</td><td class="value"><?= fd($p['data_przyjecia']) ?></td></tr>
                    <tr><td class="label">Data zwolnienia</td><td class="value"><?= fd($p['data_zwolnienia']) ?></td></tr>
                    <tr><td class="label">Stanowisko</td><td class="value"><?= dv($p['stanowisko']) ?></td></tr>
                    <tr><td class="label">Forma umowy</td><td class="value"><?= dv($p['forma_umowy']) ?></td></tr>
                    <tr><td class="label">Wymiar czasu</td><td class="value"><?= dv($p['wymiar_czasu_pracy']) ?></td></tr>
                    <tr><td class="label">Stawka</td><td class="value"><?= $p['stawka_wynagrodzenia'] ? number_format($p['stawka_wynagrodzenia'], 2, ',', ' ') . ' zł' : '-' ?></td></tr>
                    <tr><td class="label">Konto bankowe</td><td class="value"><?= dv($p['konto_bankowe']) ?></td></tr>
                </table>
            </div>
        </div>
        
        <div class="two-columns">
            <!-- Dokumenty i terminy -->
            <div class="section">
                <div class="section-title">📅 Dokumenty i terminy</div>
                <table class="data-table">
                    <?php 
                    $today = strtotime('today');
                    $badaniaClass = '';
                    if (!empty($p['badania_lekarskie'])) {
                        $badaniaDate = strtotime($p['badania_lekarskie']);
                        if ($badaniaDate < $today) $badaniaClass = 'badge badge-danger';
                        elseif ($badaniaDate < strtotime('+30 days')) $badaniaClass = 'badge badge-warning';
                    }
                    ?>
                    <tr>
                        <td class="label">Badania lekarskie do</td>
                        <td class="value"><span class="<?= $badaniaClass ?>"><?= fd($p['badania_lekarskie']) ?></span></td>
                    </tr>
                    <tr><td class="label">Szkolenie BHP do</td><td class="value"><?= fd($p['szkolenie_bhp']) ?></td></tr>
                    <tr><td class="label">Zezwolenie na pracę do</td><td class="value"><?= fd($p['zezwolenie_do']) ?></td></tr>
                    <tr><td class="label">Zakończenie pobytu</td><td class="value"><?= fd($p['data_zakonczenia_pobytu']) ?></td></tr>
                    <tr><td class="label">Grupa inwalidzka</td><td class="value"><?= dv($p['grupa_inwalidzka']) ?></td></tr>
                </table>
            </div>
            
            <!-- Adres -->
            <div class="section">
                <div class="section-title">🏠 Adres zamieszkania</div>
                <table class="data-table">
                    <tr><td class="value" style="white-space: pre-line;"><?= dv($p['adres']) ?></td></tr>
                </table>
            </div>
        </div>
        
        <!-- Kwalifikacje -->
        <div class="section">
            <div class="section-title">🎓 Kwalifikacje i uprawnienia</div>
            <div class="qualifications">
                <div class="qual-item <?= !empty($p['prawo_jazdy']) ? 'yes' : 'no' ?>">
                    <?= !empty($p['prawo_jazdy']) ? '✅' : '❌' ?> Prawo jazdy: <?= dv($p['prawo_jazdy']) ?>
                </div>
                <div class="qual-item <?= !empty($p['wozek_widlowy']) ? 'yes' : 'no' ?>">
                    <?= !empty($p['wozek_widlowy']) ? '✅' : '❌' ?> Wózek widłowy
                </div>
                <div class="qual-item <?= !empty($p['wysoki_sklad']) ? 'yes' : 'no' ?>">
                    <?= !empty($p['wysoki_sklad']) ? '✅' : '❌' ?> Wysoki skład
                </div>
            </div>
        </div>
        
        <!-- Historia stawek -->
        <?php if (!empty($historiaStawek)): ?>
        <div class="section">
            <div class="section-title">📊 Historia stawek wynagrodzenia</div>
            <table class="data-table">
                <tr style="background: #f1f5f9;">
                    <td class="label" style="width:30%">Okres</td>
                    <td class="label" style="width:30%">Stawka</td>
                    <td class="label" style="width:40%">Uwagi</td>
                </tr>
                <?php foreach ($historiaStawek as $hs): ?>
                    <tr>
                        <td class="value"><?= $nazwyMiesiecy[$hs['miesiac']] ?> <?= $hs['rok'] ?></td>
                        <td class="value"><strong><?= number_format($hs['stawka'], 2, ',', ' ') ?> zł</strong></td>
                        <td class="value"><?= htmlspecialchars($hs['uwagi']) ?: '-' ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endif; ?>
        
        <!-- Oddelegowanie -->
        <?php if ($oddelegowanie || !empty($oddelegowania)): ?>
        <div class="section">
            <div class="section-title">🏢 Oddelegowanie</div>
            <?php if ($oddelegowanie): ?>
                <div class="delegation-current">
                    <strong>Aktualnie:</strong> <?= htmlspecialchars($oddelegowanie['klient_nazwa']) ?>
                    <?php if ($oddelegowanie['stanowisko']): ?> - <?= htmlspecialchars($oddelegowanie['stanowisko']) ?><?php endif; ?>
                    <br>
                    <small>od <?= fd($oddelegowanie['data_od']) ?> <?= $oddelegowanie['data_do'] ? 'do ' . fd($oddelegowanie['data_do']) : '(bezterminowo)' ?></small>
                </div>
            <?php endif; ?>
            
            <?php if (count($oddelegowania) > 1): ?>
                <table class="data-table">
                    <tr style="background: #f1f5f9;"><td class="label">Klient</td><td class="label">Okres</td></tr>
                    <?php foreach ($oddelegowania as $o): if ($o['active']) continue; ?>
                        <tr>
                            <td class="value"><?= htmlspecialchars($o['klient_nazwa']) ?></td>
                            <td class="value"><?= fd($o['data_od']) ?> - <?= fd($o['data_do']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <!-- Uwagi -->
        <?php if (!empty($p['uwagi']) || !empty($p['notatki'])): ?>
        <div class="section">
            <div class="section-title">📝 Uwagi</div>
            <?php if (!empty($p['uwagi'])): ?>
                <p><?= nl2br(htmlspecialchars($p['uwagi'])) ?></p>
            <?php endif; ?>
            <?php if (!empty($p['notatki'])): ?>
                <div class="notes-box">
                    <strong>Notatki wewnętrzne:</strong><br>
                    <?= nl2br(htmlspecialchars($p['notatki'])) ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div class="footer">
            <p>Work Land - System Ewidencji Pracowników</p>
            <p>Wygenerowano: <?= date('d.m.Y H:i') ?> | Dokument do użytku wewnętrznego</p>
        </div>
    </div>
</body>
</html>
