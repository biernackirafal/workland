<?php
/**
 * Zarządzanie klientami (firmy do oddelegowań)
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$errors = [];
$success = '';

// Obsługa akcji
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Dodawanie klienta
    if ($action === 'add') {
        $nazwa = trim($_POST['nazwa'] ?? '');
        $adres = trim($_POST['adres'] ?? '');
        $telefon = trim($_POST['telefon'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $osoba = trim($_POST['osoba_kontaktowa'] ?? '');
        $uwagi = trim($_POST['uwagi'] ?? '');
        
        if (empty($nazwa)) {
            $errors[] = 'Nazwa klienta jest wymagana.';
        }
        
        if (empty($errors)) {
            $stmt = $db->prepare("INSERT INTO klienci (nazwa, adres, telefon, email, osoba_kontaktowa, uwagi) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$nazwa, $adres, $telefon, $email, $osoba, $uwagi]);
            
            logChange($db, 'CREATE', 'klienci', $db->lastInsertId(), "Dodano klienta: {$nazwa}");
            $success = 'Klient został dodany.';
        }
    }
    
    // Edycja klienta
    if ($action === 'edit') {
        $id = (int)$_POST['id'];
        $nazwa = trim($_POST['nazwa'] ?? '');
        $adres = trim($_POST['adres'] ?? '');
        $telefon = trim($_POST['telefon'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $osoba = trim($_POST['osoba_kontaktowa'] ?? '');
        $uwagi = trim($_POST['uwagi'] ?? '');
        
        if (empty($nazwa)) {
            $errors[] = 'Nazwa klienta jest wymagana.';
        }
        
        if (empty($errors)) {
            $stmt = $db->prepare("UPDATE klienci SET nazwa=?, adres=?, telefon=?, email=?, osoba_kontaktowa=?, uwagi=? WHERE id=?");
            $stmt->execute([$nazwa, $adres, $telefon, $email, $osoba, $uwagi, $id]);
            
            logChange($db, 'UPDATE', 'klienci', $id, "Edytowano klienta: {$nazwa}");
            $success = 'Klient został zaktualizowany.';
        }
    }
    
    // Przypisywanie pracowników do klienta
    if ($action === 'assign_workers') {
        $klient_id = (int)$_POST['klient_id'];
        $selected = $_POST['pracownicy'] ?? [];
        $stanowisko = trim($_POST['stanowisko_default'] ?? '');
        
        // Pobierz nazwę klienta
        $stmt = $db->prepare("SELECT nazwa FROM klienci WHERE id = ?");
        $stmt->execute([$klient_id]);
        $klientNazwa = $stmt->fetchColumn();
        
        // Pobierz obecnych przypisanych (aktywne oddelegowania)
        $stmt = $db->prepare("SELECT pracownik_id FROM oddelegowania WHERE klient_id = ? AND active = 1");
        $stmt->execute([$klient_id]);
        $current = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $added = 0;
        $removed = 0;
        
        // Dodaj nowych
        foreach ($selected as $pracownik_id) {
            $pracownik_id = (int)$pracownik_id;
            if (!in_array($pracownik_id, $current)) {
                // Deaktywuj poprzednie oddelegowania tego pracownika
                $db->prepare("UPDATE oddelegowania SET active = 0, data_do = ? WHERE pracownik_id = ? AND active = 1")
                   ->execute([date('Y-m-d'), $pracownik_id]);
                
                // Dodaj nowe oddelegowanie
                $stmt = $db->prepare("INSERT INTO oddelegowania (pracownik_id, klient_id, data_od, stanowisko, active) VALUES (?, ?, ?, ?, 1)");
                $stmt->execute([$pracownik_id, $klient_id, date('Y-m-d'), $stanowisko]);
                
                // Pobierz dane pracownika do logu
                $pStmt = $db->prepare("SELECT kod, imie, nazwisko FROM pracownicy WHERE id = ?");
                $pStmt->execute([$pracownik_id]);
                $pData = $pStmt->fetch();
                
                logChange($db, 'CREATE', 'oddelegowania', $db->lastInsertId(), 
                    "Oddelegowano {$pData['imie']} {$pData['nazwisko']} ({$pData['kod']}) do: {$klientNazwa}");
                $added++;
            }
        }
        
        // Usuń odznaczonych (deaktywuj oddelegowania)
        foreach ($current as $pracownik_id) {
            if (!in_array($pracownik_id, $selected)) {
                $db->prepare("UPDATE oddelegowania SET active = 0, data_do = ? WHERE pracownik_id = ? AND klient_id = ? AND active = 1")
                   ->execute([date('Y-m-d'), $pracownik_id, $klient_id]);
                
                // Pobierz dane pracownika do logu
                $pStmt = $db->prepare("SELECT kod, imie, nazwisko FROM pracownicy WHERE id = ?");
                $pStmt->execute([$pracownik_id]);
                $pData = $pStmt->fetch();
                
                logChange($db, 'UPDATE', 'oddelegowania', null, 
                    "Zakończono oddelegowanie {$pData['imie']} {$pData['nazwisko']} ({$pData['kod']}) u: {$klientNazwa}");
                $removed++;
            }
        }
        
        if ($added > 0 || $removed > 0) {
            $success = "Zaktualizowano przypisania. Dodano: {$added}, usunięto: {$removed}.";
        } else {
            $success = 'Brak zmian w przypisaniach.';
        }
        
        // Zostań w trybie edycji
        header("Location: klienci.php?edit={$klient_id}&msg=saved");
        exit;
    }
    
    // Usuwanie klienta
    if ($action === 'delete' && canDelete()) {
        $id = (int)$_POST['id'];
        
        // Sprawdź czy są oddelegowania
        $stmt = $db->prepare("SELECT COUNT(*) FROM oddelegowania WHERE klient_id = ?");
        $stmt->execute([$id]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = 'Nie można usunąć klienta - ma przypisane oddelegowania. Najpierw usuń wszystkich pracowników.';
        } else {
            $stmt = $db->prepare("SELECT nazwa FROM klienci WHERE id = ?");
            $stmt->execute([$id]);
            $klient = $stmt->fetch();
            
            $db->prepare("DELETE FROM klienci WHERE id = ?")->execute([$id]);
            logChange($db, 'DELETE', 'klienci', $id, "Usunięto klienta: {$klient['nazwa']}");
            $success = 'Klient został usunięty.';
        }
    }
}

// Komunikat z przekierowania
if (isset($_GET['msg']) && $_GET['msg'] === 'saved') {
    $success = 'Zmiany zostały zapisane.';
}

// Pobierz klientów
$klienci = $db->query("SELECT k.*, 
    (SELECT COUNT(*) FROM oddelegowania o WHERE o.klient_id = k.id AND o.active = 1) as liczba_pracownikow
    FROM klienci k WHERE k.active = 1 ORDER BY k.nazwa")->fetchAll();

// Edycja konkretnego klienta
$editKlient = null;
$przypisaniPracownicy = [];
$wszyscyPracownicy = [];

if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM klienci WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editKlient = $stmt->fetch();
    
    if ($editKlient) {
        // Pobierz przypisanych pracowników (aktywne oddelegowania)
        $stmt = $db->prepare("SELECT pracownik_id FROM oddelegowania WHERE klient_id = ? AND active = 1");
        $stmt->execute([$editKlient['id']]);
        $przypisaniPracownicy = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Pobierz wszystkich aktywnych pracowników
        $wszyscyPracownicy = $db->query("SELECT p.id, p.kod, p.imie, p.nazwisko, p.stanowisko,
            (SELECT k.nazwa FROM oddelegowania o 
             JOIN klienci k ON o.klient_id = k.id 
             WHERE o.pracownik_id = p.id AND o.active = 1 LIMIT 1) as obecny_klient
            FROM pracownicy p 
            WHERE p.data_zwolnienia IS NULL OR p.data_zwolnienia = '' OR p.data_zwolnienia > date('now')
            ORDER BY p.nazwisko, p.imie")->fetchAll();
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Klienci - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .klient-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
        }
        .klient-info h3 { margin: 0 0 10px 0; color: #1e293b; }
        .klient-info p { margin: 5px 0; color: #64748b; font-size: 0.9rem; }
        .klient-stats { text-align: right; }
        .klient-stats .count { font-size: 1.5rem; font-weight: 700; color: #2563eb; }
        .add-form { background: white; padding: 25px; border-radius: 8px; margin-bottom: 25px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        
        /* Lista pracowników */
        .workers-section { margin-top: 30px; padding-top: 20px; border-top: 2px solid #e2e8f0; }
        .workers-section h3 { margin-bottom: 15px; color: #1e293b; }
        
        .workers-list { max-height: 400px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 8px; }
        .worker-item { display: flex; align-items: center; gap: 12px; padding: 12px 15px; border-bottom: 1px solid #f1f5f9; transition: background 0.2s; cursor: pointer; }
        .worker-item:last-child { border-bottom: none; }
        .worker-item:hover { background: #f8fafc; }
        .worker-item.assigned { background: #ecfdf5; }
        .worker-item.assigned:hover { background: #d1fae5; }
        .worker-item.other-client { background: #fef3c7; }
        
        .worker-item input[type="checkbox"] { width: 20px; height: 20px; cursor: pointer; flex-shrink: 0; }
        .worker-item .worker-info { flex: 1; }
        .worker-item .worker-name { font-weight: 600; color: #1e293b; }
        .worker-item .worker-code { color: #64748b; font-size: 0.85rem; font-family: monospace; margin-left: 8px; }
        .worker-item .worker-position { color: #64748b; font-size: 0.85rem; }
        .worker-item .current-client { font-size: 0.8rem; padding: 2px 8px; background: #fef3c7; color: #92400e; border-radius: 4px; white-space: nowrap; }
        
        .workers-toolbar { display: flex; gap: 10px; margin-bottom: 15px; flex-wrap: wrap; align-items: center; }
        .workers-toolbar input[type="text"] { flex: 1; min-width: 200px; }
        .workers-counter { background: #eff6ff; padding: 8px 15px; border-radius: 6px; font-weight: 600; color: #2563eb; }
        
        .select-buttons { display: flex; gap: 8px; }
        .select-buttons button { padding: 6px 12px; font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <img src="assets/logo.png" alt="Work Land">
                <div class="user-info">
                    👤 <?php echo sanitize($currentUser['name']); ?>
                </div>
            </div>
            <div class="nav-links">
                <a href="index.php">📋 Pracownicy</a>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>🏢 Klienci (firmy)</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <?php if (!empty($errors)): ?>
            <div class="alert error"><?php foreach ($errors as $e): ?><p><?php echo $e; ?></p><?php endforeach; ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <!-- Formularz dodawania/edycji -->
        <div class="add-form">
            <h2><?php echo $editKlient ? '✏️ Edytuj klienta: ' . sanitize($editKlient['nazwa']) : '➕ Dodaj nowego klienta'; ?></h2>
            <form method="POST">
                <input type="hidden" name="action" value="<?php echo $editKlient ? 'edit' : 'add'; ?>">
                <?php if ($editKlient): ?>
                    <input type="hidden" name="id" value="<?php echo $editKlient['id']; ?>">
                <?php endif; ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label>Nazwa firmy *</label>
                        <input type="text" name="nazwa" required value="<?php echo htmlspecialchars($editKlient['nazwa'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Osoba kontaktowa</label>
                        <input type="text" name="osoba_kontaktowa" value="<?php echo htmlspecialchars($editKlient['osoba_kontaktowa'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Telefon</label>
                        <input type="text" name="telefon" value="<?php echo htmlspecialchars($editKlient['telefon'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($editKlient['email'] ?? ''); ?>">
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Adres</label>
                        <input type="text" name="adres" value="<?php echo htmlspecialchars($editKlient['adres'] ?? ''); ?>">
                    </div>
                    <div class="form-group" style="grid-column: span 2;">
                        <label>Uwagi</label>
                        <textarea name="uwagi" rows="2"><?php echo htmlspecialchars($editKlient['uwagi'] ?? ''); ?></textarea>
                    </div>
                </div>
                
                <div style="margin-top: 15px; display: flex; gap: 10px;">
                    <button type="submit" class="btn btn-primary">💾 <?php echo $editKlient ? 'Zapisz dane klienta' : 'Dodaj klienta'; ?></button>
                    <?php if ($editKlient): ?>
                        <a href="klienci.php" class="btn btn-secondary">Anuluj edycję</a>
                    <?php endif; ?>
                </div>
            </form>
            
            <?php if ($editKlient && !empty($wszyscyPracownicy)): ?>
            <!-- Sekcja przypisywania pracowników -->
            <div class="workers-section">
                <h3>👥 Przypisani pracownicy</h3>
                
                <form method="POST" id="assignForm">
                    <input type="hidden" name="action" value="assign_workers">
                    <input type="hidden" name="klient_id" value="<?php echo $editKlient['id']; ?>">
                    
                    <div class="workers-toolbar">
                        <input type="text" id="searchWorker" placeholder="🔍 Szukaj pracownika..." onkeyup="filterWorkers()">
                        <div class="form-group" style="margin: 0; min-width: 200px;">
                            <input type="text" name="stanowisko_default" placeholder="Stanowisko dla nowych">
                        </div>
                        <div class="select-buttons">
                            <button type="button" class="btn btn-small" onclick="selectAll()">✅ Zaznacz widocznych</button>
                            <button type="button" class="btn btn-small" onclick="selectNone()">❌ Odznacz wszystkich</button>
                        </div>
                        <div class="workers-counter">
                            Zaznaczono: <span id="selectedCount"><?php echo count($przypisaniPracownicy); ?></span> / <?php echo count($wszyscyPracownicy); ?>
                        </div>
                    </div>
                    
                    <div class="workers-list">
                        <?php foreach ($wszyscyPracownicy as $p): 
                            $isAssigned = in_array($p['id'], $przypisaniPracownicy);
                            $hasOtherClient = !empty($p['obecny_klient']) && !$isAssigned;
                            $itemClass = $isAssigned ? 'assigned' : ($hasOtherClient ? 'other-client' : '');
                        ?>
                            <label class="worker-item <?php echo $itemClass; ?>">
                                <input type="checkbox" name="pracownicy[]" value="<?php echo $p['id']; ?>" 
                                       <?php echo $isAssigned ? 'checked' : ''; ?>
                                       onchange="updateCounter()">
                                <div class="worker-info">
                                    <div class="worker-name">
                                        <?php echo sanitize($p['imie'] . ' ' . $p['nazwisko']); ?>
                                        <span class="worker-code"><?php echo sanitize($p['kod']); ?></span>
                                    </div>
                                    <?php if ($p['stanowisko']): ?>
                                        <div class="worker-position"><?php echo sanitize($p['stanowisko']); ?></div>
                                    <?php endif; ?>
                                </div>
                                <?php if ($hasOtherClient): ?>
                                    <span class="current-client">📍 <?php echo sanitize($p['obecny_klient']); ?></span>
                                <?php endif; ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    
                    <div style="margin-top: 15px;">
                        <button type="submit" class="btn btn-primary">💾 Zapisz przypisania pracowników</button>
                        <span class="muted" style="margin-left: 15px;">⚠️ Pracownicy z żółtym tłem są przypisani do innego klienta - zaznaczenie przeniesie ich tutaj.</span>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Lista klientów -->
        <?php if (!$editKlient): ?>
        <h2>📋 Lista klientów (<?php echo count($klienci); ?>)</h2>
        
        <?php if (empty($klienci)): ?>
            <div class="empty-state">
                <p>Brak klientów w bazie.</p>
            </div>
        <?php else: ?>
            <?php foreach ($klienci as $k): ?>
                <div class="klient-card">
                    <div class="klient-info">
                        <h3><?php echo sanitize($k['nazwa']); ?></h3>
                        <?php if ($k['osoba_kontaktowa']): ?><p>👤 <?php echo sanitize($k['osoba_kontaktowa']); ?></p><?php endif; ?>
                        <?php if ($k['telefon']): ?><p>📞 <?php echo sanitize($k['telefon']); ?></p><?php endif; ?>
                        <?php if ($k['email']): ?><p>✉️ <?php echo sanitize($k['email']); ?></p><?php endif; ?>
                        <?php if ($k['adres']): ?><p>📍 <?php echo sanitize($k['adres']); ?></p><?php endif; ?>
                    </div>
                    <div class="klient-stats">
                        <div class="count"><?php echo $k['liczba_pracownikow']; ?></div>
                        <small>pracowników</small>
                        <div style="margin-top: 10px;">
                            <a href="?edit=<?php echo $k['id']; ?>" class="btn btn-small">✏️ Edytuj</a>
                            <?php if (canDelete()): ?>
                            <form method="POST" style="display: inline;" onsubmit="return confirm('Usunąć klienta?')">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?php echo $k['id']; ?>">
                                <button type="submit" class="btn btn-small btn-danger">🗑️</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <?php endif; ?>
        
        <footer><p>Work Land © <?php echo date('Y'); ?> | v<?= WORKLAND_VERSION ?></p></footer>
    </div>
    
    <script>
    function filterWorkers() {
        const search = document.getElementById('searchWorker').value.toLowerCase();
        const items = document.querySelectorAll('.worker-item');
        
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(search) ? 'flex' : 'none';
        });
    }
    
    function selectAll() {
        document.querySelectorAll('.worker-item:not([style*="display: none"]) input[type="checkbox"]').forEach(cb => cb.checked = true);
        updateCounter();
    }
    
    function selectNone() {
        document.querySelectorAll('.worker-item input[type="checkbox"]').forEach(cb => cb.checked = false);
        updateCounter();
    }
    
    function updateCounter() {
        const count = document.querySelectorAll('.worker-item input[type="checkbox"]:checked').length;
        document.getElementById('selectedCount').textContent = count;
    }
    </script>
</body>
</html>
