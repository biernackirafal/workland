<?php
/**
 * Podgląd pracownika
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Pobierz ID pracownika
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Pobierz dane pracownika
$stmt = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) {
    header('Location: index.php');
    exit;
}

// Obsługa urlopów
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Dodawanie urlopu
    if ($action === 'add_urlop') {
        $typ = sanitize($_POST['urlop_typ'] ?? 'bezpłatny');
        $data_od = $_POST['urlop_od'] ?: null;
        $data_do = $_POST['urlop_do'] ?: null;
        $uwagi = sanitize($_POST['urlop_uwagi'] ?? '');
        
        $stmt = $db->prepare("INSERT INTO urlopy (pracownik_id, typ, data_od, data_do, uwagi) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$id, $typ, $data_od, $data_do, $uwagi]);
        
        header("Location: view.php?id=$id&msg=urlop_added");
        exit;
    }
    
    // Usuwanie urlopu
    if ($action === 'delete_urlop') {
        $urlop_id = (int)$_POST['urlop_id'];
        $db->prepare("DELETE FROM urlopy WHERE id = ? AND pracownik_id = ?")->execute([$urlop_id, $id]);
        
        header("Location: view.php?id=$id&msg=urlop_deleted");
        exit;
    }
    
    // Dodawanie stawki do historii
    if ($action === 'add_stawka') {
        $miesiac = (int)$_POST['stawka_miesiac'];
        $rok = (int)$_POST['stawka_rok'];
        $stawka = floatval(str_replace(',', '.', $_POST['stawka_kwota']));
        $uwagi = sanitize($_POST['stawka_uwagi'] ?? '');
        
        if ($miesiac >= 1 && $miesiac <= 12 && $rok >= 2000 && $stawka > 0) {
            try {
                $stmt = $db->prepare("INSERT OR REPLACE INTO historia_stawek (pracownik_id, miesiac, rok, stawka, uwagi) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$id, $miesiac, $rok, $stawka, $uwagi]);
                logChange($db, 'CREATE', 'historia_stawek', $db->lastInsertId(), "Dodano stawkę {$stawka} zł za {$miesiac}/{$rok}");
            } catch (PDOException $e) {}
        }
        
        header("Location: view.php?id=$id&msg=stawka_added");
        exit;
    }
    
    // Usuwanie stawki z historii
    if ($action === 'delete_stawka') {
        $stawka_id = (int)$_POST['stawka_id'];
        $db->prepare("DELETE FROM historia_stawek WHERE id = ? AND pracownik_id = ?")->execute([$stawka_id, $id]);
        
        header("Location: view.php?id=$id&msg=stawka_deleted");
        exit;
    }
    
    // Dodawanie oddelegowania
    if ($action === 'add_oddelegowanie') {
        $klient_id = (int)$_POST['klient_id'];
        $data_od = $_POST['oddelegowanie_od'] ?: null;
        $data_do = $_POST['oddelegowanie_do'] ?: null;
        $stanowisko = sanitize($_POST['oddelegowanie_stanowisko'] ?? '');
        $uwagi = sanitize($_POST['oddelegowanie_uwagi'] ?? '');
        
        if ($klient_id > 0) {
            // Dezaktywuj poprzednie aktywne oddelegowania
            $db->prepare("UPDATE oddelegowania SET active = 0 WHERE pracownik_id = ? AND active = 1")->execute([$id]);
            
            $stmt = $db->prepare("INSERT INTO oddelegowania (pracownik_id, klient_id, data_od, data_do, stanowisko, uwagi, active) VALUES (?, ?, ?, ?, ?, ?, 1)");
            $stmt->execute([$id, $klient_id, $data_od, $data_do, $stanowisko, $uwagi]);
            
            logChange($db, 'CREATE', 'oddelegowania', $db->lastInsertId(), "Oddelegowano pracownika {$p['imie']} {$p['nazwisko']}");
        }
        
        header("Location: view.php?id=$id&msg=oddelegowanie_added");
        exit;
    }
    
    // Edycja oddelegowania (aktualizacja daty do)
    if ($action === 'edit_oddelegowanie') {
        $oddelegowanie_id = (int)$_POST['oddelegowanie_id'];
        $data_do = $_POST['edit_data_do'] ?: null;
        
        $stmt = $db->prepare("UPDATE oddelegowania SET data_do = ? WHERE id = ? AND pracownik_id = ?");
        $stmt->execute([$data_do, $oddelegowanie_id, $id]);
        
        // Jeśli data_do jest ustawiona i jest w przeszłości, deaktywuj oddelegowanie
        if ($data_do && $data_do <= date('Y-m-d')) {
            $db->prepare("UPDATE oddelegowania SET active = 0 WHERE id = ?")->execute([$oddelegowanie_id]);
        }
        
        logChange($db, 'UPDATE', 'oddelegowania', $oddelegowanie_id, "Zmieniono datę końca oddelegowania");
        
        header("Location: view.php?id=$id&msg=oddelegowanie_updated");
        exit;
    }
    
    // Usuwanie oddelegowania
    if ($action === 'delete_oddelegowanie') {
        $oddelegowanie_id = (int)$_POST['oddelegowanie_id'];
        $db->prepare("DELETE FROM oddelegowania WHERE id = ? AND pracownik_id = ?")->execute([$oddelegowanie_id, $id]);
        
        header("Location: view.php?id=$id&msg=oddelegowanie_deleted");
        exit;
    }
    
    // Upload pliku (stary - pojedynczy)
    if ($action === 'upload_plik' && isset($_FILES['plik']) && $_FILES['plik']['error'] === UPLOAD_ERR_OK) {
        $typ = sanitize($_POST['plik_typ'] ?? 'inny');
        $nazwa = sanitize($_POST['plik_nazwa'] ?? $_FILES['plik']['name']);
        
        $uploadDir = __DIR__ . '/data/uploads/' . $id . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $ext = pathinfo($_FILES['plik']['name'], PATHINFO_EXTENSION);
        $fileName = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', $_FILES['plik']['name']);
        $filePath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['plik']['tmp_name'], $filePath)) {
            $stmt = $db->prepare("INSERT INTO pliki_pracownika (pracownik_id, nazwa, typ, nazwa_pliku, rozmiar) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$id, $nazwa, $typ, $fileName, $_FILES['plik']['size']]);
            
            logChange($db, 'CREATE', 'pliki_pracownika', $db->lastInsertId(), "Dodano plik: {$nazwa}");
        }
        
        header("Location: view.php?id=$id&msg=plik_added");
        exit;
    }
    
    // Upload wielu plików
    if ($action === 'upload_pliki' && !empty($_FILES['pliki']['name'][0])) {
        $uploadDir = __DIR__ . '/data/uploads/' . $id . '/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        $uploadedCount = 0;
        foreach ($_FILES['pliki']['name'] as $index => $originalName) {
            if ($_FILES['pliki']['error'][$index] === UPLOAD_ERR_OK && !empty($originalName)) {
                $tmpName = $_FILES['pliki']['tmp_name'][$index];
                $fileSize = $_FILES['pliki']['size'][$index];
                $typ = sanitize($_POST['pliki_typ'][$index] ?? 'inny');
                $nazwa = sanitize($_POST['pliki_nazwa'][$index] ?? '') ?: $originalName;
                
                $fileName = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', $originalName);
                $filePath = $uploadDir . $fileName;
                
                if (move_uploaded_file($tmpName, $filePath)) {
                    $stmt = $db->prepare("INSERT INTO pliki_pracownika (pracownik_id, nazwa, typ, nazwa_pliku, rozmiar) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$id, $nazwa, $typ, $fileName, $fileSize]);
                    
                    logChange($db, 'CREATE', 'pliki_pracownika', $db->lastInsertId(), "Dodano plik: {$nazwa}");
                    $uploadedCount++;
                }
            }
        }
        
        header("Location: view.php?id=$id&msg=pliki_added&count=$uploadedCount");
        exit;
    }
    
    // Usuwanie pliku
    if ($action === 'delete_plik') {
        $plik_id = (int)$_POST['plik_id'];
        
        $stmt = $db->prepare("SELECT nazwa_pliku FROM pliki_pracownika WHERE id = ? AND pracownik_id = ?");
        $stmt->execute([$plik_id, $id]);
        $plik = $stmt->fetch();
        
        if ($plik) {
            $filePath = __DIR__ . '/data/uploads/' . $id . '/' . $plik['nazwa_pliku'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
            $db->prepare("DELETE FROM pliki_pracownika WHERE id = ?")->execute([$plik_id]);
        }
        
        header("Location: view.php?id=$id&msg=plik_deleted");
        exit;
    }
    
    // Aktualizacja typu pliku
    if ($action === 'update_plik_typ') {
        $plik_id = (int)$_POST['plik_id'];
        $nowy_typ = sanitize($_POST['nowy_typ'] ?? 'inny');
        
        $stmt = $db->prepare("UPDATE pliki_pracownika SET typ = ? WHERE id = ? AND pracownik_id = ?");
        $stmt->execute([$nowy_typ, $plik_id, $id]);
        
        logChange($db, 'UPDATE', 'pliki_pracownika', $plik_id, "Zmieniono typ pliku na: {$nowy_typ}");
        
        header("Location: view.php?id=$id&msg=plik_updated");
        exit;
    }
    
    // Usuwanie pracownika
    if (isset($_POST['delete']) && $_POST['delete'] === 'confirm') {
        if (canDelete()) {
            // Zapisz dane do logu przed usunięciem
            logChange($db, 'DELETE', 'pracownicy', $id, 
                "Usunięto pracownika: {$p['imie']} {$p['nazwisko']} (kod: {$p['kod']})", 
                $p, null);
            
            $stmt = $db->prepare("DELETE FROM pracownicy WHERE id = ?");
            $stmt->execute([$id]);
            header('Location: index.php?msg=deleted');
            exit;
        }
    }
}

// Pobierz urlopy pracownika
$urlopy = $db->prepare("SELECT * FROM urlopy WHERE pracownik_id = ? ORDER BY data_od DESC");
$urlopy->execute([$id]);
$urlopy = $urlopy->fetchAll();

// Pobierz oddelegowania pracownika
$oddelegowania = $db->prepare("SELECT o.*, k.nazwa as klient_nazwa FROM oddelegowania o 
    LEFT JOIN klienci k ON o.klient_id = k.id 
    WHERE o.pracownik_id = ? ORDER BY o.data_od DESC");
$oddelegowania->execute([$id]);
$oddelegowania = $oddelegowania->fetchAll();

// Aktualne oddelegowanie (aktywne)
$aktualneOddelegowanie = null;
foreach ($oddelegowania as $o) {
    if ($o['active'] && (empty($o['data_do']) || strtotime($o['data_do']) >= strtotime('today'))) {
        $aktualneOddelegowanie = $o;
        break;
    }
}

// Pobierz listę klientów do selecta
$klienci = $db->query("SELECT id, nazwa FROM klienci WHERE active = 1 ORDER BY nazwa")->fetchAll();

// Pobierz pliki pracownika
$pliki = $db->prepare("SELECT * FROM pliki_pracownika WHERE pracownik_id = ? ORDER BY created_at DESC");
$pliki->execute([$id]);
$pliki = $pliki->fetchAll();

// Pobierz historię stawek pracownika
$historiaStawek = $db->prepare("SELECT * FROM historia_stawek WHERE pracownik_id = ? ORDER BY rok DESC, miesiac DESC");
$historiaStawek->execute([$id]);
$historiaStawek = $historiaStawek->fetchAll();

// Pobierz rozliczenia miesięczne pracownika
$rozliczenia = $db->prepare("SELECT * FROM rozliczenia_miesieczne WHERE pracownik_id = ? ORDER BY rok DESC, miesiac DESC");
$rozliczenia->execute([$id]);
$rozliczenia = $rozliczenia->fetchAll();

// Nazwy miesięcy
$nazwyMiesiecy = [1=>'Styczeń',2=>'Luty',3=>'Marzec',4=>'Kwiecień',5=>'Maj',6=>'Czerwiec',7=>'Lipiec',8=>'Sierpień',9=>'Wrzesień',10=>'Październik',11=>'Listopad',12=>'Grudzień'];

// Komunikaty
$urlop_msg = '';
$msg = '';
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'urlop_added') $urlop_msg = '<div class="alert success">Urlop został dodany.</div>';
    if ($_GET['msg'] === 'urlop_deleted') $urlop_msg = '<div class="alert success">Urlop został usunięty.</div>';
    if ($_GET['msg'] === 'oddelegowanie_added') $msg = '<div class="alert success">Oddelegowanie zostało dodane.</div>';
    if ($_GET['msg'] === 'oddelegowanie_deleted') $msg = '<div class="alert success">Oddelegowanie zostało usunięte.</div>';
    if ($_GET['msg'] === 'plik_added') $msg = '<div class="alert success">Plik został dodany.</div>';
    if ($_GET['msg'] === 'plik_deleted') $msg = '<div class="alert success">Plik został usunięty.</div>';
}

// Funkcja do wyświetlania wartości
function displayValue($value, $type = 'text') {
    if (empty($value) || $value === null) {
        return '<span class="empty">-</span>';
    }
    
    switch ($type) {
        case 'date':
            return formatDate($value);
        case 'money':
            return formatMoney($value);
        default:
            return sanitize($value);
    }
}

// Funkcja do sprawdzania terminów
function checkDateStatus($date) {
    if (empty($date)) return '';
    
    $today = strtotime('today');
    $warning30 = strtotime('+30 days');
    $dateTs = strtotime($date);
    
    if ($dateTs < $today) return 'status-expired';
    if ($dateTs < $warning30) return 'status-warning';
    return 'status-ok';
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($p['imie'] . ' ' . $p['nazwisko']) ?> - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>👤 <?= sanitize($p['imie'] . ' ' . $p['nazwisko']) ?></h1>
            <div class="header-actions">
                <a href="export_print.php?id=<?= $id ?>" class="btn btn-secondary" target="_blank">🖨️ Drukuj kartę</a>
                <a href="edit.php?id=<?= $id ?>" class="btn btn-primary">✏️ Edytuj</a>
                <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
            </div>
        </header>
        
        <?php echo $msg; ?>
        
        <?php
        // Sprawdź kompletność danych
        $braki = [];
        if (empty($p['data_urodzenia'])) $braki[] = 'Data urodzenia';
        if (empty($p['pesel']) && empty($p['dokument_tozsamosci'])) $braki[] = 'PESEL lub dokument tożsamości';
        if (empty($p['telefon'])) $braki[] = 'Telefon kontaktowy';
        if (empty($p['adres'])) $braki[] = 'Adres zamieszkania';
        if (empty($p['data_przyjecia'])) $braki[] = 'Data przyjęcia';
        if (empty($p['forma_umowy'])) $braki[] = 'Forma umowy';
        if (empty($p['stanowisko'])) $braki[] = 'Stanowisko';
        if (empty($p['stawka_wynagrodzenia'])) $braki[] = 'Stawka wynagrodzenia';
        if (empty($p['badania_lekarskie'])) $braki[] = 'Data badań lekarskich';
        if (empty($p['szkolenie_bhp'])) $braki[] = 'Data szkolenia BHP';
        if (empty($p['konto_bankowe'])) $braki[] = 'Numer konta bankowego';
        if ($p['narodowosc'] !== 'Polska' && empty($p['zezwolenie_do'])) $braki[] = 'Zezwolenie na pracę';
        
        $kompletnosc = 100 - (count($braki) / 12 * 100);
        ?>
        
        <div class="employee-card">
            <div class="card-header">
                <div class="employee-code"><?= sanitize($p['kod']) ?></div>
                <?php if ($p['stanowisko']): ?>
                    <div class="employee-position"><?= sanitize($p['stanowisko']) ?></div>
                <?php endif; ?>
                
                <!-- Ikona informacji o kompletności -->
                <div class="completeness-info" style="margin-left: auto;">
                    <?php if (count($braki) > 0): ?>
                        <div class="info-tooltip">
                            <span class="info-icon" style="background: <?= $kompletnosc < 50 ? '#fee2e2' : ($kompletnosc < 80 ? '#fef3c7' : '#dcfce7') ?>; color: <?= $kompletnosc < 50 ? '#dc2626' : ($kompletnosc < 80 ? '#92400e' : '#166534') ?>;">
                                ℹ️ <?= round($kompletnosc) ?>%
                            </span>
                            <div class="tooltip-content">
                                <strong>Brakujące dane (<?= count($braki) ?>):</strong>
                                <ul>
                                    <?php foreach ($braki as $brak): ?>
                                        <li><?= $brak ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <a href="edit.php?id=<?= $id ?>" class="btn btn-small btn-primary" style="margin-top: 10px;">✏️ Uzupełnij dane</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <span class="info-icon" style="background: #dcfce7; color: #166534;">✅ 100%</span>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Dane podstawowe -->
            <section class="detail-section">
                <h2>📋 Dane podstawowe</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">Imię</span>
                        <span class="value"><?= displayValue($p['imie']) ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Nazwisko</span>
                        <span class="value"><?= displayValue($p['nazwisko']) ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Narodowość</span>
                        <span class="value"><?= displayValue($p['narodowosc']) ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Data urodzenia</span>
                        <span class="value"><?= displayValue($p['data_urodzenia'], 'date') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Stanowisko</span>
                        <span class="value"><?= displayValue($p['stanowisko']) ?></span>
                    </div>
                </div>
            </section>
            
            <!-- Dokumenty -->
            <section class="detail-section">
                <h2>🪪 Dokumenty tożsamości</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">PESEL</span>
                        <span class="value"><code><?= displayValue($p['pesel']) ?></code></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">NIP</span>
                        <span class="value"><code><?= displayValue($p['nip']) ?></code></span>
                    </div>
                    <div class="detail-item">
                        <span class="label"><?= ucfirst($p['dokument_typ'] ?? 'Dokument tożsamości') ?></span>
                        <span class="value"><code><?= displayValue($p['dokument_numer'] ?: $p['dokument_tozsamosci']) ?></code></span>
                    </div>
                    <?php if ($p['dane_personalne']): ?>
                        <div class="detail-item full-width">
                            <span class="label">Dane personalne</span>
                            <span class="value"><?= nl2br(displayValue($p['dane_personalne'])) ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            </section>
            
            <!-- Zatrudnienie -->
            <section class="detail-section">
                <h2>💼 Zatrudnienie</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">Data przyjęcia</span>
                        <span class="value"><?= displayValue($p['data_przyjecia'], 'date') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Data zwolnienia</span>
                        <span class="value"><?= displayValue($p['data_zwolnienia'], 'date') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Okres zatrudnienia od</span>
                        <span class="value"><?= displayValue($p['okres_zatrudnienia_od'], 'date') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Okres zatrudnienia do</span>
                        <span class="value"><?= displayValue($p['okres_zatrudnienia_do'], 'date') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Forma umowy</span>
                        <span class="value"><?= displayValue($p['forma_umowy']) ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Wymiar czasu pracy</span>
                        <span class="value"><?= displayValue($p['wymiar_czasu_pracy']) ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Typ zleceniobiorcy</span>
                        <span class="value">
                            <?php
                            $typyZlec = [
                                'student' => '🎓 Student/uczeń do 26 lat',
                                'standard_26' => '🧑 Do 26 lat (PIT-0)',
                                'standardowy' => '👤 Standardowy (>26 lat)',
                                'emeryt' => '👴 Emeryt/rencista',
                                'inny_tytul' => '💼 Inny tytuł (tylko zdrow.)',
                                'bez_zus_zdrow' => '📋 Bez składek (tylko podatek)'
                            ];
                            echo $typyZlec[$p['typ_zleceniobiorcy'] ?? 'standardowy'] ?? displayValue($p['typ_zleceniobiorcy']);
                            ?>
                        </span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Koszty uzyskania</span>
                        <span class="value">
                            <?php
                            $kosztyTypy = [
                                'standardowe' => '20% - standardowe',
                                'autorskie' => '50% - prawa autorskie'
                            ];
                            echo $kosztyTypy[$p['koszty_typ'] ?? 'standardowe'] ?? '20% - standardowe';
                            ?>
                        </span>
                    </div>
                </div>
            </section>
            
            <!-- Wynagrodzenie -->
            <section class="detail-section">
                <h2>💰 Wynagrodzenie i składki</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">Aktualna stawka</span>
                        <span class="value highlight"><?= displayValue($p['stawka_wynagrodzenia'], 'money') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Składki</span>
                        <span class="value"><?= displayValue($p['skladki']) ?><?php if($p['skladki'] && isset($p['skladki_typ'])): ?> <small>(<?= $p['skladki_typ'] ?? 'brutto' ?>)</small><?php endif; ?></span>
                    </div>
                </div>
                
                <!-- Historia stawek -->
                <div style="margin-top: 20px;">
                    <h3 style="font-size: 1rem; color: #64748b; margin-bottom: 10px;">📊 Historia stawek</h3>
                    
                    <?php if (!empty($historiaStawek)): ?>
                        <table class="urlopy-table" style="width: 100%; margin-bottom: 15px;">
                            <thead>
                                <tr>
                                    <th>Miesiąc</th>
                                    <th>Rok</th>
                                    <th>Stawka</th>
                                    <th>Uwagi</th>
                                    <th>Akcje</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($historiaStawek as $hs): ?>
                                    <tr>
                                        <td><?= $nazwyMiesiecy[$hs['miesiac']] ?></td>
                                        <td><?= $hs['rok'] ?></td>
                                        <td><strong><?= number_format($hs['stawka'], 2, ',', ' ') ?> zł</strong></td>
                                        <td><?= sanitize($hs['uwagi']) ?: '-' ?></td>
                                        <td>
                                            <form method="POST" style="display:inline;" onsubmit="return confirm('Usunąć tę stawkę?')">
                                                <input type="hidden" name="action" value="delete_stawka">
                                                <input type="hidden" name="stawka_id" value="<?= $hs['id'] ?>">
                                                <button type="submit" class="btn btn-small btn-danger">🗑️</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="muted" style="margin-bottom: 15px;">Brak historii stawek.</p>
                    <?php endif; ?>
                    
                    <!-- Formularz dodawania stawki -->
                    <details class="add-urlop-form">
                        <summary class="btn btn-small">➕ Dodaj stawkę</summary>
                        <form method="POST" style="margin-top: 15px; padding: 15px; background: #f8fafc; border-radius: 8px;">
                            <input type="hidden" name="action" value="add_stawka">
                            <div class="form-grid">
                                <div class="form-group">
                                    <label for="stawka_miesiac">Miesiąc</label>
                                    <select id="stawka_miesiac" name="stawka_miesiac" required>
                                        <?php for ($m = 1; $m <= 12; $m++): ?>
                                            <option value="<?= $m ?>" <?= $m == date('m') ? 'selected' : '' ?>><?= $nazwyMiesiecy[$m] ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="stawka_rok">Rok</label>
                                    <select id="stawka_rok" name="stawka_rok" required>
                                        <?php for ($y = date('Y') - 2; $y <= date('Y') + 1; $y++): ?>
                                            <option value="<?= $y ?>" <?= $y == date('Y') ? 'selected' : '' ?>><?= $y ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="stawka_kwota">Stawka (zł)</label>
                                    <input type="number" step="0.01" min="0" id="stawka_kwota" name="stawka_kwota" required placeholder="np. 4500.00">
                                </div>
                                <div class="form-group">
                                    <label for="stawka_uwagi">Uwagi</label>
                                    <input type="text" id="stawka_uwagi" name="stawka_uwagi" placeholder="np. podwyżka, premia...">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary" style="margin-top: 10px;">💾 Zapisz stawkę</button>
                        </form>
                    </details>
                </div>
            </section>
            
            <!-- Uwagi -->
            <?php if ($p['uwagi']): ?>
                <section class="detail-section">
                    <h2>📝 Uwagi</h2>
                    <div class="notes-box" style="background: #fef3c7; padding: 15px; border-radius: 8px; border-left: 4px solid #f59e0b;">
                        <?= nl2br(displayValue($p['uwagi'])) ?>
                    </div>
                </section>
            <?php endif; ?>
            
            <!-- Notatki wewnętrzne -->
            <?php if (!empty($p['notatki'])): ?>
            <section class="detail-section">
                <h2>📋 Notatki wewnętrzne</h2>
                <div style="background: #fffbeb; padding: 15px; border-radius: 8px; border-left: 4px solid #f59e0b;">
                    <?= nl2br(sanitize($p['notatki'])) ?>
                </div>
            </section>
            <?php endif; ?>
            
            <!-- Staż pracy -->
            <section class="detail-section">
                <h2>📊 Staż pracy</h2>
                <div class="detail-grid">
                    <?php 
                    // Oblicz staż pracy
                    $stazMiesiace = 0;
                    $stazInfo = '';
                    if (!empty($p['data_przyjecia'])) {
                        $dataPrzyjecia = new DateTime($p['data_przyjecia']);
                        $dataKoniec = !empty($p['data_zwolnienia']) ? new DateTime($p['data_zwolnienia']) : new DateTime();
                        $diff = $dataPrzyjecia->diff($dataKoniec);
                        $stazMiesiace = ($diff->y * 12) + $diff->m;
                        
                        // Formatuj ładnie
                        if ($diff->y > 0) {
                            $stazInfo = $diff->y . ' ' . ($diff->y == 1 ? 'rok' : ($diff->y < 5 ? 'lata' : 'lat'));
                            if ($diff->m > 0) {
                                $stazInfo .= ' i ' . $diff->m . ' ' . ($diff->m == 1 ? 'miesiąc' : ($diff->m < 5 ? 'miesiące' : 'miesięcy'));
                            }
                        } else {
                            $stazInfo = $diff->m . ' ' . ($diff->m == 1 ? 'miesiąc' : ($diff->m < 5 ? 'miesiące' : 'miesięcy'));
                        }
                        $stazInfo .= ' (' . $stazMiesiace . ' mies.)';
                    }
                    ?>
                    <div class="detail-item">
                        <span class="label">Staż w firmie</span>
                        <span class="value" style="font-size: 1.1rem; font-weight: 600; color: #2563eb;">
                            <?php if ($stazMiesiace > 0): ?>
                                <?= $stazInfo ?>
                            <?php else: ?>
                                <span class="muted">-</span>
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Data przyjęcia</span>
                        <span class="value"><?= displayValue($p['data_przyjecia'], 'date') ?></span>
                    </div>
                    <?php if (!empty($p['data_zwolnienia'])): ?>
                    <div class="detail-item">
                        <span class="label">Data zwolnienia</span>
                        <span class="value" style="color: #dc2626;"><?= displayValue($p['data_zwolnienia'], 'date') ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </section>
            
            <!-- Zezwolenia i badania -->
            <section class="detail-section">
                <h2>📅 Zezwolenia i badania</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">Zezwolenie na pracę do</span>
                        <span class="value <?= checkDateStatus($p['zezwolenie_do']) ?>"><?= displayValue($p['zezwolenie_do'], 'date') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Data zakończenia pobytu</span>
                        <span class="value <?= checkDateStatus($p['data_zakonczenia_pobytu']) ?>"><?= displayValue($p['data_zakonczenia_pobytu'], 'date') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Badania lekarskie do</span>
                        <span class="value <?= checkDateStatus($p['badania_lekarskie']) ?>"><?= displayValue($p['badania_lekarskie'], 'date') ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Szkolenie BHP do</span>
                        <span class="value <?= checkDateStatus($p['szkolenie_bhp']) ?>"><?= displayValue($p['szkolenie_bhp'], 'date') ?></span>
                    </div>
                </div>
            </section>
            
            <!-- Kwalifikacje i uprawnienia -->
            <section class="detail-section">
                <h2>🎓 Kwalifikacje i uprawnienia</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">Prawo jazdy</span>
                        <span class="value"><?= displayValue($p['prawo_jazdy']) ?: '<span class="muted">brak</span>' ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Wózek widłowy</span>
                        <span class="value"><?= !empty($p['wozek_widlowy']) ? '<span style="color:#16a34a;">✅ Tak</span>' : '<span class="muted">❌ Nie</span>' ?></span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Wysoki skład</span>
                        <span class="value"><?= !empty($p['wysoki_sklad']) ? '<span style="color:#16a34a;">✅ Tak</span>' : '<span class="muted">❌ Nie</span>' ?></span>
                    </div>
                </div>
            </section>
            
            <!-- Oddelegowanie -->
            <section class="detail-section">
                <h2>🏢 Oddelegowanie</h2>
                
                <?php if ($aktualneOddelegowanie): ?>
                    <div class="alert" style="background: #dbeafe; border-left: 4px solid #2563eb; padding: 15px; margin-bottom: 20px;">
                        <strong>Aktualnie pracuje u:</strong> <?= sanitize($aktualneOddelegowanie['klient_nazwa']) ?>
                        <?php if ($aktualneOddelegowanie['stanowisko']): ?>
                            <br><small>Stanowisko: <?= sanitize($aktualneOddelegowanie['stanowisko']) ?></small>
                        <?php endif; ?>
                        <?php if ($aktualneOddelegowanie['data_od']): ?>
                            <br><small>Od: <?= formatDate($aktualneOddelegowanie['data_od']) ?><?= $aktualneOddelegowanie['data_do'] ? ' do ' . formatDate($aktualneOddelegowanie['data_do']) : '' ?></small>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <p class="muted" style="margin-bottom: 15px;">Pracownik nie jest obecnie oddelegowany.</p>
                <?php endif; ?>
                
                <?php if (count($oddelegowania) > 0): ?>
                    <details style="margin-bottom: 20px;">
                        <summary style="cursor: pointer; color: #2563eb;">📋 Historia oddelegowań (<?= count($oddelegowania) ?>)</summary>
                        <table class="urlopy-table" style="width: 100%; margin-top: 10px;">
                            <thead>
                                <tr>
                                    <th>Klient</th>
                                    <th>Stanowisko</th>
                                    <th>Od</th>
                                    <th>Do</th>
                                    <th>Akcje</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($oddelegowania as $o): ?>
                                    <tr <?= $o['active'] ? 'style="background:#f0fdf4;"' : '' ?>>
                                        <td><?= sanitize($o['klient_nazwa']) ?></td>
                                        <td><?= sanitize($o['stanowisko']) ?: '-' ?></td>
                                        <td><?= formatDate($o['data_od']) ?></td>
                                        <td>
                                            <form method="POST" style="display: inline-flex; gap: 5px; align-items: center;">
                                                <input type="hidden" name="action" value="edit_oddelegowanie">
                                                <input type="hidden" name="oddelegowanie_id" value="<?= $o['id'] ?>">
                                                <input type="date" name="edit_data_do" value="<?= $o['data_do'] ?>" 
                                                       style="padding: 4px 8px; border: 1px solid #e2e8f0; border-radius: 4px; font-size: 0.85rem;"
                                                       title="Zmień datę końca">
                                                <button type="submit" class="btn btn-small" style="padding: 4px 8px; font-size: 0.75rem;" title="Zapisz datę">💾</button>
                                                <?php if (!$o['data_do']): ?>
                                                    <span class="muted" style="font-size: 0.75rem;">(bezterm.)</span>
                                                <?php endif; ?>
                                            </form>
                                        </td>
                                        <td>
                                            <form method="POST" style="display:inline;" onsubmit="return confirm('Usunąć oddelegowanie?')">
                                                <input type="hidden" name="action" value="delete_oddelegowanie">
                                                <input type="hidden" name="oddelegowanie_id" value="<?= $o['id'] ?>">
                                                <button type="submit" class="btn btn-small btn-danger">🗑️</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </details>
                <?php endif; ?>
                
                <!-- Formularz dodawania oddelegowania -->
                <details class="add-urlop-form">
                    <summary class="btn btn-small">➕ Dodaj oddelegowanie</summary>
                    <form method="POST" style="margin-top: 15px; padding: 15px; background: #f8fafc; border-radius: 8px;">
                        <input type="hidden" name="action" value="add_oddelegowanie">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="klient_id">Klient (firma) *</label>
                                <select id="klient_id" name="klient_id" required>
                                    <option value="">-- wybierz klienta --</option>
                                    <?php foreach ($klienci as $k): ?>
                                        <option value="<?= $k['id'] ?>"><?= sanitize($k['nazwa']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <small><a href="klienci.php" target="_blank">+ Dodaj nowego klienta</a></small>
                            </div>
                            <div class="form-group">
                                <label for="oddelegowanie_stanowisko">Stanowisko</label>
                                <input type="text" id="oddelegowanie_stanowisko" name="oddelegowanie_stanowisko">
                            </div>
                            <div class="form-group">
                                <label for="oddelegowanie_od">Od</label>
                                <input type="date" id="oddelegowanie_od" name="oddelegowanie_od">
                            </div>
                            <div class="form-group">
                                <label for="oddelegowanie_do">Do (opcjonalnie)</label>
                                <input type="date" id="oddelegowanie_do" name="oddelegowanie_do">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary" style="margin-top: 10px;">💾 Zapisz oddelegowanie</button>
                    </form>
                </details>
            </section>
            
            <!-- Rozliczenia miesięczne -->
            <section class="detail-section">
                <h2>📊 Rozliczenia miesięczne (składki)</h2>
                <p class="muted" style="margin-bottom: 15px;">Historia rozliczeń z modułu składek. <a href="skladki.php">Przejdź do modułu składek →</a></p>
                
                <?php if (count($rozliczenia) > 0): ?>
                    <table class="urlopy-table" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Okres</th>
                                <th>Brutto</th>
                                <th>Netto</th>
                                <th>Składki ZUS</th>
                                <th>Zdrow.</th>
                                <th>Podatek</th>
                                <th>Typ</th>
                                <th>Akcje</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($rozliczenia as $r): ?>
                                <tr>
                                    <td><strong><?= $nazwyMiesiecy[$r['miesiac']] ?> <?= $r['rok'] ?></strong></td>
                                    <td style="color: #1e40af; font-weight: 600;"><?= number_format($r['kwota_brutto'], 2, ',', ' ') ?> zł</td>
                                    <td style="color: #059669; font-weight: 600;"><?= number_format($r['kwota_netto'], 2, ',', ' ') ?> zł</td>
                                    <td>
                                        <?php 
                                        $zusSuma = $r['emerytalne'] + $r['rentowe'] + $r['chorobowe'];
                                        if ($zusSuma > 0):
                                        ?>
                                            <span title="Em: <?= number_format($r['emerytalne'], 2, ',', ' ') ?>, Rent: <?= number_format($r['rentowe'], 2, ',', ' ') ?>, Chor: <?= number_format($r['chorobowe'], 2, ',', ' ') ?>">
                                                <?= number_format($zusSuma, 2, ',', ' ') ?> zł
                                            </span>
                                        <?php else: ?>
                                            <span class="muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= $r['zdrowotna'] > 0 ? number_format($r['zdrowotna'], 2, ',', ' ') . ' zł' : '<span class="muted">—</span>' ?></td>
                                    <td><?= $r['podatek'] > 0 ? number_format($r['podatek'], 2, ',', ' ') . ' zł' : '<span class="muted">—</span>' ?></td>
                                    <td>
                                        <?php
                                        $typyZlec = [
                                            'student' => '🎓 Student',
                                            'standard_26' => '🧑 <26 PIT-0',
                                            'standardowy' => '👤 Standard',
                                            'emeryt' => '👴 Emeryt',
                                            'inny_tytul' => '💼 Inny tytuł',
                                            'bez_zus_zdrow' => '📋 Bez składek'
                                        ];
                                        echo $typyZlec[$r['typ_zleceniobiorcy']] ?? $r['typ_zleceniobiorcy'];
                                        ?>
                                    </td>
                                    <td>
                                        <a href="rachunek_gen.php?pracownik_id=<?= $id ?>&miesiac=<?= $r['miesiac'] ?>&rok=<?= $r['rok'] ?>&kwota=<?= $r['kwota_brutto'] ?>&typ_zleceniobiorcy=<?= $r['typ_zleceniobiorcy'] ?>" 
                                           class="btn btn-small" title="Generuj rachunek">📄</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state" style="padding: 30px; text-align: center; background: #f8fafc; border-radius: 8px;">
                        <p style="color: #64748b; margin-bottom: 15px;">Brak rozliczeń dla tego pracownika.</p>
                        <a href="skladki.php" class="btn btn-primary">📊 Przejdź do modułu składek</a>
                    </div>
                <?php endif; ?>
            </section>
            
            <!-- Generuj dokumenty -->
            <section class="detail-section">
                <h2>📄 Generuj dokumenty</h2>
                <p class="muted" style="margin-bottom: 15px;">Kliknij aby wygenerować dokument z danymi pracownika. Dokumenty otwierają się w nowym oknie gotowe do druku.</p>
                
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px;">
                    <a href="dokumenty_gen.php?id=<?= $id ?>&doc=akta_a" target="_blank" class="btn btn-secondary" style="text-align: center;">
                        📁 Akta osobowe A
                    </a>
                    <a href="dokumenty_gen.php?id=<?= $id ?>&doc=akta_b" target="_blank" class="btn btn-secondary" style="text-align: center;">
                        📁 Akta osobowe B
                    </a>
                    <a href="dokumenty_gen.php?id=<?= $id ?>&doc=akta_c" target="_blank" class="btn btn-secondary" style="text-align: center;">
                        📁 Akta osobowe C
                    </a>
                    <a href="dokumenty_gen.php?id=<?= $id ?>&doc=rowne_traktowanie" target="_blank" class="btn btn-secondary" style="text-align: center;">
                        ⚖️ Równe traktowanie
                    </a>
                    <a href="dokumenty_gen.php?id=<?= $id ?>&doc=rodo" target="_blank" class="btn btn-secondary" style="text-align: center;">
                        🔒 Oświadczenie RODO
                    </a>
                    <a href="dokumenty_gen.php?id=<?= $id ?>&doc=ppk" target="_blank" class="btn btn-secondary" style="text-align: center;">
                        💰 Deklaracja PPK
                    </a>
                    <a href="dokumenty_gen.php?id=<?= $id ?>&doc=umowa_zlecenie" target="_blank" class="btn btn-secondary" style="text-align: center;">
                        📝 Umowa zlecenie
                    </a>
                </div>
            </section>
            
            <!-- Pliki -->
            <section class="detail-section">
                <h2>📎 Dokumenty i pliki</h2>
                
                <?php if (count($pliki) > 0): ?>
                    <table class="urlopy-table" style="width: 100%; margin-bottom: 20px;">
                        <thead>
                            <tr>
                                <th>Nazwa</th>
                                <th>Typ</th>
                                <th>Rozmiar</th>
                                <th>Data</th>
                                <th>Akcje</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($pliki as $plik): ?>
                                <tr>
                                    <td><?= sanitize($plik['nazwa']) ?></td>
                                    <td>
                                        <form method="POST" style="display: inline-flex; gap: 5px; align-items: center;">
                                            <input type="hidden" name="action" value="update_plik_typ">
                                            <input type="hidden" name="plik_id" value="<?= $plik['id'] ?>">
                                            <select name="nowy_typ" class="typ-select" style="padding: 4px; border-radius: 4px; border: 1px solid #e2e8f0; font-size: 0.85rem;" onchange="this.form.submit()">
                                                <?php 
                                                $typy = ['dowód'=>'Dowód osobisty', 'paszport'=>'Paszport', 'zezwolenie'=>'Zezwolenie na pracę', 'badania'=>'Badania lekarskie', 'bhp'=>'Szkolenie BHP', 'sanepid'=>'Sanepid', 'umowa'=>'Umowa', 'prawo_jazdy'=>'Prawo jazdy', 'uprawnienia'=>'Uprawnienia', 'inny'=>'Inny'];
                                                foreach ($typy as $val => $label): ?>
                                                    <option value="<?= $val ?>" <?= $plik['typ'] == $val ? 'selected' : '' ?>><?= $label ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </form>
                                    </td>
                                    <td><?= round($plik['rozmiar'] / 1024) ?> KB</td>
                                    <td><?= date('d.m.Y', strtotime($plik['created_at'])) ?></td>
                                    <td>
                                        <a href="download.php?id=<?= $plik['id'] ?>" class="btn btn-small" title="Pobierz">📥</a>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Usunąć plik?')">
                                            <input type="hidden" name="action" value="delete_plik">
                                            <input type="hidden" name="plik_id" value="<?= $plik['id'] ?>">
                                            <button type="submit" class="btn btn-small btn-danger">🗑️</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="muted" style="margin-bottom: 20px;">Brak załączonych plików.</p>
                <?php endif; ?>
                
                <!-- Formularz uploadu -->
                <details class="add-urlop-form">
                    <summary class="btn btn-small">➕ Dodaj plik</summary>
                    <form method="POST" enctype="multipart/form-data" style="margin-top: 15px; padding: 15px; background: #f8fafc; border-radius: 8px;">
                        <input type="hidden" name="action" value="upload_pliki">
                        <div id="pliki-container">
                            <div class="plik-row" style="display: flex; gap: 10px; margin-bottom: 10px; align-items: flex-end;">
                                <div class="form-group" style="flex: 2; margin-bottom: 0;">
                                    <label>Plik</label>
                                    <input type="file" name="pliki[]" required>
                                </div>
                                <div class="form-group" style="flex: 1; margin-bottom: 0;">
                                    <label>Typ dokumentu</label>
                                    <select name="pliki_typ[]">
                                        <option value="dowód">Dowód osobisty</option>
                                        <option value="paszport">Paszport</option>
                                        <option value="zezwolenie">Zezwolenie na pracę</option>
                                        <option value="badania">Badania lekarskie</option>
                                        <option value="bhp">Szkolenie BHP</option>
                                        <option value="sanepid">Sanepid</option>
                                        <option value="umowa">Umowa</option>
                                        <option value="prawo_jazdy">Prawo jazdy</option>
                                        <option value="uprawnienia">Uprawnienia</option>
                                        <option value="inny" selected>Inny</option>
                                    </select>
                                </div>
                                <div class="form-group" style="flex: 1; margin-bottom: 0;">
                                    <label>Nazwa (opcjonalnie)</label>
                                    <input type="text" name="pliki_nazwa[]" placeholder="Własna nazwa">
                                </div>
                                <button type="button" class="btn btn-small btn-danger" onclick="usunPlik(this)" style="margin-bottom: 0; height: 38px;">🗑️</button>
                            </div>
                        </div>
                        <button type="button" class="btn btn-small" onclick="dodajPlik()" style="margin-top: 5px;">➕ Dodaj kolejny plik</button>
                        <div style="margin-top: 15px;">
                            <button type="submit" class="btn btn-primary">📤 Wyślij pliki</button>
                        </div>
                    </form>
                </details>
            </section>
            
            <!-- Nieobecności -->
            <section class="detail-section">
                <h2>🏥 Nieobecności</h2>
                
                <?= $urlop_msg ?>
                
                <?php if (count($urlopy) > 0): ?>
                    <table class="urlopy-table" style="width: 100%; margin-bottom: 20px;">
                        <thead>
                            <tr>
                                <th>Typ</th>
                                <th>Od</th>
                                <th>Do</th>
                                <th>Uwagi</th>
                                <th style="width: 50px;">Akcja</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($urlopy as $u): ?>
                                <tr>
                                    <td><?= sanitize($u['typ']) ?></td>
                                    <td><?= formatDate($u['data_od']) ?></td>
                                    <td><?= formatDate($u['data_do']) ?></td>
                                    <td><?= sanitize($u['uwagi']) ?: '-' ?></td>
                                    <td>
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Usunąć ten urlop?')">
                                            <input type="hidden" name="action" value="delete_urlop">
                                            <input type="hidden" name="urlop_id" value="<?= $u['id'] ?>">
                                            <button type="submit" class="btn btn-small btn-danger">🗑️</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="muted" style="margin-bottom: 20px;">Brak zarejestrowanych urlopów.</p>
                <?php endif; ?>
                
                <!-- Formularz dodawania urlopu -->
                <details class="add-urlop-form">
                    <summary class="btn btn-small">➕ Dodaj nieobecność</summary>
                    <form method="POST" style="margin-top: 15px; padding: 15px; background: #f8fafc; border-radius: 8px;">
                        <input type="hidden" name="action" value="add_urlop">
                        <div class="form-grid">
                            <div class="form-group">
                                <label for="urlop_typ">Typ nieobecności</label>
                                <select id="urlop_typ" name="urlop_typ">
                                    <option value="wypoczynkowy">Urlop wypoczynkowy</option>
                                    <option value="bezpłatny">Urlop bezpłatny</option>
                                    <option value="okolicznościowy">Urlop okolicznościowy</option>
                                    <option value="macierzyński">Urlop macierzyński</option>
                                    <option value="ojcowski">Urlop ojcowski</option>
                                    <option value="wychowawczy">Urlop wychowawczy</option>
                                    <option value="zwolnienie lekarskie">Zwolnienie lekarskie (L4)</option>
                                    <option value="usprawiedliwiona">Usprawiedliwiona nieobecność</option>
                                    <option value="nieusprawiedliwiona">Nieusprawiedliwiona nieobecność</option>
                                    <option value="opieka nad dzieckiem">Opieka nad dzieckiem</option>
                                    <option value="inny">Inny</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="urlop_od">Data od</label>
                                <input type="date" id="urlop_od" name="urlop_od" required>
                            </div>
                            <div class="form-group">
                                <label for="urlop_do">Data do</label>
                                <input type="date" id="urlop_do" name="urlop_do" required>
                            </div>
                            <div class="form-group">
                                <label for="urlop_uwagi">Uwagi</label>
                                <input type="text" id="urlop_uwagi" name="urlop_uwagi" placeholder="Opcjonalne uwagi...">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary" style="margin-top: 10px;">💾 Zapisz</button>
                    </form>
                </details>
            </section>
            
            <!-- Dodatkowe informacje -->
            <section class="detail-section">
                <h2>ℹ️ Dodatkowe informacje</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">Grupa inwalidzka</span>
                        <span class="value"><?= displayValue($p['grupa_inwalidzka']) ?></span>
                    </div>
                </div>
            </section>
            
            <!-- Dane kontaktowe -->
            <section class="detail-section">
                <h2>📍 Dane kontaktowe i bankowe</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <span class="label">Telefon</span>
                        <span class="value">
                            <?php if (!empty($p['telefon'])): ?>
                                <a href="tel:<?= sanitize($p['telefon']) ?>" style="color: #2563eb; text-decoration: none;">📞 <?= sanitize($p['telefon']) ?></a>
                            <?php else: ?>
                                <span class="empty">-</span>
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="detail-item">
                        <span class="label">E-mail</span>
                        <span class="value">
                            <?php if (!empty($p['email'])): ?>
                                <a href="mailto:<?= sanitize($p['email']) ?>" style="color: #2563eb; text-decoration: none;">✉️ <?= sanitize($p['email']) ?></a>
                            <?php else: ?>
                                <span class="empty">-</span>
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="detail-item">
                        <span class="label">Konto bankowe</span>
                        <span class="value" style="display: flex; align-items: center; gap: 10px;">
                            <?php if (!empty($p['konto_bankowe'])): ?>
                                <code id="numerKonta" style="white-space: nowrap;"><?= sanitize($p['konto_bankowe']) ?></code>
                                <button type="button" class="btn btn-small" onclick="kopiujKonto()" title="Kopiuj numer konta" style="padding: 4px 8px;">📋</button>
                            <?php else: ?>
                                <span class="empty">-</span>
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="detail-item full-width">
                        <span class="label">Adres</span>
                        <span class="value"><?= nl2br(displayValue($p['adres'])) ?></span>
                    </div>
                </div>
            </section>
            
            <!-- Metadane -->
            <section class="detail-section meta-section">
                <div class="meta-info">
                    <span>Utworzono: <?= date('d.m.Y H:i', strtotime($p['created_at'])) ?></span>
                    <span>Ostatnia aktualizacja: <?= date('d.m.Y H:i', strtotime($p['updated_at'])) ?></span>
                </div>
            </section>
        </div>
        
        <!-- Akcje -->
        <div class="action-bar">
            <a href="edit.php?id=<?= $id ?>" class="btn btn-primary">✏️ Edytuj dane</a>
            <?php if (canDelete()): ?>
            <button type="button" class="btn btn-danger" onclick="confirmDelete()">🗑️ Usuń pracownika</button>
            <?php endif; ?>
        </div>
        
        <?php if (canDelete()): ?>
        <!-- Modal usuwania -->
        <div id="deleteModal" class="modal" style="display: none;">
            <div class="modal-content">
                <h3>⚠️ Potwierdź usunięcie</h3>
                <p>Czy na pewno chcesz usunąć pracownika <strong><?= sanitize($p['imie'] . ' ' . $p['nazwisko']) ?></strong>?</p>
                <p class="warning">Ta operacja jest nieodwracalna!</p>
                <form method="POST" class="modal-actions">
                    <input type="hidden" name="delete" value="confirm">
                    <button type="submit" class="btn btn-danger">Tak, usuń</button>
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Anuluj</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
        
        <footer>
            <p>Work Land © <?= date('Y') ?> | System Ewidencji Pracowników | v<?= WORKLAND_VERSION ?> (<?= WORKLAND_VERSION_DATE ?>)</p>
        </footer>
    </div>
    
    <script>
        function confirmDelete() {
            document.getElementById('deleteModal').style.display = 'flex';
        }
        
        function closeModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }
        
        // Zamknij modal klikając poza nim
        document.getElementById('deleteModal').addEventListener('click', function(e) {
            if (e.target === this) closeModal();
        });
        
        // Funkcje do zarządzania wieloma plikami
        function dodajPlik() {
            const container = document.getElementById('pliki-container');
            const row = document.createElement('div');
            row.className = 'plik-row';
            row.style.cssText = 'display: flex; gap: 10px; margin-bottom: 10px; align-items: flex-end;';
            row.innerHTML = `
                <div class="form-group" style="flex: 2; margin-bottom: 0;">
                    <label>Plik</label>
                    <input type="file" name="pliki[]">
                </div>
                <div class="form-group" style="flex: 1; margin-bottom: 0;">
                    <label>Typ dokumentu</label>
                    <select name="pliki_typ[]">
                        <option value="dowód">Dowód osobisty</option>
                        <option value="paszport">Paszport</option>
                        <option value="zezwolenie">Zezwolenie na pracę</option>
                        <option value="badania">Badania lekarskie</option>
                        <option value="bhp">Szkolenie BHP</option>
                        <option value="sanepid">Sanepid</option>
                        <option value="umowa">Umowa</option>
                        <option value="prawo_jazdy">Prawo jazdy</option>
                        <option value="uprawnienia">Uprawnienia</option>
                        <option value="inny" selected>Inny</option>
                    </select>
                </div>
                <div class="form-group" style="flex: 1; margin-bottom: 0;">
                    <label>Nazwa (opcjonalnie)</label>
                    <input type="text" name="pliki_nazwa[]" placeholder="Własna nazwa">
                </div>
                <button type="button" class="btn btn-small btn-danger" onclick="usunPlik(this)" style="margin-bottom: 0; height: 38px;">🗑️</button>
            `;
            container.appendChild(row);
        }
        
        function usunPlik(btn) {
            const container = document.getElementById('pliki-container');
            if (container.children.length > 1) {
                btn.closest('.plik-row').remove();
            }
        }
        
        // Funkcja kopiowania numeru konta
        function kopiujKonto() {
            const konto = document.getElementById('numerKonta');
            if (konto) {
                const tekst = konto.innerText.trim();
                navigator.clipboard.writeText(tekst).then(() => {
                    // Pokaż informację o skopiowaniu
                    const btn = konto.nextElementSibling;
                    const originalText = btn.innerHTML;
                    btn.innerHTML = '✅';
                    btn.style.background = '#dcfce7';
                    setTimeout(() => {
                        btn.innerHTML = originalText;
                        btn.style.background = '';
                    }, 1500);
                }).catch(err => {
                    alert('Nie udało się skopiować: ' + err);
                });
            }
        }
    </script>
</body>
</html>
