<?php
/**
 * Raport miesięczny zatrudnionych
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Wybór miesiąca i roku
$month = isset($_GET['month']) ? (int)$_GET['month'] : (int)date('m');
$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');

if ($month < 1) $month = 1;
if ($month > 12) $month = 12;
if ($year < 2000) $year = 2000;
if ($year > 2100) $year = 2100;

// Pierwszy i ostatni dzień miesiąca
$firstDay = sprintf('%04d-%02d-01', $year, $month);
$lastDay = date('Y-m-t', strtotime($firstDay));

// Pobierz pracowników zatrudnionych w danym miesiącu
// z dołączonymi oddelegowaniami (aktywnymi) i rozliczeniami składek
$sql = "SELECT p.*,
               k.nazwa AS oddelegowanie_nazwa,
               r.tryb AS skladki_tryb,
               r.stawka_godzinowa AS skladki_stawka,
               r.liczba_godzin AS skladki_godziny,
               r.kwota_brutto AS skladki_kwota_brutto,
               r.kwota_netto AS skladki_kwota_netto,
               r.typ_kwoty AS skladki_typ_kwoty
        FROM pracownicy p
        LEFT JOIN oddelegowania o ON o.pracownik_id = p.id
            AND o.active = 1
            AND (o.data_od IS NULL OR o.data_od <= ?)
            AND (o.data_do IS NULL OR o.data_do >= ?)
        LEFT JOIN klienci k ON k.id = o.klient_id
        LEFT JOIN rozliczenia_miesieczne r ON r.pracownik_id = p.id
            AND r.miesiac = ? AND r.rok = ?
        WHERE (p.data_przyjecia IS NULL OR p.data_przyjecia = '' OR p.data_przyjecia <= ?)
        AND (p.data_zwolnienia IS NULL OR p.data_zwolnienia = '' OR p.data_zwolnienia >= ?)
        ORDER BY 
            CASE WHEN LOWER(k.nazwa) LIKE '%administracja%' THEN 0 ELSE 1 END ASC,
            k.nazwa ASC,
            p.nazwisko ASC,
            p.imie ASC";

$stmt = $db->prepare($sql);
$stmt->execute([$lastDay, $firstDay, $month, $year, $lastDay, $firstDay]);
$pracownicy = $stmt->fetchAll();

// Nazwy miesięcy po polsku
$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];

$dniTygodnia = ['Niedziela', 'Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota'];

// Funkcja obliczania stażu pracy
function obliczStaz($dataPrzyjecia, $dataZwolnienia = null) {
    if (empty($dataPrzyjecia)) return ['miesiace' => 0, 'tekst' => '-'];
    
    $start = new DateTime($dataPrzyjecia);
    $koniec = !empty($dataZwolnienia) ? new DateTime($dataZwolnienia) : new DateTime();
    $diff = $start->diff($koniec);
    
    $miesiace = ($diff->y * 12) + $diff->m;
    
    return [
        'miesiace' => $miesiace,
        'tekst' => $miesiace . ' mies.'
    ];
}

// Export do CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="raport_' . $year . '_' . str_pad($month, 2, '0', STR_PAD_LEFT) . '.csv"');
    
    echo "\xEF\xBB\xBF";
    $output = fopen('php://output', 'w');
    
    fputcsv($output, ['Lp.', 'Kod', 'Imię', 'Nazwisko', 'Narodowość', 'PESEL', 'Nr dokumentu', 'Stanowisko', 'Data przyjęcia', 'Data zwolnienia', 'Staż (mies.)', 'Stawka', 'Forma umowy', 'Składki', 'Oddelegowanie', 'Tryb/Stawka', 'Godziny', 'Kwota', 'N/B', 'Adres'], ';');
    
    $lp = 1;
    foreach ($pracownicy as $p) {
        $staz = obliczStaz($p['data_przyjecia'], $p['data_zwolnienia']);
        
        // Tryb/Stawka
        if ($p['skladki_tryb'] === 'stawka_godziny') {
            $trybStawka = number_format($p['skladki_stawka'], 2, ',', ' ') . ' zł/h';
        } elseif ($p['skladki_tryb'] === 'kwota') {
            $trybStawka = 'Kwota';
        } else {
            $trybStawka = '';
        }
        
        $kwota = '';
        if ($p['skladki_kwota_brutto']) {
            $kwota = number_format($p['skladki_kwota_brutto'], 2, ',', ' ') . ' zł';
        }
        
        fputcsv($output, [
            $lp++,
            $p['kod'],
            $p['imie'],
            $p['nazwisko'],
            $p['narodowosc'] ?? '',
            $p['pesel'],
            $p['dokument_tozsamosci'],
            $p['stanowisko'],
            $p['data_przyjecia'] ? date('d.m.Y', strtotime($p['data_przyjecia'])) : '',
            $p['data_zwolnienia'] ? date('d.m.Y', strtotime($p['data_zwolnienia'])) : '',
            $staz['miesiace'],
            $p['stawka_wynagrodzenia'] ? number_format($p['stawka_wynagrodzenia'], 2, ',', ' ') . ' zł' : '',
            $p['forma_umowy'],
            $p['skladki'] ?? '',
            $p['oddelegowanie_nazwa'] ?? '',
            $trybStawka,
            $p['skladki_godziny'] ? number_format($p['skladki_godziny'], 2, ',', ' ') : '',
            $kwota,
            $p['skladki_typ_kwoty'] ? strtoupper($p['skladki_typ_kwoty']) : '',
            str_replace(["\r", "\n"], ' ', $p['adres'])
        ], ';');
    }
    
    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raport miesięczny - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .date-info {
            background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
            color: white;
            padding: 20px 25px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .date-info .today { font-size: 1.1rem; }
        .date-info .today strong { font-size: 1.3rem; }
        .month-selector {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .month-selector form {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        .month-selector select {
            padding: 10px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 6px;
            font-size: 1rem;
        }
        .report-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            text-align: center;
        }
        .summary-card .number {
            font-size: 2rem;
            font-weight: 700;
            color: #2563eb;
        }
        .summary-card .label {
            color: #64748b;
            font-size: 0.85rem;
            margin-top: 5px;
        }
        .report-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        @media print {
            .top-nav, .month-selector, .report-actions, header .btn, footer { display: none !important; }
            .date-info { background: #f1f5f9 !important; color: #1e293b !important; }
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <img src="assets/logo.png" alt="Work Land">
                <div class="user-info">
                    👤 <?php echo sanitize($currentUser['name']); ?>
                </div>
            </div>
            <div class="nav-links">
                <a href="raport_nieobecnosci.php">🏥 Raport nieobecności</a>
                <?php if (canManageUsers()): ?><a href="users.php">👥 Użytkownicy</a><?php endif; ?>
                <?php if (canViewHistory()): ?><a href="historia.php">📜 Historia</a><?php endif; ?>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>📊 Raport miesięczny</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <!-- Aktualna data -->
        <div class="date-info">
            <div class="today">
                📅 Dzisiaj: <strong><?php echo date('d.m.Y'); ?></strong>
                <br><small><?php echo $dniTygodnia[(int)date('w')]; ?>, <?php echo $miesiacNazwy[(int)date('m')]; ?> <?php echo date('Y'); ?></small>
            </div>
            <div>
                🕐 Godzina: <strong><?php echo date('H:i'); ?></strong>
            </div>
        </div>
        
        <!-- Wybór miesiąca -->
        <div class="month-selector">
            <form method="GET">
                <label><strong>Wybierz okres:</strong></label>
                <select name="month">
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?php echo $m; ?>" <?php echo $m == $month ? 'selected' : ''; ?>><?php echo $miesiacNazwy[$m]; ?></option>
                    <?php endfor; ?>
                </select>
                <select name="year">
                    <?php for ($y = date('Y') - 5; $y <= date('Y') + 1; $y++): ?>
                        <option value="<?php echo $y; ?>" <?php echo $y == $year ? 'selected' : ''; ?>><?php echo $y; ?></option>
                    <?php endfor; ?>
                </select>
                <button type="submit" class="btn btn-primary">📊 Generuj raport</button>
            </form>
        </div>
        
        <!-- Podsumowanie -->
        <h2>📋 <?php echo $miesiacNazwy[$month]; ?> <?php echo $year; ?></h2>
        
        <div class="report-summary">
            <div class="summary-card">
                <div class="number"><?php echo count($pracownicy); ?></div>
                <div class="label">Zatrudnionych</div>
            </div>
            <div class="summary-card">
                <div class="number"><?php 
                    $suma = 0;
                    foreach ($pracownicy as $p) {
                        $suma += floatval($p['stawka_wynagrodzenia']);
                    }
                    echo number_format($suma, 0, ',', ' ');
                ?> zł</div>
                <div class="label">Suma wynagrodzeń</div>
            </div>
            <div class="summary-card">
                <div class="number"><?php 
                    $pelny = 0;
                    foreach ($pracownicy as $p) {
                        if ($p['wymiar_czasu_pracy'] == 'pełny etat') $pelny++;
                    }
                    echo $pelny;
                ?></div>
                <div class="label">Pełny etat</div>
            </div>
        </div>
        
        <!-- Akcje -->
        <div class="report-actions">
            <a href="?month=<?php echo $month; ?>&year=<?php echo $year; ?>&export=csv" class="btn">📥 Pobierz CSV</a>
            <button type="button" onclick="window.print()" class="btn">🖨️ Drukuj</button>
        </div>
        
        <!-- Tabela -->
        <?php if (empty($pracownicy)): ?>
            <div class="alert">Brak zatrudnionych pracowników w wybranym okresie.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>Lp.</th>
                            <th>Kod</th>
                            <th>Imię i nazwisko</th>
                            <th>Narodowość</th>
                            <th>PESEL</th>
                            <th>Nr dokumentu</th>
                            <th>Stanowisko</th>
                            <th>Przyjęcie</th>
                            <th>Zwolnienie</th>
                            <th>Staż</th>
                            <th>Stawka</th>
                            <th>Umowa</th>
                            <th>Składki</th>
                            <th>Oddelegowanie</th>
                            <th>Tryb / Stawka</th>
                            <th>Godziny</th>
                            <th>Kwota</th>
                            <th>N/B</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $lp = 1; foreach ($pracownicy as $p): 
                            $staz = obliczStaz($p['data_przyjecia'], $p['data_zwolnienia']);
                        ?>
                        <tr>
                            <td><?php echo $lp++; ?></td>
                            <td><code><?php echo sanitize($p['kod']); ?></code></td>
                            <td>
                                <strong><?php echo sanitize($p['imie'] . ' ' . $p['nazwisko']); ?></strong>
                            </td>
                            <td><?php echo sanitize($p['narodowosc']) ?: '-'; ?></td>
                            <td><small><?php echo sanitize($p['pesel']) ?: '-'; ?></small></td>
                            <td><small><?php echo sanitize($p['dokument_tozsamosci']) ?: '-'; ?></small></td>
                            <td><?php echo sanitize($p['stanowisko']) ?: '-'; ?></td>
                            <td><?php echo $p['data_przyjecia'] ? date('d.m.Y', strtotime($p['data_przyjecia'])) : '-'; ?></td>
                            <td><?php echo $p['data_zwolnienia'] ? date('d.m.Y', strtotime($p['data_zwolnienia'])) : '-'; ?></td>
                            <td style="text-align: center; font-weight: 600; color: #2563eb;"><?php echo $staz['tekst']; ?></td>
                            <td><?php echo $p['stawka_wynagrodzenia'] ? number_format($p['stawka_wynagrodzenia'], 2, ',', ' ') . ' zł' : '-'; ?></td>
                            <td><small><?php echo sanitize($p['forma_umowy']) ?: '-'; ?></small></td>
                            <td><small><?php echo sanitize($p['skladki']) ?: '-'; ?></small></td>
                            <td>
                                <?php if (!empty($p['oddelegowanie_nazwa'])): ?>
                                    <strong><?php echo sanitize($p['oddelegowanie_nazwa']); ?></strong>
                                <?php else: ?>
                                    <span style="color:#94a3b8;">-</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:center;">
                                <?php if ($p['skladki_tryb'] === 'stawka_godziny'): ?>
                                    <span style="background:#dbeafe;color:#1d4ed8;padding:2px 7px;border-radius:4px;font-size:0.8rem;font-weight:600;">S×G</span>
                                    <br><small><?php echo $p['skladki_stawka'] ? number_format($p['skladki_stawka'], 2, ',', ' ') . ' zł/h' : ''; ?></small>
                                <?php elseif ($p['skladki_tryb'] === 'kwota'): ?>
                                    <span style="background:#f0fdf4;color:#15803d;padding:2px 7px;border-radius:4px;font-size:0.8rem;font-weight:600;">Kwota</span>
                                <?php else: ?>
                                    <span style="color:#94a3b8;">-</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:right;">
                                <?php echo $p['skladki_godziny'] ? number_format($p['skladki_godziny'], 2, ',', ' ') : '<span style="color:#94a3b8;">-</span>'; ?>
                            </td>
                            <td style="text-align:right;font-weight:600;">
                                <?php if ($p['skladki_kwota_brutto']): ?>
                                    <?php echo number_format($p['skladki_kwota_brutto'], 2, ',', ' '); ?> zł
                                <?php else: ?>
                                    <span style="color:#94a3b8;">-</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align:center;">
                                <?php if ($p['skladki_typ_kwoty']): ?>
                                    <span style="background:<?php echo $p['skladki_typ_kwoty']==='netto' ? '#f0fdf4' : '#eff6ff'; ?>;
                                        color:<?php echo $p['skladki_typ_kwoty']==='netto' ? '#15803d' : '#1d4ed8'; ?>;
                                        padding:2px 8px;border-radius:4px;font-size:0.8rem;font-weight:700;">
                                        <?php echo strtoupper($p['skladki_typ_kwoty']); ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color:#94a3b8;">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        
        <footer><p>Work Land © <?php echo date('Y'); ?> | v<?= WORKLAND_VERSION ?> | Raport: <?php echo date('d.m.Y H:i:s'); ?></p></footer>
    </div>
</body>
</html>
