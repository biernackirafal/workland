# System Ewidencji Pracowników - Work Land

## Wersja 7 (Styczeń 2026)

### Nowe funkcje w tej wersji:
- **Moduł ogłoszeń rekrutacyjnych** - zarządzanie ogłoszeniami o pracę
- **Powiązanie kandydatów z ogłoszeniami** - możliwość przypisania CV do konkretnego ogłoszenia
- **Przepisywanie zadań rekrutacyjnych** - zamykanie starego zadania i tworzenie nowego dla innej osoby
- **Edycja daty oddelegowania** - możliwość ręcznego ustawiania daty końca oddelegowania

## Opis
Aplikacja webowa PHP do ewidencjonowania przebiegu zatrudnienia pracowników w agencji pracy tymczasowej.

## Wymagania
- PHP 7.4+ (zalecane PHP 8.x)
- Rozszerzenie PDO SQLite
- Serwer WWW (Apache/Nginx) lub wbudowany serwer PHP

## Instalacja

### Opcja 1: Hosting współdzielony (np. nazwa.pl, home.pl)
1. Wgraj zawartość folderu `wl2026` do katalogu `public_html` lub podkatalogu
2. Upewnij się, że katalog `data/` ma uprawnienia do zapisu (chmod 755)
3. Otwórz stronę w przeglądarce

### Opcja 2: Lokalnie z wbudowanym serwerem PHP
```bash
cd wl2026
php -S localhost:8080
```
Następnie otwórz http://localhost:8080 w przeglądarce.

## Moduły systemu

### 1. Pracownicy (główny moduł)
- Ewidencja pracowników
- Dokumenty i pliki
- Urlopy i nieobecności
- Oddelegowania do klientów

### 2. CRM (klienci)
- Baza klientów/kontrahentów
- Zadania i przypomnienia
- Osoby kontaktowe
- Import z CSV

### 3. Kandydaci (rekrutacja)
- Upload i parsowanie CV (PDF)
- **Ogłoszenia rekrutacyjne** (NOWE!)
- Task manager dla rekruterów
- Historia kontaktów
- **Przepisywanie zadań** (NOWE!)

## Struktura plików
```
wl2026/
├── index.php          # Lista pracowników
├── add.php            # Dodawanie pracownika
├── edit.php           # Edycja pracownika
├── view.php           # Szczegóły pracownika
├── kandydaci/         # Moduł rekrutacji
│   ├── index.php      # Lista kandydatów
│   ├── dodaj.php      # Upload CV
│   ├── karta.php      # Karta kandydata
│   ├── ogloszenia.php # Zarządzanie ogłoszeniami (NOWE!)
│   └── raport.php     # Raport rekrutacji
├── crm/               # Moduł CRM
├── includes/
│   └── db.php         # Baza danych i funkcje
├── assets/
│   └── style.css      # Style CSS
└── data/
    └── pracownicy.db  # Baza SQLite
```

## Bezpieczeństwo
- Dane są przechowywane lokalnie w bazie SQLite
- Wszystkie dane wejściowe są sanityzowane
- Ochrona przed SQL Injection (PDO prepared statements)
- Ochrona przed XSS (htmlspecialchars)

---
© Work Land 2026 | System Ewidencji Pracowników
