<?php
/**
 * Edycja pracownika
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$errors = [];

// Pobierz ID pracownika
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Pobierz dane pracownika
$stmt = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
$stmt->execute([$id]);
$pracownik = $stmt->fetch();

if (!$pracownik) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Walidacja
    $kod = sanitize($_POST['kod'] ?? '');
    $imie = sanitize($_POST['imie'] ?? '');
    $nazwisko = sanitize($_POST['nazwisko'] ?? '');
    
    if (empty($kod)) $errors[] = 'Kod pracownika jest wymagany.';
    if (empty($imie)) $errors[] = 'Imię jest wymagane.';
    if (empty($nazwisko)) $errors[] = 'Nazwisko jest wymagane.';
    
    // Sprawdź unikalność kodu (poza obecnym rekordem)
    if (!empty($kod)) {
        $stmt = $db->prepare("SELECT COUNT(*) FROM pracownicy WHERE kod = ? AND id != ?");
        $stmt->execute([$kod, $id]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = 'Pracownik o takim kodzie już istnieje.';
        }
    }
    
    if (empty($errors)) {
        try {
            // Zapisz stare dane przed aktualizacją
            $stmtOld = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
            $stmtOld->execute([$id]);
            $oldData = $stmtOld->fetch();
            
            $stmt = $db->prepare("UPDATE pracownicy SET
                kod = :kod, imie = :imie, nazwisko = :nazwisko, narodowosc = :narodowosc,
                dane_personalne = :dane_personalne, dokument_tozsamosci = :dokument_tozsamosci,
                dokument_typ = :dokument_typ, dokument_numer = :dokument_numer,
                data_urodzenia = :data_urodzenia, pesel = :pesel, nip = :nip, telefon = :telefon, email = :email,
                data_przyjecia = :data_przyjecia, data_zwolnienia = :data_zwolnienia,
                okres_zatrudnienia_do = :okres_zatrudnienia_do,
                zezwolenie_do = :zezwolenie_do, stawka_wynagrodzenia = :stawka_wynagrodzenia,
                skladki = :skladki, skladki_typ = :skladki_typ, forma_umowy = :forma_umowy, wymiar_czasu_pracy = :wymiar_czasu_pracy,
                typ_zleceniobiorcy = :typ_zleceniobiorcy, koszty_typ = :koszty_typ,
                urlop_bezplatny_od = :urlop_bezplatny_od, urlop_bezplatny_do = :urlop_bezplatny_do,
                grupa_inwalidzka = :grupa_inwalidzka, stanowisko = :stanowisko,
                badania_lekarskie = :badania_lekarskie, szkolenie_bhp = :szkolenie_bhp,
                data_zakonczenia_pobytu = :data_zakonczenia_pobytu, konto_bankowe = :konto_bankowe,
                adres = :adres, uwagi = :uwagi, prawo_jazdy = :prawo_jazdy,
                wozek_widlowy = :wozek_widlowy, wysoki_sklad = :wysoki_sklad, notatki = :notatki,
                updated_at = CURRENT_TIMESTAMP
                WHERE id = :id
            ");
            
            $newData = [
                ':id' => $id,
                ':kod' => $kod,
                ':imie' => $imie,
                ':nazwisko' => $nazwisko,
                ':narodowosc' => sanitize($_POST['narodowosc'] ?? ''),
                ':dane_personalne' => sanitize($_POST['dane_personalne'] ?? ''),
                ':dokument_tozsamosci' => sanitize($_POST['dokument_numer'] ?? $_POST['dokument_tozsamosci'] ?? ''),
                ':dokument_typ' => sanitize($_POST['dokument_typ'] ?? 'dowód osobisty'),
                ':dokument_numer' => sanitize($_POST['dokument_numer'] ?? ''),
                ':data_urodzenia' => $_POST['data_urodzenia'] ?: null,
                ':pesel' => sanitize($_POST['pesel'] ?? ''),
                ':nip' => sanitize($_POST['nip'] ?? ''),
                ':telefon' => sanitize($_POST['telefon'] ?? ''),
                ':email' => sanitize($_POST['email'] ?? ''),
                ':data_przyjecia' => $_POST['data_przyjecia'] ?: null,
                ':data_zwolnienia' => $_POST['data_zwolnienia'] ?: null,
                ':okres_zatrudnienia_do' => $_POST['okres_zatrudnienia_do'] ?: null,
                ':zezwolenie_do' => $_POST['zezwolenie_do'] ?: null,
                ':stawka_wynagrodzenia' => !empty($_POST['stawka_wynagrodzenia']) ? str_replace(',', '.', $_POST['stawka_wynagrodzenia']) : null,
                ':skladki' => sanitize($_POST['skladki'] ?? ''),
                ':skladki_typ' => sanitize($_POST['skladki_typ'] ?? 'brutto'),
                ':forma_umowy' => sanitize($_POST['forma_umowy'] ?? ''),
                ':wymiar_czasu_pracy' => sanitize($_POST['wymiar_czasu_pracy'] ?? ''),
                ':typ_zleceniobiorcy' => sanitize($_POST['typ_zleceniobiorcy'] ?? 'standardowy'),
                ':koszty_typ' => sanitize($_POST['koszty_typ'] ?? 'standardowe'),
                ':urlop_bezplatny_od' => $_POST['urlop_bezplatny_od'] ?: null,
                ':urlop_bezplatny_do' => $_POST['urlop_bezplatny_do'] ?: null,
                ':grupa_inwalidzka' => sanitize($_POST['grupa_inwalidzka'] ?? ''),
                ':stanowisko' => sanitize($_POST['stanowisko'] ?? ''),
                ':badania_lekarskie' => $_POST['badania_lekarskie'] ?: null,
                ':szkolenie_bhp' => $_POST['szkolenie_bhp'] ?: null,
                ':data_zakonczenia_pobytu' => $_POST['data_zakonczenia_pobytu'] ?: null,
                ':konto_bankowe' => sanitize($_POST['konto_bankowe'] ?? ''),
                ':adres' => sanitize($_POST['adres'] ?? ''),
                ':uwagi' => sanitize($_POST['uwagi'] ?? ''),
                ':prawo_jazdy' => sanitize($_POST['prawo_jazdy'] ?? ''),
                ':wozek_widlowy' => !empty($_POST['wozek_widlowy']) ? 1 : 0,
                ':wysoki_sklad' => !empty($_POST['wysoki_sklad']) ? 1 : 0,
                ':notatki' => sanitize($_POST['notatki'] ?? ''),
            ];
            
            $stmt->execute($newData);
            
            // Zapisz stawkę do historii jeśli jest podana
            $stawka = !empty($_POST['stawka_wynagrodzenia']) ? floatval(str_replace(',', '.', $_POST['stawka_wynagrodzenia'])) : 0;
            $stawkaMiesiac = (int)($_POST['stawka_miesiac'] ?? date('m'));
            $stawkaRok = (int)($_POST['stawka_rok'] ?? date('Y'));
            
            if ($stawka > 0) {
                try {
                    $stmtStawka = $db->prepare("INSERT OR REPLACE INTO historia_stawek (pracownik_id, miesiac, rok, stawka, uwagi) VALUES (?, ?, ?, ?, ?)");
                    $stmtStawka->execute([$id, $stawkaMiesiac, $stawkaRok, $stawka, '']);
                } catch (PDOException $e) {}
            }
            
            // Loguj zmianę
            logChange($db, 'UPDATE', 'pracownicy', $id, 
                "Edytowano pracownika: {$imie} {$nazwisko} (kod: {$kod})",
                $oldData, $newData);
            
            header('Location: index.php?msg=updated');
            exit;
        } catch (PDOException $e) {
            $errors[] = 'Błąd bazy danych: ' . $e->getMessage();
        }
    }
    
    // Zachowaj dane z POST do wyświetlenia
    $pracownik = array_merge($pracownik, $_POST);
}

// Helper do pobierania wartości
$val = function($field) use ($pracownik) {
    return sanitize($pracownik[$field] ?? '');
};
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edycja: <?= $val('imie') . ' ' . $val('nazwisko') ?> - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>✏️ Edycja pracownika</h1>
            <div class="header-actions">
                <a href="view.php?id=<?= $id ?>" class="btn btn-secondary">👁️ Podgląd</a>
                <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
            </div>
        </header>
        
        <?php if (!empty($errors)): ?>
            <div class="alert error">
                <strong>Wystąpiły błędy:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" class="employee-form">
            <!-- Dane podstawowe -->
            <fieldset>
                <legend>📋 Dane podstawowe</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="kod">Kod pracownika *</label>
                        <input type="text" id="kod" name="kod" value="<?= $val('kod') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="imie">Imię *</label>
                        <input type="text" id="imie" name="imie" value="<?= $val('imie') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nazwisko">Nazwisko *</label>
                        <input type="text" id="nazwisko" name="nazwisko" value="<?= $val('nazwisko') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="narodowosc">Narodowość</label>
                        <input type="text" id="narodowosc" name="narodowosc" value="<?= $val('narodowosc') ?>" list="narodowosc-list">
                        <datalist id="narodowosc-list">
                            <option value="Polska">
                            <option value="Ukraina">
                            <option value="Białoruś">
                            <option value="Rosja">
                            <option value="Mołdawia">
                            <option value="Gruzja">
                            <option value="Kazachstan">
                            <option value="Kirgistan">
                            <option value="Turkmenistan">
                            <option value="Uzbekistan">
                            <option value="Tadżykistan">
                            <option value="Azerbejdżan">
                            <option value="Armenia">
                            <option value="Indie">
                            <option value="Nepal">
                            <option value="Filipiny">
                            <option value="Bangladesz">
                            <option value="Wietnam">
                            <option value="Turcja">
                        </datalist>
                    </div>
                    <div class="form-group">
                        <label for="data_urodzenia">Data urodzenia</label>
                        <input type="date" id="data_urodzenia" name="data_urodzenia" value="<?= $val('data_urodzenia') ?>">
                    </div>
                    <div class="form-group">
                        <label for="stanowisko">Stanowisko</label>
                        <input type="text" id="stanowisko" name="stanowisko" value="<?= $val('stanowisko') ?>">
                    </div>
                </div>
            </fieldset>
            
            <!-- Dokumenty -->
            <fieldset>
                <legend>🪪 Dokumenty tożsamości</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="pesel">PESEL</label>
                        <input type="text" id="pesel" name="pesel" value="<?= $val('pesel') ?>" maxlength="11" pattern="[0-9]{11}">
                    </div>
                    <div class="form-group">
                        <label for="nip">NIP</label>
                        <input type="text" id="nip" name="nip" value="<?= $val('nip') ?>" maxlength="13">
                    </div>
                    <div class="form-group">
                        <label for="dokument_typ">Typ dokumentu tożsamości</label>
                        <select id="dokument_typ" name="dokument_typ">
                            <option value="dowód osobisty" <?= $val('dokument_typ') == 'dowód osobisty' ? 'selected' : '' ?>>Dowód osobisty</option>
                            <option value="paszport" <?= $val('dokument_typ') == 'paszport' ? 'selected' : '' ?>>Paszport</option>
                            <option value="karta pobytu" <?= $val('dokument_typ') == 'karta pobytu' ? 'selected' : '' ?>>Karta pobytu</option>
                            <option value="inny dokument" <?= $val('dokument_typ') == 'inny dokument' ? 'selected' : '' ?>>Inny dokument tożsamości</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="dokument_numer">Nr dokumentu (seria i numer)</label>
                        <input type="text" id="dokument_numer" name="dokument_numer" value="<?= $val('dokument_numer') ?: $val('dokument_tozsamosci') ?>" placeholder="np. ABC123456">
                    </div>
                    <div class="form-group full-width">
                        <label for="dane_personalne">Dodatkowe dane personalne</label>
                        <textarea id="dane_personalne" name="dane_personalne" rows="2"><?= $val('dane_personalne') ?></textarea>
                    </div>
                </div>
            </fieldset>
            
            <!-- Zatrudnienie -->
            <fieldset>
                <legend>💼 Zatrudnienie</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="data_przyjecia">Data przyjęcia</label>
                        <input type="date" id="data_przyjecia" name="data_przyjecia" value="<?= $val('data_przyjecia') ?>">
                    </div>
                    <div class="form-group">
                        <label for="data_zwolnienia">Data zwolnienia</label>
                        <input type="date" id="data_zwolnienia" name="data_zwolnienia" value="<?= $val('data_zwolnienia') ?>">
                    </div>
                    <div class="form-group">
                        <label for="okres_zatrudnienia_do">Okres zatrudnienia do</label>
                        <input type="date" id="okres_zatrudnienia_do" name="okres_zatrudnienia_do" value="<?= $val('okres_zatrudnienia_do') ?>">
                    </div>
                    <div class="form-group">
                        <label for="forma_umowy">Forma umowy o pracę</label>
                        <select id="forma_umowy" name="forma_umowy">
                            <option value="">-- wybierz --</option>
                            <option value="umowa o pracę na czas określony" <?= $val('forma_umowy') == 'umowa o pracę na czas określony' ? 'selected' : '' ?>>Umowa o pracę na czas określony</option>
                            <option value="umowa o pracę na czas nieokreślony" <?= $val('forma_umowy') == 'umowa o pracę na czas nieokreślony' ? 'selected' : '' ?>>Umowa o pracę na czas nieokreślony</option>
                            <option value="umowa o pracę na okres próbny" <?= $val('forma_umowy') == 'umowa o pracę na okres próbny' ? 'selected' : '' ?>>Umowa o pracę na okres próbny</option>
                            <option value="umowa zlecenie" <?= $val('forma_umowy') == 'umowa zlecenie' ? 'selected' : '' ?>>Umowa zlecenie</option>
                            <option value="umowa o dzieło" <?= $val('forma_umowy') == 'umowa o dzieło' ? 'selected' : '' ?>>Umowa o dzieło</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="wymiar_czasu_pracy">Wymiar czasu pracy</label>
                        <select id="wymiar_czasu_pracy" name="wymiar_czasu_pracy">
                            <option value="">-- wybierz --</option>
                            <option value="pełny etat" <?= $val('wymiar_czasu_pracy') == 'pełny etat' ? 'selected' : '' ?>>Pełny etat</option>
                            <option value="3/4 etatu" <?= $val('wymiar_czasu_pracy') == '3/4 etatu' ? 'selected' : '' ?>>3/4 etatu</option>
                            <option value="1/2 etatu" <?= $val('wymiar_czasu_pracy') == '1/2 etatu' ? 'selected' : '' ?>>1/2 etatu</option>
                            <option value="1/4 etatu" <?= $val('wymiar_czasu_pracy') == '1/4 etatu' ? 'selected' : '' ?>>1/4 etatu</option>
                            <option value="1/8 etatu" <?= $val('wymiar_czasu_pracy') == '1/8 etatu' ? 'selected' : '' ?>>1/8 etatu</option>
                            <option value="1/16 etatu" <?= $val('wymiar_czasu_pracy') == '1/16 etatu' ? 'selected' : '' ?>>1/16 etatu</option>
                            <option value="1/32 etatu" <?= $val('wymiar_czasu_pracy') == '1/32 etatu' ? 'selected' : '' ?>>1/32 etatu</option>
                            <option value="1/40 etatu" <?= $val('wymiar_czasu_pracy') == '1/40 etatu' ? 'selected' : '' ?>>1/40 etatu</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="typ_zleceniobiorcy">Typ zleceniobiorcy (do rachunków)</label>
                        <select id="typ_zleceniobiorcy" name="typ_zleceniobiorcy">
                            <option value="standardowy" <?= $val('typ_zleceniobiorcy') == 'standardowy' || !$val('typ_zleceniobiorcy') ? 'selected' : '' ?>>👤 Standardowy (>26 lat)</option>
                            <option value="student" <?= $val('typ_zleceniobiorcy') == 'student' ? 'selected' : '' ?>>🎓 Student/uczeń do 26 lat</option>
                            <option value="standard_26" <?= $val('typ_zleceniobiorcy') == 'standard_26' ? 'selected' : '' ?>>🧑 Do 26 lat (PIT-0)</option>
                            <option value="emeryt" <?= $val('typ_zleceniobiorcy') == 'emeryt' ? 'selected' : '' ?>>👴 Emeryt/rencista</option>
                            <option value="inny_tytul" <?= $val('typ_zleceniobiorcy') == 'inny_tytul' ? 'selected' : '' ?>>💼 Inny tytuł (tylko zdrow.)</option>
                            <option value="bez_zus_zdrow" <?= $val('typ_zleceniobiorcy') == 'bez_zus_zdrow' ? 'selected' : '' ?>>📋 Bez składek (tylko podatek)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="koszty_typ">Koszty uzyskania przychodu</label>
                        <select id="koszty_typ" name="koszty_typ">
                            <option value="standardowe" <?= $val('koszty_typ') == 'standardowe' || !$val('koszty_typ') ? 'selected' : '' ?>>20% - standardowe</option>
                            <option value="autorskie" <?= $val('koszty_typ') == 'autorskie' ? 'selected' : '' ?>>50% - prawa autorskie</option>
                        </select>
                    </div>
                </div>
            </fieldset>
            
            <!-- Wynagrodzenie -->
            <fieldset>
                <legend>💰 Wynagrodzenie i składki</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="stawka_wynagrodzenia">Stawka wynagrodzenia (zł)</label>
                        <input type="text" id="stawka_wynagrodzenia" name="stawka_wynagrodzenia" value="<?= $val('stawka_wynagrodzenia') ?>" placeholder="np. 4500,00">
                    </div>
                    <div class="form-group">
                        <label for="stawka_miesiac">Miesiąc obowiązywania</label>
                        <select id="stawka_miesiac" name="stawka_miesiac">
                            <?php 
                            $miesiace = [1=>'Styczeń',2=>'Luty',3=>'Marzec',4=>'Kwiecień',5=>'Maj',6=>'Czerwiec',7=>'Lipiec',8=>'Sierpień',9=>'Wrzesień',10=>'Październik',11=>'Listopad',12=>'Grudzień'];
                            $currentMonth = (int)date('m');
                            foreach ($miesiace as $num => $nazwa): ?>
                                <option value="<?= $num ?>" <?= $num == $currentMonth ? 'selected' : '' ?>><?= $nazwa ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="stawka_rok">Rok</label>
                        <select id="stawka_rok" name="stawka_rok">
                            <?php 
                            $currentYear = (int)date('Y');
                            for ($y = $currentYear - 2; $y <= $currentYear + 1; $y++): ?>
                                <option value="<?= $y ?>" <?= $y == $currentYear ? 'selected' : '' ?>><?= $y ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="skladki">Składki</label>
                        <input type="text" id="skladki" name="skladki" value="<?= $val('skladki') ?>">
                        <div style="margin-top: 6px;">
                            <select name="skladki_typ" style="width: 100px; padding: 6px 10px;">
                                <option value="brutto" <?= ($val('skladki_typ') ?: 'brutto') == 'brutto' ? 'selected' : '' ?>>brutto</option>
                                <option value="netto" <?= $val('skladki_typ') == 'netto' ? 'selected' : '' ?>>netto</option>
                            </select>
                        </div>
                    </div>
                </div>
                <p class="help-text" style="margin-top: 10px; color: #64748b; font-size: 0.85rem;">
                    💡 Przy zmianie stawki wybierz miesiąc i rok, od którego obowiązuje nowa stawka. Historia stawek jest zapisywana automatycznie.
                </p>
            </fieldset>
            
            <!-- Zezwolenia i badania -->
            <fieldset>
                <legend>📅 Zezwolenia i badania</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="zezwolenie_do">Zezwolenie na pracę ważne do</label>
                        <input type="date" id="zezwolenie_do" name="zezwolenie_do" value="<?= $val('zezwolenie_do') ?>">
                    </div>
                    <div class="form-group">
                        <label for="data_zakonczenia_pobytu">Data zakończenia pobytu</label>
                        <input type="date" id="data_zakonczenia_pobytu" name="data_zakonczenia_pobytu" value="<?= $val('data_zakonczenia_pobytu') ?>">
                    </div>
                    <div class="form-group">
                        <label for="badania_lekarskie">Badania lekarskie ważne do</label>
                        <input type="date" id="badania_lekarskie" name="badania_lekarskie" value="<?= $val('badania_lekarskie') ?>">
                    </div>
                    <div class="form-group">
                        <label for="szkolenie_bhp">Szkolenie BHP ważne do</label>
                        <input type="date" id="szkolenie_bhp" name="szkolenie_bhp" value="<?= $val('szkolenie_bhp') ?>">
                    </div>
                </div>
            </fieldset>
            
            <!-- Urlopy i inne -->
            <fieldset>
                <legend>🏖️ Urlopy i dodatkowe informacje</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="urlop_bezplatny_od">Urlop bezpłatny od</label>
                        <input type="date" id="urlop_bezplatny_od" name="urlop_bezplatny_od" value="<?= $val('urlop_bezplatny_od') ?>">
                    </div>
                    <div class="form-group">
                        <label for="urlop_bezplatny_do">Urlop bezpłatny do</label>
                        <input type="date" id="urlop_bezplatny_do" name="urlop_bezplatny_do" value="<?= $val('urlop_bezplatny_do') ?>">
                    </div>
                    <div class="form-group">
                        <label for="grupa_inwalidzka">Grupa inwalidzka</label>
                        <select id="grupa_inwalidzka" name="grupa_inwalidzka">
                            <option value="">-- brak --</option>
                            <option value="lekki" <?= $val('grupa_inwalidzka') == 'lekki' ? 'selected' : '' ?>>Lekki stopień niepełnosprawności</option>
                            <option value="umiarkowany" <?= $val('grupa_inwalidzka') == 'umiarkowany' ? 'selected' : '' ?>>Umiarkowany stopień niepełnosprawności</option>
                            <option value="znaczny" <?= $val('grupa_inwalidzka') == 'znaczny' ? 'selected' : '' ?>>Znaczny stopień niepełnosprawności</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="konto_bankowe">Numer konta bankowego</label>
                        <input type="text" id="konto_bankowe" name="konto_bankowe" value="<?= $val('konto_bankowe') ?>" placeholder="XX XXXX XXXX XXXX XXXX XXXX XXXX">
                    </div>
                    <div class="form-group">
                        <label for="telefon">Numer telefonu</label>
                        <input type="tel" id="telefon" name="telefon" value="<?= $val('telefon') ?>" placeholder="+48 XXX XXX XXX">
                    </div>
                    <div class="form-group">
                        <label for="email">Adres e-mail</label>
                        <input type="email" id="email" name="email" value="<?= $val('email') ?>" placeholder="jan.kowalski@example.com">
                    </div>
                </div>
            </fieldset>
            
            <!-- Kwalifikacje i uprawnienia -->
            <fieldset>
                <legend>🎓 Kwalifikacje i uprawnienia</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="prawo_jazdy">Prawo jazdy (kategorie)</label>
                        <input type="text" id="prawo_jazdy" name="prawo_jazdy" value="<?= $val('prawo_jazdy') ?>" placeholder="np. B, C, C+E">
                    </div>
                    <div class="form-group">
                        <label>Dodatkowe uprawnienia</label>
                        <div class="checkbox-group">
                            <label class="checkbox-item">
                                <input type="checkbox" name="wozek_widlowy" value="1" <?= !empty($val('wozek_widlowy')) ? 'checked' : '' ?>>
                                Wózek widłowy
                            </label>
                            <label class="checkbox-item">
                                <input type="checkbox" name="wysoki_sklad" value="1" <?= !empty($val('wysoki_sklad')) ? 'checked' : '' ?>>
                                Wysoki skład
                            </label>
                        </div>
                    </div>
                </div>
            </fieldset>
            
            <!-- Adres i uwagi -->
            <fieldset>
                <legend>📍 Adres i uwagi</legend>
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label for="adres">Adres zamieszkania</label>
                        <textarea id="adres" name="adres" rows="2"><?= $val('adres') ?></textarea>
                    </div>
                    <div class="form-group full-width">
                        <label for="uwagi">Uwagi</label>
                        <textarea id="uwagi" name="uwagi" rows="3"><?= $val('uwagi') ?></textarea>
                    </div>
                    <div class="form-group full-width">
                        <label for="notatki">📝 Notatki wewnętrzne</label>
                        <textarea id="notatki" name="notatki" rows="3" placeholder="Notatki widoczne tylko dla pracowników biura..."><?= $val('notatki') ?></textarea>
                    </div>
                </div>
            </fieldset>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-large">💾 Zapisz zmiany</button>
                <a href="view.php?id=<?= $id ?>" class="btn btn-secondary">Anuluj</a>
            </div>
        </form>
        
        <footer>
            <p>Work Land © <?= date('Y') ?> | System Ewidencji Pracowników | v<?= WORKLAND_VERSION ?> (<?= WORKLAND_VERSION_DATE ?>)</p>
        </footer>
    </div>
</body>
</html>
