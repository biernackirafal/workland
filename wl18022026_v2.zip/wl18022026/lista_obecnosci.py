#!/usr/bin/env python3
"""
Generator listy obecności / karty ewidencji czasu pracy
"""
import sys
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import date, timedelta
import calendar

# Święta polskie (stałe)
SWIETA_STALE = [(1,1), (1,6), (5,1), (5,3), (8,15), (11,1), (11,11), (12,25), (12,26)]

def oblicz_wielkanoc(rok):
    a = rok % 19
    b = rok // 100
    c = rok % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return date(rok, month, day)

def pobierz_swieta(rok):
    swieta = set()
    for m, d in SWIETA_STALE:
        swieta.add(date(rok, m, d))
    wielkanoc = oblicz_wielkanoc(rok)
    swieta.add(wielkanoc)
    swieta.add(wielkanoc + timedelta(days=1))   # Poniedziałek Wielkanocny
    swieta.add(wielkanoc + timedelta(days=49))  # Zielone Świątki
    swieta.add(wielkanoc + timedelta(days=60))  # Boże Ciało
    return swieta

def generuj_liste_obecnosci(rok, miesiac, imie, nazwisko, output_path):
    wb = Workbook()
    ws = wb.active
    ws.title = f"{miesiac:02d}.{rok}"
    
    # Style
    bold = Font(bold=True)
    bold_big = Font(bold=True, size=14)
    center = Alignment(horizontal='center', vertical='center', wrap_text=True)
    thin = Border(left=Side(style='thin'), right=Side(style='thin'), 
                  top=Side(style='thin'), bottom=Side(style='thin'))
    gray = PatternFill(start_color='C0C0C0', end_color='C0C0C0', fill_type='solid')
    header_fill = PatternFill(start_color='D9D9D9', end_color='D9D9D9', fill_type='solid')
    
    # Nagłówek
    ws.merge_cells('A1:G1')
    ws['A1'] = 'LISTA OBECNOŚCI'
    ws['A1'].font = bold_big
    ws['A1'].alignment = center
    
    ws.merge_cells('A2:G2')
    ws['A2'] = 'KARTA EWIDENCJI CZASU PRACY'
    ws['A2'].font = bold_big
    ws['A2'].alignment = center
    
    # Dane pracownika
    ws['A4'] = 'Imię:'
    ws['A4'].font = bold
    ws['B4'] = imie
    ws['D4'] = 'Miesiąc:'
    ws['D4'].font = bold
    ws['E4'] = f"{miesiac:02d}.{rok}"
    
    ws['A5'] = 'Nazwisko:'
    ws['A5'].font = bold
    ws['B5'] = nazwisko
    
    # Nagłówki tabeli - row 7
    headers = ['DATA', 'GODZ.\nROZPOCZĘCIA', 'GODZ. WYJŚCIA', 'PODPIS', 'UWAGI', 'Ilość\ngodzin', 'Koło\nratunkowe\nlub podpis\nnadaw.zast']
    widths = [8, 14, 14, 18, 22, 10, 14]
    
    for col, (h, w) in enumerate(zip(headers, widths), 1):
        cell = ws.cell(row=7, column=col, value=h)
        cell.font = bold
        cell.fill = header_fill
        cell.border = thin
        cell.alignment = center
        ws.column_dimensions[get_column_letter(col)].width = w
    
    # Dni miesiąca
    swieta = pobierz_swieta(rok)
    dni = calendar.monthrange(rok, miesiac)[1]
    
    for dzien in range(1, dni + 1):
        row = 7 + dzien
        d = date(rok, miesiac, dzien)
        wolny = d.weekday() >= 5 or d in swieta
        
        # DATA
        ws.cell(row=row, column=1, value=dzien).border = thin
        ws.cell(row=row, column=1).alignment = center
        
        for col in range(1, 8):
            ws.cell(row=row, column=col).border = thin
            if wolny:
                ws.cell(row=row, column=col).fill = gray
        
        if not wolny:
            ws.cell(row=row, column=2, value='8:00').alignment = center
            ws.cell(row=row, column=3, value='16:00').alignment = center
            ws.cell(row=row, column=6, value=8).alignment = center
    
    # Suma
    last_row = 7 + dni + 2
    ws.cell(row=last_row, column=5, value='SUMA GODZIN:').font = bold
    ws.cell(row=last_row, column=5).alignment = Alignment(horizontal='right')
    ws.cell(row=last_row, column=6, value=f'=SUM(F8:F{7+dni})')
    ws.cell(row=last_row, column=6).font = bold
    ws.cell(row=last_row, column=6).border = thin
    
    # Podpisy
    sign_row = last_row + 3
    ws.cell(row=sign_row, column=1, value='Podpis pracownika:').font = bold
    ws.cell(row=sign_row, column=5, value='Podpis przełożonego:').font = bold
    
    ws.row_dimensions[1].height = 20
    ws.row_dimensions[2].height = 20
    ws.row_dimensions[7].height = 35
    
    wb.save(output_path)
    print(f"OK:{output_path}")

if __name__ == '__main__':
    if len(sys.argv) < 6:
        print("Użycie: python3 lista_obecnosci.py <rok> <miesiac> <imie> <nazwisko> <output.xlsx>")
        sys.exit(1)
    generuj_liste_obecnosci(int(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4], sys.argv[5])
