<?php
/**
 * CRM - Pobieranie Zarządu z KRS v5 (NAPRAWIONE)
 * 
 * Poprawki:
 * - Prawidłowe parsowanie imion (tablica -> string)
 * - Obsługa różnych formatów odpowiedzi KRS API
 * - Akcja czyszczenia błędnych wpisów "Array"
 * 
 * WGRAJ DO: /kadry/crm_zarzad.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('max_execution_time', 300);

require_once __DIR__ . '/includes/db.php';
requireLogin();

$db = initDatabase();

// Migracja
try { $db->exec("ALTER TABLE crm_klienci ADD COLUMN krs_checked INTEGER DEFAULT 0"); } catch (PDOException $e) {}
try { $db->exec("ALTER TABLE crm_klienci ADD COLUMN krs_numer VARCHAR(20)"); } catch (PDOException $e) {}

// === AKCJA: Usuń błędne wpisy "Array" ===
if (isset($_GET['action']) && $_GET['action'] === 'cleanup') {
    // Usuń osoby z imieniem lub nazwiskiem "Array"
    $deleted = $db->exec("DELETE FROM crm_osoby WHERE imie = 'Array' OR nazwisko = 'Array' OR imie LIKE '%Array%' OR nazwisko LIKE '%Array%'");
    
    // Zresetuj krs_checked żeby można było pobrać ponownie
    $db->exec("UPDATE crm_klienci SET krs_checked = 0 WHERE id IN (SELECT DISTINCT klient_id FROM crm_osoby WHERE uwagi LIKE '%KRS%')");
    $db->exec("UPDATE crm_klienci SET krs_checked = 0 WHERE krs_numer IS NOT NULL AND krs_numer != ''");
    
    header('Location: crm_zarzad.php?msg=cleanup&deleted=' . $deleted);
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'reset') {
    $db->exec("UPDATE crm_klienci SET krs_checked = 0, krs_numer = NULL");
    $db->exec("DELETE FROM crm_osoby WHERE uwagi LIKE '%KRS%'");
    header('Location: crm_zarzad.php?msg=reset');
    exit;
}

// === GUS API ===
class GUSApi {
    private $apiKey = 'b0f0e889eff5497cbea4';
    private $url = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';
    private $sid = null;
    public $lastError = '';
    
    public function login() {
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $this->apiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->request($envelope);
        if ($response === false) {
            $this->lastError = 'Timeout GUS';
            return false;
        }
        $this->sid = $this->extract($response, 'ZalogujResult');
        return !empty($this->sid);
    }
    
    public function logout() {
        if (!$this->sid) return;
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Wyloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Wyloguj>
            <ns:pIdentyfikatorSesji>' . $this->sid . '</ns:pIdentyfikatorSesji>
        </ns:Wyloguj>
    </soap:Body>
</soap:Envelope>';
        @$this->request($envelope);
        $this->sid = null;
    }
    
    public function searchByNip($nip) {
        if (!$this->sid) return null;
        
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:Nip>' . $nip . '</dat:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->request($envelope);
        if ($response === false) return null;
        
        $result = $this->extract($response, 'DaneSzukajPodmiotyResult');
        if (empty($result)) return null;
        
        $xml = @simplexml_load_string($result);
        if (!$xml || !isset($xml->dane)) return null;
        
        $dane = $xml->dane;
        if (isset($dane->ErrorCode) && (string)$dane->ErrorCode !== '0') return null;
        
        return [
            'regon' => (string)($dane->Regon ?? ''),
            'nazwa' => (string)($dane->Nazwa ?? ''),
            'typ' => (string)($dane->Typ ?? ''),
            'silos' => (string)($dane->SilosID ?? '')
        ];
    }
    
    public function getFullReport($regon) {
        if (!$this->sid || empty($regon)) return null;
        
        $regon9 = substr(preg_replace('/[^0-9]/', '', $regon), 0, 9);
        
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DanePobierzPelnyRaport</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DanePobierzPelnyRaport>
            <ns:pRegon>' . $regon9 . '</ns:pRegon>
            <ns:pNazwaRaportu>BIR11OsPrawna</ns:pNazwaRaportu>
        </ns:DanePobierzPelnyRaport>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->request($envelope);
        if ($response === false) return null;
        
        $result = $this->extract($response, 'DanePobierzPelnyRaportResult');
        if (empty($result)) return null;
        
        $krs = null;
        $patterns = ['praw_numerWRejestrzeEwidencji', 'praw_numerWKRS', 'numerWRejestrzeEwidencji'];
        
        foreach ($patterns as $pattern) {
            if (preg_match('/<' . $pattern . '>(\d+)<\/' . $pattern . '>/i', $result, $m)) {
                if (strlen($m[1]) >= 7) {
                    $krs = str_pad($m[1], 10, '0', STR_PAD_LEFT);
                    break;
                }
            }
        }
        
        return ['krs' => $krs];
    }
    
    private function request($envelope) {
        $headers = ['Content-Type: application/soap+xml; charset=utf-8'];
        if ($this->sid) $headers[] = 'sid: ' . $this->sid;
        
        $ch = curl_init($this->url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $envelope,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $headers
        ]);
        $response = curl_exec($ch);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            $this->lastError = $error;
            return false;
        }
        return $response;
    }
    
    private function extract($xml, $tag) {
        if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
            return html_entity_decode($m[1]);
        }
        return '';
    }
}

// === KRS API (NAPRAWIONE) ===
class KRSApi {
    public $lastError = '';
    public $debugInfo = [];
    
    public function getByKrs($krs) {
        $krs = str_pad(preg_replace('/\D/', '', $krs), 10, '0', STR_PAD_LEFT);
        $url = "https://api-krs.ms.gov.pl/api/krs/OdpisAktualny/$krs?rejestr=P&format=json";
        
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => ['Accept: application/json']
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            $this->lastError = $error;
            return null;
        }
        
        if ($httpCode !== 200) {
            $this->lastError = "HTTP $httpCode";
            return null;
        }
        
        $data = @json_decode($response, true);
        if (!$data || !isset($data['odpis'])) {
            $this->lastError = 'Nieprawidłowa odpowiedź';
            return null;
        }
        
        return $this->parseOdpis($data['odpis']);
    }
    
    /**
     * Konwertuje pole imiona z różnych formatów na string
     * Format KRS: imiona => Array ( imie => "Jan" )
     */
    private function parseImiona($imionaField) {
        if (is_string($imionaField)) {
            return trim($imionaField);
        }
        
        if (is_array($imionaField)) {
            // Format KRS API: imiona => [ 'imie' => 'Jan' ]
            if (isset($imionaField['imie'])) {
                $imie = $imionaField['imie'];
                if (is_string($imie)) {
                    return trim($imie);
                }
                if (is_array($imie)) {
                    // imie może być tablicą wielu imion
                    return implode(' ', array_filter($imie, 'is_string'));
                }
            }
            
            // Może być płaska tablica stringów
            if (isset($imionaField[0]) && is_string($imionaField[0])) {
                return implode(' ', $imionaField);
            }
            
            // Może mieć klucze imie1, imie2
            $imiona = [];
            for ($i = 1; $i <= 3; $i++) {
                if (!empty($imionaField["imie$i"])) {
                    $imiona[] = $imionaField["imie$i"];
                }
            }
            if (!empty($imiona)) {
                return implode(' ', $imiona);
            }
        }
        
        // Fallback - zwróć pusty string zamiast "Array"
        return '';
    }
    
    /**
     * Konwertuje pole nazwisko z różnych formatów na string
     * Format KRS: nazwisko => Array ( nazwiskoICzlon => "Kowalski" )
     */
    private function parseNazwisko($nazwiskoField) {
        if (is_string($nazwiskoField)) {
            return trim($nazwiskoField);
        }
        
        if (is_array($nazwiskoField)) {
            // Format KRS API: nazwisko => [ 'nazwiskoICzlon' => 'Kowalski' ]
            if (isset($nazwiskoField['nazwiskoICzlon'])) {
                return trim((string)$nazwiskoField['nazwiskoICzlon']);
            }
            
            // Alternatywny format: nazwisko => [ 'nazwisko' => 'Kowalski' ]
            if (isset($nazwiskoField['nazwisko'])) {
                $nazw = $nazwiskoField['nazwisko'];
                if (is_string($nazw)) {
                    return trim($nazw);
                }
                if (is_array($nazw)) {
                    return implode(' ', array_filter($nazw, 'is_string'));
                }
            }
            
            // Płaska tablica stringów
            if (isset($nazwiskoField[0]) && is_string($nazwiskoField[0])) {
                return implode(' ', $nazwiskoField);
            }
        }
        
        return '';
    }
    
    private function parseOdpis($odpis) {
        $result = ['zarzad' => [], 'prokurenci' => []];
        
        $dane = $odpis['dane'] ?? [];
        $dzial2 = $dane['dzial2'] ?? [];
        
        // Debug - zapisz strukturę
        $this->debugInfo['dzial2_keys'] = array_keys($dzial2);
        
        // Zarząd - może być w różnych miejscach
        $reprezentacja = $dzial2['reprezentacja'] ?? [];
        $sklad = $reprezentacja['sklad'] ?? [];
        
        // Czasem skład jest bezpośrednio tablicą, czasem ma dodatkowy poziom
        if (isset($sklad[0]) && is_array($sklad[0])) {
            // OK - to jest lista osób
        } elseif (isset($sklad['skladOrganuReprezentacji'])) {
            $sklad = $sklad['skladOrganuReprezentacji'];
        }
        
        $this->debugInfo['sklad_count'] = count($sklad);
        $this->debugInfo['sklad_sample'] = $sklad[0] ?? null;
        
        foreach ($sklad as $osoba) {
            if (!is_array($osoba)) continue;
            
            $imiona = $this->parseImiona($osoba['imiona'] ?? '');
            $nazwisko = $this->parseNazwisko($osoba['nazwisko'] ?? '');
            
            // Pomiń jeśli nie ma imienia lub nazwiska
            if (empty($imiona) || empty($nazwisko)) {
                $this->debugInfo['skipped_empty'][] = $osoba;
                continue;
            }
            
            // Pomiń jeśli zawiera "Array"
            if (strpos($imiona, 'Array') !== false || strpos($nazwisko, 'Array') !== false) {
                continue;
            }
            
            $funkcja = $osoba['funkcjaWOrganie'] ?? $osoba['funkcja'] ?? 'Członek Zarządu';
            if (is_array($funkcja)) {
                $funkcja = $funkcja['funkcja'] ?? $funkcja[0] ?? 'Członek Zarządu';
            }
            
            $result['zarzad'][] = [
                'imiona' => $imiona,
                'nazwisko' => $nazwisko,
                'funkcja' => $funkcja
            ];
        }
        
        // Prokurenci
        $prokurenci = $dzial2['prokurenci'] ?? [];
        if (isset($prokurenci['prokurenci'])) {
            $prokurenci = $prokurenci['prokurenci'];
        }
        
        foreach ($prokurenci as $prokurent) {
            if (!is_array($prokurent)) continue;
            
            $imiona = $this->parseImiona($prokurent['imiona'] ?? '');
            $nazwisko = $this->parseNazwisko($prokurent['nazwisko'] ?? '');
            
            if (empty($imiona) || empty($nazwisko)) continue;
            if (strpos($imiona, 'Array') !== false || strpos($nazwisko, 'Array') !== false) continue;
            
            $rodzaj = $prokurent['rodzajProkury'] ?? 'Prokurent';
            if (is_array($rodzaj)) {
                $rodzaj = $rodzaj['rodzajProkury'] ?? $rodzaj[0] ?? 'Prokurent';
            }
            
            $result['prokurenci'][] = [
                'imiona' => $imiona,
                'nazwisko' => $nazwisko,
                'rodzaj' => $rodzaj
            ];
        }
        
        return $result;
    }
}

// === JSON Response Helper ===
function jsonResponse($data) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// === AKCJE AJAX ===
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'process_all') {
    $stmt = $db->query("
        SELECT k.id, k.nazwa, k.nip 
        FROM crm_klienci k 
        WHERE k.nip IS NOT NULL AND k.nip != ''
        AND (k.krs_checked IS NULL OR k.krs_checked = 0)
        ORDER BY k.id
        LIMIT 1
    ");
    $firma = $stmt->fetch();
    
    if (!$firma) {
        jsonResponse(['done' => true]);
    }
    
    $result = processCompany($db, $firma['id'], $firma['nip']);
    $result['firma'] = $firma['nazwa'];
    $result['id'] = $firma['id'];
    jsonResponse($result);
}

if ($action === 'debug_krs') {
    $krs = $_GET['krs'] ?? '';
    if (!$krs) {
        jsonResponse(['error' => 'Brak KRS']);
    }
    
    $krsApi = new KRSApi();
    $data = $krsApi->getByKrs($krs);
    
    jsonResponse([
        'data' => $data,
        'debug' => $krsApi->debugInfo,
        'error' => $krsApi->lastError
    ]);
}

function processCompany($db, $klientId, $nip) {
    $log = [];
    $added = 0;
    
    // Oznacz jako sprawdzone
    $db->prepare("UPDATE crm_klienci SET krs_checked = 1 WHERE id = ?")->execute([$klientId]);
    
    $gus = new GUSApi();
    if (!$gus->login()) {
        return ['error' => 'GUS: ' . $gus->lastError, 'log' => $log, 'skipped' => true];
    }
    
    $log[] = "Szukam NIP: $nip";
    $gusData = $gus->searchByNip($nip);
    
    if (!$gusData) {
        $gus->logout();
        return ['error' => 'Nie znaleziono w GUS', 'log' => $log, 'skipped' => true];
    }
    
    if ($gusData['typ'] !== 'P') {
        $gus->logout();
        return ['error' => 'Nie jest osobą prawną', 'log' => $log, 'skipped' => true];
    }
    
    $fullReport = $gus->getFullReport($gusData['regon']);
    $gus->logout();
    
    $krs = $fullReport['krs'] ?? null;
    
    if (!$krs) {
        return ['error' => 'Brak KRS w raporcie', 'log' => $log, 'skipped' => true];
    }
    
    $log[] = "KRS: $krs";
    $db->prepare("UPDATE crm_klienci SET krs_numer = ? WHERE id = ?")->execute([$krs, $klientId]);
    
    $krsApi = new KRSApi();
    $krsData = $krsApi->getByKrs($krs);
    
    if (!$krsData) {
        return ['error' => 'KRS API: ' . $krsApi->lastError, 'log' => $log, 'skipped' => true, 'debug' => $krsApi->debugInfo];
    }
    
    $log[] = "Zarząd: " . count($krsData['zarzad']) . ", Prokurenci: " . count($krsData['prokurenci']);
    
    // Zapisz osoby
    $stmt = $db->prepare("INSERT INTO crm_osoby (klient_id, imie, nazwisko, stanowisko, uwagi, created_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
    
    foreach ($krsData['zarzad'] as $osoba) {
        // Walidacja - nie zapisuj pustych lub "Array"
        if (empty($osoba['imiona']) || empty($osoba['nazwisko'])) continue;
        if ($osoba['imiona'] === 'Array' || $osoba['nazwisko'] === 'Array') continue;
        
        $check = $db->prepare("SELECT id FROM crm_osoby WHERE klient_id = ? AND imie = ? AND nazwisko = ?");
        $check->execute([$klientId, $osoba['imiona'], $osoba['nazwisko']]);
        if ($check->fetch()) continue;
        
        $stmt->execute([$klientId, $osoba['imiona'], $osoba['nazwisko'], $osoba['funkcja'], 'Zarząd - KRS']);
        $added++;
        $log[] = "+ {$osoba['imiona']} {$osoba['nazwisko']} ({$osoba['funkcja']})";
    }
    
    foreach ($krsData['prokurenci'] as $osoba) {
        if (empty($osoba['imiona']) || empty($osoba['nazwisko'])) continue;
        if ($osoba['imiona'] === 'Array' || $osoba['nazwisko'] === 'Array') continue;
        
        $check = $db->prepare("SELECT id FROM crm_osoby WHERE klient_id = ? AND imie = ? AND nazwisko = ?");
        $check->execute([$klientId, $osoba['imiona'], $osoba['nazwisko']]);
        if ($check->fetch()) continue;
        
        $stmt->execute([$klientId, $osoba['imiona'], $osoba['nazwisko'], 'Prokurent - ' . $osoba['rodzaj'], 'Prokurent - KRS']);
        $added++;
    }
    
    return [
        'success' => true,
        'added' => $added,
        'krs' => $krs,
        'zarzad' => count($krsData['zarzad']),
        'prokurenci' => count($krsData['prokurenci']),
        'log' => $log,
        'debug' => $krsApi->debugInfo
    ];
}

// === STATYSTYKI ===
$stats = $db->query("
    SELECT 
        SUM(CASE WHEN nip IS NOT NULL AND nip != '' THEN 1 ELSE 0 END) as z_nip,
        SUM(CASE WHEN krs_checked = 1 THEN 1 ELSE 0 END) as sprawdzone,
        SUM(CASE WHEN krs_numer IS NOT NULL AND krs_numer != '' THEN 1 ELSE 0 END) as z_krs,
        SUM(CASE WHEN id IN (SELECT DISTINCT klient_id FROM crm_osoby WHERE (stanowisko LIKE '%Zarząd%' OR stanowisko LIKE '%Prokurent%' OR stanowisko LIKE '%Prezes%') AND imie != 'Array') THEN 1 ELSE 0 END) as z_zarzadem
    FROM crm_klienci
")->fetch();

// Policz błędne wpisy Array
$arrayCount = $db->query("SELECT COUNT(*) FROM crm_osoby WHERE imie = 'Array' OR nazwisko = 'Array'")->fetchColumn();

$doSprawdzenia = $stats['z_nip'] - $stats['sprawdzone'];

$firmy = $db->query("
    SELECT k.id, k.nazwa, k.nip, k.krs_checked, k.krs_numer,
           (SELECT COUNT(*) FROM crm_osoby WHERE klient_id = k.id AND (stanowisko LIKE '%Zarząd%' OR stanowisko LIKE '%Prokurent%' OR stanowisko LIKE '%Prezes%') AND imie != 'Array') as liczba_zarzad
    FROM crm_klienci k
    WHERE k.nip IS NOT NULL AND k.nip != ''
    ORDER BY k.krs_checked ASC, k.nazwa ASC
    LIMIT 150
")->fetchAll();

$msgParam = $_GET['msg'] ?? '';
$deletedCount = $_GET['deleted'] ?? 0;
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pobieranie Zarządu z KRS v5</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .card-header { padding: 20px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 10px; }
        .card-header h2 { margin: 0; font-size: 20px; }
        .card-body { padding: 20px; }
        
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 15px; }
        .alert-success { background: #dcfce7; color: #166534; }
        .alert-warning { background: #fef3c7; color: #92400e; }
        .alert-danger { background: #fee2e2; color: #991b1b; }
        
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .stat { background: #f8fafc; padding: 16px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 26px; font-weight: 700; color: #1e40af; }
        .stat-label { font-size: 11px; color: #6b7280; text-transform: uppercase; }
        .stat.green .stat-value { color: #16a34a; }
        .stat.orange .stat-value { color: #ea580c; }
        .stat.red .stat-value { color: #dc2626; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; }
        .btn-success { background: #16a34a; color: white; }
        .btn-warning { background: #ea580c; color: white; }
        .btn-danger { background: #dc2626; color: white; }
        .btn-outline { background: white; border: 1px solid #d1d5db; color: #374151; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f9fafb; font-weight: 600; font-size: 11px; text-transform: uppercase; color: #6b7280; }
        tr:hover { background: #f9fafb; }
        tr.checked { background: #f0fdf4; }
        tr.no-krs { background: #fef3c7; }
        
        .badge { display: inline-block; padding: 3px 8px; border-radius: 9999px; font-size: 11px; font-weight: 500; }
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-gray { background: #f1f5f9; color: #64748b; }
        
        .progress-bar { height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden; margin-bottom: 10px; }
        .progress-fill { height: 100%; background: #16a34a; transition: width 0.3s; }
        
        .log { background: #1f2937; color: #e5e7eb; padding: 15px; border-radius: 8px; font-family: monospace; font-size: 11px; max-height: 250px; overflow-y: auto; margin-bottom: 20px; }
        .log-entry.success { color: #4ade80; }
        .log-entry.error { color: #f87171; }
        .log-entry.skip { color: #fbbf24; }
        .log-entry.debug { color: #94a3b8; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>👥 Pobieranie Zarządu z KRS <small style="color:#6b7280">v5</small></h2>
                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                    <?php if ($arrayCount > 0): ?>
                    <a href="?action=cleanup" class="btn btn-danger btn-sm" onclick="return confirm('Usunąć <?= $arrayCount ?> błędnych wpisów Array i zresetować?')">
                        🧹 Usuń błędne (<?= $arrayCount ?>)
                    </a>
                    <?php endif; ?>
                    <a href="?action=reset" class="btn btn-warning btn-sm" onclick="return confirm('Reset wszystkiego?')">🔄 Reset</a>
                    <a href="crm/klienci.php" class="btn btn-outline btn-sm">← CRM</a>
                </div>
            </div>
            <div class="card-body">
                
                <?php if ($msgParam === 'cleanup'): ?>
                <div class="alert alert-success">✅ Usunięto <?= $deletedCount ?> błędnych wpisów. Możesz teraz ponownie pobrać dane.</div>
                <?php elseif ($msgParam === 'reset'): ?>
                <div class="alert alert-success">✅ Zresetowano wszystko</div>
                <?php endif; ?>
                
                <?php if ($arrayCount > 0): ?>
                <div class="alert alert-danger">
                    ⚠️ <strong>Wykryto <?= $arrayCount ?> błędnych wpisów "Array Array"!</strong><br>
                    Kliknij "🧹 Usuń błędne" żeby je usunąć i zresetować pobieranie.
                </div>
                <?php endif; ?>
                
                <div class="stats">
                    <div class="stat">
                        <div class="stat-value"><?= $stats['z_nip'] ?></div>
                        <div class="stat-label">Z NIP</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value"><?= $stats['sprawdzone'] ?></div>
                        <div class="stat-label">Sprawdzonych</div>
                    </div>
                    <div class="stat orange">
                        <div class="stat-value"><?= max(0, $doSprawdzenia) ?></div>
                        <div class="stat-label">Do sprawdzenia</div>
                    </div>
                    <div class="stat green">
                        <div class="stat-value"><?= $stats['z_zarzadem'] ?></div>
                        <div class="stat-label">Z zarządem</div>
                    </div>
                    <?php if ($arrayCount > 0): ?>
                    <div class="stat red">
                        <div class="stat-value"><?= $arrayCount ?></div>
                        <div class="stat-label">Błędne wpisy</div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: <?= $stats['z_nip'] > 0 ? round($stats['sprawdzone'] / $stats['z_nip'] * 100) : 0 ?>%"></div>
                </div>
                
                <div style="margin-bottom: 15px; display: flex; gap: 10px; align-items: center;">
                    <button class="btn btn-success" id="btnStart" onclick="startAll()" <?= $doSprawdzenia <= 0 || $arrayCount > 0 ? 'disabled' : '' ?>>
                        ▶️ Pobierz (<?= max(0, $doSprawdzenia) ?>)
                    </button>
                    <button class="btn btn-outline" id="btnStop" onclick="stopAll()" disabled>⏹️ Stop</button>
                    <span id="statusText" style="color: #6b7280;"></span>
                </div>
                
                <div class="log" id="log" style="display: none;"></div>
                
                <table>
                    <thead>
                        <tr>
                            <th>Firma</th>
                            <th>NIP</th>
                            <th>KRS</th>
                            <th>Zarząd</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($firmy as $f): 
                            $isChecked = $f['krs_checked'] == 1;
                            $hasKrs = !empty($f['krs_numer']);
                            $hasZarzad = $f['liczba_zarzad'] > 0;
                        ?>
                        <tr class="<?= $isChecked ? ($hasKrs ? 'checked' : 'no-krs') : '' ?>">
                            <td>
                                <a href="crm/klient_karta.php?id=<?= $f['id'] ?>" style="color: #1e40af; text-decoration: none;">
                                    <?= htmlspecialchars(mb_substr($f['nazwa'], 0, 40)) ?>
                                </a>
                            </td>
                            <td style="font-family: monospace; font-size: 12px;"><?= $f['nip'] ?></td>
                            <td style="font-family: monospace; font-size: 11px; color: #6b7280;"><?= $f['krs_numer'] ?: '—' ?></td>
                            <td><?= $hasZarzad ? '<span class="badge badge-success">✅ ' . $f['liczba_zarzad'] . '</span>' : '—' ?></td>
                            <td>
                                <?php if ($hasZarzad): ?>
                                    <span class="badge badge-success">OK</span>
                                <?php elseif ($isChecked): ?>
                                    <span class="badge badge-gray">Brak KRS</span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Czeka</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
    
    <script>
    let running = false;
    let checked = <?= $stats['sprawdzone'] ?>;
    let total = <?= $stats['z_nip'] ?>;
    
    function addLog(msg, type = '') {
        const log = document.getElementById('log');
        log.style.display = 'block';
        const time = new Date().toLocaleTimeString();
        log.innerHTML = `<div class="log-entry ${type}">[${time}] ${msg}</div>` + log.innerHTML;
    }
    
    function updateProgress() {
        document.getElementById('progressFill').style.width = (checked / total * 100) + '%';
        document.getElementById('statusText').textContent = `${checked} / ${total}`;
    }
    
    function startAll() {
        running = true;
        document.getElementById('btnStart').disabled = true;
        document.getElementById('btnStop').disabled = false;
        addLog('▶️ Start', 'success');
        processNext();
    }
    
    function stopAll() {
        running = false;
        document.getElementById('btnStart').disabled = false;
        document.getElementById('btnStop').disabled = true;
        addLog('⏹️ Stop', 'error');
    }
    
    function processNext() {
        if (!running) return;
        
        fetch(location.href, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=process_all'
        })
        .then(r => {
            const contentType = r.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error('Nieprawidłowa odpowiedź');
            }
            return r.json();
        })
        .then(data => {
            if (data.done) {
                addLog('🎉 Zakończono!', 'success');
                stopAll();
                setTimeout(() => location.reload(), 1000);
                return;
            }
            
            if (data.error || data.skipped) {
                addLog(`⏭️ ${data.firma || 'Firma'}: ${data.error}`, 'skip');
            } else {
                addLog(`✅ ${data.firma}: +${data.added} osób (KRS: ${data.krs})`, 'success');
                if (data.log) {
                    data.log.forEach(l => addLog('   ' + l, 'debug'));
                }
            }
            
            checked++;
            updateProgress();
            setTimeout(processNext, 700);
        })
        .catch(e => {
            addLog(`❌ ${e.message}`, 'error');
            checked++;
            updateProgress();
            setTimeout(processNext, 2000);
        });
    }
    </script>
</body>
</html>
