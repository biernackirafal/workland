<?php
/**
 * CRM LinkedIn - Prosty panel do wyszukiwania
 * 
 * Szybkie linki do wyszukiwania:
 * - Profilu firmy na LinkedIn
 * - Pracowników firmy na LinkedIn
 * 
 * LOKALIZACJA: /kadry/crm/crm_linkedin.php
 */

require_once '../includes/db.php';
requireLogin();

$db = initDatabase();

// Migracja
try { $db->exec("ALTER TABLE crm_klienci ADD COLUMN linkedin_url VARCHAR(255)"); } catch (PDOException $e) {}

// Zapisz URL
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $id = (int)$_POST['id'];
    $url = trim($_POST['url']);
    $db->prepare("UPDATE crm_klienci SET linkedin_url = ? WHERE id = ?")->execute([$url, $id]);
    header('Content-Type: application/json');
    echo json_encode(['ok' => true]);
    exit;
}

// Funkcje
function cleanName($name) {
    $name = preg_replace('/\s*(sp\.\s*z\s*o\.?\s*o\.?|s\.?\s*a\.?|spółka.*|sp\.\s*k\.?)\s*$/ui', '', $name);
    return trim(str_replace(['"', "'", '„', '"'], '', $name));
}

// Obsługa wejścia z karty klienta
$klientId = (int)($_GET['klient_id'] ?? 0);
$klientDane = null;
if ($klientId) {
    $stmt = $db->prepare("SELECT id, nazwa, miasto, linkedin_url FROM crm_klienci WHERE id = ?");
    $stmt->execute([$klientId]);
    $klientDane = $stmt->fetch();
}

// Filtry
$filter = $_GET['f'] ?? 'all';
$search = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['p'] ?? 1));
$perPage = 30;

$where = "WHERE nip IS NOT NULL AND nip != ''";
if ($filter === 'bez') $where .= " AND (linkedin_url IS NULL OR linkedin_url = '')";
if ($filter === 'z') $where .= " AND linkedin_url IS NOT NULL AND linkedin_url != ''";
if ($search) $where .= " AND nazwa LIKE '%" . addslashes($search) . "%'";

$total = $db->query("SELECT COUNT(*) FROM crm_klienci $where")->fetchColumn();
$pages = ceil($total / $perPage);
$offset = ($page - 1) * $perPage;

$firmy = $db->query("
    SELECT id, nazwa, miasto, linkedin_url 
    FROM crm_klienci $where 
    ORDER BY nazwa 
    LIMIT $perPage OFFSET $offset
")->fetchAll();

$stats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN linkedin_url IS NOT NULL AND linkedin_url != '' THEN 1 ELSE 0 END) as done
    FROM crm_klienci WHERE nip IS NOT NULL AND nip != ''
")->fetch();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LinkedIn - CRM</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; }
        .wrap { max-width: 1100px; margin: 0 auto; padding: 20px; }
        
        .header { background: #0077b5; color: white; padding: 20px 25px; border-radius: 12px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        .header h1 { margin: 0; font-size: 22px; display: flex; align-items: center; gap: 10px; }
        .header-stats { font-size: 14px; opacity: 0.9; }
        
        .toolbar { background: white; padding: 15px 20px; border-radius: 10px; margin-bottom: 15px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .search-box { flex: 1; min-width: 200px; padding: 10px 15px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 14px; }
        .search-box:focus { border-color: #0077b5; outline: none; }
        
        .tabs { display: flex; gap: 5px; }
        .tab { padding: 8px 16px; border: none; background: #f1f5f9; border-radius: 6px; cursor: pointer; font-size: 13px; text-decoration: none; color: #475569; }
        .tab:hover { background: #e2e8f0; }
        .tab.active { background: #0077b5; color: white; }
        
        .card { background: white; border-radius: 10px; overflow: hidden; }
        
        .row { display: grid; grid-template-columns: 1fr auto auto; gap: 10px; padding: 12px 20px; border-bottom: 1px solid #f1f5f9; align-items: center; }
        .row:hover { background: #f8fafc; }
        .row:last-child { border-bottom: none; }
        
        .firma-name { font-weight: 500; color: #1e293b; font-size: 14px; }
        .firma-meta { font-size: 12px; color: #64748b; margin-top: 2px; }
        .firma-meta a { color: #0077b5; text-decoration: none; }
        
        .btns { display: flex; gap: 6px; }
        .btn { padding: 7px 12px; border: none; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 5px; white-space: nowrap; }
        .btn-li { background: #0077b5; color: white; }
        .btn-li:hover { background: #005e8c; }
        .btn-people { background: #059669; color: white; }
        .btn-people:hover { background: #047857; }
        .btn-outline { background: white; border: 1px solid #d1d5db; color: #374151; }
        
        .url-input { width: 220px; padding: 7px 10px; border: 1px solid #e2e8f0; border-radius: 6px; font-size: 12px; }
        .url-input:focus { border-color: #0077b5; outline: none; }
        .url-input.saved { background: #dcfce7; border-color: #16a34a; }
        .url-input.has-url { background: #f0fdf4; }
        
        .pagination { display: flex; gap: 5px; justify-content: center; padding: 20px; }
        .pagination a, .pagination span { padding: 8px 14px; border-radius: 6px; text-decoration: none; font-size: 13px; }
        .pagination a { background: white; color: #374151; border: 1px solid #e2e8f0; }
        .pagination a:hover { background: #f1f5f9; }
        .pagination .cur { background: #0077b5; color: white; }
        
        .bookmarklet-box { background: #fffbeb; border: 1px solid #fcd34d; padding: 15px 20px; border-radius: 10px; margin-bottom: 15px; font-size: 13px; }
        .bookmarklet-box strong { color: #92400e; }
        .bookmarklet-link { display: inline-block; padding: 6px 14px; background: #f59e0b; color: white; border-radius: 6px; text-decoration: none; font-weight: 500; margin-left: 10px; }
        
        .empty { text-align: center; padding: 60px 20px; color: #64748b; }
        
        @media (max-width: 700px) {
            .row { grid-template-columns: 1fr; gap: 8px; }
            .btns { justify-content: flex-start; }
            .url-input { width: 100%; }
        }
    </style>
</head>
<body>
<div class="wrap">
    
    <div class="header">
        <h1>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
            LinkedIn
        </h1>
        <div class="header-stats">
            ✅ <?= $stats['done'] ?> / <?= $stats['total'] ?> firm
            <a href="klienci.php" style="color: white; margin-left: 15px;">← CRM</a>
        </div>
    </div>
    
    <div class="bookmarklet-box">
        <strong>💡 Wskazówka:</strong> Przeciągnij ten przycisk na pasek zakładek → 
        <a class="bookmarklet-link" href="javascript:(function(){if(location.hostname.includes('linkedin.com')){navigator.clipboard.writeText(location.href);alert('✅ Skopiowano: '+location.href)}else{alert('Otwórz LinkedIn!')}})();">📋 Kopiuj URL</a>
        <br><small style="color:#92400e">Gdy jesteś na LinkedIn, kliknij go żeby skopiować URL do schowka.</small>
    </div>
    
    <form class="toolbar" method="GET">
        <input type="text" name="q" class="search-box" placeholder="🔍 Szukaj firmy..." value="<?= htmlspecialchars($search) ?>">
        <input type="hidden" name="f" value="<?= $filter ?>">
        <?php if ($klientId): ?><input type="hidden" name="klient_id" value="<?= $klientId ?>"><?php endif; ?>
        
        <div class="tabs">
            <a href="?f=all&q=<?= urlencode($search) ?><?= $klientId ? '&klient_id='.$klientId : '' ?>" class="tab <?= $filter === 'all' ? 'active' : '' ?>">Wszystkie</a>
            <a href="?f=bez&q=<?= urlencode($search) ?><?= $klientId ? '&klient_id='.$klientId : '' ?>" class="tab <?= $filter === 'bez' ? 'active' : '' ?>">Bez LinkedIn (<?= $stats['total'] - $stats['done'] ?>)</a>
            <a href="?f=z&q=<?= urlencode($search) ?><?= $klientId ? '&klient_id='.$klientId : '' ?>" class="tab <?= $filter === 'z' ? 'active' : '' ?>">Z LinkedIn</a>
        </div>
    </form>
    
    <div class="card">
        <?php if ($klientDane): 
            $cleanName = cleanName($klientDane['nazwa']);
            $liSearch = 'https://www.linkedin.com/search/results/companies/?keywords=' . urlencode($cleanName);
            $peopleSearch = 'https://www.linkedin.com/search/results/people/?keywords=' . urlencode($cleanName);
            $hasUrl = !empty($klientDane['linkedin_url']);
        ?>
        <div style="background: #ede9fe; border-bottom: 2px solid #7c3aed; padding: 15px 20px;">
            <div style="font-size: 13px; color: #7c3aed; font-weight: 600; margin-bottom: 10px;">🎯 Wybrany klient</div>
            <div class="row" style="padding: 0; border: none; background: transparent;">
                <div>
                    <div class="firma-name" style="font-size: 16px;"><?= htmlspecialchars($klientDane['nazwa']) ?></div>
                    <div class="firma-meta">
                        <?= $klientDane['miasto'] ? htmlspecialchars($klientDane['miasto']) : '' ?>
                        <?php if ($hasUrl): ?>
                            · <a href="<?= htmlspecialchars($klientDane['linkedin_url']) ?>" target="_blank">Zobacz profil →</a>
                        <?php endif; ?>
                        · <a href="klient_karta.php?id=<?= $klientDane['id'] ?>">Karta klienta</a>
                    </div>
                </div>
                <div class="btns">
                    <a href="<?= $liSearch ?>" target="_blank" class="btn btn-li">🔍 Firma</a>
                    <a href="<?= $peopleSearch ?>" target="_blank" class="btn btn-people">👥 Pracownicy</a>
                </div>
                <input 
                    type="text" 
                    class="url-input <?= $hasUrl ? 'has-url' : '' ?>" 
                    placeholder="Wklej URL profilu..." 
                    value="<?= htmlspecialchars($klientDane['linkedin_url'] ?? '') ?>"
                    data-id="<?= $klientDane['id'] ?>"
                    onchange="saveUrl(this)"
                >
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (empty($firmy)): ?>
            <div class="empty">Brak firm do wyświetlenia</div>
        <?php else: ?>
            <?php foreach ($firmy as $f): 
                $cleanName = cleanName($f['nazwa']);
                $liSearch = 'https://www.linkedin.com/search/results/companies/?keywords=' . urlencode($cleanName);
                $peopleSearch = 'https://www.linkedin.com/search/results/people/?keywords=' . urlencode($cleanName);
                $hasUrl = !empty($f['linkedin_url']);
            ?>
            <div class="row">
                <div>
                    <div class="firma-name"><?= htmlspecialchars($f['nazwa']) ?></div>
                    <div class="firma-meta">
                        <?= $f['miasto'] ? htmlspecialchars($f['miasto']) : '' ?>
                        <?php if ($hasUrl): ?>
                            · <a href="<?= htmlspecialchars($f['linkedin_url']) ?>" target="_blank">Zobacz profil →</a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="btns">
                    <a href="<?= $liSearch ?>" target="_blank" class="btn btn-li" title="Szukaj profilu firmy">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                        Firma
                    </a>
                    <a href="<?= $peopleSearch ?>" target="_blank" class="btn btn-people" title="Szukaj pracowników">
                        👥 Ludzie
                    </a>
                </div>
                
                <input type="text" 
                       class="url-input <?= $hasUrl ? 'has-url' : '' ?>" 
                       data-id="<?= $f['id'] ?>"
                       value="<?= htmlspecialchars($f['linkedin_url'] ?? '') ?>"
                       placeholder="Wklej URL LinkedIn..."
                       onkeypress="if(event.key==='Enter'){saveUrl(this);event.preventDefault()}"
                       onpaste="setTimeout(()=>saveUrl(this),100)">
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <?php if ($pages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?f=<?= $filter ?>&q=<?= urlencode($search) ?>&p=<?= $page-1 ?><?= $klientId ? '&klient_id='.$klientId : '' ?>">← Poprz.</a>
        <?php endif; ?>
        
        <?php for ($i = max(1, $page-2); $i <= min($pages, $page+2); $i++): ?>
            <?php if ($i == $page): ?>
                <span class="cur"><?= $i ?></span>
            <?php else: ?>
                <a href="?f=<?= $filter ?>&q=<?= urlencode($search) ?>&p=<?= $i ?><?= $klientId ? '&klient_id='.$klientId : '' ?>"><?= $i ?></a>
            <?php endif; ?>
        <?php endfor; ?>
        
        <?php if ($page < $pages): ?>
            <a href="?f=<?= $filter ?>&q=<?= urlencode($search) ?>&p=<?= $page+1 ?><?= $klientId ? '&klient_id='.$klientId : '' ?>">Nast. →</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    
</div>

<script>
function saveUrl(input) {
    const id = input.dataset.id;
    const url = input.value.trim();
    
    fetch(location.href, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'save=1&id=' + id + '&url=' + encodeURIComponent(url)
    })
    .then(r => r.json())
    .then(() => {
        input.classList.add('saved');
        setTimeout(() => input.classList.remove('saved'), 1500);
    });
}
</script>
</body>
</html>
