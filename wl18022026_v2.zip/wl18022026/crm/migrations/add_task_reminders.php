<?php
/**
 * Migracja: Dodanie pól przypomnień mailowych do zadań
 * System Ewidencji Pracowników - Work Land CRM
 * 
 * Uruchom jednorazowo: php add_task_reminders.php
 */

require_once '../../includes/db.php';

$db = initDatabase();

echo "=== Migracja: Przypomnienia mailowe dla zadań ===\n\n";

try {
    $db->beginTransaction();
    
    // Sprawdź czy kolumny już istnieją
    $columns = $db->query("PRAGMA table_info(crm_zadania)")->fetchAll(PDO::FETCH_COLUMN, 1);
    
    $newColumns = [
        'przypomnienie_email' => "ALTER TABLE crm_zadania ADD COLUMN przypomnienie_email INTEGER DEFAULT 0",
        'przypomnienie_dni' => "ALTER TABLE crm_zadania ADD COLUMN przypomnienie_dni INTEGER DEFAULT 1",
        'przypomnienie_wyslane' => "ALTER TABLE crm_zadania ADD COLUMN przypomnienie_wyslane INTEGER DEFAULT 0",
        'przypomnienie_data' => "ALTER TABLE crm_zadania ADD COLUMN przypomnienie_data TEXT"
    ];
    
    foreach ($newColumns as $colName => $sql) {
        if (!in_array($colName, $columns)) {
            $db->exec($sql);
            echo "✓ Dodano kolumnę: $colName\n";
        } else {
            echo "• Kolumna już istnieje: $colName\n";
        }
    }
    
    // Sprawdź czy tabela konfiguracji mailowej istnieje
    $tableExists = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='crm_config'")->fetch();
    
    if (!$tableExists) {
        $db->exec("
            CREATE TABLE crm_config (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                klucz TEXT UNIQUE NOT NULL,
                wartosc TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                updated_at TEXT DEFAULT CURRENT_TIMESTAMP
            )
        ");
        echo "✓ Utworzono tabelę: crm_config\n";
        
        // Domyślna konfiguracja SMTP
        $defaults = [
            ['mail_smtp_host', 'smtp.gmail.com'],
            ['mail_smtp_port', '587'],
            ['mail_smtp_secure', 'tls'],
            ['mail_smtp_user', ''],
            ['mail_smtp_pass', ''],
            ['mail_from_email', ''],
            ['mail_from_name', 'Work Land CRM'],
            ['mail_enabled', '0'],
            ['reminder_default_days', '1'],
            ['reminder_cron_last_run', '']
        ];
        
        $stmt = $db->prepare("INSERT INTO crm_config (klucz, wartosc) VALUES (?, ?)");
        foreach ($defaults as $config) {
            $stmt->execute($config);
        }
        echo "✓ Dodano domyślną konfigurację mailową\n";
    } else {
        echo "• Tabela crm_config już istnieje\n";
    }
    
    // Tabela logów wysyłek
    $logTableExists = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='crm_mail_log'")->fetch();
    
    if (!$logTableExists) {
        $db->exec("
            CREATE TABLE crm_mail_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                zadanie_id INTEGER,
                user_id INTEGER,
                email TEXT,
                temat TEXT,
                status TEXT,
                error_msg TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (zadanie_id) REFERENCES crm_zadania(id),
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ");
        echo "✓ Utworzono tabelę: crm_mail_log\n";
    } else {
        echo "• Tabela crm_mail_log już istnieje\n";
    }
    
    $db->commit();
    
    echo "\n=== Migracja zakończona pomyślnie! ===\n";
    echo "\nNastępne kroki:\n";
    echo "1. Skonfiguruj ustawienia SMTP w panelu administracyjnym\n";
    echo "2. Dodaj skrypt cron_reminders.php do zadań crona:\n";
    echo "   0 8 * * * php /path/to/crm/cron_reminders.php\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "❌ Błąd migracji: " . $e->getMessage() . "\n";
    exit(1);
}
