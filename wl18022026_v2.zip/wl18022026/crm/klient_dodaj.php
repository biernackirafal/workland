<?php
/**
 * CRM - Dodaj/Edytuj potencjalnego klienta
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

$id = intval($_GET['id'] ?? 0);
$klient = null;
$errors = [];
$success = false;

// Pobierz użytkowników
$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();

// Edycja - pobierz dane
if ($id > 0) {
    $stmt = $db->prepare("SELECT * FROM crm_klienci WHERE id = ?");
    $stmt->execute([$id]);
    $klient = $stmt->fetch();
    
    if (!$klient) {
        header('Location: klienci.php');
        exit;
    }
}

// Obsługa formularza
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'nazwa' => trim($_POST['nazwa'] ?? ''),
        'nip' => trim($_POST['nip'] ?? ''),
        'regon' => trim($_POST['regon'] ?? ''),
        'adres' => trim($_POST['adres'] ?? ''),
        'kod_pocztowy' => trim($_POST['kod_pocztowy'] ?? ''),
        'miasto' => trim($_POST['miasto'] ?? ''),
        'wojewodztwo' => trim($_POST['wojewodztwo'] ?? ''),
        'telefon' => trim($_POST['telefon'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'www' => trim($_POST['www'] ?? ''),
        'branza' => trim($_POST['branza'] ?? ''),
        'ilosc_pracownikow' => trim($_POST['ilosc_pracownikow'] ?? ''),
        'zrodlo_pozyskania' => trim($_POST['zrodlo_pozyskania'] ?? ''),
        'polecenie_od_kogo' => trim($_POST['polecenie_od_kogo'] ?? ''),
        'status' => $_POST['status'] ?? 'nowy',
        'priorytet' => $_POST['priorytet'] ?? 'normalny',
        'przypisany_do' => intval($_POST['przypisany_do'] ?? 0) ?: null,
        'uwagi' => trim($_POST['uwagi'] ?? '')
    ];
    
    // Walidacja
    if (empty($data['nazwa'])) {
        $errors[] = 'Nazwa firmy jest wymagana';
    }
    
    // Sprawdź duplikat NIP
    if ($data['nip']) {
        $stmt = $db->prepare("SELECT id FROM crm_klienci WHERE nip = ? AND id != ?");
        $stmt->execute([$data['nip'], $id]);
        if ($stmt->fetch()) {
            $errors[] = 'Potencjalny klient z takim NIP już istnieje';
        }
    }
    
    if (empty($errors)) {
        if ($id > 0) {
            // Aktualizacja
            $sql = "UPDATE crm_klienci SET 
                    nazwa = ?, nip = ?, regon = ?, adres = ?, kod_pocztowy = ?, miasto = ?,
                    wojewodztwo = ?, telefon = ?, email = ?, www = ?, branza = ?,
                    ilosc_pracownikow = ?, zrodlo_pozyskania = ?, polecenie_od_kogo = ?, status = ?, priorytet = ?,
                    przypisany_do = ?, uwagi = ?, updated_at = datetime('now')
                    WHERE id = ?";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                $data['nazwa'], $data['nip'], $data['regon'], $data['adres'], $data['kod_pocztowy'],
                $data['miasto'], $data['wojewodztwo'], $data['telefon'], $data['email'], $data['www'],
                $data['branza'], $data['ilosc_pracownikow'], $data['zrodlo_pozyskania'], $data['polecenie_od_kogo'], $data['status'],
                $data['priorytet'], $data['przypisany_do'], $data['uwagi'], $id
            ]);
            
            logChange($db, 'UPDATE', 'crm_klienci', $id, "Zaktualizowano lead: {$data['nazwa']}", $klient, $data);
            $success = true;
            
            // Odśwież dane
            $stmt = $db->prepare("SELECT * FROM crm_klienci WHERE id = ?");
            $stmt->execute([$id]);
            $klient = $stmt->fetch();
        } else {
            // Nowy klient
            $guid = generateGuid();
            $sql = "INSERT INTO crm_klienci 
                    (nazwa, nip, regon, adres, kod_pocztowy, miasto, wojewodztwo, telefon, email, www,
                     branza, ilosc_pracownikow, zrodlo_pozyskania, polecenie_od_kogo, status, priorytet, przypisany_do, uwagi, created_by, guid)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $db->prepare($sql);
            $stmt->execute([
                $data['nazwa'], $data['nip'], $data['regon'], $data['adres'], $data['kod_pocztowy'],
                $data['miasto'], $data['wojewodztwo'], $data['telefon'], $data['email'], $data['www'],
                $data['branza'], $data['ilosc_pracownikow'], $data['zrodlo_pozyskania'], $data['polecenie_od_kogo'], $data['status'],
                $data['priorytet'], $data['przypisany_do'], $data['uwagi'], $currentUser['id'], $guid
            ]);
            
            $newId = $db->lastInsertId();
            logChange($db, 'CREATE', 'crm_klienci', $newId, "Dodano lead: {$data['nazwa']}");
            
            header("Location: klient_karta.php?id=$newId&msg=created");
            exit;
        }
    }
    
    // Zachowaj dane w formularzu
    $klient = array_merge($klient ?? [], $data);
}

$crmStatusy = getCrmStatusy();
$crmPriorytety = getCrmPriorytety();

$wojewodztwa = [
    'dolnośląskie', 'kujawsko-pomorskie', 'lubelskie', 'lubuskie', 
    'łódzkie', 'małopolskie', 'mazowieckie', 'opolskie', 
    'podkarpackie', 'podlaskie', 'pomorskie', 'śląskie', 
    'świętokrzyskie', 'warmińsko-mazurskie', 'wielkopolskie', 'zachodniopomorskie'
];

$zrodla = ['Strona www', 'Polecenie', 'Targi', 'Cold call', 'LinkedIn', 'Ogłoszenie', 'Przetarg', 'Inne'];
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $id > 0 ? 'Edytuj' : 'Dodaj'; ?> potencjalnego klienta - CRM - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .crm-nav { background: #1e40af; padding: 10px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .crm-nav a { color: rgba(255,255,255,0.85); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; transition: all 0.2s; }
        .crm-nav a:hover, .crm-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .crm-nav .nav-title { color: white; font-weight: 600; margin-right: 20px; }
        
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }
        @media (max-width: 900px) { .form-grid { grid-template-columns: 1fr; } }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 15px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 20px; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; font-size: 0.9rem; color: #374151; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px 12px; border: 2px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #2563eb; outline: none; }
        .form-group textarea { min-height: 100px; resize: vertical; }
        
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert.success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert.error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        
        .actions { display: flex; gap: 15px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?php echo sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../klienci.php">🏢 Klienci</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <div class="crm-nav">
            <span class="nav-title">🎯 CRM</span>
            <a href="./">Dashboard</a>
            <a href="klienci.php" class="active">Potencjalni Klienci</a>
            <a href="zadania.php">Zadania</a>
            <a href="kalendarz.php">Kalendarz</a>
        </div>
        
        <header>
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h1><?php echo $id > 0 ? '✏️ Edycja klienta' : '➕ Nowy potencjalny klient'; ?></h1>
                    <p class="subtitle"><?php echo $id > 0 ? htmlspecialchars($klient['nazwa']) : 'Dodaj lead do bazy CRM'; ?></p>
                </div>
                <a href="klienci.php" class="btn">← Wróć do listy</a>
            </div>
        </header>
        
        <?php if ($success): ?>
            <div class="alert success">Dane zostały zapisane</div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="alert error">
                <?php foreach ($errors as $e): ?>
                    <div><?php echo htmlspecialchars($e); ?></div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-grid">
                <!-- Dane podstawowe -->
                <div class="card">
                    <div class="card-header">📋 Dane podstawowe</div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Nazwa firmy *</label>
                            <input type="text" name="nazwa" required value="<?php echo htmlspecialchars($klient['nazwa'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>NIP</label>
                                <input type="text" name="nip" maxlength="20" value="<?php echo htmlspecialchars($klient['nip'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>REGON</label>
                                <input type="text" name="regon" maxlength="20" value="<?php echo htmlspecialchars($klient['regon'] ?? ''); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Adres</label>
                            <input type="text" name="adres" value="<?php echo htmlspecialchars($klient['adres'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Kod pocztowy</label>
                                <input type="text" name="kod_pocztowy" maxlength="10" value="<?php echo htmlspecialchars($klient['kod_pocztowy'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>Miasto</label>
                                <input type="text" name="miasto" value="<?php echo htmlspecialchars($klient['miasto'] ?? ''); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Województwo</label>
                            <select name="wojewodztwo">
                                <option value="">-- wybierz --</option>
                                <?php foreach ($wojewodztwa as $w): ?>
                                    <option value="<?php echo $w; ?>" <?php echo ($klient['wojewodztwo'] ?? '') === $w ? 'selected' : ''; ?>><?php echo ucfirst($w); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Kontakt i status -->
                <div class="card">
                    <div class="card-header">📞 Kontakt i status</div>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Telefon</label>
                                <input type="text" name="telefon" value="<?php echo htmlspecialchars($klient['telefon'] ?? ''); ?>">
                            </div>
                            <div class="form-group">
                                <label>E-mail</label>
                                <input type="email" name="email" value="<?php echo htmlspecialchars($klient['email'] ?? ''); ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Strona WWW</label>
                            <input type="url" name="www" placeholder="https://" value="<?php echo htmlspecialchars($klient['www'] ?? ''); ?>">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Branża</label>
                                <input type="text" name="branza" list="branze-list" value="<?php echo htmlspecialchars($klient['branza'] ?? ''); ?>">
                                <datalist id="branze-list">
                                    <option value="Produkcja">
                                    <option value="Logistyka">
                                    <option value="Budownictwo">
                                    <option value="IT">
                                    <option value="Handel">
                                    <option value="Usługi">
                                    <option value="Rolnictwo">
                                </datalist>
                            </div>
                            <div class="form-group">
                                <label>Ilość pracowników</label>
                                <select name="ilosc_pracownikow">
                                    <option value="">-- wybierz --</option>
                                    <option value="1-10" <?php echo ($klient['ilosc_pracownikow'] ?? '') === '1-10' ? 'selected' : ''; ?>>1-10</option>
                                    <option value="11-50" <?php echo ($klient['ilosc_pracownikow'] ?? '') === '11-50' ? 'selected' : ''; ?>>11-50</option>
                                    <option value="51-100" <?php echo ($klient['ilosc_pracownikow'] ?? '') === '51-100' ? 'selected' : ''; ?>>51-100</option>
                                    <option value="101-250" <?php echo ($klient['ilosc_pracownikow'] ?? '') === '101-250' ? 'selected' : ''; ?>>101-250</option>
                                    <option value="251-500" <?php echo ($klient['ilosc_pracownikow'] ?? '') === '251-500' ? 'selected' : ''; ?>>251-500</option>
                                    <option value="500+" <?php echo ($klient['ilosc_pracownikow'] ?? '') === '500+' ? 'selected' : ''; ?>>500+</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Status</label>
                                <select name="status">
                                    <?php foreach ($crmStatusy as $key => $s): ?>
                                        <option value="<?php echo $key; ?>" <?php echo ($klient['status'] ?? 'nowy') === $key ? 'selected' : ''; ?>><?php echo $s['label']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Priorytet</label>
                                <select name="priorytet">
                                    <?php foreach ($crmPriorytety as $key => $p): ?>
                                        <option value="<?php echo $key; ?>" <?php echo ($klient['priorytet'] ?? 'normalny') === $key ? 'selected' : ''; ?>><?php echo $p['label']; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Przypisany do</label>
                                <select name="przypisany_do">
                                    <option value="">-- nieprzypisany --</option>
                                    <?php foreach ($users as $u): ?>
                                        <option value="<?php echo $u['id']; ?>" <?php echo ($klient['przypisany_do'] ?? '') == $u['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($u['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Źródło pozyskania</label>
                                <select name="zrodlo_pozyskania" id="zrodlo_pozyskania" onchange="togglePolecenieOdKogo()">
                                    <option value="">-- wybierz --</option>
                                    <?php foreach ($zrodla as $z): ?>
                                        <option value="<?php echo $z; ?>" <?php echo ($klient['zrodlo_pozyskania'] ?? '') === $z ? 'selected' : ''; ?>><?php echo $z; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group" id="polecenie_od_kogo_group" style="display: <?php echo ($klient['zrodlo_pozyskania'] ?? '') === 'Polecenie' ? 'block' : 'none'; ?>;">
                            <label>Od kogo polecenie?</label>
                            <input type="text" name="polecenie_od_kogo" id="polecenie_od_kogo" placeholder="Wpisz od kogo otrzymano polecenie..." value="<?php echo htmlspecialchars($klient['polecenie_od_kogo'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Uwagi -->
            <div class="card">
                <div class="card-header">📝 Uwagi</div>
                <div class="card-body">
                    <div class="form-group" style="margin-bottom: 0;">
                        <textarea name="uwagi" placeholder="Dodatkowe informacje..."><?php echo htmlspecialchars($klient['uwagi'] ?? ''); ?></textarea>
                    </div>
                </div>
            </div>
            
            <div class="actions">
                <button type="submit" class="btn btn-primary btn-lg">
                    <?php echo $id > 0 ? '💾 Zapisz zmiany' : '➕ Dodaj klienta'; ?>
                </button>
                <?php if ($id > 0): ?>
                    <a href="klient_karta.php?id=<?php echo $id; ?>" class="btn btn-lg">Przejdź do karty</a>
                <?php endif; ?>
            </div>
        </form>
    </div>
    
    <script>
    function togglePolecenieOdKogo() {
        var zrodlo = document.getElementById('zrodlo_pozyskania').value;
        var polecenieGroup = document.getElementById('polecenie_od_kogo_group');
        
        if (zrodlo === 'Polecenie') {
            polecenieGroup.style.display = 'block';
        } else {
            polecenieGroup.style.display = 'none';
            document.getElementById('polecenie_od_kogo').value = '';
        }
    }
    
    // Uruchom przy załadowaniu strony
    document.addEventListener('DOMContentLoaded', function() {
        togglePolecenieOdKogo();
    });
    </script>
</body>
</html>
