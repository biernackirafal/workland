<?php
/**
 * CRM Update Tool v2 - Aktualizacja danych firm z CSV (GUS)
 * 
 * Wgraj do: /kadry/crm_gus_update.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1); // Włącz wyświetlanie błędów dla debugowania

require_once __DIR__ . '/includes/db.php';
requireLogin();

$db = initDatabase();

$message = '';
$messageType = '';
$debugInfo = [];

// === UPLOAD CSV ===
if (isset($_POST['upload']) && !empty($_FILES['csv_file']['tmp_name'])) {
    $content = file_get_contents($_FILES['csv_file']['tmp_name']);
    
    // Konwersja kodowania
    if (!mb_check_encoding($content, 'UTF-8')) {
        $content = @iconv('Windows-1250', 'UTF-8//TRANSLIT//IGNORE', $content) ?: $content;
    }
    $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
    
    // Parsuj CSV
    $lines = preg_split('/\r?\n/', $content);
    $separator = (substr_count($lines[0], ';') > substr_count($lines[0], ',')) ? ';' : ',';
    
    // Nagłówki
    $headers = str_getcsv($lines[0], $separator, '"', '\\');
    $headerMap = [];
    foreach ($headers as $i => $h) {
        $headerMap[trim($h)] = $i;
    }
    
    $debugInfo[] = "Nagłówki CSV: " . implode(', ', $headers);
    $debugInfo[] = "Separator: '$separator'";
    
    $imported = [];
    for ($i = 1; $i < count($lines); $i++) {
        $line = trim($lines[$i]);
        if (empty($line)) continue;
        
        $row = str_getcsv($line, $separator, '"', '\\');
        
        // Mapowanie kolumn z CSV GUS - różne możliwe nazwy kolumn
        $nazwa_input = trim($row[$headerMap['Firma (input)'] ?? $headerMap['nazwa_input'] ?? $headerMap['Nazwa'] ?? 0] ?? '');
        $nazwa_gus = trim($row[$headerMap['Firma (GUS)'] ?? $headerMap['nazwa_gus'] ?? 2] ?? '');
        $nip = trim($row[$headerMap['NIP'] ?? $headerMap['nip'] ?? 3] ?? '');
        $regon = trim($row[$headerMap['REGON'] ?? $headerMap['regon'] ?? 4] ?? '');
        $adres_full = trim($row[$headerMap['Adres'] ?? $headerMap['adres'] ?? 5] ?? '');
        $status = trim($row[$headerMap['Status'] ?? $headerMap['status'] ?? 7] ?? '');
        
        if (empty($nazwa_input)) continue;
        
        // Akceptuj tylko success lub jeśli ma NIP
        if ($status !== 'success' && empty($nip)) continue;
        
        // Parsuj adres
        $adres = '';
        $kod_pocztowy = '';
        $miasto = '';
        
        if (!empty($adres_full)) {
            $parts = array_map('trim', explode(',', $adres_full));
            
            foreach ($parts as $part) {
                if (preg_match('/^\d{2}-\d{3}$/', $part)) {
                    $kod_pocztowy = $part;
                } elseif (preg_match('/^(ul\.|al\.|pl\.|os\.)/i', $part) || preg_match('/^\d+/', $part)) {
                    $adres .= ($adres ? ', ' : '') . $part;
                } elseif (empty($kod_pocztowy) && preg_match('/\d{2}-\d{3}/', $part, $m)) {
                    $kod_pocztowy = $m[0];
                    $miasto = trim(str_replace($m[0], '', $part));
                } else {
                    if (empty($miasto)) $miasto = $part;
                }
            }
        }
        
        $imported[] = [
            'nazwa_input' => $nazwa_input,
            'nazwa_gus' => $nazwa_gus,
            'nip' => $nip,
            'regon' => $regon,
            'adres' => trim($adres),
            'kod_pocztowy' => $kod_pocztowy,
            'miasto' => trim($miasto),
            'adres_full' => $adres_full
        ];
    }
    
    $_SESSION['gus_import'] = $imported;
    $message = "Załadowano " . count($imported) . " firm z CSV";
    $messageType = 'success';
    $debugInfo[] = "Zaimportowano " . count($imported) . " rekordów";
}

// === WYKONAJ AKTUALIZACJĘ ===
if (isset($_POST['update'])) {
    $selected = $_POST['match'] ?? [];
    $updated = 0;
    $skipped = 0;
    $errors = [];
    
    $gusData = $_SESSION['gus_import'] ?? [];
    
    foreach ($selected as $idx => $crmId) {
        if (empty($crmId) || $crmId === '0' || $crmId === 'skip') {
            $skipped++;
            continue;
        }
        
        $gus = $gusData[$idx] ?? null;
        if (!$gus) {
            $errors[] = "Brak danych GUS dla indeksu $idx";
            continue;
        }
        
        // Pobierz aktualne dane
        $stmt = $db->prepare("SELECT * FROM crm_klienci WHERE id = ?");
        $stmt->execute([$crmId]);
        $oldData = $stmt->fetch();
        
        if (!$oldData) {
            $errors[] = "Nie znaleziono klienta ID: $crmId";
            continue;
        }
        
        // Przygotuj dane do aktualizacji - ZAWSZE aktualizuj jeśli mamy nowe dane
        $updates = [];
        
        if (!empty($gus['nip'])) {
            $updates['nip'] = $gus['nip'];
        }
        
        if (!empty($gus['regon'])) {
            $updates['regon'] = $gus['regon'];
        }
        
        if (!empty($gus['adres']) && empty($oldData['adres'])) {
            $updates['adres'] = $gus['adres'];
        }
        
        if (!empty($gus['kod_pocztowy']) && empty($oldData['kod_pocztowy'])) {
            $updates['kod_pocztowy'] = $gus['kod_pocztowy'];
        }
        
        if (!empty($gus['miasto']) && empty($oldData['miasto'])) {
            $updates['miasto'] = $gus['miasto'];
        }
        
        if (!empty($updates)) {
            $setParts = [];
            $values = [];
            foreach ($updates as $field => $value) {
                $setParts[] = "$field = ?";
                $values[] = $value;
            }
            $setParts[] = "updated_at = CURRENT_TIMESTAMP";
            $values[] = $crmId;
            
            $sql = "UPDATE crm_klienci SET " . implode(", ", $setParts) . " WHERE id = ?";
            
            try {
                $stmt = $db->prepare($sql);
                $result = $stmt->execute($values);
                
                if ($result) {
                    $updated++;
                    $debugInfo[] = "✅ Zaktualizowano: {$oldData['nazwa']} (ID: $crmId) - " . implode(', ', array_keys($updates));
                } else {
                    $errors[] = "Błąd SQL dla ID: $crmId";
                }
            } catch (PDOException $e) {
                $errors[] = "Błąd PDO dla {$oldData['nazwa']}: " . $e->getMessage();
            }
        } else {
            $skipped++;
            $debugInfo[] = "⏭️ Pominięto (brak nowych danych): {$oldData['nazwa']}";
        }
    }
    
    $message = "Zaktualizowano: $updated firm, Pominięto: $skipped";
    if (!empty($errors)) {
        $message .= " | Błędy: " . count($errors);
        $debugInfo = array_merge($debugInfo, $errors);
    }
    $messageType = $updated > 0 ? 'success' : 'warning';
    
    // NIE czyść sesji od razu - pozwól zobaczyć wyniki
    // unset($_SESSION['gus_import']);
}

// === WYCZYŚĆ ===
if (isset($_POST['clear'])) {
    unset($_SESSION['gus_import']);
    $message = "Wyczyszczono dane importu";
    $messageType = 'info';
}

// === POBIERZ DANE ===
$gusData = $_SESSION['gus_import'] ?? [];
$matches = [];

if (!empty($gusData)) {
    // Pobierz wszystkie firmy z CRM
    $stmt = $db->query("SELECT id, nazwa, nip, regon, adres, kod_pocztowy, miasto FROM crm_klienci ORDER BY nazwa");
    $crmFirmy = $stmt->fetchAll();
    
    foreach ($gusData as $gus) {
        $bestMatch = null;
        $bestScore = 0;
        
        $searchName = mb_strtoupper($gus['nazwa_input']);
        $searchName = preg_replace('/[^A-ZĄĆĘŁŃÓŚŹŻ0-9\s]/u', ' ', $searchName);
        $searchWords = array_filter(preg_split('/\s+/', $searchName), fn($w) => mb_strlen($w) >= 2);
        
        foreach ($crmFirmy as $crm) {
            $crmName = mb_strtoupper($crm['nazwa']);
            $crmName = preg_replace('/[^A-ZĄĆĘŁŃÓŚŹŻ0-9\s]/u', ' ', $crmName);
            
            $score = 0;
            foreach ($searchWords as $word) {
                if (mb_strlen($word) >= 3 && mb_strpos($crmName, $word) !== false) {
                    $score += mb_strlen($word);
                }
            }
            
            // Bonus za podobną długość
            $lenDiff = abs(mb_strlen($searchName) - mb_strlen($crmName));
            if ($lenDiff < 20) $score += (20 - $lenDiff);
            
            // Bonus za identyczny początek
            if (!empty($searchWords[0]) && mb_strpos($crmName, $searchWords[0]) === 0) {
                $score += 30;
            }
            
            if ($score > $bestScore && $score >= 15) {
                $bestScore = $score;
                $bestMatch = $crm;
            }
        }
        
        $matches[] = [
            'gus' => $gus,
            'crm' => $bestMatch,
            'score' => $bestScore
        ];
    }
}

// Pobierz wszystkie firmy CRM do selecta
$allCrmFirmy = $db->query("SELECT id, nazwa, nip, regon FROM crm_klienci ORDER BY nazwa")->fetchAll();

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aktualizacja CRM z GUS</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .container { max-width: 1600px; margin: 0 auto; padding: 20px; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .card-header { padding: 20px; border-bottom: 1px solid #e5e7eb; }
        .card-header h2 { margin: 0; font-size: 20px; }
        .card-body { padding: 20px; }
        
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
        .alert-info { background: #dbeafe; color: #1e40af; border: 1px solid #93c5fd; }
        .alert-warning { background: #fef3c7; color: #92400e; border: 1px solid #fcd34d; }
        
        .debug { background: #1f2937; color: #e5e7eb; padding: 15px; border-radius: 8px; font-family: monospace; font-size: 12px; max-height: 200px; overflow-y: auto; margin-bottom: 20px; }
        .debug div { padding: 2px 0; }
        
        .upload-zone { border: 2px dashed #d1d5db; border-radius: 8px; padding: 40px; text-align: center; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-danger { background: #dc2626; color: white; }
        .btn-outline { background: white; border: 1px solid #d1d5db; color: #374151; }
        
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #e5e7eb; vertical-align: top; }
        th { background: #f9fafb; font-weight: 600; font-size: 11px; text-transform: uppercase; color: #6b7280; position: sticky; top: 0; }
        
        .match-row { transition: background 0.2s; }
        .match-row:hover { background: #f9fafb; }
        .match-row.no-match { background: #fef3c7; }
        .match-row.has-data { background: #dcfce7; }
        
        .company-name { font-weight: 600; color: #111827; font-size: 13px; }
        .company-details { font-size: 11px; color: #6b7280; margin-top: 4px; }
        
        .match-select { width: 100%; padding: 6px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 12px; }
        
        .badge { display: inline-block; padding: 2px 8px; border-radius: 9999px; font-size: 11px; font-weight: 500; margin: 1px; }
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-info { background: #dbeafe; color: #1e40af; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        
        .stats { display: flex; gap: 20px; margin-bottom: 20px; flex-wrap: wrap; }
        .stat { padding: 16px 24px; background: #f9fafb; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 28px; font-weight: 700; }
        .stat-label { font-size: 12px; color: #6b7280; }
        
        .table-container { max-height: 600px; overflow-y: auto; }
        
        .data-preview { font-family: monospace; font-size: 11px; color: #059669; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>🔄 Aktualizacja CRM danymi z GUS</h2>
            </div>
            <div class="card-body">
                <?php if ($message): ?>
                <div class="alert alert-<?= $messageType ?>"><?= htmlspecialchars($message) ?></div>
                <?php endif; ?>
                
                <?php if (!empty($debugInfo)): ?>
                <div class="debug">
                    <strong>Debug info:</strong>
                    <?php foreach ($debugInfo as $info): ?>
                    <div><?= htmlspecialchars($info) ?></div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                
                <?php if (empty($gusData)): ?>
                <!-- UPLOAD -->
                <form method="post" enctype="multipart/form-data">
                    <div class="upload-zone">
                        <div style="font-size: 48px; margin-bottom: 16px;">📤</div>
                        <div style="font-size: 18px; margin-bottom: 8px;">Wybierz plik CSV z GUS Enricher</div>
                        <input type="file" name="csv_file" accept=".csv" required style="margin-bottom: 16px;">
                        <br>
                        <button type="submit" name="upload" class="btn btn-primary">📁 Załaduj plik</button>
                    </div>
                </form>
                <?php else: ?>
                <!-- DOPASOWANIA -->
                <?php
                $matched = count(array_filter($matches, fn($m) => $m['crm'] !== null));
                $withNip = count(array_filter($gusData, fn($g) => !empty($g['nip'])));
                ?>
                
                <div class="stats">
                    <div class="stat">
                        <div class="stat-value"><?= count($matches) ?></div>
                        <div class="stat-label">Firm z CSV</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #16a34a;"><?= $matched ?></div>
                        <div class="stat-label">Auto-dopasowanych</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value" style="color: #2563eb;"><?= $withNip ?></div>
                        <div class="stat-label">Z NIP-em</div>
                    </div>
                </div>
                
                <form method="post">
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th style="width: 25%">Firma z CSV</th>
                                    <th style="width: 15%">Dane z GUS</th>
                                    <th style="width: 30%">Dopasuj do firmy w CRM</th>
                                    <th style="width: 15%">Aktualne dane w CRM</th>
                                    <th style="width: 15%">Co zostanie zaktualizowane</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($matches as $idx => $match): 
                                    $gus = $match['gus'];
                                    $crm = $match['crm'];
                                    $hasMatch = $crm !== null;
                                    $hasNewData = !empty($gus['nip']) || !empty($gus['regon']);
                                ?>
                                <tr class="match-row <?= !$hasMatch ? 'no-match' : ($hasNewData ? 'has-data' : '') ?>">
                                    <td>
                                        <div class="company-name"><?= htmlspecialchars($gus['nazwa_input']) ?></div>
                                        <?php if (!empty($gus['nazwa_gus']) && $gus['nazwa_gus'] !== $gus['nazwa_input']): ?>
                                        <div class="company-details">GUS: <?= htmlspecialchars($gus['nazwa_gus']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($gus['nip']): ?><span class="badge badge-success">NIP: <?= $gus['nip'] ?></span><br><?php endif; ?>
                                        <?php if ($gus['regon']): ?><span class="badge badge-info">REGON: <?= $gus['regon'] ?></span><br><?php endif; ?>
                                        <?php if ($gus['miasto']): ?><span class="badge badge-warning"><?= $gus['miasto'] ?></span><?php endif; ?>
                                    </td>
                                    <td>
                                        <select name="match[<?= $idx ?>]" class="match-select">
                                            <option value="skip">-- Pomiń --</option>
                                            <?php foreach ($allCrmFirmy as $f): ?>
                                            <option value="<?= $f['id'] ?>" <?= ($crm && $crm['id'] == $f['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($f['nazwa']) ?>
                                                <?= $f['nip'] ? " [NIP: {$f['nip']}]" : '' ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </td>
                                    <td>
                                        <?php if ($hasMatch): ?>
                                        <div class="company-details">
                                            NIP: <?= $crm['nip'] ?: '<em>brak</em>' ?><br>
                                            REGON: <?= $crm['regon'] ?: '<em>brak</em>' ?><br>
                                            Miasto: <?= $crm['miasto'] ?: '<em>brak</em>' ?>
                                        </div>
                                        <?php else: ?>
                                        <em style="color: #9ca3af;">Wybierz firmę</em>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($hasMatch): ?>
                                            <?php if ($gus['nip'] && empty($crm['nip'])): ?>
                                            <div class="data-preview">+ NIP: <?= $gus['nip'] ?></div>
                                            <?php elseif ($gus['nip']): ?>
                                            <div style="color: #9ca3af; font-size: 11px;">NIP: już jest</div>
                                            <?php endif; ?>
                                            
                                            <?php if ($gus['regon'] && empty($crm['regon'])): ?>
                                            <div class="data-preview">+ REGON: <?= $gus['regon'] ?></div>
                                            <?php elseif ($gus['regon']): ?>
                                            <div style="color: #9ca3af; font-size: 11px;">REGON: już jest</div>
                                            <?php endif; ?>
                                            
                                            <?php if ($gus['miasto'] && empty($crm['miasto'])): ?>
                                            <div class="data-preview">+ Miasto: <?= $gus['miasto'] ?></div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div style="margin-top: 20px; display: flex; gap: 12px; flex-wrap: wrap;">
                        <button type="submit" name="update" class="btn btn-success">✅ Wykonaj aktualizację</button>
                        <button type="submit" name="clear" class="btn btn-outline">🗑️ Wyczyść i zacznij od nowa</button>
                        <a href="crm/klienci.php" class="btn btn-outline">← Powrót do CRM</a>
                    </div>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
