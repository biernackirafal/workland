<?php
/**
 * CRM - Kalendarz
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

$month = intval($_GET['month'] ?? date('n'));
$year = intval($_GET['year'] ?? date('Y'));

if ($month < 1) { $month = 12; $year--; }
if ($month > 12) { $month = 1; $year++; }

$firstDay = mktime(0, 0, 0, $month, 1, $year);
$daysInMonth = date('t', $firstDay);
$startWeekday = date('N', $firstDay);

$startDate = date('Y-m-01', $firstDay);
$endDate = date('Y-m-t', $firstDay);

$stmt = $db->prepare("
    SELECT z.*, k.nazwa as klient_nazwa
    FROM crm_zadania z
    LEFT JOIN crm_klienci k ON z.klient_id = k.id
    WHERE z.termin_data BETWEEN ? AND ?
    AND z.status NOT IN ('zakonczone', 'anulowane')
    ORDER BY z.termin_godzina ASC
");
$stmt->execute([$startDate, $endDate]);
$zadania = $stmt->fetchAll();

$zadaniaByDay = [];
foreach ($zadania as $z) {
    $day = intval(date('j', strtotime($z['termin_data'])));
    if (!isset($zadaniaByDay[$day])) $zadaniaByDay[$day] = [];
    $zadaniaByDay[$day][] = $z;
}

$typyZadan = getCrmTypyZadan();
$monthNames = ['', 'Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'];
$dayNames = ['Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'Sb', 'Nd'];

$prevMonth = $month - 1; $prevYear = $year;
if ($prevMonth < 1) { $prevMonth = 12; $prevYear--; }
$nextMonth = $month + 1; $nextYear = $year;
if ($nextMonth > 12) { $nextMonth = 1; $nextYear++; }

$today = date('Y-m-d');

// Nadchodzące zadania
$stmt = $db->prepare("
    SELECT z.*, k.nazwa as klient_nazwa
    FROM crm_zadania z
    LEFT JOIN crm_klienci k ON z.klient_id = k.id
    WHERE z.termin_data BETWEEN date('now') AND date('now', '+7 days')
    AND z.status NOT IN ('zakonczone', 'anulowane')
    ORDER BY z.termin_data ASC, z.termin_godzina ASC
    LIMIT 10
");
$stmt->execute();
$upcoming = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kalendarz - CRM - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .crm-nav { background: #1e40af; padding: 10px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .crm-nav a { color: rgba(255,255,255,0.85); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; }
        .crm-nav a:hover, .crm-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .crm-nav .nav-title { color: white; font-weight: 600; margin-right: 20px; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 25px; }
        .card-header { padding: 15px 20px; border-bottom: 1px solid #e2e8f0; }
        .card-body { padding: 0; }
        
        .calendar-header { display: flex; justify-content: space-between; align-items: center; }
        .calendar-header h2 { margin: 0; }
        
        .calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); }
        .calendar-day-header { background: #f8fafc; padding: 12px; text-align: center; font-weight: 600; font-size: 0.85rem; border-bottom: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0; }
        .calendar-day-header:last-child { border-right: none; }
        
        .calendar-day { min-height: 100px; padding: 8px; border-bottom: 1px solid #e2e8f0; border-right: 1px solid #e2e8f0; background: white; }
        .calendar-day:nth-child(7n) { border-right: none; }
        .calendar-day.other-month { background: #f8fafc; color: #94a3b8; }
        .calendar-day.today { background: #eff6ff; }
        .calendar-day .day-number { font-weight: 600; margin-bottom: 5px; }
        
        .calendar-event { font-size: 0.75rem; padding: 3px 6px; border-radius: 4px; margin-bottom: 3px; cursor: pointer; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .calendar-event.type-telefon { background: #dbeafe; color: #1d4ed8; }
        .calendar-event.type-spotkanie { background: #dcfce7; color: #15803d; }
        .calendar-event.type-email { background: #fef3c7; color: #b45309; }
        .calendar-event.type-zadanie { background: #e0e7ff; color: #4338ca; }
        .calendar-event.type-oferta { background: #fce7f3; color: #9d174d; }
        .calendar-event.type-inne { background: #f1f5f9; color: #475569; }
        
        .legend { display: flex; gap: 20px; flex-wrap: wrap; padding: 15px 20px; }
        .legend-item { display: flex; align-items: center; gap: 8px; font-size: 0.85rem; }
        .legend-color { width: 16px; height: 16px; border-radius: 4px; }
        
        .upcoming-list { padding: 20px; }
        .upcoming-item { padding: 10px 0; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; }
        .upcoming-item:last-child { border-bottom: none; }
        .upcoming-item a { color: inherit; text-decoration: none; }
        .upcoming-item a:hover { color: #2563eb; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?php echo sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../klienci.php">🏢 Klienci</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <div class="crm-nav">
            <span class="nav-title">🎯 CRM</span>
            <a href="./">Dashboard</a>
            <a href="klienci.php">Potencjalni Klienci</a>
            <a href="zadania.php">Zadania</a>
            <a href="kalendarz.php" class="active">Kalendarz</a>
        </div>
        
        <div class="card">
            <div class="card-header">
                <div class="calendar-header">
                    <a href="?month=<?php echo $prevMonth; ?>&year=<?php echo $prevYear; ?>" class="btn">← Poprzedni</a>
                    <h2><?php echo $monthNames[$month]; ?> <?php echo $year; ?></h2>
                    <div style="display: flex; gap: 10px;">
                        <a href="?month=<?php echo date('n'); ?>&year=<?php echo date('Y'); ?>" class="btn">Dziś</a>
                        <a href="?month=<?php echo $nextMonth; ?>&year=<?php echo $nextYear; ?>" class="btn">Następny →</a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="calendar-grid">
                    <?php foreach ($dayNames as $dn): ?>
                        <div class="calendar-day-header"><?php echo $dn; ?></div>
                    <?php endforeach; ?>
                    
                    <?php for ($i = 1; $i < $startWeekday; $i++): ?>
                        <div class="calendar-day other-month"></div>
                    <?php endfor; ?>
                    
                    <?php for ($day = 1; $day <= $daysInMonth; $day++): 
                        $currentDate = sprintf('%04d-%02d-%02d', $year, $month, $day);
                        $isToday = $currentDate === $today;
                        $dayTasks = $zadaniaByDay[$day] ?? [];
                    ?>
                        <div class="calendar-day <?php echo $isToday ? 'today' : ''; ?>">
                            <div class="day-number"><?php echo $day; ?></div>
                            <?php foreach ($dayTasks as $task): ?>
                                <div class="calendar-event type-<?php echo $task['typ']; ?>" 
                                     onclick="window.location.href='klient_karta.php?id=<?php echo $task['klient_id']; ?>&tab=zadania'"
                                     title="<?php echo htmlspecialchars($task['tytul'] . ' - ' . $task['klient_nazwa']); ?>">
                                    <?php if ($task['termin_godzina']): ?><?php echo substr($task['termin_godzina'], 0, 5); ?> <?php endif; ?>
                                    <?php echo htmlspecialchars(mb_substr($task['tytul'], 0, 15)); ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endfor; ?>
                    
                    <?php 
                    $lastWeekday = date('N', mktime(0, 0, 0, $month, $daysInMonth, $year));
                    for ($i = $lastWeekday; $i < 7; $i++): 
                    ?>
                        <div class="calendar-day other-month"></div>
                    <?php endfor; ?>
                </div>
                
                <div class="legend">
                    <div class="legend-item"><div class="legend-color" style="background: #dbeafe;"></div> Telefon</div>
                    <div class="legend-item"><div class="legend-color" style="background: #dcfce7;"></div> Spotkanie</div>
                    <div class="legend-item"><div class="legend-color" style="background: #fef3c7;"></div> E-mail</div>
                    <div class="legend-item"><div class="legend-color" style="background: #e0e7ff;"></div> Zadanie</div>
                    <div class="legend-item"><div class="legend-color" style="background: #fce7f3;"></div> Oferta</div>
                </div>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header"><h3 style="margin: 0;">📅 Nadchodzące zadania (7 dni)</h3></div>
            <div class="upcoming-list">
                <?php if (empty($upcoming)): ?>
                    <p style="color: #64748b; text-align: center;">Brak zadań na najbliższe 7 dni</p>
                <?php else: ?>
                    <?php foreach ($upcoming as $task): ?>
                        <div class="upcoming-item">
                            <div>
                                <a href="klient_karta.php?id=<?php echo $task['klient_id']; ?>&tab=zadania"><strong><?php echo htmlspecialchars($task['tytul']); ?></strong></a>
                                <div style="font-size: 0.85rem; color: #64748b;">🏢 <?php echo htmlspecialchars($task['klient_nazwa']); ?> · <?php echo $typyZadan[$task['typ']] ?? $task['typ']; ?></div>
                            </div>
                            <div style="text-align: right; font-size: 0.9rem;">
                                📅 <?php echo date('d.m.Y', strtotime($task['termin_data'])); ?>
                                <?php if ($task['termin_godzina']): ?><br><?php echo substr($task['termin_godzina'], 0, 5); ?><?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
