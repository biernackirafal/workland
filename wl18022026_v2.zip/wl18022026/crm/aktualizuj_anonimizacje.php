<?php
/**
 * Jednorazowy skrypt do aktualizacji flag anonimizacji
 * Uruchom raz po wgraniu nowej wersji!
 * 
 * LOKALIZACJA: /kadry/crm/aktualizuj_anonimizacje.php
 */

require_once '../includes/db.php';
requireLogin();

$db = initDatabase();

// Funkcja wykrywająca anonimizowane dane
function isAnonymized($imie, $nazwisko) {
    // Sprawdź czy zawiera gwiazdki
    if (strpos($imie, '*') !== false || strpos($nazwisko, '*') !== false) {
        return true;
    }
    // Sprawdź wzorzec typu "A***" lub "Ab***"
    if (preg_match('/^[A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]?\*+$/u', $imie) || 
        preg_match('/^[A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]?\*+$/u', $nazwisko)) {
        return true;
    }
    return false;
}

// Pobierz wszystkie osoby
$osoby = $db->query("SELECT id, imie, nazwisko FROM crm_osoby")->fetchAll();

$updated = 0;
$zanonimizowane = 0;
$pelne = 0;

foreach ($osoby as $osoba) {
    $czyZanonimizowane = isAnonymized($osoba['imie'] ?? '', $osoba['nazwisko'] ?? '') ? 1 : 0;
    
    $stmt = $db->prepare("UPDATE crm_osoby SET dane_zanonimizowane = ? WHERE id = ?");
    $stmt->execute([$czyZanonimizowane, $osoba['id']]);
    
    $updated++;
    if ($czyZanonimizowane) {
        $zanonimizowane++;
    } else {
        $pelne++;
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Aktualizacja flag anonimizacji</title>
    <style>
        body { font-family: system-ui, sans-serif; padding: 40px; background: #f1f5f9; }
        .card { max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h1 { color: #1e293b; margin-bottom: 20px; }
        .stat { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #e2e8f0; }
        .stat:last-child { border-bottom: none; }
        .stat-label { color: #64748b; }
        .stat-value { font-weight: 600; color: #1e293b; }
        .success { background: #dcfce7; color: #166534; padding: 15px; border-radius: 8px; margin-top: 20px; }
        .back { display: inline-block; margin-top: 20px; color: #2563eb; text-decoration: none; }
        .back:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="card">
        <h1>✅ Aktualizacja zakończona</h1>
        
        <div class="stat">
            <span class="stat-label">Przeanalizowanych osób:</span>
            <span class="stat-value"><?= $updated ?></span>
        </div>
        <div class="stat">
            <span class="stat-label">🔒 Zanonimizowanych (A*** K***):</span>
            <span class="stat-value"><?= $zanonimizowane ?></span>
        </div>
        <div class="stat">
            <span class="stat-label">✅ Z pełnymi danymi:</span>
            <span class="stat-value"><?= $pelne ?></span>
        </div>
        
        <div class="success">
            Flagi anonimizacji zostały zaktualizowane dla wszystkich osób kontaktowych.
            Teraz możesz filtrować firmy po statusie danych osobowych.
        </div>
        
        <a href="klienci.php" class="back">← Wróć do listy klientów</a>
    </div>
</body>
</html>
