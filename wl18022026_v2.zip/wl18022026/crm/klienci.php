<?php
/**
 * CRM - Lista potencjalnych klientów v3
 * Z filtrami kompletności, kolumnami NIP/REGON, oznaczeniem osób kontaktowych
 * 
 * WGRAJ DO: /kadry/crm/klienci.php
 */

require_once '../includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Filtry
$search = trim($_GET['search'] ?? '');
$status = $_GET['status'] ?? '';
$przypisany = $_GET['przypisany'] ?? '';
$branza = $_GET['branza'] ?? '';
$kompletnosc = $_GET['kompletnosc'] ?? '';

// Budowanie zapytania
$where = ['1=1'];
$params = [];

if ($search) {
    $where[] = "(k.nazwa LIKE ? OR k.nip LIKE ? OR k.regon LIKE ? OR k.miasto LIKE ? OR k.email LIKE ? OR k.adres LIKE ?)";
    $searchParam = "%$search%";
    $params = array_merge($params, [$searchParam, $searchParam, $searchParam, $searchParam, $searchParam, $searchParam]);
}

if ($status) {
    $where[] = "k.status = ?";
    $params[] = $status;
}

if ($przypisany) {
    $where[] = "k.przypisany_do = ?";
    $params[] = $przypisany;
}

if ($branza) {
    $where[] = "k.branza = ?";
    $params[] = $branza;
}

// Filtr kompletności
if ($kompletnosc === 'z_nip') {
    $where[] = "(k.nip IS NOT NULL AND k.nip != '')";
} elseif ($kompletnosc === 'bez_nip') {
    $where[] = "(k.nip IS NULL OR k.nip = '')";
} elseif ($kompletnosc === 'z_regon') {
    $where[] = "(k.regon IS NOT NULL AND k.regon != '')";
} elseif ($kompletnosc === 'bez_regon') {
    $where[] = "(k.regon IS NULL OR k.regon = '')";
} elseif ($kompletnosc === 'z_osoba') {
    $where[] = "(SELECT COUNT(*) FROM crm_osoby WHERE klient_id = k.id) > 0";
} elseif ($kompletnosc === 'bez_osoby') {
    $where[] = "(SELECT COUNT(*) FROM crm_osoby WHERE klient_id = k.id) = 0";
} elseif ($kompletnosc === 'pelne') {
    $where[] = "(k.nip IS NOT NULL AND k.nip != '' AND k.regon IS NOT NULL AND k.regon != '')";
} elseif ($kompletnosc === 'puste') {
    $where[] = "((k.nip IS NULL OR k.nip = '') AND (k.regon IS NULL OR k.regon = ''))";
} elseif ($kompletnosc === 'osoba_zanonimizowana') {
    // Firmy z osobami gdzie dane są zanonimizowane (A*** K*** - wykrywamy po wzorcu lub fladze)
    $where[] = "(SELECT COUNT(*) FROM crm_osoby WHERE klient_id = k.id AND (
        dane_zanonimizowane = 1 
        OR imie LIKE '%*%' 
        OR nazwisko LIKE '%*%'
        OR (LENGTH(imie) <= 3 AND imie LIKE '%*')
    )) > 0";
} elseif ($kompletnosc === 'osoba_pelna') {
    // Firmy z osobami gdzie dane są pełne (bez gwiazdek i flagi)
    $where[] = "(SELECT COUNT(*) FROM crm_osoby WHERE klient_id = k.id AND 
        dane_zanonimizowane = 0 
        AND imie NOT LIKE '%*%' 
        AND nazwisko NOT LIKE '%*%'
        AND LENGTH(imie) > 1
    ) > 0";
}

$whereClause = implode(' AND ', $where);

// Paginacja
$perPage = 50;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

// Pobierz całkowitą liczbę
$stmt = $db->prepare("SELECT COUNT(*) FROM crm_klienci k WHERE $whereClause");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $perPage);

// Pobierz klientów z liczbą osób kontaktowych
$stmt = $db->prepare("
    SELECT k.*, u.name as przypisany_nazwa,
           (SELECT COUNT(*) FROM crm_zadania WHERE klient_id = k.id AND status NOT IN ('zakonczone', 'anulowane')) as otwarte_zadania,
           (SELECT COUNT(*) FROM crm_osoby WHERE klient_id = k.id) as liczba_osob
    FROM crm_klienci k
    LEFT JOIN users u ON k.przypisany_do = u.id
    WHERE $whereClause
    ORDER BY k.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$klienci = $stmt->fetchAll();

// Użytkownicy i branże do filtrów
$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();
$branze = $db->query("SELECT DISTINCT branza FROM crm_klienci WHERE branza IS NOT NULL AND branza != '' ORDER BY branza")->fetchAll(PDO::FETCH_COLUMN);

// Statystyki
$stats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN (nip IS NOT NULL AND nip != '') THEN 1 ELSE 0 END) as z_nip,
        SUM(CASE WHEN (regon IS NOT NULL AND regon != '') THEN 1 ELSE 0 END) as z_regon,
        SUM(CASE WHEN id IN (SELECT DISTINCT klient_id FROM crm_osoby) THEN 1 ELSE 0 END) as z_osoba
    FROM crm_klienci
")->fetch();

$crmStatusy = getCrmStatusy();
$crmPriorytety = getCrmPriorytety();
$hasFilters = $search || $status || $przypisany || $branza || $kompletnosc;
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Potencjalni Klienci - CRM v3</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .crm-nav { background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); padding: 12px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .crm-nav a { color: rgba(255,255,255,0.9); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; transition: all 0.2s; }
        .crm-nav a:hover, .crm-nav a.active { background: rgba(255,255,255,0.2); color: white; }
        .crm-nav .nav-title { color: white; font-weight: 700; margin-right: 20px; font-size: 1.1rem; }
        
        /* STATYSTYKI - NOWE */
        .stats-bar { 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); 
            gap: 12px; 
            margin-bottom: 20px; 
            padding: 15px;
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            border-radius: 12px;
            border: 1px solid #bae6fd;
        }
        .stat-box { 
            background: white; 
            padding: 12px 16px; 
            border-radius: 8px; 
            text-align: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .stat-box .value { font-size: 24px; font-weight: 700; color: #1e40af; }
        .stat-box .label { font-size: 11px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-box.green .value { color: #16a34a; }
        .stat-box.orange .value { color: #ea580c; }
        .stat-box.red .value { color: #dc2626; }
        
        .filters { background: white; padding: 20px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .filters-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.8rem; color: #64748b; font-weight: 600; }
        .filter-group select, .filter-group input { padding: 10px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; min-width: 150px; }
        .filter-group select:focus, .filter-group input:focus { border-color: #3b82f6; outline: none; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1); }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; display: flex; justify-content: space-between; align-items: center; background: #f8fafc; }
        
        .badge { display: inline-block; padding: 4px 10px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; }
        
        table { width: 100%; border-collapse: collapse; }
        th { padding: 12px 10px; text-align: left; background: #f1f5f9; font-weight: 700; font-size: 0.75rem; color: #475569; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e2e8f0; }
        td { padding: 12px 10px; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; }
        tr:hover { background: #f8fafc; }
        
        .firma-nazwa { font-weight: 600; color: #1e293b; }
        .firma-nazwa a { color: inherit; text-decoration: none; }
        .firma-nazwa a:hover { color: #2563eb; }
        
        /* KOLUMNY DANYCH - NOWE */
        .col-nip, .col-regon { font-family: 'SF Mono', Monaco, monospace; font-size: 0.85rem; color: #334155; }
        .col-empty { color: #cbd5e1; font-style: italic; }
        
        /* IKONA OSOBY - NOWE */
        .osoba-badge { 
            display: inline-flex; 
            align-items: center; 
            gap: 4px; 
            padding: 3px 8px; 
            background: #dbeafe; 
            color: #1e40af; 
            border-radius: 12px; 
            font-size: 0.75rem; 
            font-weight: 600; 
        }
        .osoba-badge.empty { background: #f1f5f9; color: #94a3b8; }
        
        .actions { display: flex; gap: 6px; }
        .actions a { 
            padding: 6px 10px; 
            border-radius: 6px; 
            text-decoration: none; 
            font-size: 0.85rem;
            background: #f1f5f9;
            transition: background 0.2s;
        }
        .actions a:hover { background: #e2e8f0; }
        
        .pagination { display: flex; gap: 5px; justify-content: center; margin-top: 20px; flex-wrap: wrap; }
        .pagination a, .pagination span { padding: 8px 14px; border: 1px solid #e2e8f0; border-radius: 6px; text-decoration: none; color: #374151; }
        .pagination a:hover { background: #f1f5f9; }
        .pagination .active { background: #2563eb; color: white; border-color: #2563eb; }
        
        .header-actions { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
        .btn { padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 6px; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-primary:hover { background: #1d4ed8; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?= sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../klienci.php">🏢 Klienci</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <div class="crm-nav">
            <span class="nav-title">🎯 CRM</span>
            <a href="./">Dashboard</a>
            <a href="klienci.php" class="active">Potencjalni Klienci</a>
            <a href="zadania.php">Zadania</a>
            <a href="kalendarz.php">Kalendarz</a>
        </div>
        
        <header>
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                <div>
                    <h1>🏢 Potencjalni Klienci</h1>
                    <p class="subtitle">Lista leadów CRM - wersja v3</p>
                </div>
                <div class="header-actions">
                    <a href="../crm_gus_update.php" class="btn" style="background: #059669; color: white;">🔄 Aktualizuj z GUS</a>
                    <a href="import_csv.php" class="btn" style="background: #f1f5f9; color: #374151;">📥 Import</a>
                    <a href="klient_dodaj.php" class="btn btn-primary">+ Dodaj</a>
                </div>
            </div>
        </header>
        
        <!-- STATYSTYKI -->
        <div class="stats-bar">
            <div class="stat-box">
                <div class="value"><?= number_format($stats['total']) ?></div>
                <div class="label">Wszystkich</div>
            </div>
            <div class="stat-box green">
                <div class="value"><?= number_format($stats['z_nip']) ?></div>
                <div class="label">Z NIP</div>
            </div>
            <div class="stat-box">
                <div class="value"><?= number_format($stats['z_regon']) ?></div>
                <div class="label">Z REGON</div>
            </div>
            <div class="stat-box">
                <div class="value"><?= number_format($stats['z_osoba']) ?></div>
                <div class="label">Z osobą</div>
            </div>
            <div class="stat-box red">
                <div class="value"><?= number_format($stats['total'] - $stats['z_nip']) ?></div>
                <div class="label">Bez NIP</div>
            </div>
        </div>
        
        <!-- FILTRY -->
        <div class="filters">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group" style="flex: 2; min-width: 200px;">
                        <label>🔍 Szukaj</label>
                        <input type="text" name="search" placeholder="Nazwa, NIP, REGON, miasto..." value="<?= htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">-- Wszystkie --</option>
                            <?php foreach ($crmStatusy as $key => $s): ?>
                                <option value="<?= $key; ?>" <?= $status === $key ? 'selected' : ''; ?>><?= $s['label']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Przypisany</label>
                        <select name="przypisany">
                            <option value="">-- Wszyscy --</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?= $u['id']; ?>" <?= $przypisany == $u['id'] ? 'selected' : ''; ?>><?= htmlspecialchars($u['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>📊 Kompletność</label>
                        <select name="kompletnosc">
                            <option value="">-- Wszystkie --</option>
                            <option value="pelne" <?= $kompletnosc === 'pelne' ? 'selected' : ''; ?>>✅ NIP + REGON</option>
                            <option value="puste" <?= $kompletnosc === 'puste' ? 'selected' : ''; ?>>❌ Bez NIP i REGON</option>
                            <option value="z_nip" <?= $kompletnosc === 'z_nip' ? 'selected' : ''; ?>>Z NIP</option>
                            <option value="bez_nip" <?= $kompletnosc === 'bez_nip' ? 'selected' : ''; ?>>Bez NIP</option>
                            <option value="z_regon" <?= $kompletnosc === 'z_regon' ? 'selected' : ''; ?>>Z REGON</option>
                            <option value="bez_regon" <?= $kompletnosc === 'bez_regon' ? 'selected' : ''; ?>>Bez REGON</option>
                            <option value="z_osoba" <?= $kompletnosc === 'z_osoba' ? 'selected' : ''; ?>>👤 Z osobą kontaktową</option>
                            <option value="bez_osoby" <?= $kompletnosc === 'bez_osoby' ? 'selected' : ''; ?>>👤 Bez osoby kontaktowej</option>
                            <option value="osoba_zanonimizowana" <?= $kompletnosc === 'osoba_zanonimizowana' ? 'selected' : ''; ?>>🔒 Osoba zanonimizowana (A*** K***)</option>
                            <option value="osoba_pelna" <?= $kompletnosc === 'osoba_pelna' ? 'selected' : ''; ?>>✅ Osoba z pełnymi danymi</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">Filtruj</button>
                        <?php if ($hasFilters): ?>
                            <a href="klienci.php" class="btn" style="background: #f1f5f9; color: #374151;">✕ Wyczyść</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- LISTA -->
        <div class="card">
            <div class="card-header">
                <span>Znaleziono: <strong><?= $total; ?></strong> klientów (strona <?= $page ?>/<?= max(1, $totalPages) ?>)</span>
            </div>
            
            <?php if (empty($klienci)): ?>
                <div style="text-align: center; padding: 60px; color: #64748b;">
                    <div style="font-size: 3rem; margin-bottom: 15px;">🏢</div>
                    <p>Brak klientów spełniających kryteria</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th style="width: 28%">Firma</th>
                            <th style="width: 12%">NIP</th>
                            <th style="width: 12%">REGON</th>
                            <th style="width: 14%">Miasto</th>
                            <th style="width: 10%">Osoba</th>
                            <th style="width: 10%">Status</th>
                            <th style="width: 8%">Kontakt</th>
                            <th style="width: 6%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($klienci as $k): 
                            $st = $crmStatusy[$k['status']] ?? $crmStatusy['nowy'];
                        ?>
                        <tr>
                            <td>
                                <div class="firma-nazwa">
                                    <a href="klient_karta.php?id=<?= $k['id']; ?>"><?= htmlspecialchars($k['nazwa']); ?></a>
                                </div>
                            </td>
                            <td class="col-nip <?= empty($k['nip']) ? 'col-empty' : '' ?>">
                                <?= !empty($k['nip']) ? htmlspecialchars($k['nip']) : '—' ?>
                            </td>
                            <td class="col-regon <?= empty($k['regon']) ? 'col-empty' : '' ?>">
                                <?= !empty($k['regon']) ? htmlspecialchars($k['regon']) : '—' ?>
                            </td>
                            <td>
                                <?php if ($k['miasto']): ?>
                                    <?= htmlspecialchars($k['miasto']); ?>
                                <?php else: ?>
                                    <span class="col-empty">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($k['liczba_osob'] > 0): ?>
                                    <span class="osoba-badge">👤 <?= $k['liczba_osob'] ?></span>
                                <?php else: ?>
                                    <span class="osoba-badge empty">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge" style="background: <?= $st['bg']; ?>; color: <?= $st['color']; ?>;">
                                    <?= $st['label']; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($k['telefon']): ?>
                                    <a href="tel:<?= $k['telefon']; ?>" style="font-size: 0.8rem;">📞</a>
                                <?php endif; ?>
                                <?php if ($k['email']): ?>
                                    <a href="mailto:<?= $k['email']; ?>" style="font-size: 0.8rem;">✉️</a>
                                <?php endif; ?>
                                <?php if (!$k['telefon'] && !$k['email']): ?>
                                    <span class="col-empty">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="actions">
                                <a href="klient_karta.php?id=<?= $k['id']; ?>" title="Karta">👁️</a>
                                <a href="klient_dodaj.php?id=<?= $k['id']; ?>" title="Edytuj">✏️</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => 1])); ?>">«</a>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">‹</a>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="active"><?= $i; ?></span>
                <?php else: ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])); ?>"><?= $i; ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($page < $totalPages): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">›</a>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $totalPages])); ?>">»</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
