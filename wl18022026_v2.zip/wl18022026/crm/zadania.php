<?php
/**
 * CRM - Lista zadań
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Filtry
$status = $_GET['status'] ?? '';
$przypisany = $_GET['przypisany'] ?? '';
$klient = $_GET['klient'] ?? '';

$where = ['1=1'];
$params = [];

if ($status) { $where[] = "z.status = ?"; $params[] = $status; }
if ($przypisany) { $where[] = "z.przypisany_do = ?"; $params[] = $przypisany; }
if ($klient) { $where[] = "z.klient_id = ?"; $params[] = $klient; }

$whereClause = implode(' AND ', $where);

$stmt = $db->prepare("
    SELECT z.*, k.nazwa as klient_nazwa, u.name as przypisany_nazwa
    FROM crm_zadania z
    LEFT JOIN crm_klienci k ON z.klient_id = k.id
    LEFT JOIN users u ON z.przypisany_do = u.id
    WHERE $whereClause
    ORDER BY 
        CASE z.status WHEN 'nowe' THEN 1 WHEN 'w_trakcie' THEN 2 ELSE 3 END,
        z.termin_data ASC
");
$stmt->execute($params);
$zadania = $stmt->fetchAll();

$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();
$klienci = $db->query("SELECT id, nazwa FROM crm_klienci ORDER BY nazwa")->fetchAll();

$statusyZadan = getCrmStatusyZadan();
$crmPriorytety = getCrmPriorytety();
$typyZadan = getCrmTypyZadan();

// Statystyki
$stats = ['nowe' => 0, 'w_trakcie' => 0, 'przeterminowane' => 0, 'dzisiaj' => 0];
foreach ($zadania as $z) {
    if ($z['status'] === 'nowe') $stats['nowe']++;
    if ($z['status'] === 'w_trakcie') $stats['w_trakcie']++;
    if ($z['termin_data'] && $z['termin_data'] < date('Y-m-d') && $z['status'] !== 'zakonczone') $stats['przeterminowane']++;
    if ($z['termin_data'] === date('Y-m-d')) $stats['dzisiaj']++;
}

$hasFilters = $status || $przypisany || $klient;
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zadania - CRM - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .crm-nav { background: #1e40af; padding: 10px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .crm-nav a { color: rgba(255,255,255,0.85); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; }
        .crm-nav a:hover, .crm-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .crm-nav .nav-title { color: white; font-weight: 600; margin-right: 20px; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 25px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); text-align: center; }
        .stat-card .value { font-size: 2rem; font-weight: 700; }
        .stat-card .label { color: #64748b; font-size: 0.85rem; margin-top: 5px; }
        
        .filters { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .filters-row { display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.85rem; color: #64748b; font-weight: 500; }
        .filter-group select { padding: 8px 12px; border: 2px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem; min-width: 150px; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .card-body { padding: 20px; }
        
        .task-item { display: flex; gap: 15px; padding: 15px; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 12px; align-items: flex-start; }
        .task-item:hover { border-color: #2563eb; }
        .task-item.completed { opacity: 0.6; background: #f8fafc; }
        .task-checkbox { width: 22px; height: 22px; cursor: pointer; accent-color: #2563eb; margin-top: 2px; }
        .task-content { flex: 1; }
        .task-content h4 { margin: 0 0 8px 0; font-size: 0.95rem; }
        .task-content h4 a { color: inherit; text-decoration: none; }
        .task-meta { font-size: 0.8rem; color: #64748b; display: flex; gap: 15px; flex-wrap: wrap; }
        .task-overdue { color: #dc2626 !important; font-weight: 600; }
        
        .badge { display: inline-block; padding: 3px 10px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; }
        
        .empty-state { text-align: center; padding: 60px; color: #64748b; }
        .empty-state .icon { font-size: 3rem; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?php echo sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../klienci.php">🏢 Klienci</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <div class="crm-nav">
            <span class="nav-title">🎯 CRM</span>
            <a href="./">Dashboard</a>
            <a href="klienci.php">Potencjalni Klienci</a>
            <a href="zadania.php" class="active">Zadania</a>
            <a href="kalendarz.php">Kalendarz</a>
        </div>
        
        <header>
            <h1>✅ Zadania</h1>
            <p class="subtitle">Wszystkie zadania CRM</p>
        </header>
        
        <!-- Statystyki -->
        <div class="stats-grid">
            <div class="stat-card"><div class="value" style="color: #0891b2;"><?php echo $stats['nowe']; ?></div><div class="label">Nowych</div></div>
            <div class="stat-card"><div class="value" style="color: #d97706;"><?php echo $stats['w_trakcie']; ?></div><div class="label">W trakcie</div></div>
            <div class="stat-card"><div class="value" style="color: #dc2626;"><?php echo $stats['przeterminowane']; ?></div><div class="label">Przeterminowanych</div></div>
            <div class="stat-card"><div class="value" style="color: #16a34a;"><?php echo $stats['dzisiaj']; ?></div><div class="label">Na dziś</div></div>
        </div>
        
        <!-- Filtry -->
        <div class="filters">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">-- Wszystkie --</option>
                            <?php foreach ($statusyZadan as $key => $s): ?>
                                <option value="<?php echo $key; ?>" <?php echo $status === $key ? 'selected' : ''; ?>><?php echo $s['label']; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Przypisany do</label>
                        <select name="przypisany">
                            <option value="">-- Wszyscy --</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?php echo $u['id']; ?>" <?php echo $przypisany == $u['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($u['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Klient</label>
                        <select name="klient">
                            <option value="">-- Wszyscy --</option>
                            <?php foreach ($klienci as $k): ?>
                                <option value="<?php echo $k['id']; ?>" <?php echo $klient == $k['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($k['nazwa']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">Filtruj</button>
                        <?php if ($hasFilters): ?><a href="zadania.php" class="btn">Wyczyść</a><?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Lista -->
        <div class="card">
            <div class="card-body">
                <?php if (empty($zadania)): ?>
                    <div class="empty-state">
                        <div class="icon">✅</div>
                        <p>Brak zadań spełniających kryteria</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($zadania as $zadanie): 
                        $isOverdue = $zadanie['termin_data'] && $zadanie['termin_data'] < date('Y-m-d') && $zadanie['status'] !== 'zakonczone';
                        $isCompleted = $zadanie['status'] === 'zakonczone';
                        $pr = $crmPriorytety[$zadanie['priorytet']] ?? $crmPriorytety['normalny'];
                        $st = $statusyZadan[$zadanie['status']] ?? $statusyZadan['nowe'];
                    ?>
                        <div class="task-item <?php echo $isCompleted ? 'completed' : ''; ?>">
                            <input type="checkbox" class="task-checkbox" <?php echo $isCompleted ? 'checked disabled' : ''; ?> onchange="completeTask(<?php echo $zadanie['id']; ?>)">
                            <div class="task-content">
                                <h4><a href="klient_karta.php?id=<?php echo $zadanie['klient_id']; ?>&tab=zadania"><?php echo htmlspecialchars($zadanie['tytul']); ?></a></h4>
                                <div class="task-meta">
                                    <span>🏢 <a href="klient_karta.php?id=<?php echo $zadanie['klient_id']; ?>"><?php echo htmlspecialchars($zadanie['klient_nazwa']); ?></a></span>
                                    <span class="badge" style="background: <?php echo $st['bg']; ?>; color: <?php echo $st['color']; ?>;"><?php echo $st['label']; ?></span>
                                    <span class="badge" style="background: <?php echo $pr['bg']; ?>; color: <?php echo $pr['color']; ?>;"><?php echo $pr['label']; ?></span>
                                    <span>📋 <?php echo $typyZadan[$zadanie['typ']] ?? $zadanie['typ']; ?></span>
                                    <?php if ($zadanie['przypisany_nazwa']): ?><span>👤 <?php echo htmlspecialchars($zadanie['przypisany_nazwa']); ?></span><?php endif; ?>
                                    <?php if ($zadanie['termin_data']): ?>
                                        <span class="<?php echo $isOverdue ? 'task-overdue' : ''; ?>">📅 <?php echo date('d.m.Y', strtotime($zadanie['termin_data'])); ?><?php if ($zadanie['termin_godzina']): ?> <?php echo substr($zadanie['termin_godzina'], 0, 5); ?><?php endif; ?></span>
                                    <?php endif; ?>
                                    <?php if (!empty($zadanie['przypomnienie_email'])): ?>
                                        <span title="Przypomnienie mailowe <?php echo $zadanie['przypomnienie_wyslane'] ? '(wysłane)' : '(' . $zadanie['przypomnienie_dni'] . ' dni przed)'; ?>" style="<?php echo $zadanie['przypomnienie_wyslane'] ? 'opacity: 0.5;' : ''; ?>">
                                            <?php echo $zadanie['przypomnienie_wyslane'] ? '📧✓' : '📧'; ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
    function completeTask(id) {
        fetch('api/zadanie_complete.php', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({id: id}) }).then(() => location.reload());
    }
    </script>
</body>
</html>
