<?php
/**
 * CRM - Dashboard
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Statystyki CRM
$stats = [];
$stmt = $db->query("SELECT status, COUNT(*) as cnt FROM crm_klienci GROUP BY status");
$statusy = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

$stats['wszystkie'] = array_sum($statusy);
$stats['nowe'] = $statusy['nowy'] ?? 0;
$stats['w_trakcie'] = ($statusy['kontakt'] ?? 0) + ($statusy['negocjacje'] ?? 0) + ($statusy['oferta'] ?? 0);
$stats['wygrane'] = $statusy['wygrana'] ?? 0;

// Moje zadania
$stmt = $db->prepare("
    SELECT z.*, k.nazwa as klient_nazwa 
    FROM crm_zadania z
    LEFT JOIN crm_klienci k ON z.klient_id = k.id
    WHERE z.przypisany_do = ? AND z.status NOT IN ('zakonczone', 'anulowane')
    ORDER BY z.termin_data ASC, z.priorytet DESC
    LIMIT 10
");
$stmt->execute([$currentUser['id']]);
$mojeZadania = $stmt->fetchAll();

// Zadania przeterminowane
$stmt = $db->prepare("
    SELECT COUNT(*) FROM crm_zadania 
    WHERE przypisany_do = ? AND termin_data < date('now') AND status NOT IN ('zakonczone', 'anulowane')
");
$stmt->execute([$currentUser['id']]);
$przeterminowane = $stmt->fetchColumn();

// Ostatnio dodani klienci
$stmt = $db->query("
    SELECT k.*, u.name as przypisany_nazwa
    FROM crm_klienci k
    LEFT JOIN users u ON k.przypisany_do = u.id
    ORDER BY k.created_at DESC
    LIMIT 5
");
$ostatniKlienci = $stmt->fetchAll();

$crmStatusy = getCrmStatusy();
$crmPriorytety = getCrmPriorytety();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .crm-nav { background: #1e40af; padding: 10px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .crm-nav a { color: rgba(255,255,255,0.85); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; transition: all 0.2s; }
        .crm-nav a:hover, .crm-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .crm-nav .nav-title { color: white; font-weight: 600; margin-right: 20px; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 25px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .stat-card .value { font-size: 2.5rem; font-weight: 700; color: #2563eb; }
        .stat-card .label { color: #64748b; font-size: 0.95rem; margin-top: 5px; }
        .stat-card.warning .value { color: #dc2626; }
        
        .dashboard-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 25px; }
        @media (max-width: 1024px) { .dashboard-grid { grid-template-columns: 1fr; } }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; }
        .card-header { padding: 18px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; display: flex; justify-content: space-between; align-items: center; }
        .card-body { padding: 20px; }
        
        .task-item { display: flex; gap: 12px; padding: 12px; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 10px; align-items: flex-start; }
        .task-item:hover { border-color: #2563eb; background: #f8fafc; }
        .task-checkbox { width: 20px; height: 20px; cursor: pointer; accent-color: #2563eb; margin-top: 2px; }
        .task-content { flex: 1; }
        .task-content h4 { margin: 0 0 5px 0; font-size: 0.95rem; }
        .task-content h4 a { color: inherit; text-decoration: none; }
        .task-meta { font-size: 0.8rem; color: #64748b; display: flex; gap: 12px; flex-wrap: wrap; }
        .task-overdue { color: #dc2626 !important; font-weight: 600; }
        
        .badge { display: inline-block; padding: 3px 10px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; }
        
        .client-row { padding: 12px 0; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center; }
        .client-row:last-child { border-bottom: none; }
        .client-name { font-weight: 500; }
        .client-name a { color: inherit; text-decoration: none; }
        .client-name a:hover { color: #2563eb; }
        .client-city { font-size: 0.85rem; color: #64748b; }
        
        .empty-state { text-align: center; padding: 40px; color: #64748b; }
        .empty-state .icon { font-size: 3rem; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">
                    👤 <?php echo sanitize($currentUser['name']); ?>
                </div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../klienci.php">🏢 Klienci</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <div class="crm-nav">
            <span class="nav-title">🎯 CRM</span>
            <a href="./" class="active">Dashboard</a>
            <a href="klienci.php">Potencjalni Klienci</a>
            <a href="zadania.php">Zadania</a>
            <a href="kalendarz.php">Kalendarz</a>
        </div>
        
        <header>
            <h1>🎯 CRM - Potencjalni Klienci</h1>
            <p class="subtitle">Zarządzanie leadami i prospektami</p>
        </header>
        
        <!-- Statystyki -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="value"><?php echo $stats['wszystkie']; ?></div>
                <div class="label">Wszystkich leadów</div>
            </div>
            <div class="stat-card">
                <div class="value" style="color: #0891b2;"><?php echo $stats['nowe']; ?></div>
                <div class="label">Nowych leadów</div>
            </div>
            <div class="stat-card">
                <div class="value" style="color: #d97706;"><?php echo $stats['w_trakcie']; ?></div>
                <div class="label">W trakcie</div>
            </div>
            <div class="stat-card">
                <div class="value" style="color: #16a34a;"><?php echo $stats['wygrane']; ?></div>
                <div class="label">Wygranych</div>
            </div>
        </div>
        
        <div class="dashboard-grid">
            <!-- Moje zadania -->
            <div class="card">
                <div class="card-header">
                    ✅ Moje zadania
                    <?php if ($przeterminowane > 0): ?>
                        <span class="badge" style="background: #fee2e2; color: #dc2626;"><?php echo $przeterminowane; ?> przeterminowanych</span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if (empty($mojeZadania)): ?>
                        <div class="empty-state">
                            <div class="icon">🎉</div>
                            <p>Brak zadań do wykonania!</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($mojeZadania as $zadanie): 
                            $isOverdue = $zadanie['termin_data'] && $zadanie['termin_data'] < date('Y-m-d');
                            $priorytet = $crmPriorytety[$zadanie['priorytet']] ?? $crmPriorytety['normalny'];
                        ?>
                            <div class="task-item">
                                <input type="checkbox" class="task-checkbox" onchange="completeTask(<?php echo $zadanie['id']; ?>)">
                                <div class="task-content">
                                    <h4><a href="klient_karta.php?id=<?php echo $zadanie['klient_id']; ?>&tab=zadania"><?php echo htmlspecialchars($zadanie['tytul']); ?></a></h4>
                                    <div class="task-meta">
                                        <span>🏢 <?php echo htmlspecialchars($zadanie['klient_nazwa']); ?></span>
                                        <span class="badge" style="background: <?php echo $priorytet['bg']; ?>; color: <?php echo $priorytet['color']; ?>;"><?php echo $priorytet['label']; ?></span>
                                        <?php if ($zadanie['termin_data']): ?>
                                            <span class="<?php echo $isOverdue ? 'task-overdue' : ''; ?>">
                                                📅 <?php echo date('d.m.Y', strtotime($zadanie['termin_data'])); ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <div style="text-align: center; margin-top: 15px;">
                            <a href="zadania.php?przypisany=<?php echo $currentUser['id']; ?>" class="btn">Zobacz wszystkie</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Ostatnio dodani klienci -->
            <div class="card">
                <div class="card-header">
                    🏢 Ostatnio dodani
                    <a href="klient_dodaj.php" class="btn btn-primary" style="padding: 6px 12px; font-size: 0.85rem;">+ Dodaj</a>
                </div>
                <div class="card-body">
                    <?php if (empty($ostatniKlienci)): ?>
                        <div class="empty-state">
                            <div class="icon">🏢</div>
                            <p>Brak potencjalnych klientów</p>
                            <a href="klient_dodaj.php" class="btn btn-primary">Dodaj pierwszego</a>
                        </div>
                    <?php else: ?>
                        <?php foreach ($ostatniKlienci as $klient): 
                            $status = $crmStatusy[$klient['status']] ?? $crmStatusy['nowy'];
                        ?>
                            <div class="client-row">
                                <div>
                                    <div class="client-name"><a href="klient_karta.php?id=<?php echo $klient['id']; ?>"><?php echo htmlspecialchars($klient['nazwa']); ?></a></div>
                                    <?php if ($klient['miasto']): ?>
                                        <div class="client-city"><?php echo htmlspecialchars($klient['miasto']); ?></div>
                                    <?php endif; ?>
                                </div>
                                <span class="badge" style="background: <?php echo $status['bg']; ?>; color: <?php echo $status['color']; ?>;"><?php echo $status['label']; ?></span>
                            </div>
                        <?php endforeach; ?>
                        <div style="text-align: center; margin-top: 15px;">
                            <a href="klienci.php" class="btn">Zobacz wszystkich</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function completeTask(taskId) {
        fetch('api/zadanie_complete.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({id: taskId})
        }).then(() => location.reload());
    }
    </script>
</body>
</html>
