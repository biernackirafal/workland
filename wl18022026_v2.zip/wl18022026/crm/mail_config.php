<?php
/**
 * CRM - Konfiguracja powiadomień mailowych
 * System Ewidencji Pracowników - Work Land CRM
 */

require_once '../includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Sprawdź czy użytkownik ma uprawnienia admina (można dostosować)
// if ($currentUser['role'] !== 'admin') { header('Location: ./'); exit; }

$message = '';
$messageType = '';

// Obsługa zapisu
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = [
        'mail_smtp_host', 'mail_smtp_port', 'mail_smtp_secure', 
        'mail_smtp_user', 'mail_smtp_pass', 'mail_from_email', 
        'mail_from_name', 'mail_enabled', 'reminder_default_days'
    ];
    
    try {
        $db->beginTransaction();
        
        foreach ($fields as $field) {
            $value = $_POST[$field] ?? '';
            
            // Specjalna obsługa checkboxa
            if ($field === 'mail_enabled') {
                $value = isset($_POST[$field]) ? '1' : '0';
            }
            
            // Nie nadpisuj hasła jeśli puste
            if ($field === 'mail_smtp_pass' && empty($value)) {
                continue;
            }
            
            $stmt = $db->prepare("UPDATE crm_config SET wartosc = ?, updated_at = CURRENT_TIMESTAMP WHERE klucz = ?");
            $stmt->execute([$value, $field]);
        }
        
        $db->commit();
        $message = 'Ustawienia zostały zapisane.';
        $messageType = 'success';
    } catch (Exception $e) {
        $db->rollBack();
        $message = 'Błąd zapisu: ' . $e->getMessage();
        $messageType = 'error';
    }
}

// Obsługa testu wysyłki
if (isset($_POST['test_email'])) {
    require_once __DIR__ . '/includes/CrmMailer.php';
    
    $testEmail = trim($_POST['test_email_address'] ?? '');
    
    if ($testEmail) {
        $mailer = new CrmMailer($db);
        
        if (!$mailer->isEnabled()) {
            $message = 'Wysyłanie maili jest wyłączone. Włącz je najpierw i zapisz ustawienia.';
            $messageType = 'error';
        } else {
            $subject = '🧪 Test - Work Land CRM';
            $body = '
            <html>
            <body style="font-family: Arial, sans-serif; padding: 20px;">
                <h2>✅ Test wysyłki maili</h2>
                <p>Jeśli widzisz tę wiadomość, konfiguracja SMTP działa poprawnie!</p>
                <p><small>Wysłano: ' . date('Y-m-d H:i:s') . '</small></p>
            </body>
            </html>';
            
            $result = $mailer->send($testEmail, $subject, $body);
            
            if ($result) {
                $message = "Mail testowy został wysłany na adres: $testEmail";
                $messageType = 'success';
            } else {
                $message = 'Błąd wysyłki: ' . $mailer->getLastError();
                $messageType = 'error';
            }
        }
    } else {
        $message = 'Podaj adres email do testu.';
        $messageType = 'error';
    }
}

// Pobierz aktualną konfigurację
$config = [];
$stmt = $db->query("SELECT klucz, wartosc FROM crm_config");
while ($row = $stmt->fetch()) {
    $config[$row['klucz']] = $row['wartosc'];
}

// Pobierz ostatnie logi
$logs = $db->query("
    SELECT l.*, z.tytul as zadanie_tytul
    FROM crm_mail_log l
    LEFT JOIN crm_zadania z ON l.zadanie_id = z.id
    ORDER BY l.created_at DESC
    LIMIT 20
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfiguracja maili - CRM - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .crm-nav { background: #1e40af; padding: 10px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .crm-nav a { color: rgba(255,255,255,0.85); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; }
        .crm-nav a:hover, .crm-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .crm-nav .nav-title { color: white; font-weight: 600; margin-right: 20px; }
        
        .config-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 20px; }
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .card-header { padding: 20px; border-bottom: 1px solid #e2e8f0; }
        .card-header h3 { margin: 0; font-size: 1.1rem; }
        .card-body { padding: 20px; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; font-size: 0.9rem; color: #374151; }
        .form-group input, .form-group select { width: 100%; padding: 10px 12px; border: 2px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem; box-sizing: border-box; }
        .form-group input:focus, .form-group select:focus { border-color: #2563eb; outline: none; }
        .form-group small { color: #64748b; font-size: 0.8rem; display: block; margin-top: 4px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        
        .checkbox-label { display: flex; align-items: center; gap: 10px; cursor: pointer; }
        .checkbox-label input { width: auto; }
        
        .alert { padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        
        .test-section { background: #f0f9ff; padding: 15px; border-radius: 8px; margin-top: 15px; border: 1px solid #bae6fd; }
        .test-section h4 { margin: 0 0 10px 0; font-size: 0.95rem; }
        .test-row { display: flex; gap: 10px; }
        .test-row input { flex: 1; }
        
        .log-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        .log-table th, .log-table td { padding: 10px; text-align: left; border-bottom: 1px solid #e2e8f0; }
        .log-table th { background: #f8fafc; font-weight: 600; }
        .status-sent { color: #16a34a; }
        .status-error { color: #dc2626; }
        
        .cron-info { background: #fef3c7; padding: 15px; border-radius: 8px; border: 1px solid #fcd34d; margin-top: 15px; }
        .cron-info code { background: #1f2937; color: #10b981; padding: 8px 12px; border-radius: 4px; display: block; margin-top: 10px; font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?php echo sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../klienci.php">🏢 Klienci</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <div class="crm-nav">
            <span class="nav-title">🎯 CRM</span>
            <a href="./">Dashboard</a>
            <a href="klienci.php">Potencjalni Klienci</a>
            <a href="zadania.php">Zadania</a>
            <a href="kalendarz.php">Kalendarz</a>
            <a href="mail_config.php" class="active">⚙️ Konfiguracja maili</a>
        </div>
        
        <header>
            <h1>📧 Konfiguracja powiadomień mailowych</h1>
            <p class="subtitle">Ustawienia SMTP i przypomnienia o zadaniach</p>
        </header>
        
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $messageType; ?>">
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="config-grid">
                <!-- SMTP Settings -->
                <div class="card">
                    <div class="card-header">
                        <h3>🔧 Ustawienia serwera SMTP</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label class="checkbox-label">
                                <input type="checkbox" name="mail_enabled" value="1" <?php echo ($config['mail_enabled'] ?? '0') === '1' ? 'checked' : ''; ?>>
                                <span><strong>Włącz wysyłanie maili</strong></span>
                            </label>
                        </div>
                        
                        <div class="form-group">
                            <label>Serwer SMTP</label>
                            <input type="text" name="mail_smtp_host" value="<?php echo htmlspecialchars($config['mail_smtp_host'] ?? ''); ?>" placeholder="smtp.gmail.com">
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label>Port</label>
                                <input type="number" name="mail_smtp_port" value="<?php echo htmlspecialchars($config['mail_smtp_port'] ?? '587'); ?>">
                            </div>
                            <div class="form-group">
                                <label>Szyfrowanie</label>
                                <select name="mail_smtp_secure">
                                    <option value="tls" <?php echo ($config['mail_smtp_secure'] ?? '') === 'tls' ? 'selected' : ''; ?>>TLS</option>
                                    <option value="ssl" <?php echo ($config['mail_smtp_secure'] ?? '') === 'ssl' ? 'selected' : ''; ?>>SSL</option>
                                    <option value="" <?php echo empty($config['mail_smtp_secure']) ? 'selected' : ''; ?>>Brak</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Login SMTP</label>
                            <input type="text" name="mail_smtp_user" value="<?php echo htmlspecialchars($config['mail_smtp_user'] ?? ''); ?>" placeholder="user@example.com">
                        </div>
                        
                        <div class="form-group">
                            <label>Hasło SMTP</label>
                            <input type="password" name="mail_smtp_pass" placeholder="<?php echo !empty($config['mail_smtp_pass']) ? '••••••••' : ''; ?>">
                            <small>Pozostaw puste, aby nie zmieniać</small>
                        </div>
                    </div>
                </div>
                
                <!-- Sender Settings -->
                <div class="card">
                    <div class="card-header">
                        <h3>✉️ Nadawca wiadomości</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Adres email nadawcy</label>
                            <input type="email" name="mail_from_email" value="<?php echo htmlspecialchars($config['mail_from_email'] ?? ''); ?>" placeholder="crm@firma.pl">
                        </div>
                        
                        <div class="form-group">
                            <label>Nazwa nadawcy</label>
                            <input type="text" name="mail_from_name" value="<?php echo htmlspecialchars($config['mail_from_name'] ?? 'Work Land CRM'); ?>">
                        </div>
                        
                        <div class="form-group">
                            <label>Domyślna ilość dni przed terminem</label>
                            <select name="reminder_default_days">
                                <option value="0" <?php echo ($config['reminder_default_days'] ?? '1') === '0' ? 'selected' : ''; ?>>W dniu terminu</option>
                                <option value="1" <?php echo ($config['reminder_default_days'] ?? '1') === '1' ? 'selected' : ''; ?>>1 dzień przed</option>
                                <option value="2" <?php echo ($config['reminder_default_days'] ?? '1') === '2' ? 'selected' : ''; ?>>2 dni przed</option>
                                <option value="3" <?php echo ($config['reminder_default_days'] ?? '1') === '3' ? 'selected' : ''; ?>>3 dni przed</option>
                                <option value="7" <?php echo ($config['reminder_default_days'] ?? '1') === '7' ? 'selected' : ''; ?>>Tydzień przed</option>
                            </select>
                        </div>
                        
                        <div class="test-section">
                            <h4>🧪 Test wysyłki</h4>
                            <div class="test-row">
                                <input type="email" name="test_email_address" placeholder="Podaj email do testu">
                                <button type="submit" name="test_email" value="1" class="btn">Wyślij test</button>
                            </div>
                        </div>
                        
                        <div class="cron-info">
                            <strong>⏰ Konfiguracja CRON</strong>
                            <p style="margin: 5px 0; font-size: 0.9rem;">Aby przypomnienia były wysyłane automatycznie, dodaj zadanie cron:</p>
                            <code>0 8 * * * php <?php echo realpath(__DIR__); ?>/cron_reminders.php</code>
                            <?php if (!empty($config['reminder_cron_last_run'])): ?>
                                <p style="margin: 10px 0 0 0; font-size: 0.85rem; color: #78350f;">
                                    Ostatnie uruchomienie: <?php echo $config['reminder_cron_last_run']; ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="margin-top: 20px;">
                <button type="submit" class="btn btn-primary" style="padding: 12px 30px;">💾 Zapisz ustawienia</button>
            </div>
        </form>
        
        <!-- Logi wysyłek -->
        <?php if (!empty($logs)): ?>
        <div class="card" style="margin-top: 30px;">
            <div class="card-header">
                <h3>📋 Historia wysyłek (ostatnie 20)</h3>
            </div>
            <div class="card-body" style="padding: 0;">
                <table class="log-table">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Zadanie</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>Błąd</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo date('d.m.Y H:i', strtotime($log['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($log['zadanie_tytul'] ?? '-'); ?></td>
                            <td><?php echo htmlspecialchars($log['email']); ?></td>
                            <td class="status-<?php echo $log['status']; ?>">
                                <?php echo $log['status'] === 'sent' ? '✓ Wysłano' : '✗ Błąd'; ?>
                            </td>
                            <td><?php echo htmlspecialchars($log['error_msg'] ?? '-'); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>
