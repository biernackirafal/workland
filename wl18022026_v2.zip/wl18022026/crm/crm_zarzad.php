<?php
/**
 * CRM - Pobieranie Zarządu i Prokurentów z KRS
 * 
 * Dla firm z NIP w CRM:
 * 1. Szuka w GUS po NIP → dostaje REGON i typ podmiotu
 * 2. Pobiera pełny raport z GUS → dostaje numer KRS
 * 3. Pobiera z API KRS MS → zarząd i prokurenci
 * 4. Zapisuje do tabeli crm_osoby
 * 
 * WGRAJ DO: /kadry/crm_zarzad.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 300);

require_once __DIR__ . '/includes/db.php';
requireLogin();

$db = initDatabase();

$message = '';
$messageType = '';
$log = [];

// === GUS API ===
class GUSApi {
    private $apiKey = 'b0f0e889eff5497cbea4';
    private $url = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';
    private $sid = null;
    
    public function login() {
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $this->apiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->request($envelope);
        $this->sid = $this->extract($response, 'ZalogujResult');
        return !empty($this->sid);
    }
    
    public function logout() {
        if (!$this->sid) return;
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Wyloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Wyloguj>
            <ns:pIdentyfikatorSesji>' . $this->sid . '</ns:pIdentyfikatorSesji>
        </ns:Wyloguj>
    </soap:Body>
</soap:Envelope>';
        $this->request($envelope);
        $this->sid = null;
    }
    
    public function searchByNip($nip) {
        if (!$this->sid) return null;
        
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:Nip>' . $nip . '</dat:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->request($envelope);
        $result = $this->extract($response, 'DaneSzukajPodmiotyResult');
        
        if (empty($result)) return null;
        
        $xml = @simplexml_load_string($result);
        if (!$xml || !isset($xml->dane)) return null;
        
        $dane = $xml->dane;
        if (isset($dane->ErrorCode) && (string)$dane->ErrorCode !== '0') return null;
        
        return [
            'regon' => (string)($dane->Regon ?? ''),
            'nazwa' => (string)($dane->Nazwa ?? ''),
            'typ' => (string)($dane->Typ ?? ''),
            'silos' => (string)($dane->SilosID ?? '')
        ];
    }
    
    public function getFullReport($regon) {
        if (!$this->sid || empty($regon)) return null;
        
        // Typ raportu zależy od długości REGON
        $regon14 = str_pad($regon, 14, '0', STR_PAD_RIGHT);
        $reportName = 'BIR11OsPrawna'; // Dla osób prawnych
        
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DanePobierzPelnyRaport</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DanePobierzPelnyRaport>
            <ns:pRegon>' . $regon14 . '</ns:pRegon>
            <ns:pNazwaRaportu>' . $reportName . '</ns:pNazwaRaportu>
        </ns:DanePobierzPelnyRaport>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->request($envelope);
        $result = $this->extract($response, 'DanePobierzPelnyRaportResult');
        
        if (empty($result)) return null;
        
        $xml = @simplexml_load_string($result);
        if (!$xml || !isset($xml->dane)) return null;
        
        $dane = $xml->dane;
        return [
            'krs' => (string)($dane->praw_numerWRejestrzeEwidencji ?? $dane->praw_numerWKRS ?? ''),
            'nazwa' => (string)($dane->praw_nazwa ?? ''),
            'adres' => (string)($dane->praw_adSiedzUlica_Nazwa ?? '') . ' ' . 
                       (string)($dane->praw_adSiedzNumerNieruchomosci ?? '') .
                       ((string)($dane->praw_adSiedzNumerLokalu ?? '') ? '/' . (string)$dane->praw_adSiedzNumerLokalu : ''),
            'miasto' => (string)($dane->praw_adSiedzMiejscowosc_Nazwa ?? ''),
            'kod' => (string)($dane->praw_adSiedzKodPocztowy ?? '')
        ];
    }
    
    private function request($envelope) {
        $headers = ['Content-Type: application/soap+xml; charset=utf-8'];
        if ($this->sid) $headers[] = 'sid: ' . $this->sid;
        
        $ch = curl_init($this->url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $envelope,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $headers
        ]);
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }
    
    private function extract($xml, $tag) {
        if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
            return html_entity_decode($m[1]);
        }
        return '';
    }
}

// === KRS API ===
class KRSApi {
    public function getByKrs($krs) {
        $krs = str_pad(preg_replace('/\D/', '', $krs), 10, '0', STR_PAD_LEFT);
        $url = "https://api-krs.ms.gov.pl/api/krs/OdpisAktualny/$krs?rejestr=P&format=json";
        
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => ['Accept: application/json']
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) return null;
        
        $data = json_decode($response, true);
        if (!isset($data['odpis'])) return null;
        
        return $this->parseOdpis($data['odpis']);
    }
    
    private function parseOdpis($odpis) {
        $result = [
            'zarzad' => [],
            'prokurenci' => [],
            'nazwa' => '',
            'krs' => ''
        ];
        
        $dane = $odpis['dane'] ?? [];
        $dzial1 = $dane['dzial1'] ?? [];
        $dzial2 = $dane['dzial2'] ?? [];
        
        // Nazwa i KRS
        $result['nazwa'] = $dzial1['danePodmiotu']['nazwa'] ?? '';
        $result['krs'] = $dzial1['danePodmiotu']['numerKRS'] ?? '';
        
        // Zarząd (reprezentacja)
        $reprezentacja = $dzial2['reprezentacja'] ?? [];
        $sklad = $reprezentacja['sklad'] ?? [];
        
        foreach ($sklad as $osoba) {
            $result['zarzad'][] = [
                'imiona' => $osoba['imiona'] ?? '',
                'nazwisko' => $osoba['nazwisko'] ?? '',
                'funkcja' => $osoba['funkcjaWOrganie'] ?? 'Członek Zarządu'
            ];
        }
        
        // Prokurenci
        $prokura = $dzial2['prokurenci'] ?? [];
        
        foreach ($prokura as $prokurent) {
            $result['prokurenci'][] = [
                'imiona' => $prokurent['imiona'] ?? '',
                'nazwisko' => $prokurent['nazwisko'] ?? '',
                'rodzaj' => $prokurent['rodzajProkury'] ?? 'Prokurent'
            ];
        }
        
        return $result;
    }
}

// === AKCJE ===
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($action === 'process') {
    header('Content-Type: application/json; charset=utf-8');
    
    $klientId = (int)($_POST['klient_id'] ?? 0);
    $nip = trim($_POST['nip'] ?? '');
    
    if (!$klientId || !$nip) {
        echo json_encode(['error' => 'Brak danych']);
        exit;
    }
    
    $result = processCompany($db, $klientId, $nip);
    echo json_encode($result);
    exit;
}

if ($action === 'process_all') {
    header('Content-Type: application/json; charset=utf-8');
    
    // Pobierz następną firmę do przetworzenia
    $stmt = $db->query("
        SELECT k.id, k.nazwa, k.nip 
        FROM crm_klienci k 
        WHERE k.nip IS NOT NULL AND k.nip != ''
        AND k.id NOT IN (SELECT DISTINCT klient_id FROM crm_osoby WHERE stanowisko LIKE '%Zarząd%' OR stanowisko LIKE '%Prokurent%')
        ORDER BY k.id
        LIMIT 1
    ");
    $firma = $stmt->fetch();
    
    if (!$firma) {
        echo json_encode(['done' => true, 'message' => 'Wszystkie firmy przetworzone']);
        exit;
    }
    
    $result = processCompany($db, $firma['id'], $firma['nip']);
    $result['firma'] = $firma['nazwa'];
    echo json_encode($result);
    exit;
}

function processCompany($db, $klientId, $nip) {
    $log = [];
    $added = 0;
    
    // 1. Szukaj w GUS po NIP
    $gus = new GUSApi();
    if (!$gus->login()) {
        return ['error' => 'Nie można połączyć z GUS', 'log' => $log];
    }
    
    $log[] = "Szukam w GUS po NIP: $nip";
    $gusData = $gus->searchByNip($nip);
    
    if (!$gusData) {
        $gus->logout();
        return ['error' => 'Nie znaleziono w GUS', 'log' => $log];
    }
    
    $log[] = "Znaleziono: {$gusData['nazwa']} (Typ: {$gusData['typ']})";
    
    // Tylko dla osób prawnych (Typ = P)
    if ($gusData['typ'] !== 'P') {
        $gus->logout();
        return ['error' => 'To nie jest osoba prawna (brak KRS)', 'log' => $log];
    }
    
    // 2. Pobierz pełny raport z GUS
    $log[] = "Pobieram pełny raport z GUS...";
    $fullReport = $gus->getFullReport($gusData['regon']);
    $gus->logout();
    
    $krs = null;
    if ($fullReport && !empty($fullReport['krs'])) {
        $krs = $fullReport['krs'];
        $log[] = "Znaleziono KRS: $krs";
    }
    
    if (!$krs) {
        return ['error' => 'Nie znaleziono numeru KRS', 'log' => $log];
    }
    
    // 3. Pobierz dane z API KRS
    $log[] = "Pobieram dane z API KRS...";
    $krsApi = new KRSApi();
    $krsData = $krsApi->getByKrs($krs);
    
    if (!$krsData) {
        return ['error' => 'Nie można pobrać danych z KRS', 'log' => $log];
    }
    
    $log[] = "Zarząd: " . count($krsData['zarzad']) . " osób";
    $log[] = "Prokurenci: " . count($krsData['prokurenci']) . " osób";
    
    // 4. Zapisz do bazy
    $stmt = $db->prepare("INSERT INTO crm_osoby (klient_id, imie, nazwisko, stanowisko, uwagi, created_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
    
    // Zarząd
    foreach ($krsData['zarzad'] as $osoba) {
        // Sprawdź czy już istnieje
        $check = $db->prepare("SELECT id FROM crm_osoby WHERE klient_id = ? AND imie = ? AND nazwisko = ?");
        $check->execute([$klientId, $osoba['imiona'], $osoba['nazwisko']]);
        if ($check->fetch()) {
            $log[] = "⏭️ Pomijam (już istnieje): {$osoba['imiona']} {$osoba['nazwisko']}";
            continue;
        }
        
        $stmt->execute([
            $klientId,
            $osoba['imiona'],
            $osoba['nazwisko'],
            $osoba['funkcja'],
            'Zarząd - pobrano z KRS'
        ]);
        $added++;
        $log[] = "✅ Dodano: {$osoba['funkcja']}: {$osoba['imiona']} {$osoba['nazwisko']}";
    }
    
    // Prokurenci
    foreach ($krsData['prokurenci'] as $osoba) {
        // Sprawdź czy już istnieje
        $check = $db->prepare("SELECT id FROM crm_osoby WHERE klient_id = ? AND imie = ? AND nazwisko = ?");
        $check->execute([$klientId, $osoba['imiona'], $osoba['nazwisko']]);
        if ($check->fetch()) {
            $log[] = "⏭️ Pomijam (już istnieje): {$osoba['imiona']} {$osoba['nazwisko']}";
            continue;
        }
        
        $stmt->execute([
            $klientId,
            $osoba['imiona'],
            $osoba['nazwisko'],
            'Prokurent - ' . $osoba['rodzaj'],
            'Prokurent - pobrano z KRS'
        ]);
        $added++;
        $log[] = "✅ Dodano: Prokurent: {$osoba['imiona']} {$osoba['nazwisko']}";
    }
    
    return [
        'success' => true,
        'added' => $added,
        'krs' => $krs,
        'zarzad' => count($krsData['zarzad']),
        'prokurenci' => count($krsData['prokurenci']),
        'log' => $log
    ];
}

// === STATYSTYKI ===
$stats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN nip IS NOT NULL AND nip != '' THEN 1 ELSE 0 END) as z_nip,
        SUM(CASE WHEN id IN (SELECT DISTINCT klient_id FROM crm_osoby) THEN 1 ELSE 0 END) as z_osoba,
        SUM(CASE WHEN id IN (SELECT DISTINCT klient_id FROM crm_osoby WHERE stanowisko LIKE '%Zarząd%' OR stanowisko LIKE '%Prokurent%') THEN 1 ELSE 0 END) as z_zarzadem
    FROM crm_klienci
")->fetch();

// Firmy z NIP ale bez zarządu
$doPobrania = $db->query("
    SELECT k.id, k.nazwa, k.nip, k.miasto,
           (SELECT COUNT(*) FROM crm_osoby WHERE klient_id = k.id) as liczba_osob,
           (SELECT COUNT(*) FROM crm_osoby WHERE klient_id = k.id AND (stanowisko LIKE '%Zarząd%' OR stanowisko LIKE '%Prokurent%')) as liczba_zarzad
    FROM crm_klienci k
    WHERE k.nip IS NOT NULL AND k.nip != ''
    ORDER BY k.nazwa
    LIMIT 200
")->fetchAll();

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pobieranie Zarządu z KRS - CRM</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .card-header { padding: 20px; border-bottom: 1px solid #e5e7eb; display: flex; justify-content: space-between; align-items: center; }
        .card-header h2 { margin: 0; font-size: 20px; }
        .card-body { padding: 20px; }
        
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .stat { background: #f8fafc; padding: 16px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 28px; font-weight: 700; color: #1e40af; }
        .stat-label { font-size: 12px; color: #6b7280; }
        .stat.green .stat-value { color: #16a34a; }
        .stat.orange .stat-value { color: #ea580c; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; text-decoration: none; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-outline { background: white; border: 1px solid #d1d5db; color: #374151; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f9fafb; font-weight: 600; font-size: 11px; text-transform: uppercase; color: #6b7280; }
        tr:hover { background: #f9fafb; }
        
        .badge { display: inline-block; padding: 3px 10px; border-radius: 9999px; font-size: 11px; font-weight: 500; }
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .badge-info { background: #dbeafe; color: #1e40af; }
        
        .log { background: #1f2937; color: #e5e7eb; padding: 15px; border-radius: 8px; font-family: monospace; font-size: 12px; max-height: 300px; overflow-y: auto; margin-bottom: 20px; }
        .log-entry { padding: 3px 0; border-bottom: 1px solid #374151; }
        .log-entry.success { color: #4ade80; }
        .log-entry.error { color: #f87171; }
        
        .progress-bar { height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden; margin-bottom: 10px; }
        .progress-fill { height: 100%; background: linear-gradient(90deg, #16a34a, #22c55e); transition: width 0.3s; }
        
        .nip-col { font-family: monospace; }
        
        .actions-cell { display: flex; gap: 6px; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h2>👥 Pobieranie Zarządu i Prokurentów z KRS</h2>
                <a href="crm/klienci.php" class="btn btn-outline">← Powrót do CRM</a>
            </div>
            <div class="card-body">
                
                <div class="stats">
                    <div class="stat">
                        <div class="stat-value"><?= $stats['total'] ?></div>
                        <div class="stat-label">Wszystkich firm</div>
                    </div>
                    <div class="stat">
                        <div class="stat-value"><?= $stats['z_nip'] ?></div>
                        <div class="stat-label">Z NIP (do pobrania)</div>
                    </div>
                    <div class="stat green">
                        <div class="stat-value"><?= $stats['z_zarzadem'] ?></div>
                        <div class="stat-label">Z zarządem</div>
                    </div>
                    <div class="stat orange">
                        <div class="stat-value"><?= $stats['z_nip'] - $stats['z_zarzadem'] ?></div>
                        <div class="stat-label">Bez zarządu</div>
                    </div>
                </div>
                
                <div style="margin-bottom: 20px; padding: 15px; background: #eff6ff; border-radius: 8px; border-left: 4px solid #2563eb;">
                    <strong>💡 Jak to działa?</strong>
                    <ol style="margin: 10px 0 0 20px; color: #374151;">
                        <li>Dla każdej firmy z NIP - szukamy w GUS</li>
                        <li>Pobieramy numer KRS z raportu GUS</li>
                        <li>Z API KRS pobieramy członków zarządu i prokurentów</li>
                        <li>Zapisujemy jako osoby kontaktowe w CRM</li>
                    </ol>
                </div>
                
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <button class="btn btn-success" id="btnStartAll" onclick="startAll()">▶️ Pobierz dla wszystkich firm bez zarządu</button>
                    <button class="btn btn-outline" id="btnStop" onclick="stopProcessing()" disabled>⏹️ Stop</button>
                    <span id="statusText" style="margin-left: 15px; color: #6b7280;"></span>
                </div>
                
                <div class="log" id="log" style="display: none;"></div>
                
                <h3 style="margin: 20px 0 15px;">Firmy z NIP</h3>
                
                <table>
                    <thead>
                        <tr>
                            <th style="width: 35%">Firma</th>
                            <th style="width: 15%">NIP</th>
                            <th style="width: 15%">Miasto</th>
                            <th style="width: 10%">Osoby</th>
                            <th style="width: 10%">Zarząd</th>
                            <th style="width: 15%">Akcja</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($doPobrania as $f): ?>
                        <tr id="row-<?= $f['id'] ?>">
                            <td>
                                <a href="crm/klient_karta.php?id=<?= $f['id'] ?>" style="color: #1e40af; text-decoration: none; font-weight: 500;">
                                    <?= htmlspecialchars($f['nazwa']) ?>
                                </a>
                            </td>
                            <td class="nip-col"><?= htmlspecialchars($f['nip']) ?></td>
                            <td><?= htmlspecialchars($f['miasto'] ?: '—') ?></td>
                            <td>
                                <?php if ($f['liczba_osob'] > 0): ?>
                                    <span class="badge badge-info">👤 <?= $f['liczba_osob'] ?></span>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </td>
                            <td id="zarzad-<?= $f['id'] ?>">
                                <?php if ($f['liczba_zarzad'] > 0): ?>
                                    <span class="badge badge-success">✅ <?= $f['liczba_zarzad'] ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="actions-cell">
                                <?php if ($f['liczba_zarzad'] == 0): ?>
                                <button class="btn btn-primary btn-sm" onclick="processOne(<?= $f['id'] ?>, '<?= $f['nip'] ?>')" id="btn-<?= $f['id'] ?>">
                                    📥 Pobierz
                                </button>
                                <?php else: ?>
                                <span style="color: #16a34a; font-size: 12px;">✅ Gotowe</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
            </div>
        </div>
    </div>
    
    <script>
    let processing = false;
    let processed = 0;
    let total = <?= $stats['z_nip'] - $stats['z_zarzadem'] ?>;
    
    function addLog(msg, type = '') {
        const log = document.getElementById('log');
        log.style.display = 'block';
        const time = new Date().toLocaleTimeString();
        log.innerHTML = `<div class="log-entry ${type}">[${time}] ${msg}</div>` + log.innerHTML;
    }
    
    function updateProgress() {
        const pct = total > 0 ? (processed / total * 100) : 0;
        document.getElementById('progressFill').style.width = pct + '%';
        document.getElementById('statusText').textContent = `Przetworzono: ${processed} / ${total}`;
    }
    
    function processOne(id, nip) {
        const btn = document.getElementById('btn-' + id);
        if (btn) {
            btn.disabled = true;
            btn.textContent = '⏳...';
        }
        
        const formData = new FormData();
        formData.append('action', 'process');
        formData.append('klient_id', id);
        formData.append('nip', nip);
        
        fetch(location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.error) {
                    addLog(`❌ ID ${id}: ${data.error}`, 'error');
                    if (btn) {
                        btn.disabled = false;
                        btn.textContent = '📥 Pobierz';
                    }
                } else {
                    addLog(`✅ ID ${id}: Dodano ${data.added} osób (Zarząd: ${data.zarzad}, Prokurenci: ${data.prokurenci})`, 'success');
                    
                    // Aktualizuj wiersz
                    const zarzadCell = document.getElementById('zarzad-' + id);
                    if (zarzadCell) {
                        zarzadCell.innerHTML = `<span class="badge badge-success">✅ ${data.zarzad + data.prokurenci}</span>`;
                    }
                    if (btn) {
                        btn.parentElement.innerHTML = '<span style="color: #16a34a; font-size: 12px;">✅ Gotowe</span>';
                    }
                    
                    processed++;
                    updateProgress();
                }
                
                // Wyświetl szczegółowy log
                if (data.log) {
                    data.log.forEach(l => addLog('   ' + l));
                }
            })
            .catch(e => {
                addLog(`❌ Błąd: ${e.message}`, 'error');
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = '📥 Pobierz';
                }
            });
    }
    
    function startAll() {
        processing = true;
        document.getElementById('btnStartAll').disabled = true;
        document.getElementById('btnStop').disabled = false;
        processNext();
    }
    
    function stopProcessing() {
        processing = false;
        document.getElementById('btnStartAll').disabled = false;
        document.getElementById('btnStop').disabled = true;
    }
    
    function processNext() {
        if (!processing) return;
        
        const formData = new FormData();
        formData.append('action', 'process_all');
        
        fetch(location.href, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.done) {
                    addLog('🎉 Zakończono przetwarzanie!', 'success');
                    stopProcessing();
                    return;
                }
                
                if (data.error) {
                    addLog(`❌ ${data.firma}: ${data.error}`, 'error');
                } else {
                    addLog(`✅ ${data.firma}: Dodano ${data.added} osób`, 'success');
                    processed++;
                    updateProgress();
                }
                
                // Następna firma po krótkim opóźnieniu
                setTimeout(processNext, 500);
            })
            .catch(e => {
                addLog(`❌ Błąd: ${e.message}`, 'error');
                setTimeout(processNext, 2000);
            });
    }
    </script>
</body>
</html>
