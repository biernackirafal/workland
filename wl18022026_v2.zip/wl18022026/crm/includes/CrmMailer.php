<?php
/**
 * CRM Mail Helper - Wysyłanie maili przez SMTP
 * System Ewidencji Pracowników - Work Land CRM
 */

class CrmMailer {
    private $db;
    private $config = [];
    private $lastError = '';
    
    public function __construct($db) {
        $this->db = $db;
        $this->loadConfig();
    }
    
    private function loadConfig() {
        $stmt = $this->db->query("SELECT klucz, wartosc FROM crm_config WHERE klucz LIKE 'mail_%' OR klucz LIKE 'reminder_%'");
        while ($row = $stmt->fetch()) {
            $this->config[$row['klucz']] = $row['wartosc'];
        }
    }
    
    public function getConfig($key, $default = '') {
        return $this->config[$key] ?? $default;
    }
    
    public function isEnabled() {
        return $this->getConfig('mail_enabled') === '1';
    }
    
    public function getLastError() {
        return $this->lastError;
    }
    
    /**
     * Wysyła mail - używa PHPMailer jeśli dostępny, w przeciwnym razie mail()
     */
    public function send($to, $subject, $body, $isHtml = true) {
        $this->lastError = '';
        
        if (!$this->isEnabled()) {
            $this->lastError = 'Wysyłanie maili jest wyłączone w konfiguracji';
            return false;
        }
        
        // Sprawdź czy PHPMailer jest zainstalowany
        $phpmailerPath = __DIR__ . '/../vendor/phpmailer/phpmailer/src/PHPMailer.php';
        
        if (file_exists($phpmailerPath)) {
            return $this->sendViaPHPMailer($to, $subject, $body, $isHtml);
        } else {
            return $this->sendViaNativeMail($to, $subject, $body, $isHtml);
        }
    }
    
    private function sendViaPHPMailer($to, $subject, $body, $isHtml) {
        require_once __DIR__ . '/../vendor/autoload.php';
        
        $mail = new PHPMailer\PHPMailer\PHPMailer(true);
        
        try {
            // Konfiguracja SMTP
            $mail->isSMTP();
            $mail->Host = $this->getConfig('mail_smtp_host');
            $mail->Port = intval($this->getConfig('mail_smtp_port', 587));
            $mail->SMTPSecure = $this->getConfig('mail_smtp_secure', 'tls');
            
            $smtpUser = $this->getConfig('mail_smtp_user');
            if ($smtpUser) {
                $mail->SMTPAuth = true;
                $mail->Username = $smtpUser;
                $mail->Password = $this->getConfig('mail_smtp_pass');
            }
            
            // Nadawca i odbiorca
            $mail->setFrom(
                $this->getConfig('mail_from_email'),
                $this->getConfig('mail_from_name', 'Work Land CRM')
            );
            $mail->addAddress($to);
            
            // Treść
            $mail->CharSet = 'UTF-8';
            $mail->isHTML($isHtml);
            $mail->Subject = $subject;
            $mail->Body = $body;
            
            if ($isHtml) {
                $mail->AltBody = strip_tags($body);
            }
            
            $mail->send();
            return true;
            
        } catch (Exception $e) {
            $this->lastError = $mail->ErrorInfo;
            return false;
        }
    }
    
    private function sendViaNativeMail($to, $subject, $body, $isHtml) {
        $headers = [];
        $headers[] = 'MIME-Version: 1.0';
        $headers[] = 'From: ' . $this->getConfig('mail_from_name', 'Work Land CRM') . ' <' . $this->getConfig('mail_from_email') . '>';
        $headers[] = 'Reply-To: ' . $this->getConfig('mail_from_email');
        
        if ($isHtml) {
            $headers[] = 'Content-type: text/html; charset=UTF-8';
        } else {
            $headers[] = 'Content-type: text/plain; charset=UTF-8';
        }
        
        $result = @mail($to, $subject, $body, implode("\r\n", $headers));
        
        if (!$result) {
            $this->lastError = 'Nie udało się wysłać maila przez funkcję mail()';
        }
        
        return $result;
    }
    
    /**
     * Zapisuje log wysyłki
     */
    public function logSend($zadanieId, $userId, $email, $subject, $success, $errorMsg = '') {
        $stmt = $this->db->prepare("
            INSERT INTO crm_mail_log (zadanie_id, user_id, email, temat, status, error_msg)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $zadanieId,
            $userId,
            $email,
            $subject,
            $success ? 'sent' : 'error',
            $errorMsg
        ]);
    }
    
    /**
     * Generuje HTML przypomnienia o zadaniu
     */
    public function generateReminderEmail($zadanie, $klient, $user) {
        $terminFormatted = date('d.m.Y', strtotime($zadanie['termin_data']));
        if ($zadanie['termin_godzina']) {
            $terminFormatted .= ' o ' . substr($zadanie['termin_godzina'], 0, 5);
        }
        
        $priorytetLabels = [
            'niski' => '🟢 Niski',
            'normalny' => '🟡 Normalny',
            'wysoki' => '🟠 Wysoki',
            'pilny' => '🔴 Pilny'
        ];
        $priorytet = $priorytetLabels[$zadanie['priorytet']] ?? $zadanie['priorytet'];
        
        $html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #1e40af; color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center; }
        .content { background: #f8fafc; padding: 30px; border: 1px solid #e2e8f0; }
        .task-box { background: white; padding: 20px; border-radius: 8px; border-left: 4px solid #2563eb; margin: 20px 0; }
        .task-title { font-size: 1.3em; font-weight: 600; color: #1e3a5f; margin-bottom: 10px; }
        .task-meta { color: #64748b; font-size: 0.9em; }
        .task-meta span { display: inline-block; margin-right: 15px; }
        .btn { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 15px; }
        .footer { text-align: center; padding: 20px; color: #94a3b8; font-size: 0.85em; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📋 Przypomnienie o zadaniu</h1>
        </div>
        <div class="content">
            <p>Cześć <strong>' . htmlspecialchars($user['name']) . '</strong>,</p>
            <p>Przypominamy o zbliżającym się zadaniu:</p>
            
            <div class="task-box">
                <div class="task-title">' . htmlspecialchars($zadanie['tytul']) . '</div>
                <div class="task-meta">
                    <span>📅 <strong>Termin:</strong> ' . $terminFormatted . '</span><br>
                    <span>🏢 <strong>Klient:</strong> ' . htmlspecialchars($klient['nazwa']) . '</span><br>
                    <span>⚡ <strong>Priorytet:</strong> ' . $priorytet . '</span>
                </div>
                ' . ($zadanie['opis'] ? '<p style="margin-top: 15px; color: #475569;">' . nl2br(htmlspecialchars($zadanie['opis'])) . '</p>' : '') . '
            </div>
            
            <p>Powodzenia!</p>
        </div>
        <div class="footer">
            <p>Ta wiadomość została wysłana automatycznie przez Work Land CRM</p>
        </div>
    </div>
</body>
</html>';
        
        return $html;
    }
}
