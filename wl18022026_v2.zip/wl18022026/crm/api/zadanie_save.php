<?php
require_once '../../includes/db.php';
$db = initDatabase();
requireLogin();
$currentUser = getCurrentUser();

$klient_id = intval($_POST['klient_id'] ?? 0);
$zadanie_id = intval($_POST['zadanie_id'] ?? 0);

if (!$klient_id) { header('Location: ../klienci.php'); exit; }

$data = [
    'tytul' => trim($_POST['tytul'] ?? ''),
    'opis' => trim($_POST['opis'] ?? ''),
    'typ' => $_POST['typ'] ?? 'zadanie',
    'priorytet' => $_POST['priorytet'] ?? 'normalny',
    'termin_data' => $_POST['termin_data'] ?: null,
    'termin_godzina' => $_POST['termin_godzina'] ?: null,
    'przypisany_do' => intval($_POST['przypisany_do'] ?? 0) ?: null,
    'przypomnienie_email' => isset($_POST['przypomnienie_email']) ? 1 : 0,
    'przypomnienie_dni' => intval($_POST['przypomnienie_dni'] ?? 1)
];

// Oblicz datę przypomnienia jeśli włączone
$przypomnienie_data = null;
if ($data['przypomnienie_email'] && $data['termin_data']) {
    $termin = new DateTime($data['termin_data']);
    $termin->modify('-' . $data['przypomnienie_dni'] . ' days');
    $przypomnienie_data = $termin->format('Y-m-d');
}

if ($zadanie_id > 0) {
    // Sprawdź czy termin/przypomnienie się zmienił - jeśli tak, zresetuj status wysłania
    $stmt = $db->prepare("SELECT termin_data, przypomnienie_dni, przypomnienie_email FROM crm_zadania WHERE id = ?");
    $stmt->execute([$zadanie_id]);
    $oldData = $stmt->fetch();
    
    $resetReminder = ($oldData['termin_data'] != $data['termin_data'] || 
                      $oldData['przypomnienie_dni'] != $data['przypomnienie_dni'] ||
                      $oldData['przypomnienie_email'] != $data['przypomnienie_email']);
    
    $przypomnienie_wyslane = $resetReminder ? 0 : null; // null = nie zmieniaj
    
    if ($przypomnienie_wyslane === 0) {
        $stmt = $db->prepare("UPDATE crm_zadania SET tytul=?, opis=?, typ=?, priorytet=?, termin_data=?, termin_godzina=?, przypisany_do=?, przypomnienie_email=?, przypomnienie_dni=?, przypomnienie_data=?, przypomnienie_wyslane=0 WHERE id=? AND klient_id=?");
        $stmt->execute([$data['tytul'], $data['opis'], $data['typ'], $data['priorytet'], $data['termin_data'], $data['termin_godzina'], $data['przypisany_do'], $data['przypomnienie_email'], $data['przypomnienie_dni'], $przypomnienie_data, $zadanie_id, $klient_id]);
    } else {
        $stmt = $db->prepare("UPDATE crm_zadania SET tytul=?, opis=?, typ=?, priorytet=?, termin_data=?, termin_godzina=?, przypisany_do=?, przypomnienie_email=?, przypomnienie_dni=?, przypomnienie_data=? WHERE id=? AND klient_id=?");
        $stmt->execute([$data['tytul'], $data['opis'], $data['typ'], $data['priorytet'], $data['termin_data'], $data['termin_godzina'], $data['przypisany_do'], $data['przypomnienie_email'], $data['przypomnienie_dni'], $przypomnienie_data, $zadanie_id, $klient_id]);
    }
} else {
    $stmt = $db->prepare("INSERT INTO crm_zadania (klient_id, tytul, opis, typ, priorytet, termin_data, termin_godzina, przypisany_do, przypomnienie_email, przypomnienie_dni, przypomnienie_data, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$klient_id, $data['tytul'], $data['opis'], $data['typ'], $data['priorytet'], $data['termin_data'], $data['termin_godzina'], $data['przypisany_do'], $data['przypomnienie_email'], $data['przypomnienie_dni'], $przypomnienie_data, $currentUser['id']]);
}

header("Location: ../klient_karta.php?id=$klient_id&tab=zadania");
