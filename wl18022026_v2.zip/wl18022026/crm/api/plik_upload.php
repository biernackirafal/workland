<?php
require_once '../../includes/db.php';
$db = initDatabase();
requireLogin();
$currentUser = getCurrentUser();

$klient_id = intval($_POST['klient_id'] ?? 0);
if (!$klient_id) { header('Location: ../klienci.php'); exit; }

if (!isset($_FILES['plik']) || $_FILES['plik']['error'] !== UPLOAD_ERR_OK) {
    header("Location: ../klient_karta.php?id=$klient_id&tab=pliki&error=upload");
    exit;
}

$file = $_FILES['plik'];
$maxSize = 10 * 1024 * 1024; // 10 MB

if ($file['size'] > $maxSize) {
    header("Location: ../klient_karta.php?id=$klient_id&tab=pliki&error=size");
    exit;
}

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$newName = 'crm_' . $klient_id . '_' . uniqid() . '.' . $ext;

$uploadDir = __DIR__ . '/../../data/uploads/crm/';
if (!is_dir($uploadDir)) { mkdir($uploadDir, 0755, true); }

if (move_uploaded_file($file['tmp_name'], $uploadDir . $newName)) {
    $stmt = $db->prepare("INSERT INTO crm_pliki (klient_id, nazwa_oryginalna, nazwa_pliku, rozmiar, typ_mime, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$klient_id, $file['name'], $newName, $file['size'], $file['type'], $currentUser['id']]);
}

header("Location: ../klient_karta.php?id=$klient_id&tab=pliki");
