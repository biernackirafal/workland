<?php
require_once '../../includes/db.php';
$db = initDatabase();
requireLogin();
header('Content-Type: application/json');

if (!canDelete()) {
    echo json_encode(['success' => false, 'error' => 'Brak uprawnień']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);

if ($id > 0) {
    // Usuń pliki z dysku
    $stmt = $db->prepare("SELECT nazwa_pliku FROM crm_pliki WHERE klient_id = ?");
    $stmt->execute([$id]);
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $plik) {
        $filePath = __DIR__ . '/../../data/uploads/crm/' . $plik;
        if (file_exists($filePath)) { unlink($filePath); }
    }
    
    // Usuń klienta (kaskadowo usunie osoby, zadania, pliki)
    $db->prepare("DELETE FROM crm_klienci WHERE id = ?")->execute([$id]);
    
    logChange($db, 'DELETE', 'crm_klienci', $id, "Usunięto lead");
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
