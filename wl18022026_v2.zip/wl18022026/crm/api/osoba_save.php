<?php
require_once '../../includes/db.php';
$db = initDatabase();
requireLogin();

$klient_id = intval($_POST['klient_id'] ?? 0);
$osoba_id = intval($_POST['osoba_id'] ?? 0);

if (!$klient_id) { header('Location: ../klienci.php'); exit; }

$data = [
    'imie' => trim($_POST['imie'] ?? ''),
    'nazwisko' => trim($_POST['nazwisko'] ?? ''),
    'stanowisko' => trim($_POST['stanowisko'] ?? ''),
    'telefon' => trim($_POST['telefon'] ?? ''),
    'email' => trim($_POST['email'] ?? ''),
    'linkedin_url' => trim($_POST['linkedin_url'] ?? ''),
    'glowny_kontakt' => isset($_POST['glowny_kontakt']) ? 1 : 0,
    'uwagi' => trim($_POST['uwagi'] ?? '')
];

// Automatyczne wykrywanie anonimizowanych danych
// Wzorce: A***, A*** K***, zawiera gwiazdki, bardzo krótkie imię z gwiazdką
function isAnonymized($imie, $nazwisko) {
    // Sprawdź czy zawiera gwiazdki
    if (strpos($imie, '*') !== false || strpos($nazwisko, '*') !== false) {
        return true;
    }
    // Sprawdź wzorzec typu "A***" lub "Ab***"
    if (preg_match('/^[A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]?\*+$/u', $imie) || 
        preg_match('/^[A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]?\*+$/u', $nazwisko)) {
        return true;
    }
    return false;
}

$dane_zanonimizowane = isAnonymized($data['imie'], $data['nazwisko']) ? 1 : 0;

if ($osoba_id > 0) {
    $stmt = $db->prepare("UPDATE crm_osoby SET imie=?, nazwisko=?, stanowisko=?, telefon=?, email=?, linkedin_url=?, glowny_kontakt=?, uwagi=?, dane_zanonimizowane=? WHERE id=? AND klient_id=?");
    $stmt->execute([$data['imie'], $data['nazwisko'], $data['stanowisko'], $data['telefon'], $data['email'], $data['linkedin_url'], $data['glowny_kontakt'], $data['uwagi'], $dane_zanonimizowane, $osoba_id, $klient_id]);
} else {
    // Generuj GUID dla nowej osoby
    $guid = generateGuid();
    $stmt = $db->prepare("INSERT INTO crm_osoby (klient_id, imie, nazwisko, stanowisko, telefon, email, linkedin_url, glowny_kontakt, uwagi, guid, dane_zanonimizowane) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$klient_id, $data['imie'], $data['nazwisko'], $data['stanowisko'], $data['telefon'], $data['email'], $data['linkedin_url'], $data['glowny_kontakt'], $data['uwagi'], $guid, $dane_zanonimizowane]);
}

header("Location: ../klient_karta.php?id=$klient_id&tab=osoby");
