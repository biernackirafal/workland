<?php
require_once '../../includes/db.php';
$db = initDatabase();
requireLogin();
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);

if ($id > 0) {
    $stmt = $db->prepare("SELECT nazwa_pliku FROM crm_pliki WHERE id = ?");
    $stmt->execute([$id]);
    $plik = $stmt->fetch();
    
    if ($plik) {
        $filePath = __DIR__ . '/../../data/uploads/crm/' . $plik['nazwa_pliku'];
        if (file_exists($filePath)) { unlink($filePath); }
        $db->prepare("DELETE FROM crm_pliki WHERE id = ?")->execute([$id]);
    }
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
