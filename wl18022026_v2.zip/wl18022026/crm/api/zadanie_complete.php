<?php
require_once '../../includes/db.php';
$db = initDatabase();
requireLogin();
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);

if ($id > 0) {
    $db->prepare("UPDATE crm_zadania SET status = 'zakonczone', completed_at = datetime('now') WHERE id = ?")->execute([$id]);
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
