<?php
/**
 * CRM - Import klientów z CSV
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

$message = '';
$messageType = '';
$previewData = [];
$totalRows = 0;

// Obsługa uploadu i podglądu
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    
    if ($_POST['action'] === 'preview' && isset($_FILES['csv_file'])) {
        $file = $_FILES['csv_file'];
        
        if ($file['error'] === UPLOAD_ERR_OK) {
            // Kopiuj do tymczasowej lokalizacji
            $storedPath = '../data/uploads/temp_import_' . uniqid() . '.csv';
            move_uploaded_file($file['tmp_name'], $storedPath);
            $_SESSION['csv_stored_path'] = $storedPath;
            $_SESSION['csv_original_name'] = $file['name'];
            
            // Odczytaj pierwsze 10 wierszy do podglądu
            if (($handle = fopen($storedPath, "r")) !== FALSE) {
                $rowNum = 0;
                while (($data = fgetcsv($handle, 10000, ";")) !== FALSE && $rowNum < 11) {
                    $previewData[] = $data;
                    $rowNum++;
                }
                
                // Policz wszystkie wiersze
                rewind($handle);
                $totalRows = -1; // Minus nagłówek
                while (fgetcsv($handle, 10000, ";") !== FALSE) {
                    $totalRows++;
                }
                fclose($handle);
                $_SESSION['csv_total_rows'] = $totalRows;
            }
            
            $message = "Plik wczytany pomyślnie. Sprawdź podgląd i potwierdź import.";
            $messageType = 'success';
        } else {
            $message = "Błąd podczas wczytywania pliku.";
            $messageType = 'error';
        }
    }
    
    if ($_POST['action'] === 'import' && isset($_SESSION['csv_stored_path'])) {
        $storedPath = $_SESSION['csv_stored_path'];
        $importedCount = 0;
        $skippedCount = 0;
        
        if (file_exists($storedPath) && ($handle = fopen($storedPath, "r")) !== FALSE) {
            try {
                // Dodaj brakujące kolumny jeśli nie istnieją
                $newColumns = [
                    'forma_prawna' => 'VARCHAR(255)',
                    'forma_wlasnosci' => 'VARCHAR(255)',
                    'pkd_glowne' => 'TEXT',
                    'pkd_pozostale' => 'TEXT',
                    'faks' => 'VARCHAR(50)'
                ];
                
                foreach ($newColumns as $col => $type) {
                    try {
                        $db->exec("ALTER TABLE crm_klienci ADD COLUMN $col $type");
                    } catch (PDOException $e) {}
                }
                
                // Przygotuj zapytanie INSERT
                $stmt = $db->prepare("INSERT INTO crm_klienci 
                    (nazwa, forma_prawna, forma_wlasnosci, pkd_glowne, pkd_pozostale, telefon, faks, ilosc_pracownikow, status, zrodlo_pozyskania, created_by, created_at, updated_at) 
                    VALUES 
                    (:nazwa, :forma_prawna, :forma_wlasnosci, :pkd_glowne, :pkd_pozostale, :telefon, :faks, :ilosc_pracownikow, 'nowy', 'Import CSV', :created_by, datetime('now'), datetime('now'))");
                
                // Pomiń nagłówek
                $header = fgetcsv($handle, 10000, ";");
                
                $db->beginTransaction();
                
                while (($data = fgetcsv($handle, 10000, ";")) !== FALSE) {
                    // Sprawdź czy wiersz ma wystarczającą liczbę kolumn i nazwę firmy
                    if (count($data) >= 1) {
                        $companyName = trim($data[0] ?? '');
                        
                        if (!empty($companyName)) {
                            try {
                                $stmt->execute([
                                    ':nazwa' => $companyName,
                                    ':forma_prawna' => trim($data[1] ?? ''),
                                    ':forma_wlasnosci' => trim($data[2] ?? ''),
                                    ':pkd_glowne' => trim($data[3] ?? ''),
                                    ':pkd_pozostale' => trim($data[4] ?? ''),
                                    ':telefon' => trim($data[5] ?? ''),
                                    ':faks' => trim($data[6] ?? ''),
                                    ':ilosc_pracownikow' => trim($data[7] ?? ''),
                                    ':created_by' => $currentUser['id']
                                ]);
                                $importedCount++;
                            } catch (Exception $e) {
                                $skippedCount++;
                            }
                        } else {
                            $skippedCount++;
                        }
                    } else {
                        $skippedCount++;
                    }
                }
                
                $db->commit();
                
                // Loguj akcję
                logChange($db, 'import', 'crm_klienci', 0, "Import CSV: $importedCount rekordów z pliku " . ($_SESSION['csv_original_name'] ?? 'nieznany'));
                
                $message = "Import zakończony! Zaimportowano: $importedCount rekordów. Pominięto: $skippedCount.";
                $messageType = 'success';
                
                // Wyczyść sesję i usuń plik tymczasowy
                unlink($storedPath);
                unset($_SESSION['csv_stored_path']);
                unset($_SESSION['csv_total_rows']);
                unset($_SESSION['csv_original_name']);
                
            } catch (Exception $e) {
                if ($db->inTransaction()) {
                    $db->rollBack();
                }
                $message = "Błąd podczas importu: " . $e->getMessage();
                $messageType = 'error';
            }
            
            fclose($handle);
        }
    }
    
    if ($_POST['action'] === 'cancel' && isset($_SESSION['csv_stored_path'])) {
        if (file_exists($_SESSION['csv_stored_path'])) {
            unlink($_SESSION['csv_stored_path']);
        }
        unset($_SESSION['csv_stored_path']);
        unset($_SESSION['csv_total_rows']);
        unset($_SESSION['csv_original_name']);
        
        $message = "Import anulowany.";
        $messageType = 'info';
    }
}

// Sprawdź czy jest zapisany podgląd w sesji
if (isset($_SESSION['csv_stored_path']) && file_exists($_SESSION['csv_stored_path']) && empty($previewData)) {
    $storedPath = $_SESSION['csv_stored_path'];
    if (($handle = fopen($storedPath, "r")) !== FALSE) {
        $rowNum = 0;
        while (($data = fgetcsv($handle, 10000, ";")) !== FALSE && $rowNum < 11) {
            $previewData[] = $data;
            $rowNum++;
        }
        fclose($handle);
    }
    $totalRows = $_SESSION['csv_total_rows'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import CSV - CRM - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .crm-nav { background: #1e40af; padding: 10px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .crm-nav a { color: rgba(255,255,255,0.85); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; transition: all 0.2s; }
        .crm-nav a:hover, .crm-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .crm-nav .nav-title { color: white; font-weight: 600; margin-right: 20px; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-body { padding: 25px; }
        
        .upload-zone { 
            border: 3px dashed #cbd5e1; 
            border-radius: 12px; 
            padding: 50px; 
            text-align: center; 
            transition: all 0.3s;
            cursor: pointer;
        }
        .upload-zone:hover { border-color: #2563eb; background: #f0f9ff; }
        .upload-zone.dragover { border-color: #2563eb; background: #dbeafe; }
        .upload-zone .icon { font-size: 4rem; margin-bottom: 15px; }
        .upload-zone h3 { margin: 0 0 10px 0; color: #374151; }
        .upload-zone p { color: #64748b; margin: 0; }
        .upload-zone input[type="file"] { display: none; }
        
        .alert { padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
        .alert-info { background: #dbeafe; color: #1e40af; border: 1px solid #93c5fd; }
        
        .preview-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; }
        .preview-table th { background: #f1f5f9; padding: 10px; text-align: left; font-weight: 600; color: #475569; border-bottom: 2px solid #e2e8f0; }
        .preview-table td { padding: 10px; border-bottom: 1px solid #e2e8f0; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .preview-table tr:hover td { background: #f8fafc; }
        
        .mapping-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px; background: #fffbeb; padding: 15px; border-radius: 8px; border: 1px solid #fcd34d; margin: 20px 0; }
        .mapping-item { font-size: 0.9rem; }
        .mapping-item span { color: #64748b; }
        .mapping-item strong { color: #374151; }
        
        .btn-group { display: flex; gap: 15px; margin-top: 25px; }
        .btn-group form { flex: 1; }
        .btn-group .btn { width: 100%; padding: 15px; font-size: 1rem; }
        
        .info-box { background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 20px; margin-top: 20px; }
        .info-box h4 { margin: 0 0 10px 0; color: #1e40af; }
        .info-box ol { margin: 0; padding-left: 20px; color: #1e40af; }
        .info-box li { margin-bottom: 5px; }
        
        .stats { display: flex; gap: 20px; margin-bottom: 20px; }
        .stat { background: #f1f5f9; padding: 15px 20px; border-radius: 8px; }
        .stat strong { font-size: 1.5rem; color: #1e40af; }
        .stat span { display: block; font-size: 0.85rem; color: #64748b; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?php echo sanitize($currentUser['name']); ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../klienci.php">🏢 Klienci</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <div class="crm-nav">
            <span class="nav-title">🎯 CRM</span>
            <a href="./">Dashboard</a>
            <a href="klienci.php">Potencjalni Klienci</a>
            <a href="zadania.php">Zadania</a>
            <a href="kalendarz.php">Kalendarz</a>
        </div>
        
        <header>
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <h1>📥 Import danych z CSV</h1>
                    <p class="subtitle">Zaimportuj potencjalnych klientów z pliku CSV</p>
                </div>
                <a href="klienci.php" class="btn">← Powrót do listy</a>
            </div>
        </header>
        
        <?php if ($message): ?>
        <div class="alert alert-<?php echo $messageType; ?>">
            <?php echo htmlspecialchars($message); ?>
            <?php if ($messageType === 'success' && strpos($message, 'Zaimportowano') !== false): ?>
                <br><a href="klienci.php" style="color: inherit; font-weight: 600;">→ Zobacz listę klientów</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <?php if (empty($previewData)): ?>
        <!-- Formularz uploadu -->
        <div class="card">
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data" id="uploadForm">
                    <input type="hidden" name="action" value="preview">
                    
                    <label class="upload-zone" id="dropZone">
                        <div class="icon">📄</div>
                        <h3>Wybierz plik CSV lub przeciągnij tutaj</h3>
                        <p>Akceptowane formaty: .csv (separator: średnik)</p>
                        <p id="selectedFile" style="margin-top: 15px; color: #2563eb; font-weight: 600;"></p>
                        <input type="file" name="csv_file" accept=".csv" required id="fileInput">
                    </label>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 20px; padding: 15px; font-size: 1rem;">
                        📤 Wczytaj plik i zobacz podgląd
                    </button>
                </form>
                
                <div class="info-box">
                    <h4>💡 Jak przygotować plik CSV?</h4>
                    <ol>
                        <li>Eksportuj dane z programu Excel jako CSV (separator: średnik)</li>
                        <li>Pierwszy wiersz powinien zawierać nagłówki kolumn</li>
                        <li>Zalecane kodowanie: UTF-8</li>
                        <li>Oczekiwane kolumny: Firma, Forma prawna, Forma własności, PKD główne, PKD pozostałe, Telefon, Faks, Wielkość zatrudnienia</li>
                    </ol>
                </div>
            </div>
        </div>
        
        <?php else: ?>
        <!-- Podgląd danych -->
        <div class="stats">
            <div class="stat">
                <strong><?php echo number_format($totalRows, 0, ',', ' '); ?></strong>
                <span>Rekordów do importu</span>
            </div>
            <div class="stat">
                <strong><?php echo count($previewData[0] ?? []); ?></strong>
                <span>Kolumn w pliku</span>
            </div>
            <div class="stat">
                <strong><?php echo htmlspecialchars($_SESSION['csv_original_name'] ?? 'nieznany'); ?></strong>
                <span>Nazwa pliku</span>
            </div>
        </div>
        
        <div class="card">
            <div class="card-body">
                <h3 style="margin-top: 0;">📊 Podgląd danych (pierwsze 10 wierszy)</h3>
                
                <div style="overflow-x: auto;">
                    <table class="preview-table">
                        <thead>
                            <tr>
                                <?php if (!empty($previewData[0])): ?>
                                    <?php foreach ($previewData[0] as $header): ?>
                                    <th><?php echo htmlspecialchars(mb_substr($header, 0, 25)); ?></th>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php for ($i = 1; $i < count($previewData); $i++): ?>
                            <tr>
                                <?php foreach ($previewData[$i] as $cell): ?>
                                <td title="<?php echo htmlspecialchars($cell); ?>">
                                    <?php echo htmlspecialchars(mb_substr($cell, 0, 40)); ?>
                                </td>
                                <?php endforeach; ?>
                            </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
                
                <?php if ($totalRows > 10): ?>
                <p style="color: #64748b; font-style: italic; margin-top: 15px;">
                    ... i <?php echo number_format($totalRows - 10, 0, ',', ' '); ?> więcej rekordów
                </p>
                <?php endif; ?>
                
                <div class="mapping-grid">
                    <div class="mapping-item"><span>Kolumna 1:</span> <strong>Nazwa firmy</strong></div>
                    <div class="mapping-item"><span>Kolumna 2:</span> <strong>Forma prawna</strong></div>
                    <div class="mapping-item"><span>Kolumna 3:</span> <strong>Forma własności</strong></div>
                    <div class="mapping-item"><span>Kolumna 4:</span> <strong>PKD główne</strong></div>
                    <div class="mapping-item"><span>Kolumna 5:</span> <strong>PKD pozostałe</strong></div>
                    <div class="mapping-item"><span>Kolumna 6:</span> <strong>Telefon</strong></div>
                    <div class="mapping-item"><span>Kolumna 7:</span> <strong>Faks</strong></div>
                    <div class="mapping-item"><span>Kolumna 8:</span> <strong>Wielkość firmy</strong></div>
                </div>
                
                <div class="btn-group">
                    <form method="POST">
                        <input type="hidden" name="action" value="import">
                        <button type="submit" class="btn btn-primary" onclick="return confirm('Czy na pewno chcesz zaimportować <?php echo number_format($totalRows, 0, ',', ' '); ?> rekordów?')">
                            ✅ Potwierdź import (<?php echo number_format($totalRows, 0, ',', ' '); ?> rekordów)
                        </button>
                    </form>
                    <form method="POST" style="flex: 0.3;">
                        <input type="hidden" name="action" value="cancel">
                        <button type="submit" class="btn" style="background: #64748b; color: white;">
                            ❌ Anuluj
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <script>
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const selectedFile = document.getElementById('selectedFile');

    if (dropZone && fileInput) {
        // Kliknięcie
        dropZone.addEventListener('click', () => fileInput.click());
        
        // Zmiana pliku
        fileInput.addEventListener('change', function() {
            if (this.files[0]) {
                selectedFile.textContent = '📄 ' + this.files[0].name;
            }
        });
        
        // Drag & drop
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, e => {
                e.preventDefault();
                e.stopPropagation();
            });
        });
        
        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, () => dropZone.classList.add('dragover'));
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, () => dropZone.classList.remove('dragover'));
        });
        
        dropZone.addEventListener('drop', e => {
            const files = e.dataTransfer.files;
            if (files.length) {
                fileInput.files = files;
                selectedFile.textContent = '📄 ' + files[0].name;
            }
        });
    }
    </script>
</body>
</html>
