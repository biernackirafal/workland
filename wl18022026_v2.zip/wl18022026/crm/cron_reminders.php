<?php
/**
 * CRM Cron - Wysyłanie przypomnień mailowych o zadaniach
 * System Ewidencji Pracowników - Work Land CRM
 * 
 * Uruchom przez cron np. codziennie o 8:00:
 * 0 8 * * * php /path/to/crm/cron_reminders.php
 * 
 * Parametry:
 *   --dry-run    Tylko sprawdza, nie wysyła maili
 *   --verbose    Wyświetla szczegółowe informacje
 */

// Określ ścieżkę do includes - dostosuj jeśli trzeba
$basePath = __DIR__;
if (file_exists($basePath . '/../includes/db.php')) {
    require_once $basePath . '/../includes/db.php';
} else {
    // Fallback dla uruchamiania z różnych lokalizacji
    require_once dirname(__DIR__) . '/includes/db.php';
}

require_once __DIR__ . '/includes/CrmMailer.php';

// Parsuj argumenty
$dryRun = in_array('--dry-run', $argv ?? []);
$verbose = in_array('--verbose', $argv ?? []) || in_array('-v', $argv ?? []);

function logMsg($msg, $forceShow = false) {
    global $verbose;
    if ($verbose || $forceShow) {
        echo date('[Y-m-d H:i:s] ') . $msg . "\n";
    }
}

logMsg("=== CRM Reminder Cron Started ===", true);
if ($dryRun) logMsg("TRYB TESTOWY (--dry-run) - maile nie będą wysyłane", true);

try {
    $db = initDatabase();
    $mailer = new CrmMailer($db);
    
    // Sprawdź czy wysyłanie maili jest włączone
    if (!$mailer->isEnabled()) {
        logMsg("Wysyłanie maili jest WYŁĄCZONE w konfiguracji. Zakończono.", true);
        exit(0);
    }
    
    $today = date('Y-m-d');
    logMsg("Szukam przypomnień do wysłania na dzień: $today");
    
    // Znajdź zadania do przypomnienia
    // Warunki:
    // - przypomnienie_email = 1 (włączone)
    // - przypomnienie_data <= dziś (czas na przypomnienie)
    // - przypomnienie_wyslane = 0 (jeszcze nie wysłane)
    // - status != 'zakonczone' (zadanie nie jest zakończone)
    // - przypisany_do IS NOT NULL (ktoś jest przypisany)
    // - termin_data IS NOT NULL (jest termin)
    
    $stmt = $db->prepare("
        SELECT 
            z.*,
            k.nazwa as klient_nazwa,
            k.id as klient_id,
            u.id as user_id,
            u.name as user_name,
            u.email as user_email
        FROM crm_zadania z
        JOIN crm_klienci k ON z.klient_id = k.id
        JOIN users u ON z.przypisany_do = u.id
        WHERE z.przypomnienie_email = 1
          AND z.przypomnienie_wyslane = 0
          AND z.przypomnienie_data <= ?
          AND z.status != 'zakonczone'
          AND z.termin_data IS NOT NULL
          AND z.przypisany_do IS NOT NULL
        ORDER BY z.termin_data ASC
    ");
    $stmt->execute([$today]);
    $zadania = $stmt->fetchAll();
    
    $count = count($zadania);
    logMsg("Znaleziono $count zadań do przypomnienia", true);
    
    if ($count === 0) {
        logMsg("Brak zadań do przypomnienia. Zakończono.", true);
        updateLastRun($db);
        exit(0);
    }
    
    $sent = 0;
    $errors = 0;
    
    foreach ($zadania as $zadanie) {
        $email = $zadanie['user_email'];
        
        if (empty($email)) {
            logMsg("⚠ Brak emaila dla użytkownika: {$zadanie['user_name']} (ID: {$zadanie['user_id']})");
            $errors++;
            continue;
        }
        
        logMsg("Wysyłam przypomnienie: \"{$zadanie['tytul']}\" -> $email");
        
        $subject = "📋 Przypomnienie: {$zadanie['tytul']} (termin: " . date('d.m.Y', strtotime($zadanie['termin_data'])) . ")";
        
        $klient = ['nazwa' => $zadanie['klient_nazwa'], 'id' => $zadanie['klient_id']];
        $user = ['name' => $zadanie['user_name'], 'email' => $email];
        
        $body = $mailer->generateReminderEmail($zadanie, $klient, $user);
        
        if ($dryRun) {
            logMsg("  [DRY-RUN] Mail nie został wysłany");
            $sent++;
        } else {
            $success = $mailer->send($email, $subject, $body);
            
            if ($success) {
                logMsg("  ✓ Wysłano pomyślnie");
                $sent++;
                
                // Oznacz jako wysłane
                $updateStmt = $db->prepare("UPDATE crm_zadania SET przypomnienie_wyslane = 1 WHERE id = ?");
                $updateStmt->execute([$zadanie['id']]);
                
                // Zapisz log
                $mailer->logSend($zadanie['id'], $zadanie['user_id'], $email, $subject, true);
            } else {
                $error = $mailer->getLastError();
                logMsg("  ✗ Błąd wysyłki: $error", true);
                $errors++;
                
                // Zapisz log błędu
                $mailer->logSend($zadanie['id'], $zadanie['user_id'], $email, $subject, false, $error);
            }
        }
    }
    
    updateLastRun($db);
    
    logMsg("=== Podsumowanie ===", true);
    logMsg("Wysłano: $sent / $count", true);
    if ($errors > 0) {
        logMsg("Błędy: $errors", true);
    }
    logMsg("=== Zakończono ===", true);
    
} catch (Exception $e) {
    logMsg("BŁĄD KRYTYCZNY: " . $e->getMessage(), true);
    exit(1);
}

function updateLastRun($db) {
    $stmt = $db->prepare("UPDATE crm_config SET wartosc = ?, updated_at = CURRENT_TIMESTAMP WHERE klucz = 'reminder_cron_last_run'");
    $stmt->execute([date('Y-m-d H:i:s')]);
}
