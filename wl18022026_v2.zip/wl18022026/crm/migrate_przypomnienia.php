<?php
/**
 * Migracja: Dodanie kolumn przypomnienia do tabeli crm_zadania
 * Uruchom raz na serwerze: php migrate_przypomnienia.php
 */

require_once 'includes/db.php';
$db = initDatabase();

echo "=== Migracja kolumn przypomnienia ===\n\n";

// Sprawdź czy kolumny już istnieją
$columns = [];
$result = $db->query("PRAGMA table_info(crm_zadania)");
while ($row = $result->fetch()) {
    $columns[] = $row['name'];
}

$added = [];

// Dodaj brakujące kolumny
if (!in_array('przypomnienie_email', $columns)) {
    $db->exec("ALTER TABLE crm_zadania ADD COLUMN przypomnienie_email INTEGER DEFAULT 0");
    $added[] = 'przypomnienie_email';
}

if (!in_array('przypomnienie_dni', $columns)) {
    $db->exec("ALTER TABLE crm_zadania ADD COLUMN przypomnienie_dni INTEGER DEFAULT 1");
    $added[] = 'przypomnienie_dni';
}

if (!in_array('przypomnienie_data', $columns)) {
    $db->exec("ALTER TABLE crm_zadania ADD COLUMN przypomnienie_data TEXT");
    $added[] = 'przypomnienie_data';
}

if (!in_array('przypomnienie_wyslane', $columns)) {
    $db->exec("ALTER TABLE crm_zadania ADD COLUMN przypomnienie_wyslane INTEGER DEFAULT 0");
    $added[] = 'przypomnienie_wyslane';
}

if (count($added) > 0) {
    echo "Dodano kolumny: " . implode(', ', $added) . "\n";
    echo "✅ Migracja zakończona pomyślnie!\n";
} else {
    echo "Wszystkie kolumny już istnieją.\n";
    echo "✅ Baza danych jest aktualna.\n";
}
