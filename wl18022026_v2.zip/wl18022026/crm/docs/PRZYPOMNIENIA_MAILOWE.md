# Przypomnienia mailowe - Work Land CRM

## 📋 Opis funkcjonalności

System przypomnień mailowych automatycznie wysyła powiadomienia email do użytkowników przypisanych do zadań przed nadchodzącym terminem.

## 🚀 Instalacja

### 1. Uruchom migrację bazy danych

```bash
cd /path/to/crm
php migrations/add_task_reminders.php
```

Migracja doda:
- Nowe pola do tabeli `crm_zadania` (przypomnienie_email, przypomnienie_dni, przypomnienie_wyslane, przypomnienie_data)
- Tabelę `crm_config` z konfiguracją SMTP
- Tabelę `crm_mail_log` z historią wysyłek

### 2. (Opcjonalnie) Zainstaluj PHPMailer

Dla bardziej niezawodnego wysyłania maili przez SMTP:

```bash
cd /path/to/crm
composer require phpmailer/phpmailer
```

Bez PHPMailer system użyje natywnej funkcji `mail()` PHP.

### 3. Skonfiguruj SMTP

Otwórz panel konfiguracji: **CRM → ⚙️ Konfiguracja maili**

Wypełnij:
- Serwer SMTP (np. `smtp.gmail.com`)
- Port (np. `587` dla TLS, `465` dla SSL)
- Login i hasło
- Adres i nazwę nadawcy

### 4. Skonfiguruj CRON

Dodaj zadanie cron do automatycznego wysyłania przypomnień:

```bash
# Codziennie o 8:00
0 8 * * * php /path/to/crm/cron_reminders.php

# Lub z logowaniem
0 8 * * * php /path/to/crm/cron_reminders.php --verbose >> /var/log/crm_reminders.log 2>&1
```

## 📧 Konfiguracja Gmail

Dla kont Gmail:
1. Włącz **2-Step Verification** na koncie Google
2. Wygeneruj **App Password**: Google Account → Security → App passwords
3. Użyj wygenerowanego hasła w konfiguracji SMTP (nie hasła do konta!)

Ustawienia:
- Host: `smtp.gmail.com`
- Port: `587`
- Szyfrowanie: `TLS`

## 🔧 Użycie

### Dodawanie przypomnienia do zadania

1. Przy tworzeniu/edycji zadania zaznacz **"📧 Wyślij przypomnienie mailowe"**
2. Wybierz ile dni przed terminem wysłać przypomnienie
3. Upewnij się, że zadanie ma ustawiony **termin** i **przypisaną osobę**

### Wymagania dla przypomnienia

Przypomnienie zostanie wysłane gdy:
- ✓ Zadanie ma włączone przypomnienie (`przypomnienie_email = 1`)
- ✓ Zadanie ma ustawiony termin
- ✓ Zadanie jest przypisane do użytkownika z adresem email
- ✓ Zadanie nie jest zakończone
- ✓ Przypomnienie nie było jeszcze wysłane

### Oznaczenia w interfejsie

- 📧 - Zadanie ma ustawione przypomnienie (oczekuje na wysłanie)
- 📧✓ - Przypomnienie zostało wysłane

## 🧪 Testowanie

### Test wysyłki z panelu

1. Otwórz **CRM → ⚙️ Konfiguracja maili**
2. Podaj adres email w sekcji "Test wysyłki"
3. Kliknij "Wyślij test"

### Test CRON w trybie dry-run

```bash
php cron_reminders.php --dry-run --verbose
```

Wyświetli jakie maile zostałyby wysłane, bez faktycznej wysyłki.

## 📁 Struktura plików

```
crm/
├── migrations/
│   └── add_task_reminders.php    # Migracja bazy danych
├── includes/
│   └── CrmMailer.php             # Klasa do wysyłania maili
├── api/
│   └── zadanie_save.php          # (zaktualizowany) Zapis zadania z przypomnieniem
├── cron_reminders.php            # Skrypt CRON
├── mail_config.php               # Panel konfiguracji SMTP
├── klient_karta.php              # (zaktualizowany) Formularz zadania
└── zadania.php                   # (zaktualizowany) Lista zadań
```

## ❓ Rozwiązywanie problemów

### "Wysyłanie maili jest wyłączone"
→ Włącz checkbox "Włącz wysyłanie maili" w konfiguracji

### "Nie udało się wysłać maila"
→ Sprawdź poprawność danych SMTP
→ Dla Gmail użyj App Password zamiast hasła konta
→ Sprawdź czy port nie jest zablokowany przez firewall

### "Brak emaila dla użytkownika"
→ Dodaj adres email w tabeli `users` dla przypisanego użytkownika

### CRON nie działa
→ Sprawdź czy ścieżka do PHP jest poprawna
→ Sprawdź uprawnienia do pliku cron_reminders.php
→ Sprawdź logi: `tail -f /var/log/crm_reminders.log`
