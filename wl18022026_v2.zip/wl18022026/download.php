<?php
/**
 * Pobieranie plików pracownika
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Pobierz info o pliku
$stmt = $db->prepare("SELECT * FROM pliki_pracownika WHERE id = ?");
$stmt->execute([$id]);
$plik = $stmt->fetch();

if (!$plik) {
    header('Location: index.php');
    exit;
}

$filePath = __DIR__ . '/data/uploads/' . $plik['pracownik_id'] . '/' . $plik['nazwa_pliku'];

if (!file_exists($filePath)) {
    echo "Plik nie istnieje.";
    exit;
}

// Wyślij plik
$ext = pathinfo($plik['nazwa_pliku'], PATHINFO_EXTENSION);
$downloadName = $plik['nazwa'] . '.' . $ext;

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $downloadName . '"');
header('Content-Length: ' . filesize($filePath));
header('Cache-Control: no-cache');

readfile($filePath);
exit;
