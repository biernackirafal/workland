<?php
/**
 * Konfiguracja bazy danych SQLite
 * System Ewidencji Pracowników - Work Land
 */

// Wersja systemu
define('WORKLAND_VERSION', '2.4.6');
define('WORKLAND_VERSION_DATE', '10.02.2026');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('DB_PATH', __DIR__ . '/../data/pracownicy.db');
define('BACKUP_DIR', __DIR__ . '/../data/backups/');

function getDB() {
    $dbDir = dirname(DB_PATH);
    if (!is_dir($dbDir)) {
        mkdir($dbDir, 0755, true);
    }
    
    $db = new PDO('sqlite:' . DB_PATH);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $db->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    return $db;
}

// === ROLE I UPRAWNIENIA ===
// admin - pełny dostęp + historia zmian + zarządzanie użytkownikami
// moderator - wszystko oprócz historii zmian i dodawania użytkowników
// viewer - może dodać, nie może usunąć

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

function getUserRole() {
    return isset($_SESSION['user_role']) ? $_SESSION['user_role'] : 'viewer';
}

function isAdmin() {
    return getUserRole() === 'admin';
}

function isModerator() {
    return in_array(getUserRole(), ['admin', 'moderator', 'rekruter']);
}

function isViewer() {
    return getUserRole() === 'viewer';
}

function isRecruiter() {
    return getUserRole() === 'rekruter';
}

function canDelete() {
    return in_array(getUserRole(), ['admin', 'moderator', 'rekruter']);
}

function canManageUsers() {
    return isAdmin();
}

function canViewHistory() {
    return isAdmin();
}

function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: index.php?msg=noperm');
        exit;
    }
}

function requireModerator() {
    requireLogin();
    if (!isModerator()) {
        header('Location: index.php?msg=noperm');
        exit;
    }
}

function getCurrentUser() {
    if (!isset($_SESSION['user_id'])) return null;
    return [
        'id' => $_SESSION['user_id'],
        'login' => $_SESSION['user_login'],
        'name' => $_SESSION['user_name'],
        'role' => $_SESSION['user_role'] ?? 'viewer'
    ];
}

function getRoleName($role) {
    $roles = [
        'admin' => 'Administrator',
        'moderator' => 'Moderator',
        'rekruter' => 'Rekruter',
        'viewer' => 'Podgląd'
    ];
    return $roles[$role] ?? 'Nieznana';
}

// === HISTORIA ZMIAN ===
function logChange($db, $akcja, $tabela, $rekordId, $opis, $stareDane = null, $noweDane = null) {
    $user = getCurrentUser();
    $stmt = $db->prepare("INSERT INTO historia_zmian 
        (user_id, user_name, akcja, tabela, rekord_id, opis, stare_dane, nowe_dane, ip_address) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $user ? $user['id'] : null,
        $user ? $user['name'] : 'System',
        $akcja,
        $tabela,
        $rekordId,
        $opis,
        $stareDane ? json_encode($stareDane, JSON_UNESCAPED_UNICODE) : null,
        $noweDane ? json_encode($noweDane, JSON_UNESCAPED_UNICODE) : null,
        $_SERVER['REMOTE_ADDR'] ?? null
    ]);
}

// === BACKUP BAZY ===
function createBackup() {
    if (!file_exists(DB_PATH)) return false;
    
    if (!is_dir(BACKUP_DIR)) {
        mkdir(BACKUP_DIR, 0755, true);
    }
    
    $backupFile = BACKUP_DIR . 'backup_' . date('Y-m-d_H-i-s') . '.db';
    return copy(DB_PATH, $backupFile);
}

function getBackups() {
    if (!is_dir(BACKUP_DIR)) return [];
    
    $files = glob(BACKUP_DIR . 'backup_*.db');
    $backups = [];
    foreach ($files as $file) {
        $backups[] = [
            'file' => basename($file),
            'path' => $file,
            'size' => filesize($file),
            'date' => filemtime($file)
        ];
    }
    usort($backups, function($a, $b) { return $b['date'] - $a['date']; });
    return $backups;
}

// === INICJALIZACJA BAZY ===
function initDatabase() {
    $db = getDB();
    
    // Tabela użytkowników z rolami
    $db->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        login VARCHAR(50) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(100) NOT NULL,
        role VARCHAR(20) DEFAULT 'viewer',
        active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_login DATETIME
    )");
    
    // Migracja: dodaj kolumnę role jeśli nie istnieje
    try {
        $db->exec("ALTER TABLE users ADD COLUMN role VARCHAR(20) DEFAULT 'viewer'");
    } catch (PDOException $e) {}
    
    // WAŻNE: Aktualizuj role na podstawie is_admin dla wszystkich użytkowników
    try {
        // Najpierw sprawdź czy kolumna is_admin istnieje
        $result = $db->query("PRAGMA table_info(users)");
        $columns = $result->fetchAll(PDO::FETCH_COLUMN, 1);
        if (in_array('is_admin', $columns)) {
            $db->exec("UPDATE users SET role = 'admin' WHERE is_admin = 1");
            $db->exec("UPDATE users SET role = 'viewer' WHERE (is_admin = 0 OR is_admin IS NULL) AND (role IS NULL OR role = '')");
        }
    } catch (PDOException $e) {}
    
    // Upewnij się że rafal ma rolę admin
    $db->exec("UPDATE users SET role = 'admin' WHERE login = 'rafal'");
    
    // Domyślny admin - rafal / WorkLand2024!
    $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE login = 'rafal'");
    $stmt->execute();
    if ($stmt->fetchColumn() == 0) {
        $hash = password_hash('WorkLand2024!', PASSWORD_DEFAULT);
        $db->prepare("INSERT INTO users (login, password, name, role) VALUES ('rafal', ?, 'Rafał - Administrator', 'admin')")->execute([$hash]);
    } else {
        // Upewnij się że rafal ma rolę admin
        $db->exec("UPDATE users SET role = 'admin' WHERE login = 'rafal'");
    }
    
    // Tabela historii zmian
    $db->exec("CREATE TABLE IF NOT EXISTS historia_zmian (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        user_name VARCHAR(100),
        akcja VARCHAR(50),
        tabela VARCHAR(50),
        rekord_id INTEGER,
        opis TEXT,
        stare_dane TEXT,
        nowe_dane TEXT,
        ip_address VARCHAR(45),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Tabela pracowników
    $db->exec("CREATE TABLE IF NOT EXISTS pracownicy (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kod VARCHAR(50) UNIQUE,
        imie VARCHAR(100),
        nazwisko VARCHAR(100),
        narodowosc VARCHAR(100),
        dane_personalne TEXT,
        dokument_tozsamosci VARCHAR(100),
        data_urodzenia DATE,
        pesel VARCHAR(11),
        nip VARCHAR(13),
        
        data_przyjecia DATE,
        data_zwolnienia DATE,
        okres_zatrudnienia_od DATE,
        okres_zatrudnienia_do DATE,
        
        zezwolenie_do DATE,
        stawka_wynagrodzenia DECIMAL(10,2),
        skladki TEXT,
        forma_umowy VARCHAR(100),
        wymiar_czasu_pracy VARCHAR(50),
        typ_zleceniobiorcy VARCHAR(50) DEFAULT 'standardowy',
        koszty_typ VARCHAR(20) DEFAULT 'standardowe',
        
        grupa_inwalidzka VARCHAR(50),
        stanowisko VARCHAR(200),
        badania_lekarskie DATE,
        szkolenie_bhp DATE,
        data_zakonczenia_pobytu DATE,
        
        telefon VARCHAR(20),
        konto_bankowe VARCHAR(50),
        adres TEXT,
        uwagi TEXT,
        
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Migracja: dodaj kolumny typ_zleceniobiorcy i koszty_typ jeśli nie istnieją
    try {
        $db->exec("ALTER TABLE pracownicy ADD COLUMN typ_zleceniobiorcy VARCHAR(50) DEFAULT 'standardowy'");
    } catch (PDOException $e) {}
    try {
        $db->exec("ALTER TABLE pracownicy ADD COLUMN koszty_typ VARCHAR(20) DEFAULT 'standardowe'");
    } catch (PDOException $e) {}
    
    // Tabela urlopów
    $db->exec("CREATE TABLE IF NOT EXISTS urlopy (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pracownik_id INTEGER NOT NULL,
        typ VARCHAR(100) DEFAULT 'bezpłatny',
        data_od DATE,
        data_do DATE,
        uwagi TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pracownik_id) REFERENCES pracownicy(id) ON DELETE CASCADE
    )");
    
    // Tabela klientów (firmy do których oddelegowani są pracownicy)
    $db->exec("CREATE TABLE IF NOT EXISTS klienci (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nazwa VARCHAR(200) NOT NULL,
        adres TEXT,
        telefon VARCHAR(50),
        email VARCHAR(100),
        osoba_kontaktowa VARCHAR(100),
        uwagi TEXT,
        active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Tabela oddelegowań (pracownik -> klient)
    $db->exec("CREATE TABLE IF NOT EXISTS oddelegowania (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pracownik_id INTEGER NOT NULL,
        klient_id INTEGER NOT NULL,
        data_od DATE,
        data_do DATE,
        stanowisko VARCHAR(200),
        uwagi TEXT,
        active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pracownik_id) REFERENCES pracownicy(id) ON DELETE CASCADE,
        FOREIGN KEY (klient_id) REFERENCES klienci(id) ON DELETE CASCADE
    )");
    
    // Tabela plików pracownika
    $db->exec("CREATE TABLE IF NOT EXISTS pliki_pracownika (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pracownik_id INTEGER NOT NULL,
        nazwa VARCHAR(200),
        typ VARCHAR(100),
        nazwa_pliku VARCHAR(255),
        rozmiar INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pracownik_id) REFERENCES pracownicy(id) ON DELETE CASCADE
    )");
    
    // Tabela historii stawek wynagrodzenia
    $db->exec("CREATE TABLE IF NOT EXISTS historia_stawek (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pracownik_id INTEGER NOT NULL,
        miesiac INTEGER NOT NULL,
        rok INTEGER NOT NULL,
        stawka DECIMAL(10,2) NOT NULL,
        uwagi VARCHAR(255),
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (pracownik_id) REFERENCES pracownicy(id) ON DELETE CASCADE,
        UNIQUE(pracownik_id, miesiac, rok)
    )");
    
    // Tabela rozliczeń miesięcznych (składki/rachunki)
    $db->exec("CREATE TABLE IF NOT EXISTS rozliczenia_miesieczne (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        pracownik_id INTEGER NOT NULL,
        miesiac INTEGER NOT NULL,
        rok INTEGER NOT NULL,
        
        -- Tryb obliczenia
        tryb VARCHAR(20) DEFAULT 'kwota',  -- 'kwota' lub 'stawka_godziny'
        stawka_godzinowa DECIMAL(10,2),
        liczba_godzin DECIMAL(10,2),
        
        -- Kwoty
        kwota_brutto DECIMAL(10,2) NOT NULL,
        kwota_netto DECIMAL(10,2),
        typ_kwoty VARCHAR(10) DEFAULT 'brutto',  -- 'brutto' lub 'netto'
        
        -- Typ zleceniobiorcy i parametry
        typ_zleceniobiorcy VARCHAR(50) DEFAULT 'standardowy',
        koszty_typ VARCHAR(20) DEFAULT 'standardowe',  -- 'standardowe' lub 'autorskie'
        z_chorobowym INTEGER DEFAULT 1,
        
        -- Szczegóły rachunku
        nr_rachunku VARCHAR(50),
        data_rachunku DATE,
        
        -- Obliczone wartości (cache)
        emerytalne DECIMAL(10,2) DEFAULT 0,
        rentowe DECIMAL(10,2) DEFAULT 0,
        chorobowe DECIMAL(10,2) DEFAULT 0,
        zdrowotna DECIMAL(10,2) DEFAULT 0,
        podatek DECIMAL(10,2) DEFAULT 0,
        koszty_uzyskania DECIMAL(10,2) DEFAULT 0,
        
        uwagi TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        
        FOREIGN KEY (pracownik_id) REFERENCES pracownicy(id) ON DELETE CASCADE,
        FOREIGN KEY (created_by) REFERENCES users(id),
        UNIQUE(pracownik_id, miesiac, rok)
    )");
    
    // === CRM - POTENCJALNI KLIENCI (LEADY) ===
    $db->exec("CREATE TABLE IF NOT EXISTS crm_klienci (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nazwa VARCHAR(255) NOT NULL,
        nip VARCHAR(20),
        regon VARCHAR(20),
        adres VARCHAR(255),
        kod_pocztowy VARCHAR(10),
        miasto VARCHAR(100),
        wojewodztwo VARCHAR(50),
        telefon VARCHAR(50),
        email VARCHAR(100),
        www VARCHAR(255),
        branza VARCHAR(100),
        ilosc_pracownikow VARCHAR(50),
        zrodlo_pozyskania VARCHAR(100),
        status VARCHAR(50) DEFAULT 'nowy',
        priorytet VARCHAR(20) DEFAULT 'normalny',
        uwagi TEXT,
        przypisany_do INTEGER,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (przypisany_do) REFERENCES users(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    
    // === CRM - OSOBY KONTAKTOWE ===
    $db->exec("CREATE TABLE IF NOT EXISTS crm_osoby (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        klient_id INTEGER NOT NULL,
        imie VARCHAR(100),
        nazwisko VARCHAR(100),
        stanowisko VARCHAR(100),
        telefon VARCHAR(50),
        email VARCHAR(100),
        linkedin_url VARCHAR(255),
        glowny_kontakt INTEGER DEFAULT 0,
        uwagi TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (klient_id) REFERENCES crm_klienci(id) ON DELETE CASCADE
    )");
    
    // === CRM - ZADANIA ===
    $db->exec("CREATE TABLE IF NOT EXISTS crm_zadania (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        klient_id INTEGER NOT NULL,
        tytul VARCHAR(255) NOT NULL,
        opis TEXT,
        typ VARCHAR(50) DEFAULT 'zadanie',
        priorytet VARCHAR(20) DEFAULT 'normalny',
        status VARCHAR(50) DEFAULT 'nowe',
        przypisany_do INTEGER,
        termin_data DATE,
        termin_godzina TIME,
        przypomnienie INTEGER DEFAULT 0,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        completed_at DATETIME,
        FOREIGN KEY (klient_id) REFERENCES crm_klienci(id) ON DELETE CASCADE,
        FOREIGN KEY (przypisany_do) REFERENCES users(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    
    // === CRM - PLIKI ===
    $db->exec("CREATE TABLE IF NOT EXISTS crm_pliki (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        klient_id INTEGER NOT NULL,
        nazwa_oryginalna VARCHAR(255),
        nazwa_pliku VARCHAR(255),
        rozmiar INTEGER,
        typ_mime VARCHAR(100),
        opis VARCHAR(255),
        uploaded_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (klient_id) REFERENCES crm_klienci(id) ON DELETE CASCADE,
        FOREIGN KEY (uploaded_by) REFERENCES users(id)
    )");
    
    // Migracja - dodaj kolumnę polecenie_od_kogo do crm_klienci
    try {
        $db->exec("ALTER TABLE crm_klienci ADD COLUMN polecenie_od_kogo VARCHAR(255)");
    } catch (PDOException $e) {}
    
    // === INDEKSY CRM ===
    $db->exec("CREATE INDEX IF NOT EXISTS idx_crm_klienci_status ON crm_klienci(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_crm_klienci_przypisany ON crm_klienci(przypisany_do)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_crm_zadania_status ON crm_zadania(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_crm_zadania_termin ON crm_zadania(termin_data)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_crm_zadania_przypisany ON crm_zadania(przypisany_do)");
    
    // Migracja - dodaj kolumnę skladki_typ (netto/brutto)
    try {
        $db->exec("ALTER TABLE pracownicy ADD COLUMN skladki_typ VARCHAR(10) DEFAULT 'brutto'");
    } catch (PDOException $e) {}
    
    // Migracja - dodaj nowe kolumny do pracownicy
    $newColumns = [
        'telefon' => 'VARCHAR(20)',
        'email' => 'VARCHAR(150)',
        'prawo_jazdy' => 'VARCHAR(100)',
        'wozek_widlowy' => 'INTEGER DEFAULT 0',
        'wysoki_sklad' => 'INTEGER DEFAULT 0',
        'notatki' => 'TEXT'
    ];
    
    foreach ($newColumns as $col => $type) {
        try {
            $db->exec("ALTER TABLE pracownicy ADD COLUMN {$col} {$type}");
        } catch (PDOException $e) {}
    }
    
    // Migracja - dodaj pola dokumentu tożsamości
    try {
        $db->exec("ALTER TABLE pracownicy ADD COLUMN dokument_typ VARCHAR(50) DEFAULT 'dowód osobisty'");
    } catch (PDOException $e) {}
    try {
        $db->exec("ALTER TABLE pracownicy ADD COLUMN dokument_numer VARCHAR(50)");
    } catch (PDOException $e) {}
    
    // === MIGRACJA: GUID dla firm i osób ===
    // GUID dla crm_klienci - unikalny identyfikator firmy
    try {
        $db->exec("ALTER TABLE crm_klienci ADD COLUMN guid VARCHAR(36)");
        // Generuj GUID dla istniejących rekordów
        $stmt = $db->query("SELECT id FROM crm_klienci WHERE guid IS NULL");
        $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($ids as $id) {
            $guid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                mt_rand(0, 0xffff),
                mt_rand(0, 0x0fff) | 0x4000,
                mt_rand(0, 0x3fff) | 0x8000,
                mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
            );
            $db->prepare("UPDATE crm_klienci SET guid = ? WHERE id = ?")->execute([$guid, $id]);
        }
    } catch (PDOException $e) {}
    
    // GUID dla crm_osoby - unikalny identyfikator osoby
    try {
        $db->exec("ALTER TABLE crm_osoby ADD COLUMN guid VARCHAR(36)");
        // Generuj GUID dla istniejących rekordów
        $stmt = $db->query("SELECT id FROM crm_osoby WHERE guid IS NULL");
        $ids = $stmt->fetchAll(PDO::FETCH_COLUMN);
        foreach ($ids as $id) {
            $guid = sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
                mt_rand(0, 0xffff), mt_rand(0, 0xffff),
                mt_rand(0, 0xffff),
                mt_rand(0, 0x0fff) | 0x4000,
                mt_rand(0, 0x3fff) | 0x8000,
                mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
            );
            $db->prepare("UPDATE crm_osoby SET guid = ? WHERE id = ?")->execute([$guid, $id]);
        }
    } catch (PDOException $e) {}
    
    // Pole oznaczające anonimizację danych osoby (A*** K*** vs Adam Kowalski)
    try {
        $db->exec("ALTER TABLE crm_osoby ADD COLUMN dane_zanonimizowane INTEGER DEFAULT 0");
    } catch (PDOException $e) {}
    
    // Indeksy dla GUID
    try {
        $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_crm_klienci_guid ON crm_klienci(guid)");
        $db->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_crm_osoby_guid ON crm_osoby(guid)");
    } catch (PDOException $e) {}
    
    // === MODUŁ KANDYDATÓW ===
    $db->exec("CREATE TABLE IF NOT EXISTS kandydaci (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guid VARCHAR(36) UNIQUE,
        imie VARCHAR(100),
        nazwisko VARCHAR(100),
        email VARCHAR(150),
        telefon VARCHAR(50),
        data_urodzenia DATE,
        miejscowosc VARCHAR(150),
        prawo_jazdy VARCHAR(100),
        wozki_widlowe INTEGER DEFAULT 0,
        status VARCHAR(50) DEFAULT 'nowy',
        notatki TEXT,
        cv_filename VARCHAR(255),
        cv_original_name VARCHAR(255),
        cv_text TEXT,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    
    // Historia zmian kandydatów
    $db->exec("CREATE TABLE IF NOT EXISTS kandydaci_historia (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kandydat_id INTEGER NOT NULL,
        user_id INTEGER,
        user_name VARCHAR(100),
        pole VARCHAR(100),
        stara_wartosc TEXT,
        nowa_wartosc TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (kandydat_id) REFERENCES kandydaci(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )");
    
    // Zadania/kontakty z kandydatami (task manager rekrutera)
    $db->exec("CREATE TABLE IF NOT EXISTS kandydaci_zadania (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kandydat_id INTEGER NOT NULL,
        typ VARCHAR(50) DEFAULT 'telefon',
        tytul VARCHAR(255) NOT NULL,
        opis TEXT,
        termin_data DATE,
        termin_godzina TIME,
        priorytet VARCHAR(20) DEFAULT 'normalny',
        status VARCHAR(20) DEFAULT 'zaplanowane',
        wynik TEXT,
        przypisany_do INTEGER,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        completed_at DATETIME,
        FOREIGN KEY (kandydat_id) REFERENCES kandydaci(id) ON DELETE CASCADE,
        FOREIGN KEY (przypisany_do) REFERENCES users(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    
    // Indeksy dla zadań kandydatów
    $db->exec("CREATE INDEX IF NOT EXISTS idx_kandydaci_zadania_kandydat ON kandydaci_zadania(kandydat_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_kandydaci_zadania_termin ON kandydaci_zadania(termin_data)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_kandydaci_zadania_przypisany ON kandydaci_zadania(przypisany_do)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_kandydaci_zadania_status ON kandydaci_zadania(status)");
    
    // Indeksy kandydatów
    $db->exec("CREATE INDEX IF NOT EXISTS idx_kandydaci_status ON kandydaci(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_kandydaci_guid ON kandydaci(guid)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_kandydaci_historia_kandydat ON kandydaci_historia(kandydat_id)");
    
    // === OGŁOSZENIA REKRUTACYJNE ===
    $db->exec("CREATE TABLE IF NOT EXISTS ogloszenia (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tytul VARCHAR(255) NOT NULL,
        stanowisko VARCHAR(150),
        lokalizacja VARCHAR(150),
        opis TEXT,
        wymagania TEXT,
        oferujemy TEXT,
        wynagrodzenie_od DECIMAL(10,2),
        wynagrodzenie_do DECIMAL(10,2),
        typ_umowy VARCHAR(50),
        wymiar_pracy VARCHAR(50),
        status VARCHAR(20) DEFAULT 'aktywne',
        data_publikacji DATE,
        data_waznosci DATE,
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    
    $db->exec("CREATE INDEX IF NOT EXISTS idx_ogloszenia_status ON ogloszenia(status)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_ogloszenia_data_waznosci ON ogloszenia(data_waznosci)");
    
    // Migracja: dodaj kolumnę ogloszenie_id do kandydatów
    try {
        $db->exec("ALTER TABLE kandydaci ADD COLUMN ogloszenie_id INTEGER REFERENCES ogloszenia(id)");
    } catch (PDOException $e) {}
    
    // Migracja: dodaj kolumnę przepisane_z do zadań kandydatów
    try {
        $db->exec("ALTER TABLE kandydaci_zadania ADD COLUMN przepisane_z INTEGER REFERENCES kandydaci_zadania(id)");
    } catch (PDOException $e) {}
    
    // Migracja: dodaj kolumnę przepisane_do do zadań kandydatów (kto przejął)
    try {
        $db->exec("ALTER TABLE kandydaci_zadania ADD COLUMN przepisane_do INTEGER REFERENCES users(id)");
    } catch (PDOException $e) {}
    
    // Inicjalizuj tabele delegacji
    initDelegacjeTable($db);
    
    return $db;
}

// === FUNKCJE POMOCNICZE ===
function generateGuid() {
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),
        mt_rand(0, 0xffff),
        mt_rand(0, 0x0fff) | 0x4000,
        mt_rand(0, 0x3fff) | 0x8000,
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

function generateKod($db) {
    $year = date('Y');
    $stmt = $db->query("SELECT MAX(CAST(SUBSTR(kod, 7) AS INTEGER)) as max_num FROM pracownicy WHERE kod LIKE 'WL{$year}%'");
    $result = $stmt->fetch();
    $nextNum = ($result['max_num'] ?? 0) + 1;
    return sprintf("WL%s%04d", $year, $nextNum);
}

function sanitize($input) {
    if (is_array($input)) {
        return array_map('sanitize', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function formatDate($date) {
    if (empty($date)) return '-';
    return date('d.m.Y', strtotime($date));
}

function formatMoney($amount) {
    if (empty($amount)) return '-';
    return number_format($amount, 2, ',', ' ') . ' zł';
}

function getUrlopyPracownika($db, $pracownikId) {
    $stmt = $db->prepare("SELECT * FROM urlopy WHERE pracownik_id = ? ORDER BY data_od DESC");
    $stmt->execute([$pracownikId]);
    return $stmt->fetchAll();
}

function addUrlop($db, $pracownikId, $typ, $dataOd, $dataDo, $uwagi = '') {
    $stmt = $db->prepare("INSERT INTO urlopy (pracownik_id, typ, data_od, data_do, uwagi) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$pracownikId, $typ, $dataOd ?: null, $dataDo ?: null, $uwagi]);
}

function deleteUrlop($db, $urlopId) {
    $stmt = $db->prepare("DELETE FROM urlopy WHERE id = ?");
    return $stmt->execute([$urlopId]);
}

// === FUNKCJE CRM ===
function getCrmStatusy() {
    return [
        'nowy' => ['label' => 'Nowy lead', 'color' => '#0891b2', 'bg' => '#e0f2fe'],
        'kontakt' => ['label' => 'W kontakcie', 'color' => '#2563eb', 'bg' => '#dbeafe'],
        'negocjacje' => ['label' => 'Negocjacje', 'color' => '#d97706', 'bg' => '#fef3c7'],
        'oferta' => ['label' => 'Wysłano ofertę', 'color' => '#7c3aed', 'bg' => '#ede9fe'],
        'wygrana' => ['label' => 'Wygrana', 'color' => '#16a34a', 'bg' => '#dcfce7'],
        'przegrana' => ['label' => 'Przegrana', 'color' => '#dc2626', 'bg' => '#fee2e2'],
        'odlozony' => ['label' => 'Odłożony', 'color' => '#64748b', 'bg' => '#f1f5f9']
    ];
}

function getCrmPriorytety() {
    return [
        'niski' => ['label' => 'Niski', 'color' => '#64748b', 'bg' => '#f1f5f9'],
        'normalny' => ['label' => 'Normalny', 'color' => '#0891b2', 'bg' => '#e0f2fe'],
        'wysoki' => ['label' => 'Wysoki', 'color' => '#d97706', 'bg' => '#fef3c7'],
        'pilny' => ['label' => 'Pilny', 'color' => '#dc2626', 'bg' => '#fee2e2']
    ];
}

function getCrmTypyZadan() {
    return [
        'zadanie' => 'Zadanie',
        'telefon' => 'Telefon',
        'email' => 'E-mail',
        'spotkanie' => 'Spotkanie',
        'oferta' => 'Przygotowanie oferty',
        'inne' => 'Inne'
    ];
}

function getCrmStatusyZadan() {
    return [
        'nowe' => ['label' => 'Nowe', 'color' => '#0891b2', 'bg' => '#e0f2fe'],
        'w_trakcie' => ['label' => 'W trakcie', 'color' => '#d97706', 'bg' => '#fef3c7'],
        'zakonczone' => ['label' => 'Zakończone', 'color' => '#16a34a', 'bg' => '#dcfce7'],
        'anulowane' => ['label' => 'Anulowane', 'color' => '#64748b', 'bg' => '#f1f5f9']
    ];
}

// === FUNKCJE KANDYDATÓW ===
function getKandydatStatusy() {
    return [
        'nowy' => ['label' => 'Nowy', 'color' => '#0891b2', 'bg' => '#e0f2fe', 'icon' => '📥'],
        'w_kontakcie' => ['label' => 'W kontakcie', 'color' => '#2563eb', 'bg' => '#dbeafe', 'icon' => '📞'],
        'rozmowa' => ['label' => 'Rozmowa kwalifikacyjna', 'color' => '#7c3aed', 'bg' => '#ede9fe', 'icon' => '🗣️'],
        'oferta' => ['label' => 'Oferta pracy', 'color' => '#d97706', 'bg' => '#fef3c7', 'icon' => '📋'],
        'zatrudniony' => ['label' => 'Zatrudniony', 'color' => '#16a34a', 'bg' => '#dcfce7', 'icon' => '✅'],
        'odrzucony' => ['label' => 'Odrzucony', 'color' => '#dc2626', 'bg' => '#fee2e2', 'icon' => '❌'],
        'rezerwa' => ['label' => 'Rezerwa', 'color' => '#64748b', 'bg' => '#f1f5f9', 'icon' => '📁']
    ];
}

function getKategorieJazdy() {
    return ['AM', 'A1', 'A2', 'A', 'B1', 'B', 'C1', 'C', 'D1', 'D', 'BE', 'C1E', 'CE', 'D1E', 'DE', 'T'];
}

function logKandydatChange($db, $kandydatId, $pole, $staraWartosc, $nowaWartosc) {
    if ($staraWartosc === $nowaWartosc) return;
    
    $user = getCurrentUser();
    $stmt = $db->prepare("INSERT INTO kandydaci_historia 
        (kandydat_id, user_id, user_name, pole, stara_wartosc, nowa_wartosc) 
        VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $kandydatId,
        $user ? $user['id'] : null,
        $user ? $user['name'] : 'System',
        $pole,
        $staraWartosc,
        $nowaWartosc
    ]);
}

// === FUNKCJE ZADAŃ KANDYDATÓW ===
function getKandydatZadaniaTypy() {
    return [
        'telefon' => ['label' => 'Telefon', 'icon' => '📞', 'color' => '#2563eb'],
        'email' => ['label' => 'Email', 'icon' => '✉️', 'color' => '#7c3aed'],
        'spotkanie' => ['label' => 'Spotkanie', 'icon' => '🤝', 'color' => '#059669'],
        'rozmowa' => ['label' => 'Rozmowa kwalifikacyjna', 'icon' => '🗣️', 'color' => '#d97706'],
        'inne' => ['label' => 'Inne', 'icon' => '📋', 'color' => '#64748b']
    ];
}

function getKandydatZadaniaStatusy() {
    return [
        'zaplanowane' => ['label' => 'Zaplanowane', 'color' => '#2563eb', 'bg' => '#dbeafe', 'icon' => '📅'],
        'wykonane' => ['label' => 'Wykonane', 'color' => '#16a34a', 'bg' => '#dcfce7', 'icon' => '✅'],
        'nieodbiera' => ['label' => 'Nie odbiera', 'color' => '#d97706', 'bg' => '#fef3c7', 'icon' => '📵'],
        'oddzwoni' => ['label' => 'Oddzwoni', 'color' => '#7c3aed', 'bg' => '#ede9fe', 'icon' => '🔄'],
        'przepisane' => ['label' => 'Przepisane', 'color' => '#0891b2', 'bg' => '#e0f2fe', 'icon' => '↪️'],
        'anulowane' => ['label' => 'Anulowane', 'color' => '#dc2626', 'bg' => '#fee2e2', 'icon' => '❌']
    ];
}

// === FUNKCJE OGŁOSZEŃ ===
function getOgloszeniaStatusy() {
    return [
        'aktywne' => ['label' => 'Aktywne', 'color' => '#16a34a', 'bg' => '#dcfce7', 'icon' => '✅'],
        'wstrzymane' => ['label' => 'Wstrzymane', 'color' => '#d97706', 'bg' => '#fef3c7', 'icon' => '⏸️'],
        'zakonczone' => ['label' => 'Zakończone', 'color' => '#64748b', 'bg' => '#f1f5f9', 'icon' => '🏁'],
        'archiwalne' => ['label' => 'Archiwalne', 'color' => '#94a3b8', 'bg' => '#f1f5f9', 'icon' => '📦']
    ];
}

function getTypyUmowy() {
    return [
        'umowa_o_prace' => 'Umowa o pracę',
        'b2b' => 'B2B',
        'zlecenie' => 'Umowa zlecenie',
        'dzielo' => 'Umowa o dzieło',
        'staz' => 'Staż/Praktyka',
        'tymczasowa' => 'Praca tymczasowa'
    ];
}

function getWymiaryPracy() {
    return [
        'pelny' => 'Pełny etat',
        'pol' => '1/2 etatu',
        'czwierc' => '1/4 etatu',
        'elastyczny' => 'Elastyczny',
        'projekt' => 'Projektowy'
    ];
}

function getKandydatZadaniaPriorytety() {
    return [
        'niski' => ['label' => 'Niski', 'color' => '#16a34a', 'bg' => '#dcfce7'],
        'normalny' => ['label' => 'Normalny', 'color' => '#2563eb', 'bg' => '#dbeafe'],
        'wysoki' => ['label' => 'Wysoki', 'color' => '#d97706', 'bg' => '#fef3c7'],
        'pilny' => ['label' => 'Pilny', 'color' => '#dc2626', 'bg' => '#fee2e2']
    ];
}

// === TABELE DELEGACJI ===
function initDelegacjeTable($db) {
    // Lokalizacje z kilometrami
    $db->exec("CREATE TABLE IF NOT EXISTS delegacje_lokalizacje (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nazwa VARCHAR(100) NOT NULL UNIQUE,
        kilometry INTEGER NOT NULL DEFAULT 0,
        active INTEGER DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Wstaw domyślne lokalizacje jeśli tabela pusta
    $count = $db->query("SELECT COUNT(*) FROM delegacje_lokalizacje")->fetchColumn();
    if ($count == 0) {
        $db->exec("INSERT INTO delegacje_lokalizacje (nazwa, kilometry) VALUES 
            ('Czeladź', 410),
            ('Gdańsk', 320),
            ('Nysa', 264),
            ('Rzeszów', 620),
            ('Warszawa', 320)
        ");
    }
    
    // Główna tabela delegacji
    $db->exec("CREATE TABLE IF NOT EXISTS delegacje (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nr_delegacji VARCHAR(20) NOT NULL,
        pracownik_id INTEGER NOT NULL,
        miesiac INTEGER NOT NULL,
        rok INTEGER NOT NULL,
        lokalizacja_id INTEGER NOT NULL,
        cel_wyjazdu TEXT,
        transport_samochod INTEGER DEFAULT 1,
        data_zlecenia DATE,
        
        typ_delegacji VARCHAR(20) DEFAULT 'krajowa',
        kurs_eur DECIMAL(10,4) DEFAULT NULL,
        
        dieta_kraj VARCHAR(50) DEFAULT 'Polska',
        dieta_stawka DECIMAL(10,2) DEFAULT 45.00,
        
        stawka_km DECIMAL(10,2) DEFAULT 1.15,
        noclegi_stawka DECIMAL(10,2) DEFAULT 67.50,
        inne_wydatki DECIMAL(10,2) DEFAULT 0,
        zaliczka DECIMAL(10,2) DEFAULT 0,
        
        status VARCHAR(20) DEFAULT 'draft',
        created_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        
        FOREIGN KEY (pracownik_id) REFERENCES pracownicy(id),
        FOREIGN KEY (lokalizacja_id) REFERENCES delegacje_lokalizacje(id),
        FOREIGN KEY (created_by) REFERENCES users(id)
    )");
    
    // Migracja - dodaj kolumny jeśli nie istnieją
    try {
        $db->exec("ALTER TABLE delegacje ADD COLUMN typ_delegacji VARCHAR(20) DEFAULT 'krajowa'");
    } catch (Exception $e) {}
    try {
        $db->exec("ALTER TABLE delegacje ADD COLUMN kurs_eur DECIMAL(10,4) DEFAULT NULL");
    } catch (Exception $e) {}
    
    // Zakresy dat delegacji (może być wiele zakresów)
    $db->exec("CREATE TABLE IF NOT EXISTS delegacje_zakresy (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        delegacja_id INTEGER NOT NULL,
        data_od DATE NOT NULL,
        data_do DATE NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (delegacja_id) REFERENCES delegacje(id) ON DELETE CASCADE
    )");
    
    // Indeksy
    $db->exec("CREATE INDEX IF NOT EXISTS idx_delegacje_pracownik ON delegacje(pracownik_id)");
    $db->exec("CREATE INDEX IF NOT EXISTS idx_delegacje_rok_miesiac ON delegacje(rok, miesiac)");
}

// Funkcje pomocnicze delegacji
function getLokalizacjeDelegacji($db) {
    return $db->query("SELECT * FROM delegacje_lokalizacje WHERE active = 1 ORDER BY nazwa")->fetchAll();
}

function obliczDniDelegacji($zakresy) {
    $sumaDni = 0;
    foreach ($zakresy as $z) {
        $od = new DateTime($z['data_od']);
        $do = new DateTime($z['data_do']);
        $diff = $od->diff($do);
        $sumaDni += $diff->days + 1; // +1 bo liczymy też dzień początkowy
    }
    return $sumaDni;
}

function obliczNoclegi($zakresy) {
    $sumaNoclegów = 0;
    foreach ($zakresy as $z) {
        $od = new DateTime($z['data_od']);
        $do = new DateTime($z['data_do']);
        $diff = $od->diff($do);
        $dni = $diff->days + 1;
        
        // Noclegi = dni - 1 (bo ostatni dzień bez noclegu) - minus weekendy w środku
        // Uproszczenie: noclegi = dni - 1 na każdy tydzień
        $tygodnie = floor($dni / 7);
        $noclegiWZakresie = $dni - 1 - $tygodnie;
        if ($noclegiWZakresie < 0) $noclegiWZakresie = 0;
        
        $sumaNoclegów += $noclegiWZakresie;
    }
    return $sumaNoclegów;
}

function formatujZakresy($zakresy) {
    $wynik = [];
    foreach ($zakresy as $z) {
        $od = (int)date('j', strtotime($z['data_od']));
        $do = (int)date('j', strtotime($z['data_do']));
        if ($od == $do) {
            $wynik[] = $od;
        } else {
            $wynik[] = $od . '-' . $do;
        }
    }
    return implode(', ', $wynik);
}

function getPierwszyDzienRoboczy($rok, $miesiac) {
    $data = new DateTime("$rok-$miesiac-01");
    while ($data->format('N') >= 6) { // 6=sobota, 7=niedziela
        $data->modify('+1 day');
    }
    return $data->format('Y-m-d');
}

/**
 * Pobiera kurs EUR z NBP na dany dzień
 * Jeśli w danym dniu nie ma kursu (weekend/święto), szuka wcześniejszego
 * @param string $data Data w formacie Y-m-d
 * @return array|null [kurs, data_kursu] lub null jeśli nie znaleziono
 */
function pobierzKursEUR($data) {
    $dataObj = new DateTime($data);
    $maxProb = 10; // Maksymalnie cofamy się 10 dni
    
    for ($i = 0; $i < $maxProb; $i++) {
        $dataStr = $dataObj->format('Y-m-d');
        $url = "https://api.nbp.pl/api/exchangerates/rates/a/eur/{$dataStr}/?format=json";
        
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => 'Accept: application/json',
                'timeout' => 5
            ]
        ]);
        
        $response = @file_get_contents($url, false, $context);
        
        if ($response !== false) {
            $json = json_decode($response, true);
            if (isset($json['rates'][0]['mid'])) {
                return [
                    'kurs' => (float)$json['rates'][0]['mid'],
                    'data' => $dataStr
                ];
            }
        }
        
        // Cofnij o jeden dzień
        $dataObj->modify('-1 day');
    }
    
    return null;
}

/**
 * Pobiera kursy EUR dla każdego zakresu dat delegacji
 * @param array $zakresy Tablica zakresów [['od' => 'Y-m-d', 'do' => 'Y-m-d'], ...]
 * @return array Tablica kursów [['data_wyjazdu' => ..., 'kurs' => ..., 'data_kursu' => ...], ...]
 */
function pobierzKursyDlaZakresow($zakresy) {
    $kursy = [];
    
    foreach ($zakresy as $zakres) {
        $dataWyjazdu = $zakres['od'];
        $kursInfo = pobierzKursEUR($dataWyjazdu);
        
        if ($kursInfo) {
            $kursy[] = [
                'data_wyjazdu' => $dataWyjazdu,
                'kurs' => $kursInfo['kurs'],
                'data_kursu' => $kursInfo['data']
            ];
        }
    }
    
    return $kursy;
}

/**
 * Oblicza koszty delegacji zagranicznej z różnymi kursami dla każdego zakresu
 * @param array $zakresy Zakresy dat z bazy
 * @param array $kursy Kursy dla każdego zakresu (JSON z bazy)
 * @return array Szczegóły kosztów
 */
function obliczKosztyZagranicznej($zakresy, $kursy) {
    $szczegoly = [];
    $sumaDieta = 0;
    $sumaNoclegi = 0;
    
    foreach ($zakresy as $i => $zakres) {
        $kurs = isset($kursy[$i]) ? $kursy[$i]['kurs'] : 4.30; // Domyślny kurs
        $dataKursu = isset($kursy[$i]) ? $kursy[$i]['data_kursu'] : null;
        
        // Oblicz dni w zakresie
        $od = new DateTime($zakres['data_od']);
        $do = new DateTime($zakres['data_do']);
        $dni = $od->diff($do)->days + 1;
        
        // Oblicz noclegi (dni - 1)
        $noclegiZakres = max(0, $dni - 1);
        
        // Przelicz na PLN
        $dietaEur = DIETA_EUR * $dni;
        $dietaPln = $dietaEur * $kurs;
        
        $noclegiEur = NOCLEG_EUR * $noclegiZakres;
        $noclegiPln = $noclegiEur * $kurs;
        
        $szczegoly[] = [
            'zakres' => date('d.m', strtotime($zakres['data_od'])) . '-' . date('d.m', strtotime($zakres['data_do'])),
            'dni' => $dni,
            'noclegi' => $noclegiZakres,
            'kurs' => $kurs,
            'data_kursu' => $dataKursu,
            'dieta_eur' => $dietaEur,
            'dieta_pln' => $dietaPln,
            'noclegi_eur' => $noclegiEur,
            'noclegi_pln' => $noclegiPln
        ];
        
        $sumaDieta += $dietaPln;
        $sumaNoclegi += $noclegiPln;
    }
    
    return [
        'szczegoly' => $szczegoly,
        'suma_dieta' => $sumaDieta,
        'suma_noclegi' => $sumaNoclegi
    ];
}

/**
 * Stałe dla delegacji zagranicznych (Niemcy)
 */
define('DIETA_EUR', 49);      // Dieta dzienna w EUR
define('NOCLEG_EUR', 170);    // Ryczałt za nocleg w EUR

// Inicjalizuj bazę i utwórz globalną zmienną $db
initDatabase();
$db = getDB();
?>

