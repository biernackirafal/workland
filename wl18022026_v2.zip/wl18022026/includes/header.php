<?php
require_once __DIR__ . '/db.php';
$db = initDatabase();
requireLogin();

$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $pageTitle ?? 'Work Land' ?> - System CRM</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/lucide-static@0.321.0/font/lucide.min.css">
    <style>
        /* Lucide icons jako font */
        .icon { font-family: 'lucide'; font-size: 1.1em; }
    </style>
</head>
<body>
    <nav class="navbar">
        <a href="/index.php" class="navbar-brand">
            <strong>Work Land</strong> | CRM
        </a>
        
        <ul class="navbar-nav">
            <li><a href="/index.php" class="<?= $currentPage == 'index.php' ? 'active' : '' ?>">📊 Dashboard</a></li>
            <li><a href="/crm/klienci.php" class="<?= strpos($currentPage, 'klient') !== false ? 'active' : '' ?>">🏢 Potencjalni Klienci</a></li>
            <li><a href="/crm/zadania.php" class="<?= $currentPage == 'zadania.php' ? 'active' : '' ?>">✅ Zadania</a></li>
            <li><a href="/crm/kalendarz.php" class="<?= $currentPage == 'kalendarz.php' ? 'active' : '' ?>">📅 Kalendarz</a></li>
            <?php if (isAdmin()): ?>
            <li><a href="/users.php" class="<?= $currentPage == 'users.php' ? 'active' : '' ?>">👥 Użytkownicy</a></li>
            <?php endif; ?>
        </ul>
        
        <div class="navbar-user">
            <span><?= htmlspecialchars($_SESSION['user_name']) ?></span>
            <a href="/logout.php">Wyloguj</a>
        </div>
    </nav>
