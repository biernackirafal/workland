    <script src="/assets/js/app.js"></script>
</body>
</html>
