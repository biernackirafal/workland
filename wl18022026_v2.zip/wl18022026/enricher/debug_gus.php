<?php
/**
 * Debug GUS - szczegółowa diagnostyka wyszukiwania
 */

header('Content-Type: text/html; charset=utf-8');

$gusApiKey = 'b0f0e889eff5497cbea4';
$searchName = $_GET['firma'] ?? 'Talex';

echo "<h1>🔍 Debug GUS - wyszukiwanie '$searchName'</h1><pre>";

// Środowisko PRODUKCYJNE
$baseUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/';

// === LOGOWANIE ===
echo "=== LOGOWANIE ===\n";
$ch = curl_init($baseUrl . 'Zaloguj');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['pKluczUzytkownika' => $gusApiKey]),
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json']
]);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP: $httpCode\n";
echo "Response: $response\n";

$data = json_decode($response, true);
$sid = $data['d'] ?? null;

if (!$sid) {
    echo "❌ Brak SID!\n</pre>";
    exit;
}
echo "✅ SID: $sid\n";

// === TEST RÓŻNYCH FORMATÓW WYSZUKIWANIA ===
$tests = [
    // Format 1: Nazwa jako string
    ['name' => 'Nazwa (string)', 'params' => ['Nazwa' => $searchName]],
    
    // Format 2: Nazwa z wildcards
    ['name' => 'Nazwa z %', 'params' => ['Nazwa' => '%' . $searchName . '%']],
    
    // Format 3: Nazwy (liczba mnoga - może być inna nazwa pola)
    ['name' => 'Nazwy', 'params' => ['Nazwy' => $searchName]],
    
    // Format 4: NazwaFirmy
    ['name' => 'NazwaFirmy', 'params' => ['NazwaFirmy' => $searchName]],
    
    // Format 5: Pełna nazwa ze spółka
    ['name' => 'Pełna nazwa', 'params' => ['Nazwa' => $searchName . ' SPÓŁKA']],
    
    // Format 6: Wielkie litery
    ['name' => 'UPPERCASE', 'params' => ['Nazwa' => mb_strtoupper($searchName)]],
];

foreach ($tests as $i => $test) {
    echo "\n=== TEST " . ($i+1) . ": {$test['name']} ===\n";
    echo "Params: " . json_encode($test['params'], JSON_UNESCAPED_UNICODE) . "\n";
    
    $ch = curl_init($baseUrl . 'daneSzukajPodmioty');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['pParametryWyszukiwania' => $test['params']]),
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'sid: ' . $sid
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "HTTP: $httpCode\n";
    
    $data = json_decode($response, true);
    $result = $data['d'] ?? '';
    
    if (empty($result)) {
        echo "❌ Pusta odpowiedź\n";
    } else if (strpos($result, 'ErrorCode') !== false) {
        echo "⚠️ Błąd: " . htmlspecialchars(substr($result, 0, 300)) . "\n";
    } else if (strpos($result, '<dane>') !== false) {
        echo "✅ ZNALEZIONO!\n";
        echo htmlspecialchars(substr($result, 0, 800)) . "\n";
    } else {
        echo "? Odpowiedź: " . htmlspecialchars(substr($result, 0, 300)) . "\n";
    }
}

// === SPRAWDŹ KOMUNIKAT BŁĘDU ===
echo "\n=== KOMUNIKAT BŁĘDU GUS ===\n";
$ch = curl_init($baseUrl . 'GetValue');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['pNazwaParametru' => 'KomunikatBledu']),
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'sid: ' . $sid]
]);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);
echo "Błąd: " . ($data['d'] ?? 'brak') . "\n";

// === TEST PRZEZ REGON (powinno działać) ===
echo "\n=== TEST PRZEZ REGON (kontrolny) ===\n";
// REGON Talex SA: 630303246
$ch = curl_init($baseUrl . 'daneSzukajPodmioty');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['pParametryWyszukiwania' => ['Regon' => '630303246']]),
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'sid: ' . $sid]
]);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);
$result = $data['d'] ?? '';
echo "Wynik dla REGON 630303246 (Talex):\n";
echo htmlspecialchars(substr($result, 0, 600)) . "\n";

echo "\n</pre>";

echo "<hr><form method='get'>";
echo "<input name='firma' value='" . htmlspecialchars($searchName) . "' style='padding:8px; width:200px;'>";
echo "<button style='padding:8px 15px;'>Szukaj</button>";
echo "</form>";
