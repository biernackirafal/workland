<?php
/**
 * Test GUS BIR1 - SOAP API (wersja 1.0)
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test GUS BIR1 (SOAP)</h1><pre>";

$gusApiKey = 'b0f0e889eff5497cbea4';
$testRegon = '630303246'; // Talex
$testNip = '7820009289'; // Talex

// Adresy SOAP
$wsdl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc?singleWsdl';
$location = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';

echo "=== KONFIGURACJA ===\n";
echo "WSDL: $wsdl\n";
echo "Location: $location\n";
echo "Klucz: " . substr($gusApiKey, 0, 8) . "...\n\n";

try {
    // Utwórz klienta SOAP
    echo "=== TWORZENIE KLIENTA SOAP ===\n";
    
    $options = [
        'soap_version' => SOAP_1_2,
        'trace' => true,
        'exceptions' => true,
        'cache_wsdl' => WSDL_CACHE_NONE,
        'stream_context' => stream_context_create([
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
            ]
        ])
    ];
    
    $client = new SoapClient($wsdl, $options);
    echo "✅ Klient SOAP utworzony\n";
    
    // Lista dostępnych funkcji
    echo "\nDostępne funkcje SOAP:\n";
    $functions = $client->__getFunctions();
    foreach (array_slice($functions, 0, 10) as $f) {
        echo "  - " . substr($f, 0, 80) . "\n";
    }
    
    // === LOGOWANIE ===
    echo "\n=== LOGOWANIE ===\n";
    
    $loginResult = $client->Zaloguj(['pKluczUzytkownika' => $gusApiKey]);
    $sid = $loginResult->ZalogujResult ?? null;
    
    echo "Wynik logowania: ";
    print_r($loginResult);
    
    if (empty($sid)) {
        echo "\n❌ Brak SID - logowanie nie powiodło się\n";
        echo "</pre>";
        exit;
    }
    
    echo "\n✅ SID: $sid\n";
    
    // Ustaw SID w nagłówku
    $header = new SoapHeader(
        'http://CIS/BIR/PUBL/2014/07',
        'sid',
        $sid
    );
    $client->__setSoapHeaders($header);
    
    // === WYSZUKIWANIE PO REGON ===
    echo "\n=== WYSZUKIWANIE PO REGON ($testRegon) ===\n";
    
    $searchParams = new stdClass();
    $searchParams->Regon = $testRegon;
    
    $searchResult = $client->DaneSzukaj(['pParametryWyszukiwania' => $searchParams]);
    
    echo "Wynik wyszukiwania:\n";
    print_r($searchResult);
    
    // === WYSZUKIWANIE PO NIP ===
    echo "\n=== WYSZUKIWANIE PO NIP ($testNip) ===\n";
    
    $searchParams2 = new stdClass();
    $searchParams2->Nip = $testNip;
    
    $searchResult2 = $client->DaneSzukaj(['pParametryWyszukiwania' => $searchParams2]);
    
    echo "Wynik wyszukiwania:\n";
    print_r($searchResult2);
    
    // === WYSZUKIWANIE PO NAZWIE ===
    echo "\n=== WYSZUKIWANIE PO NAZWIE (Talex) ===\n";
    
    $searchParams3 = new stdClass();
    $searchParams3->Nazwa = 'Talex';
    
    $searchResult3 = $client->DaneSzukaj(['pParametryWyszukiwania' => $searchParams3]);
    
    echo "Wynik wyszukiwania:\n";
    print_r($searchResult3);
    
    // Parsuj XML jeśli jest
    $xmlResult = $searchResult3->DaneSzukajResult ?? '';
    if ($xmlResult && strpos($xmlResult, '<') !== false) {
        echo "\nParsowany XML:\n";
        $xml = @simplexml_load_string($xmlResult);
        if ($xml) {
            foreach ($xml->dane as $firma) {
                echo "  Nazwa: " . ($firma->Nazwa ?? 'brak') . "\n";
                echo "  REGON: " . ($firma->Regon ?? 'brak') . "\n";
                echo "  NIP: " . ($firma->Nip ?? 'brak') . "\n";
            }
        }
    }
    
    // === WYLOGOWANIE ===
    echo "\n=== WYLOGOWANIE ===\n";
    $client->Wyloguj(['pIdentyfikatorSesji' => $sid]);
    echo "✅ Wylogowano\n";
    
} catch (SoapFault $e) {
    echo "\n❌ SOAP Error: " . $e->getMessage() . "\n";
    echo "Code: " . $e->getCode() . "\n";
    echo "File: " . $e->getFile() . ":" . $e->getLine() . "\n";
    
    if (isset($client)) {
        echo "\nLast Request:\n" . htmlspecialchars($client->__getLastRequest()) . "\n";
        echo "\nLast Response:\n" . htmlspecialchars($client->__getLastResponse()) . "\n";
    }
} catch (Exception $e) {
    echo "\n❌ Error: " . $e->getMessage() . "\n";
}

echo "\n</pre>";
