<?php
/**
 * CompanyEnricher v4 - GUS BIR + API KRS MS
 * 
 * Strategia:
 * 1. Szukaj w GUS BIR po nazwie → NIP, REGON, KRS, adres, telefon
 * 2. Jeśli firma ma KRS → pobierz zarząd z API KRS MS
 */

class CompanyEnricher
{
    private $gusApiKey;
    private $gusSid = null;
    private $gusBaseUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/';
    private $krsApiUrl = 'https://api-krs.ms.gov.pl/api/krs/OdpisAktualny/';
    
    private $delay = 1;
    private $timeout = 30;
    
    public function __construct(string $gusApiKey)
    {
        $this->gusApiKey = $gusApiKey;
    }
    
    /**
     * Logowanie do GUS BIR
     */
    public function loginGUS(): bool
    {
        $response = $this->postRequest(
            $this->gusBaseUrl . 'Zaloguj',
            json_encode(['pKluczUzytkownika' => $this->gusApiKey])
        );
        
        if ($response) {
            $data = json_decode($response, true);
            $this->gusSid = $data['d'] ?? null;
            return !empty($this->gusSid);
        }
        return false;
    }
    
    /**
     * Wylogowanie z GUS BIR
     */
    public function logoutGUS(): void
    {
        if ($this->gusSid) {
            $this->postRequest(
                $this->gusBaseUrl . 'Wyloguj',
                json_encode(['pIdentyfikatorSesji' => $this->gusSid])
            );
            $this->gusSid = null;
        }
    }
    
    /**
     * Główna metoda wzbogacania danych firmy
     */
    public function enrichCompany(string $companyName, string $legalForm = ''): array
    {
        $result = [
            'nazwa' => $companyName,
            'forma_prawna' => $legalForm,
            'adres' => null,
            'www' => null,
            'email' => null,
            'telefon' => null,
            'faks' => null,
            'nip' => null,
            'regon' => null,
            'krs' => null,
            'zarzad' => null,
            'zrodlo' => null,
            'status' => 'pending',
            'error' => null
        ];
        
        // Upewnij się że jesteśmy zalogowani
        if (!$this->gusSid && !$this->loginGUS()) {
            $result['status'] = 'error';
            $result['error'] = 'Nie można zalogować do GUS';
            return $result;
        }
        
        try {
            // KROK 1: Szukaj w GUS po nazwie
            $gusData = $this->searchGUS($companyName);
            
            if ($gusData) {
                $result['regon'] = $gusData['regon'] ?? null;
                $result['nip'] = $gusData['nip'] ?? null;
                $result['zrodlo'] = 'GUS BIR';
                
                // KROK 2: Pobierz pełny raport z GUS
                if ($result['regon']) {
                    $fullReport = $this->getGUSFullReport($result['regon'], $gusData['typ'] ?? 'P');
                    
                    if ($fullReport) {
                        $result['krs'] = $fullReport['krs'] ?? null;
                        $result['adres'] = $fullReport['adres'] ?? null;
                        $result['telefon'] = $fullReport['telefon'] ?? null;
                        $result['faks'] = $fullReport['faks'] ?? null;
                        $result['email'] = $fullReport['email'] ?? null;
                        $result['www'] = $fullReport['www'] ?? null;
                        
                        // Nadpisz NIP jeśli jest w raporcie
                        if (!empty($fullReport['nip'])) {
                            $result['nip'] = $fullReport['nip'];
                        }
                    }
                }
                
                // KROK 3: Jeśli mamy KRS - pobierz zarząd z API KRS MS
                if (!empty($result['krs'])) {
                    sleep(1); // Pauza przed kolejnym API
                    $krsData = $this->getKRSData($result['krs']);
                    
                    if ($krsData) {
                        $result['zarzad'] = $krsData['zarzad'] ?? null;
                        $result['zrodlo'] = 'GUS BIR + API KRS';
                        
                        // Uzupełnij brakujące dane z KRS
                        if (empty($result['adres']) && !empty($krsData['adres'])) {
                            $result['adres'] = $krsData['adres'];
                        }
                    }
                }
                
                $result['status'] = 'success';
            } else {
                $result['status'] = 'not_found';
                $result['error'] = 'Nie znaleziono w GUS';
            }
            
        } catch (Exception $e) {
            $result['status'] = 'error';
            $result['error'] = $e->getMessage();
        }
        
        return $result;
    }
    
    /**
     * Wyszukiwanie w GUS po nazwie
     */
    private function searchGUS(string $name): ?array
    {
        $searchName = $this->normalizeForSearch($name);
        
        $response = $this->postRequest(
            $this->gusBaseUrl . 'daneSzukajPodmioty',
            json_encode(['pParametryWyszukiwania' => ['Nazwa' => $searchName]]),
            ['sid: ' . $this->gusSid]
        );
        
        if (!$response) return null;
        
        $data = json_decode($response, true);
        $xml = $data['d'] ?? '';
        
        if (empty($xml) || strpos($xml, '<') === false) {
            // Spróbuj z krótszą nazwą
            $shortName = $this->getShortName($searchName);
            if ($shortName !== $searchName) {
                $response = $this->postRequest(
                    $this->gusBaseUrl . 'daneSzukajPodmioty',
                    json_encode(['pParametryWyszukiwania' => ['Nazwa' => $shortName]]),
                    ['sid: ' . $this->gusSid]
                );
                $data = json_decode($response, true);
                $xml = $data['d'] ?? '';
            }
        }
        
        if (empty($xml) || strpos($xml, '<') === false) {
            return null;
        }
        
        $xmlDoc = @simplexml_load_string($xml);
        if (!$xmlDoc || !isset($xmlDoc->dane)) {
            return null;
        }
        
        // Sprawdź czy to błąd
        $errorCode = (string)($xmlDoc->dane->ErrorCode ?? '');
        if ($errorCode && $errorCode !== '0') {
            return null;
        }
        
        // Znajdź najlepsze dopasowanie
        $bestMatch = null;
        $bestScore = 0;
        $searchLower = mb_strtolower($searchName);
        
        foreach ($xmlDoc->dane as $firma) {
            $nazwa = (string)($firma->Nazwa ?? '');
            $nazwaLower = mb_strtolower($nazwa);
            
            // Oblicz podobieństwo
            similar_text($searchLower, $nazwaLower, $score);
            
            if ($score > $bestScore) {
                $bestScore = $score;
                $bestMatch = [
                    'regon' => (string)($firma->Regon ?? ''),
                    'nip' => (string)($firma->Nip ?? ''),
                    'nazwa' => $nazwa,
                    'typ' => (string)($firma->Typ ?? 'P'), // P = prawna, F = fizyczna
                    'silos' => (string)($firma->SilosID ?? '6')
                ];
            }
        }
        
        return $bestMatch;
    }
    
    /**
     * Pobierz pełny raport z GUS
     */
    private function getGUSFullReport(string $regon, string $typ = 'P'): ?array
    {
        // Wybierz odpowiedni raport w zależności od typu podmiotu
        $reportName = ($typ === 'F') ? 'BIR11OsFizycznaDzworzytelna' : 'BIR11OsPrawna';
        
        // Dla 9-znakowego REGON
        if (strlen($regon) <= 9) {
            $regon = str_pad($regon, 9, '0', STR_PAD_LEFT);
        }
        
        $response = $this->postRequest(
            $this->gusBaseUrl . 'DanePobierzPelnyRaport',
            json_encode([
                'pRegon' => $regon,
                'pNazwaRaportu' => $reportName
            ]),
            ['sid: ' . $this->gusSid]
        );
        
        if (!$response) return null;
        
        $data = json_decode($response, true);
        $xml = $data['d'] ?? '';
        
        if (empty($xml) || strpos($xml, '<') === false) {
            return null;
        }
        
        $xmlDoc = @simplexml_load_string($xml);
        if (!$xmlDoc || !isset($xmlDoc->dane)) {
            return null;
        }
        
        $dane = $xmlDoc->dane;
        
        // Parsuj adres
        $ulica = (string)($dane->praw_adSiedzUlica_Nazwa ?? $dane->fiz_adSiedzUlica_Nazwa ?? '');
        $nrDomu = (string)($dane->praw_adSiedzNumerNieruchomosci ?? $dane->fiz_adSiedzNumerNieruchomosci ?? '');
        $nrLokalu = (string)($dane->praw_adSiedzNumerLokalu ?? $dane->fiz_adSiedzNumerLokalu ?? '');
        $kodPocztowy = (string)($dane->praw_adSiedzKodPocztowy ?? $dane->fiz_adSiedzKodPocztowy ?? '');
        $miejscowosc = (string)($dane->praw_adSiedzMiejscowosc_Nazwa ?? $dane->fiz_adSiedzMiejscowosc_Nazwa ?? '');
        
        // Formatuj kod pocztowy
        if (strlen($kodPocztowy) === 5) {
            $kodPocztowy = substr($kodPocztowy, 0, 2) . '-' . substr($kodPocztowy, 2);
        }
        
        $adresParts = array_filter([
            $ulica,
            $nrDomu . ($nrLokalu ? '/' . $nrLokalu : ''),
            $kodPocztowy,
            $miejscowosc
        ]);
        
        return [
            'nip' => (string)($dane->praw_nip ?? $dane->fiz_nip ?? ''),
            'krs' => (string)($dane->praw_numerWRejestrzeEwidencji ?? ''),
            'adres' => implode(', ', $adresParts),
            'telefon' => (string)($dane->praw_numerTelefonu ?? $dane->fiz_numerTelefonu ?? ''),
            'faks' => (string)($dane->praw_numerFaksu ?? $dane->fiz_numerFaksu ?? ''),
            'email' => (string)($dane->praw_adresEmail ?? $dane->fiz_adresEmail ?? ''),
            'www' => (string)($dane->praw_adresStronyinternetowej ?? $dane->fiz_adresStronyinternetowej ?? '')
        ];
    }
    
    /**
     * Pobierz dane z API KRS MS (głównie zarząd)
     */
    private function getKRSData(string $krsNumber): ?array
    {
        $krsNumber = str_pad($krsNumber, 10, '0', STR_PAD_LEFT);
        $url = $this->krsApiUrl . $krsNumber . '?rejestr=P&format=json';
        
        $response = $this->getRequest($url);
        
        if (!$response) return null;
        
        $data = json_decode($response, true);
        if (!$data || !isset($data['odpis'])) return null;
        
        $odpis = $data['odpis'];
        $dane = $odpis['dane'] ?? [];
        $dzial2 = $dane['dzial2'] ?? [];
        
        // Parsuj zarząd
        $zarzad = [];
        $reprezentacja = $dzial2['reprezentacja'] ?? [];
        $sklad = $reprezentacja['sklad'] ?? [];
        
        if (is_array($sklad)) {
            foreach ($sklad as $osoba) {
                $imiona = $osoba['imiona'] ?? '';
                $nazwisko = $osoba['nazwisko'] ?? '';
                $funkcja = $osoba['funkcjaWOrganie'] ?? '';
                
                if ($imiona || $nazwisko) {
                    $zarzad[] = trim("$funkcja: $imiona $nazwisko");
                }
            }
        }
        
        // Parsuj adres jako fallback
        $dzial1 = $dane['dzial1'] ?? [];
        $siedzibaIAdres = $dzial1['siedzibaIAdres'] ?? [];
        $adres = $siedzibaIAdres['adres'] ?? [];
        
        $adresStr = '';
        if (!empty($adres)) {
            $parts = array_filter([
                $adres['ulica'] ?? '',
                ($adres['nrDomu'] ?? '') . (isset($adres['nrLokalu']) ? '/' . $adres['nrLokalu'] : ''),
                $adres['kodPocztowy'] ?? '',
                $adres['miejscowosc'] ?? ''
            ]);
            $adresStr = implode(', ', $parts);
        }
        
        return [
            'zarzad' => implode('; ', $zarzad),
            'adres' => $adresStr
        ];
    }
    
    /**
     * Normalizuj nazwę do wyszukiwania
     */
    private function normalizeForSearch(string $name): string
    {
        // Usuń formy prawne
        $name = preg_replace('/\s+(sp\.?\s*z\.?\s*o\.?\s*o\.?|sp\.?\s*j\.?|s\.?\s*a\.?|sp\.?\s*k\.?|s\.?\s*c\.?)\.?$/iu', '', $name);
        $name = preg_replace('/\s+(spółka z ograniczoną odpowiedzialnością|spółka akcyjna|spółka jawna|spółka komandytowa)$/iu', '', $name);
        $name = preg_replace('/\s+(w\s+upadłości|w\s+likwidacji|w\s+restrukturyzacji)$/iu', '', $name);
        
        // Usuń cudzysłowy
        $name = str_replace(['"', '„', '"', '«', '»', "'", '"'], '', $name);
        
        // Usuń podwójne spacje
        $name = preg_replace('/\s+/', ' ', $name);
        
        return trim($name);
    }
    
    /**
     * Skróć nazwę do pierwszych słów
     */
    private function getShortName(string $name): string
    {
        $words = explode(' ', $name);
        if (count($words) > 2) {
            return implode(' ', array_slice($words, 0, 2));
        }
        return $name;
    }
    
    /**
     * POST request
     */
    private function postRequest(string $url, string $postData, array $extraHeaders = []): ?string
    {
        $ch = curl_init($url);
        
        $headers = [
            'Content-Type: application/json',
            'Accept: application/json',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0'
        ];
        
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $postData,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => array_merge($headers, $extraHeaders),
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return ($httpCode >= 200 && $httpCode < 400) ? $response : null;
    }
    
    /**
     * GET request
     */
    private function getRequest(string $url): ?string
    {
        $ch = curl_init($url);
        
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0'
            ],
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return ($httpCode >= 200 && $httpCode < 400) ? $response : null;
    }
    
    /**
     * Przetwórz partię firm
     */
    public function processBatch(array $companies, int $offset = 0, int $limit = 10): array
    {
        $results = [];
        $batch = array_slice($companies, $offset, $limit);
        
        foreach ($batch as $index => $company) {
            $name = $company['Firma (nazwa)'] ?? $company['nazwa'] ?? '';
            $form = $company['Forma prawna'] ?? $company['forma_prawna'] ?? '';
            
            if (empty($name)) continue;
            
            $result = $this->enrichCompany($name, $form);
            $result['original_index'] = $offset + $index;
            $results[] = $result;
            
            // Delay między firmami
            if ($index < count($batch) - 1) {
                sleep($this->delay);
            }
        }
        
        return [
            'results' => $results,
            'processed' => count($results),
            'offset' => $offset,
            'next_offset' => $offset + count($results),
            'total' => count($companies),
            'remaining' => max(0, count($companies) - $offset - count($results))
        ];
    }
    
    /**
     * Zapisz wyniki do CSV
     */
    public function saveToCSV(array $results, string $filepath, bool $append = false): bool
    {
        $mode = $append ? 'a' : 'w';
        $fp = fopen($filepath, $mode);
        
        if (!$fp) return false;
        
        if (!$append) {
            fwrite($fp, "\xEF\xBB\xBF"); // BOM dla Excel
            fputcsv($fp, [
                'Firma (nazwa)', 'Forma prawna', 'NIP', 'REGON', 'KRS',
                'Adres', 'Telefon', 'Faks', 'Email', 'WWW',
                'Zarząd', 'Źródło', 'Status', 'Błąd'
            ], ';', '"', '\\');
        }
        
        foreach ($results as $r) {
            fputcsv($fp, [
                $r['nazwa'],
                $r['forma_prawna'],
                $r['nip'],
                $r['regon'],
                $r['krs'],
                $r['adres'],
                $r['telefon'],
                $r['faks'],
                $r['email'],
                $r['www'],
                $r['zarzad'],
                $r['zrodlo'],
                $r['status'],
                $r['error']
            ], ';', '"', '\\');
        }
        
        fclose($fp);
        return true;
    }
    
    public function setDelay(int $seconds): void { $this->delay = $seconds; }
    public function isLoggedIn(): bool { return !empty($this->gusSid); }
}
