<?php
/**
 * Test GUS - wyszukiwanie po nazwie - różne formaty
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test GUS - wyszukiwanie po nazwie</h1><pre>";

$gusApiKey = 'b0f0e889eff5497cbea4';
$serviceUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';

// === LOGOWANIE ===
$loginEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $gusApiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $loginEnvelope);
$sid = extractValue($response['body'], 'ZalogujResult');
echo "SID: $sid\n\n";

// Różne warianty wyszukiwania po nazwie
$nameTests = [
    ['field' => 'Nazwa', 'value' => 'ORLEN'],
    ['field' => 'Nazwa', 'value' => 'ORLEN SPÓŁKA AKCYJNA'],
    ['field' => 'Nazwa', 'value' => 'PKO'],
    ['field' => 'Nazwa', 'value' => 'POWSZECHNA KASA'],
    ['field' => 'Nazwy', 'value' => 'ORLEN'],
    ['field' => 'NazwaPodmiotu', 'value' => 'ORLEN'],
];

foreach ($nameTests as $test) {
    echo "=== {$test['field']}: '{$test['value']}' ===\n";
    
    $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:' . $test['field'] . '>' . htmlspecialchars($test['value']) . '</dat:' . $test['field'] . '>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';

    $response = soapRequest($serviceUrl, $envelope, $sid);
    $result = extractValue($response['body'], 'DaneSzukajPodmiotyResult');
    
    if (!empty($result) && strpos($result, '<') !== false) {
        $xml = @simplexml_load_string($result);
        if ($xml && isset($xml->dane)) {
            $errorCode = (string)($xml->dane->ErrorCode ?? '');
            if ($errorCode && $errorCode !== '0') {
                echo "ErrorCode: $errorCode\n";
            } else {
                echo "✅ ZNALEZIONO!\n";
                $count = 0;
                foreach ($xml->dane as $firma) {
                    if ($count++ >= 3) break;
                    echo "  - " . ($firma->Nazwa ?? '') . "\n";
                }
            }
        }
    } else {
        echo "Pusta odpowiedź\n";
    }
    echo "\n";
}

// Test z kombinacją parametrów - może nazwa + województwo?
echo "=== Nazwa + Wojewodztwo ===\n";
$envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:Nazwa>ORLEN</dat:Nazwa>
                <dat:Wojewodztwo>MAZOWIECKIE</dat:Wojewodztwo>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $envelope, $sid);
$result = extractValue($response['body'], 'DaneSzukajPodmiotyResult');
echo empty($result) ? "Pusta\n" : "Dane: " . substr($result, 0, 300) . "\n";

// Sprawdź błąd GUS
echo "\n=== Komunikat błędu GUS ===\n";
$getValueEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/GetValue</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:GetValue>
            <ns:pNazwaParametru>KomunikatBledu</ns:pNazwaParametru>
        </ns:GetValue>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $getValueEnvelope, $sid);
$error = extractValue($response['body'], 'GetValueResult');
echo "Błąd: " . ($error ?: "(brak)") . "\n";

echo "\n</pre>";

function soapRequest($url, $envelope, $sid = null) {
    $headers = ['Content-Type: application/soap+xml; charset=utf-8'];
    if ($sid) $headers[] = 'sid: ' . $sid;
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $envelope,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $headers
    ]);
    
    $body = curl_exec($ch);
    curl_close($ch);
    
    return ['body' => $body];
}

function extractValue($xml, $tag) {
    if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
        return html_entity_decode($m[1]);
    }
    return '';
}
