<?php
/**
 * KRS Helper v2 - Profesjonalne narzędzie do uzupełniania danych z KRS
 * 
 * Funkcje:
 * - Upload CSV z firmami
 * - Szybki workflow: klik → szukaj → wklej KRS → Enter → następna
 * - Automatyczne pobieranie danych z API KRS MS
 * - Filtrowanie i wyszukiwanie
 * - Eksport do CSV
 * - Zachowanie postępu między sesjami
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

$dataDir = __DIR__ . '/data';
$companiesFile = $dataDir . '/krs_companies.json';

if (!is_dir($dataDir)) mkdir($dataDir, 0777, true);

// === ROUTING API ===
$action = $_GET['action'] ?? $_POST['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' || !empty($action)) {
    header('Content-Type: application/json; charset=utf-8');
    
    try {
        switch ($action) {
            case 'upload':
                handleUpload($companiesFile);
                break;
            case 'list':
                handleList($companiesFile);
                break;
            case 'save':
                handleSave($companiesFile);
                break;
            case 'skip':
                handleSkip($companiesFile);
                break;
            case 'lookup':
                handleLookup();
                break;
            case 'download':
                handleDownload($companiesFile);
                break;
            case 'reset':
                @unlink($companiesFile);
                echo json_encode(['success' => true]);
                break;
            case 'stats':
                handleStats($companiesFile);
                break;
            default:
                if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_FILES['file'])) {
                    handleUpload($companiesFile);
                } else {
                    throw new Exception('Nieznana akcja');
                }
        }
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['error' => $e->getMessage()]);
    }
    exit;
}

// === FUNKCJE API ===

function handleUpload($file) {
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Błąd uploadu pliku');
    }
    
    $content = file_get_contents($_FILES['file']['tmp_name']);
    
    // Konwersja kodowania
    if (!mb_check_encoding($content, 'UTF-8') || preg_match('/[\x80-\x9F]/', $content)) {
        $content = @iconv('Windows-1250', 'UTF-8//TRANSLIT//IGNORE', $content) ?: $content;
    }
    $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
    
    // Parsuj CSV
    $lines = preg_split('/\r?\n/', $content);
    $separator = (substr_count($lines[0], ';') > substr_count($lines[0], ',')) ? ';' : ',';
    
    $companies = [];
    for ($i = 1; $i < count($lines); $i++) {
        $line = trim($lines[$i]);
        if (empty($line)) continue;
        
        $row = str_getcsv($line, $separator, '"', '\\');
        if (empty(trim($row[0] ?? ''))) continue;
        
        $companies[] = [
            'id' => $i,
            'nazwa' => trim($row[0] ?? ''),
            'forma_prawna' => trim($row[1] ?? ''),
            'krs' => '',
            'nip' => '',
            'regon' => '',
            'adres' => '',
            'zarzad' => '',
            'status' => 'pending',
            'updated_at' => null
        ];
    }
    
    if (empty($companies)) {
        throw new Exception('Nie znaleziono firm w pliku');
    }
    
    file_put_contents($file, json_encode($companies, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    echo json_encode([
        'success' => true,
        'count' => count($companies),
        'message' => 'Załadowano ' . count($companies) . ' firm'
    ]);
}

function handleList($file) {
    $companies = loadCompanies($file);
    
    $filter = $_GET['filter'] ?? 'all';
    $search = $_GET['search'] ?? '';
    $page = max(1, (int)($_GET['page'] ?? 1));
    $perPage = 50;
    
    // Filtruj
    $filtered = array_filter($companies, function($c) use ($filter, $search) {
        if ($filter !== 'all' && $c['status'] !== $filter) return false;
        if ($search && stripos($c['nazwa'], $search) === false) return false;
        return true;
    });
    
    $total = count($filtered);
    $pages = ceil($total / $perPage);
    $offset = ($page - 1) * $perPage;
    
    $items = array_slice(array_values($filtered), $offset, $perPage);
    
    echo json_encode([
        'items' => $items,
        'total' => $total,
        'page' => $page,
        'pages' => $pages,
        'perPage' => $perPage
    ]);
}

function handleSave($file) {
    $id = (int)($_POST['id'] ?? 0);
    $krs = preg_replace('/[^0-9]/', '', $_POST['krs'] ?? '');
    
    if (!$id) throw new Exception('Brak ID firmy');
    if (strlen($krs) < 10) throw new Exception('Numer KRS musi mieć 10 cyfr');
    
    $companies = loadCompanies($file);
    $found = false;
    
    foreach ($companies as &$c) {
        if ($c['id'] === $id) {
            $c['krs'] = str_pad($krs, 10, '0', STR_PAD_LEFT);
            
            // Pobierz dane z API KRS
            $krsData = fetchKRSData($c['krs']);
            
            if ($krsData) {
                $c['nip'] = $krsData['nip'];
                $c['regon'] = $krsData['regon'];
                $c['adres'] = $krsData['adres'];
                $c['zarzad'] = $krsData['zarzad'];
                $c['status'] = 'success';
            } else {
                $c['status'] = 'not_found';
            }
            
            $c['updated_at'] = date('Y-m-d H:i:s');
            $found = true;
            break;
        }
    }
    
    if (!$found) throw new Exception('Nie znaleziono firmy');
    
    file_put_contents($file, json_encode($companies, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    // Znajdź następną firmę do uzupełnienia
    $nextId = null;
    $foundCurrent = false;
    foreach ($companies as $c) {
        if ($c['id'] === $id) {
            $foundCurrent = true;
            continue;
        }
        if ($foundCurrent && $c['status'] === 'pending') {
            $nextId = $c['id'];
            break;
        }
    }
    
    echo json_encode([
        'success' => true,
        'company' => $companies[array_search($id, array_column($companies, 'id'))],
        'nextId' => $nextId
    ]);
}

function handleSkip($file) {
    $id = (int)($_POST['id'] ?? 0);
    if (!$id) throw new Exception('Brak ID');
    
    $companies = loadCompanies($file);
    
    foreach ($companies as &$c) {
        if ($c['id'] === $id) {
            $c['status'] = 'skipped';
            $c['updated_at'] = date('Y-m-d H:i:s');
            break;
        }
    }
    
    file_put_contents($file, json_encode($companies, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    
    // Znajdź następną
    $nextId = null;
    $foundCurrent = false;
    foreach ($companies as $c) {
        if ($c['id'] === $id) {
            $foundCurrent = true;
            continue;
        }
        if ($foundCurrent && $c['status'] === 'pending') {
            $nextId = $c['id'];
            break;
        }
    }
    
    echo json_encode(['success' => true, 'nextId' => $nextId]);
}

function handleLookup() {
    $krs = preg_replace('/[^0-9]/', '', $_GET['krs'] ?? '');
    if (strlen($krs) < 10) throw new Exception('Za krótki numer KRS');
    
    $data = fetchKRSData(str_pad($krs, 10, '0', STR_PAD_LEFT));
    
    if (!$data) throw new Exception('Nie znaleziono w KRS');
    
    echo json_encode(['success' => true, 'data' => $data]);
}

function handleStats($file) {
    $companies = loadCompanies($file);
    
    $stats = [
        'total' => count($companies),
        'pending' => 0,
        'success' => 0,
        'skipped' => 0,
        'not_found' => 0
    ];
    
    foreach ($companies as $c) {
        $stats[$c['status']] = ($stats[$c['status']] ?? 0) + 1;
    }
    
    $stats['done'] = $stats['success'] + $stats['skipped'] + $stats['not_found'];
    $stats['progress'] = $stats['total'] > 0 ? round($stats['done'] / $stats['total'] * 100) : 0;
    
    echo json_encode($stats);
}

function handleDownload($file) {
    $companies = loadCompanies($file);
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="firmy_krs_' . date('Y-m-d_His') . '.csv"');
    
    $fp = fopen('php://output', 'w');
    fwrite($fp, "\xEF\xBB\xBF"); // BOM
    
    fputcsv($fp, [
        'Firma (nazwa)', 'Forma prawna', 'KRS', 'NIP', 'REGON', 
        'Adres', 'Zarząd', 'Status'
    ], ';', '"', '\\');
    
    foreach ($companies as $c) {
        fputcsv($fp, [
            $c['nazwa'],
            $c['forma_prawna'],
            $c['krs'],
            $c['nip'],
            $c['regon'],
            $c['adres'],
            $c['zarzad'],
            $c['status']
        ], ';', '"', '\\');
    }
    
    fclose($fp);
}

function loadCompanies($file) {
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function fetchKRSData($krs) {
    $url = "https://api-krs.ms.gov.pl/api/krs/OdpisAktualny/$krs?rejestr=P&format=json";
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => ['Accept: application/json']
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) return null;
    
    $data = json_decode($response, true);
    if (!isset($data['odpis'])) return null;
    
    $odpis = $data['odpis'];
    $dane = $odpis['dane'] ?? [];
    $dzial1 = $dane['dzial1'] ?? [];
    $dzial2 = $dane['dzial2'] ?? [];
    
    // Identyfikatory
    $identyfikatory = $dzial1['danePodmiotu']['identyfikatory'] ?? [];
    
    // Adres
    $adres = '';
    $siedzibaIAdres = $dzial1['siedzibaIAdres'] ?? [];
    $adr = $siedzibaIAdres['adres'] ?? [];
    if (!empty($adr)) {
        $parts = array_filter([
            $adr['ulica'] ?? '',
            ($adr['nrDomu'] ?? '') . (!empty($adr['nrLokalu']) ? '/' . $adr['nrLokalu'] : ''),
            $adr['kodPocztowy'] ?? '',
            $adr['miejscowosc'] ?? ''
        ]);
        $adres = implode(', ', $parts);
    }
    
    // Zarząd
    $zarzad = [];
    $reprezentacja = $dzial2['reprezentacja'] ?? [];
    $sklad = $reprezentacja['sklad'] ?? [];
    foreach ($sklad as $osoba) {
        $imiona = $osoba['imiona'] ?? '';
        $nazwisko = $osoba['nazwisko'] ?? '';
        $funkcja = $osoba['funkcjaWOrganie'] ?? '';
        if ($imiona || $nazwisko) {
            $zarzad[] = trim("$funkcja: $imiona $nazwisko");
        }
    }
    
    return [
        'nazwa' => $dzial1['danePodmiotu']['nazwa'] ?? '',
        'nip' => $identyfikatory['nip'] ?? '',
        'regon' => $identyfikatory['regon'] ?? '',
        'adres' => $adres,
        'zarzad' => implode('; ', $zarzad)
    ];
}

// === HTML INTERFACE ===
$hasData = file_exists($companiesFile) && filesize($companiesFile) > 10;
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KRS Helper v2</title>
    <style>
        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --success: #16a34a;
            --warning: #ca8a04;
            --danger: #dc2626;
            --gray-50: #f9fafb;
            --gray-100: #f3f4f6;
            --gray-200: #e5e7eb;
            --gray-300: #d1d5db;
            --gray-500: #6b7280;
            --gray-700: #374151;
            --gray-900: #111827;
        }
        
        * { box-sizing: border-box; margin: 0; padding: 0; }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--gray-100);
            color: var(--gray-900);
            line-height: 1.5;
        }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        
        /* Header */
        .header {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        
        .header h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--gray-900);
            margin-bottom: 8px;
        }
        
        .header p { color: var(--gray-500); }
        
        /* Stats */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 12px;
            margin: 20px 0;
        }
        
        .stat-card {
            background: var(--gray-50);
            border-radius: 8px;
            padding: 16px;
            text-align: center;
        }
        
        .stat-value {
            font-size: 28px;
            font-weight: 700;
            color: var(--gray-900);
        }
        
        .stat-label {
            font-size: 12px;
            color: var(--gray-500);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .stat-card.success .stat-value { color: var(--success); }
        .stat-card.warning .stat-value { color: var(--warning); }
        .stat-card.danger .stat-value { color: var(--danger); }
        
        /* Progress */
        .progress-bar {
            height: 8px;
            background: var(--gray-200);
            border-radius: 4px;
            overflow: hidden;
            margin-bottom: 20px;
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--success), #22c55e);
            transition: width 0.3s ease;
        }
        
        /* Cards */
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .card-header {
            padding: 16px 20px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
        }
        
        .card-body { padding: 20px; }
        
        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
        }
        
        .btn-primary { background: var(--primary); color: white; }
        .btn-primary:hover { background: var(--primary-dark); }
        
        .btn-success { background: var(--success); color: white; }
        .btn-success:hover { background: #15803d; }
        
        .btn-warning { background: var(--warning); color: white; }
        .btn-danger { background: var(--danger); color: white; }
        
        .btn-outline {
            background: white;
            border: 1px solid var(--gray-300);
            color: var(--gray-700);
        }
        .btn-outline:hover { background: var(--gray-50); }
        
        .btn-sm { padding: 6px 12px; font-size: 13px; }
        
        /* Forms */
        .input {
            padding: 8px 12px;
            border: 1px solid var(--gray-300);
            border-radius: 6px;
            font-size: 14px;
            transition: border-color 0.2s;
        }
        
        .input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        
        /* Upload */
        .upload-zone {
            border: 2px dashed var(--gray-300);
            border-radius: 12px;
            padding: 60px 40px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .upload-zone:hover {
            border-color: var(--primary);
            background: rgba(37, 99, 235, 0.02);
        }
        
        .upload-zone.dragover {
            border-color: var(--primary);
            background: rgba(37, 99, 235, 0.05);
        }
        
        .upload-icon { font-size: 48px; margin-bottom: 16px; }
        .upload-text { font-size: 18px; color: var(--gray-700); margin-bottom: 8px; }
        .upload-hint { font-size: 14px; color: var(--gray-500); }
        
        /* Table */
        .table-wrap { overflow-x: auto; }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 16px;
            text-align: left;
            border-bottom: 1px solid var(--gray-200);
        }
        
        th {
            background: var(--gray-50);
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: var(--gray-500);
        }
        
        tr:hover { background: var(--gray-50); }
        
        .company-name {
            font-weight: 500;
            color: var(--gray-900);
            max-width: 300px;
        }
        
        .company-form {
            font-size: 12px;
            color: var(--gray-500);
        }
        
        /* Status badges */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 4px 10px;
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .badge-pending { background: #fef3c7; color: #92400e; }
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-skipped { background: var(--gray-200); color: var(--gray-700); }
        .badge-not_found { background: #fee2e2; color: #991b1b; }
        
        /* KRS Input */
        .krs-input-group {
            display: flex;
            gap: 8px;
            align-items: center;
        }
        
        .krs-input {
            width: 130px;
            font-family: monospace;
            text-align: center;
        }
        
        /* Filters */
        .filters {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .filter-tabs {
            display: flex;
            background: var(--gray-100);
            border-radius: 6px;
            padding: 4px;
        }
        
        .filter-tab {
            padding: 6px 14px;
            border: none;
            background: none;
            border-radius: 4px;
            font-size: 13px;
            cursor: pointer;
            color: var(--gray-600);
            transition: all 0.2s;
        }
        
        .filter-tab:hover { color: var(--gray-900); }
        .filter-tab.active {
            background: white;
            color: var(--gray-900);
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        
        /* Tooltip */
        .tooltip {
            position: relative;
        }
        
        .tooltip-text {
            visibility: hidden;
            position: absolute;
            bottom: 100%;
            left: 50%;
            transform: translateX(-50%);
            background: var(--gray-900);
            color: white;
            padding: 6px 10px;
            border-radius: 4px;
            font-size: 12px;
            white-space: nowrap;
            z-index: 100;
            margin-bottom: 6px;
        }
        
        .tooltip:hover .tooltip-text { visibility: visible; }
        
        /* Actions row */
        .actions-row {
            display: flex;
            gap: 8px;
            justify-content: flex-end;
            margin-top: 16px;
        }
        
        /* Data preview */
        .data-preview {
            font-size: 12px;
            color: var(--gray-600);
            margin-top: 4px;
        }
        
        .data-preview span {
            display: inline-block;
            margin-right: 12px;
        }
        
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: var(--gray-500);
        }
        
        /* Keyboard hint */
        .kbd {
            display: inline-block;
            padding: 2px 6px;
            background: var(--gray-100);
            border: 1px solid var(--gray-300);
            border-radius: 4px;
            font-size: 11px;
            font-family: monospace;
        }
        
        /* Loading */
        .loading {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid var(--gray-200);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        
        @keyframes spin { to { transform: rotate(360deg); } }
        
        /* Responsive */
        @media (max-width: 768px) {
            .stats-grid { grid-template-columns: repeat(2, 1fr); }
            .filters { flex-direction: column; align-items: stretch; }
            .krs-input { width: 100px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📋 KRS Helper v2</h1>
            <p>Pół-automatyczne uzupełnianie danych firm z Krajowego Rejestru Sądowego</p>
        </div>
        
        <div id="app">
            <?php if (!$hasData): ?>
            <!-- UPLOAD VIEW -->
            <div class="card">
                <div class="card-body">
                    <div class="upload-zone" id="uploadZone">
                        <input type="file" id="fileInput" accept=".csv" style="display:none">
                        <div class="upload-icon">📁</div>
                        <div class="upload-text">Przeciągnij plik CSV lub kliknij aby wybrać</div>
                        <div class="upload-hint">Plik powinien zawierać kolumny: Nazwa firmy, Forma prawna</div>
                    </div>
                    
                    <div style="margin-top: 30px; padding: 20px; background: #eff6ff; border-radius: 8px; border-left: 4px solid var(--primary);">
                        <strong style="color: var(--primary);">💡 Jak to działa?</strong>
                        <ol style="margin: 12px 0 0 20px; color: var(--gray-700);">
                            <li>Załaduj plik CSV z listą firm</li>
                            <li>Dla każdej firmy kliknij <strong>🔍 Szukaj</strong> - otworzy się wyszukiwarka KRS</li>
                            <li>Znajdź firmę i skopiuj numer KRS</li>
                            <li>Wklej numer w pole i naciśnij <kbd class="kbd">Enter</kbd></li>
                            <li>System <strong>automatycznie</strong> pobierze: NIP, REGON, adres, zarząd</li>
                            <li>Pobierz gotowy CSV z wszystkimi danymi</li>
                        </ol>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <!-- MAIN VIEW -->
            <div class="card">
                <div class="card-body">
                    <div class="stats-grid" id="statsGrid">
                        <div class="stat-card"><div class="stat-value" id="statTotal">-</div><div class="stat-label">Wszystkich</div></div>
                        <div class="stat-card warning"><div class="stat-value" id="statPending">-</div><div class="stat-label">Do zrobienia</div></div>
                        <div class="stat-card success"><div class="stat-value" id="statSuccess">-</div><div class="stat-label">Uzupełnione</div></div>
                        <div class="stat-card"><div class="stat-value" id="statSkipped">-</div><div class="stat-label">Pominięte</div></div>
                    </div>
                    
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                    </div>
                    
                    <div class="actions-row">
                        <a href="?action=download" class="btn btn-success">📥 Pobierz CSV</a>
                        <button class="btn btn-danger" onclick="resetData()">🗑️ Reset</button>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <span class="card-title">Lista firm</span>
                    <div class="filters">
                        <div class="filter-tabs">
                            <button class="filter-tab active" data-filter="all">Wszystkie</button>
                            <button class="filter-tab" data-filter="pending">Do zrobienia</button>
                            <button class="filter-tab" data-filter="success">Gotowe</button>
                            <button class="filter-tab" data-filter="skipped">Pominięte</button>
                        </div>
                        <input type="text" class="input" placeholder="🔍 Szukaj firmy..." id="searchInput" style="width: 200px;">
                    </div>
                </div>
                
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th style="width:40%">Firma</th>
                                <th style="width:120px">Status</th>
                                <th style="width:280px">Numer KRS</th>
                                <th style="width:100px">Akcje</th>
                            </tr>
                        </thead>
                        <tbody id="companiesTable">
                            <tr><td colspan="4" class="empty-state">Ładowanie...</td></tr>
                        </tbody>
                    </table>
                </div>
                
                <div style="padding: 16px; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--gray-200);">
                    <span id="pageInfo" style="color: var(--gray-500); font-size: 14px;"></span>
                    <div id="pagination"></div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    const API_URL = location.href.split('?')[0];
    let currentFilter = 'all';
    let currentPage = 1;
    let currentSearch = '';
    
    // Upload handling
    const uploadZone = document.getElementById('uploadZone');
    const fileInput = document.getElementById('fileInput');
    
    if (uploadZone) {
        uploadZone.addEventListener('click', () => fileInput.click());
        uploadZone.addEventListener('dragover', e => { e.preventDefault(); uploadZone.classList.add('dragover'); });
        uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('dragover'));
        uploadZone.addEventListener('drop', e => {
            e.preventDefault();
            uploadZone.classList.remove('dragover');
            if (e.dataTransfer.files.length) uploadFile(e.dataTransfer.files[0]);
        });
        
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length) uploadFile(fileInput.files[0]);
        });
    }
    
    function uploadFile(file) {
        const formData = new FormData();
        formData.append('file', file);
        
        uploadZone.innerHTML = '<div class="loading"></div><div style="margin-top:12px">Przetwarzanie...</div>';
        
        fetch(API_URL + '?action=upload', { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Błąd: ' + (data.error || 'Nieznany błąd'));
                    location.reload();
                }
            })
            .catch(err => {
                alert('Błąd połączenia');
                location.reload();
            });
    }
    
    // Main view
    if (document.getElementById('companiesTable')) {
        loadStats();
        loadCompanies();
        
        // Filter tabs
        document.querySelectorAll('.filter-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                currentFilter = tab.dataset.filter;
                currentPage = 1;
                loadCompanies();
            });
        });
        
        // Search
        let searchTimeout;
        document.getElementById('searchInput').addEventListener('input', e => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                currentSearch = e.target.value;
                currentPage = 1;
                loadCompanies();
            }, 300);
        });
    }
    
    function loadStats() {
        fetch(API_URL + '?action=stats')
            .then(r => r.json())
            .then(stats => {
                document.getElementById('statTotal').textContent = stats.total;
                document.getElementById('statPending').textContent = stats.pending;
                document.getElementById('statSuccess').textContent = stats.success;
                document.getElementById('statSkipped').textContent = stats.skipped + stats.not_found;
                document.getElementById('progressFill').style.width = stats.progress + '%';
            });
    }
    
    function loadCompanies() {
        const params = new URLSearchParams({
            action: 'list',
            filter: currentFilter,
            search: currentSearch,
            page: currentPage
        });
        
        fetch(API_URL + '?' + params)
            .then(r => r.json())
            .then(data => {
                renderTable(data.items);
                renderPagination(data);
            });
    }
    
    function renderTable(items) {
        const tbody = document.getElementById('companiesTable');
        
        if (!items.length) {
            tbody.innerHTML = '<tr><td colspan="4" class="empty-state">Brak firm do wyświetlenia</td></tr>';
            return;
        }
        
        tbody.innerHTML = items.map(c => `
            <tr id="row-${c.id}">
                <td>
                    <div class="company-name">${escapeHtml(c.nazwa)}</div>
                    <div class="company-form">${escapeHtml(c.forma_prawna)}</div>
                    ${c.status === 'success' ? `
                        <div class="data-preview">
                            <span>NIP: ${c.nip || '-'}</span>
                            <span>REGON: ${c.regon || '-'}</span>
                            <span>Adres: ${(c.adres || '').substring(0, 40)}${(c.adres || '').length > 40 ? '...' : ''}</span>
                        </div>
                    ` : ''}
                </td>
                <td>
                    <span class="badge badge-${c.status}">
                        ${c.status === 'pending' ? '⏳ Do zrobienia' : 
                          c.status === 'success' ? '✅ Gotowe' : 
                          c.status === 'skipped' ? '⏭️ Pominięte' : '❌ Nie znaleziono'}
                    </span>
                </td>
                <td>
                    ${c.status === 'pending' ? `
                        <div class="krs-input-group">
                            <a href="https://wyszukiwarka-krs.ms.gov.pl/" target="_blank" class="btn btn-outline btn-sm">🔍 Szukaj</a>
                            <input type="text" class="input krs-input" placeholder="0000000000" maxlength="10" 
                                   id="krs-${c.id}" onkeypress="if(event.key==='Enter')saveKrs(${c.id})">
                            <button class="btn btn-primary btn-sm" onclick="saveKrs(${c.id})">💾</button>
                        </div>
                    ` : c.krs ? `<code style="font-size:14px">${c.krs}</code>` : '-'}
                </td>
                <td>
                    ${c.status === 'pending' ? `
                        <button class="btn btn-outline btn-sm" onclick="skipCompany(${c.id})">Pomiń</button>
                    ` : ''}
                </td>
            </tr>
        `).join('');
    }
    
    function renderPagination(data) {
        document.getElementById('pageInfo').textContent = 
            `Pokazuje ${(data.page-1)*data.perPage + 1}-${Math.min(data.page*data.perPage, data.total)} z ${data.total}`;
        
        let html = '';
        if (data.pages > 1) {
            html += `<button class="btn btn-outline btn-sm" ${data.page <= 1 ? 'disabled' : ''} onclick="goToPage(${data.page-1})">← Poprz.</button>`;
            html += `<span style="margin: 0 12px; color: var(--gray-500);">Strona ${data.page} z ${data.pages}</span>`;
            html += `<button class="btn btn-outline btn-sm" ${data.page >= data.pages ? 'disabled' : ''} onclick="goToPage(${data.page+1})">Nast. →</button>`;
        }
        document.getElementById('pagination').innerHTML = html;
    }
    
    function goToPage(page) {
        currentPage = page;
        loadCompanies();
    }
    
    function saveKrs(id) {
        const input = document.getElementById('krs-' + id);
        const krs = input.value.replace(/\D/g, '');
        
        if (krs.length < 10) {
            alert('Numer KRS musi mieć 10 cyfr');
            input.focus();
            return;
        }
        
        input.disabled = true;
        
        const formData = new FormData();
        formData.append('action', 'save');
        formData.append('id', id);
        formData.append('krs', krs);
        
        fetch(API_URL, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadStats();
                    loadCompanies();
                    
                    // Focus next
                    if (data.nextId) {
                        setTimeout(() => {
                            const nextInput = document.getElementById('krs-' + data.nextId);
                            if (nextInput) nextInput.focus();
                        }, 100);
                    }
                } else {
                    alert('Błąd: ' + (data.error || 'Nieznany błąd'));
                    input.disabled = false;
                }
            })
            .catch(() => {
                alert('Błąd połączenia');
                input.disabled = false;
            });
    }
    
    function skipCompany(id) {
        const formData = new FormData();
        formData.append('action', 'skip');
        formData.append('id', id);
        
        fetch(API_URL, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    loadStats();
                    loadCompanies();
                }
            });
    }
    
    function resetData() {
        if (!confirm('Na pewno usunąć wszystkie dane i zacząć od nowa?')) return;
        
        fetch(API_URL + '?action=reset')
            .then(() => location.reload());
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text || '';
        return div.innerHTML;
    }
    </script>
</body>
</html>
