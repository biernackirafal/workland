<?php
/**
 * Test pełnego pipeline - GUS + KRS dla jednej firmy
 */

header('Content-Type: text/html; charset=utf-8');

// Klucz GUS
$gusApiKey = 'b0f0e889eff5497cbea4';
$testCompany = $_GET['firma'] ?? 'Chemos';

echo "<h1>🧪 Test Pipeline: GUS + KRS</h1>";
echo "<p>Firma: <strong>$testCompany</strong></p>";
echo "<p><a href='?firma=Merazet'>Test: Merazet</a> | <a href='?firma=Agrobex'>Test: Agrobex</a> | <a href='?firma=Talex'>Test: Talex</a></p>";
echo "<pre style='background:#f5f5f5; padding:15px;'>";

require_once __DIR__ . '/CompanyEnricher.php';

$enricher = new CompanyEnricher($gusApiKey);

echo "=== KROK 1: Logowanie do GUS BIR ===\n";
$loginOk = $enricher->loginGUS();
echo $loginOk ? "✅ Zalogowano\n" : "❌ Błąd logowania\n";

if (!$loginOk) {
    echo "</pre>";
    exit;
}

echo "\n=== KROK 2: Wzbogacanie danych firmy '$testCompany' ===\n";
$startTime = microtime(true);

$result = $enricher->enrichCompany($testCompany);

$duration = round(microtime(true) - $startTime, 2);
echo "Czas: {$duration}s\n\n";

echo "=== WYNIK ===\n";
foreach ($result as $key => $value) {
    if ($value !== null && $value !== '') {
        echo str_pad($key, 15) . ": $value\n";
    }
}

echo "\n=== KROK 3: Wylogowanie ===\n";
$enricher->logoutGUS();
echo "✅ Wylogowano\n";

// Podsumowanie
echo "\n=== PODSUMOWANIE ===\n";
if ($result['status'] === 'success') {
    echo "✅ SUKCES - Dane pobrane z: {$result['zrodlo']}\n";
    
    $found = [];
    if ($result['nip']) $found[] = 'NIP';
    if ($result['regon']) $found[] = 'REGON';
    if ($result['krs']) $found[] = 'KRS';
    if ($result['adres']) $found[] = 'Adres';
    if ($result['telefon']) $found[] = 'Telefon';
    if ($result['zarzad']) $found[] = 'Zarząd';
    
    echo "Znaleziono: " . implode(', ', $found) . "\n";
} else {
    echo "❌ {$result['status']}: {$result['error']}\n";
}

echo "</pre>";

// Formularz
echo "<hr><h3>Testuj inną firmę:</h3>";
echo "<form method='get'>";
echo "<input type='text' name='firma' value='" . htmlspecialchars($testCompany) . "' style='padding:10px; width:300px;'>";
echo "<button type='submit' style='padding:10px 20px;'>Szukaj</button>";
echo "</form>";
