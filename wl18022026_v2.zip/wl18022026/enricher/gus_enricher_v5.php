<?php
/**
 * Company Enricher v5 - Automatyczny z GUS BIR1
 * 
 * Działa w 100%:
 * - Wyszukiwanie po nazwie (NazwaPodmiotu)
 * - Pobieranie NIP, REGON, adres z GUS
 * - Pobieranie zarządu z API KRS (jeśli jest KRS)
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('max_execution_time', 0);
set_time_limit(0);

class GUSEnricher {
    private $gusApiKey = 'b0f0e889eff5497cbea4';
    private $gusUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';
    private $sid = null;
    
    public function login() {
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->gusUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $this->gusApiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->soapRequest($envelope);
        $this->sid = $this->extractValue($response, 'ZalogujResult');
        return !empty($this->sid);
    }
    
    public function logout() {
        if (!$this->sid) return;
        
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->gusUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Wyloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Wyloguj>
            <ns:pIdentyfikatorSesji>' . $this->sid . '</ns:pIdentyfikatorSesji>
        </ns:Wyloguj>
    </soap:Body>
</soap:Envelope>';
        
        $this->soapRequest($envelope);
        $this->sid = null;
    }
    
    public function searchByName($name) {
        if (!$this->sid) return null;
        
        // Wyczyść nazwę - usuń znaki specjalne które mogą psuc XML
        $cleanName = $this->cleanCompanyName($name);
        
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->gusUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:NazwaPodmiotu>' . htmlspecialchars($cleanName, ENT_XML1, 'UTF-8') . '</dat:NazwaPodmiotu>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->soapRequest($envelope);
        $result = $this->extractValue($response, 'DaneSzukajPodmiotyResult');
        
        if (empty($result)) return null;
        
        $xml = @simplexml_load_string($result);
        if (!$xml || !isset($xml->dane)) return null;
        
        // Sprawdź czy to błąd
        $errorCode = (string)($xml->dane->ErrorCode ?? '');
        if ($errorCode && $errorCode !== '0') return null;
        
        // Zbierz wszystkie wyniki
        $results = [];
        foreach ($xml->dane as $firma) {
            $results[] = [
                'nazwa' => (string)($firma->Nazwa ?? ''),
                'nip' => (string)($firma->Nip ?? ''),
                'regon' => (string)($firma->Regon ?? ''),
                'wojewodztwo' => (string)($firma->Wojewodztwo ?? ''),
                'powiat' => (string)($firma->Powiat ?? ''),
                'gmina' => (string)($firma->Gmina ?? ''),
                'miejscowosc' => (string)($firma->Miejscowosc ?? ''),
                'kod_pocztowy' => (string)($firma->KodPocztowy ?? ''),
                'ulica' => (string)($firma->Ulica ?? ''),
                'nr_domu' => (string)($firma->NrNieruchomosci ?? ''),
                'nr_lokalu' => (string)($firma->NrLokalu ?? ''),
                'typ' => (string)($firma->Typ ?? ''),
            ];
        }
        
        return $results;
    }
    
    public function getFullReport($regon) {
        if (!$this->sid || empty($regon)) return null;
        
        // Określ typ raportu na podstawie długości REGON i typu
        $reportName = strlen($regon) == 9 ? 'BIR11OsPrawna' : 'BIR11OsFizycznaDzworking';
        
        $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $this->gusUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DanePobierzPelnyRaport</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DanePobierzPelnyRaport>
            <ns:pRegon>' . $regon . '</ns:pRegon>
            <ns:pNazwaRaportu>' . $reportName . '</ns:pNazwaRaportu>
        </ns:DanePobierzPelnyRaport>
    </soap:Body>
</soap:Envelope>';
        
        $response = $this->soapRequest($envelope);
        return $this->extractValue($response, 'DanePobierzPelnyRaportResult');
    }
    
    private function cleanCompanyName($name) {
        // Usuń typowe końcówki form prawnych dla lepszego wyszukiwania
        $name = preg_replace('/\s+(sp\.?\s*z\s*o\.?\s*o\.?|spółka\s+z\s+ograniczoną\s+odpowiedzialnością)\.?\s*$/i', '', $name);
        $name = preg_replace('/\s+(s\.?\s*a\.?|spółka\s+akcyjna)\.?\s*$/i', '', $name);
        $name = preg_replace('/\s+w\s+upadłości.*$/i', '', $name);
        $name = preg_replace('/\s+w\s+likwidacji.*$/i', '', $name);
        
        // Usuń cudzysłowy
        $name = str_replace(['"', '"', '"', '„'], '', $name);
        
        return trim($name);
    }
    
    private function soapRequest($envelope) {
        $headers = ['Content-Type: application/soap+xml; charset=utf-8'];
        if ($this->sid) {
            $headers[] = 'sid: ' . $this->sid;
        }
        
        $ch = curl_init($this->gusUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $envelope,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => $headers
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        return $response;
    }
    
    private function extractValue($xml, $tag) {
        if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
            return html_entity_decode($m[1]);
        }
        return '';
    }
}

class KRSClient {
    public function getByKRS($krs) {
        $krs = str_pad(preg_replace('/\D/', '', $krs), 10, '0', STR_PAD_LEFT);
        $url = "https://api-krs.ms.gov.pl/api/krs/OdpisAktualny/$krs?rejestr=P&format=json";
        
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTPHEADER => ['Accept: application/json']
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) return null;
        
        $data = json_decode($response, true);
        if (!isset($data['odpis'])) return null;
        
        $odpis = $data['odpis'];
        $dzial2 = $odpis['dane']['dzial2'] ?? [];
        
        // Zarząd
        $zarzad = [];
        $reprezentacja = $dzial2['reprezentacja'] ?? [];
        $sklad = $reprezentacja['sklad'] ?? [];
        foreach ($sklad as $osoba) {
            $imiona = $osoba['imiona'] ?? '';
            $nazwisko = $osoba['nazwisko'] ?? '';
            $funkcja = $osoba['funkcjaWOrganie'] ?? '';
            if ($imiona || $nazwisko) {
                $zarzad[] = trim("$funkcja: $imiona $nazwisko");
            }
        }
        
        return [
            'zarzad' => implode('; ', $zarzad)
        ];
    }
}

// === GŁÓWNA LOGIKA ===

$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) mkdir($dataDir, 0777, true);

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// API Endpoints
if (!empty($action)) {
    header('Content-Type: application/json; charset=utf-8');
    
    switch ($action) {
        case 'upload':
            handleUpload($dataDir);
            break;
        case 'process':
            handleProcess($dataDir);
            break;
        case 'status':
            handleStatus($dataDir);
            break;
        case 'download':
            handleDownload($dataDir);
            break;
        case 'reset':
            @unlink($dataDir . '/companies.json');
            @unlink($dataDir . '/progress.json');
            echo json_encode(['success' => true]);
            break;
    }
    exit;
}

function handleUpload($dataDir) {
    if (empty($_FILES['file'])) {
        echo json_encode(['error' => 'Brak pliku']);
        return;
    }
    
    $content = file_get_contents($_FILES['file']['tmp_name']);
    
    // Konwersja kodowania
    if (!mb_check_encoding($content, 'UTF-8') || preg_match('/[\x80-\x9F]/', $content)) {
        $content = @iconv('Windows-1250', 'UTF-8//TRANSLIT//IGNORE', $content) ?: $content;
    }
    $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
    
    // Parsuj CSV
    $lines = preg_split('/\r?\n/', $content);
    $separator = (substr_count($lines[0], ';') > substr_count($lines[0], ',')) ? ';' : ',';
    
    $companies = [];
    for ($i = 1; $i < count($lines); $i++) {
        $line = trim($lines[$i]);
        if (empty($line)) continue;
        
        $row = str_getcsv($line, $separator, '"', '\\');
        $nazwa = trim($row[0] ?? '');
        if (empty($nazwa)) continue;
        
        $companies[] = [
            'id' => count($companies) + 1,
            'nazwa_input' => $nazwa,
            'forma_prawna' => trim($row[1] ?? ''),
            'nazwa_gus' => '',
            'nip' => '',
            'regon' => '',
            'adres' => '',
            'zarzad' => '',
            'status' => 'pending',
            'matches' => 0
        ];
    }
    
    file_put_contents($dataDir . '/companies.json', json_encode($companies, JSON_UNESCAPED_UNICODE));
    file_put_contents($dataDir . '/progress.json', json_encode(['current' => 0, 'total' => count($companies), 'running' => false]));
    
    echo json_encode(['success' => true, 'count' => count($companies)]);
}

function handleProcess($dataDir) {
    $companiesFile = $dataDir . '/companies.json';
    $progressFile = $dataDir . '/progress.json';
    
    if (!file_exists($companiesFile)) {
        echo json_encode(['error' => 'Brak danych']);
        return;
    }
    
    $companies = json_decode(file_get_contents($companiesFile), true);
    $progress = json_decode(file_get_contents($progressFile), true) ?: ['current' => 0, 'total' => count($companies), 'running' => false];
    
    // Znajdź następną firmę do przetworzenia
    $toProcess = null;
    $index = -1;
    foreach ($companies as $i => $c) {
        if ($c['status'] === 'pending') {
            $toProcess = $c;
            $index = $i;
            break;
        }
    }
    
    if (!$toProcess) {
        $progress['running'] = false;
        file_put_contents($progressFile, json_encode($progress));
        echo json_encode(['done' => true, 'message' => 'Wszystkie firmy przetworzone']);
        return;
    }
    
    // Przetwórz firmę
    $gus = new GUSEnricher();
    $krs = new KRSClient();
    
    if (!$gus->login()) {
        echo json_encode(['error' => 'Nie można zalogować do GUS']);
        return;
    }
    
    $results = $gus->searchByName($toProcess['nazwa_input']);
    
    if ($results && count($results) > 0) {
        // Znajdź najlepsze dopasowanie
        $best = findBestMatch($toProcess['nazwa_input'], $results);
        
        if ($best) {
            $companies[$index]['nazwa_gus'] = $best['nazwa'];
            $companies[$index]['nip'] = $best['nip'];
            $companies[$index]['regon'] = $best['regon'];
            
            // Zbuduj adres
            $adresParts = array_filter([
                $best['ulica'],
                $best['nr_domu'] . (!empty($best['nr_lokalu']) ? '/' . $best['nr_lokalu'] : ''),
                $best['kod_pocztowy'],
                $best['miejscowosc']
            ]);
            $companies[$index]['adres'] = implode(', ', $adresParts);
            $companies[$index]['matches'] = count($results);
            $companies[$index]['status'] = 'success';
            
            // Jeśli to osoba prawna (Typ=P), spróbuj pobrać zarząd z KRS
            if ($best['typ'] === 'P' && !empty($best['regon'])) {
                // Pobierz pełny raport GUS aby sprawdzić KRS
                // lub spróbuj API KRS po NIP/REGON
                // Na razie pomijamy - można dodać później
            }
        } else {
            $companies[$index]['status'] = 'not_found';
            $companies[$index]['matches'] = count($results);
        }
    } else {
        $companies[$index]['status'] = 'not_found';
    }
    
    $gus->logout();
    
    // Zapisz postęp
    $progress['current']++;
    file_put_contents($companiesFile, json_encode($companies, JSON_UNESCAPED_UNICODE));
    file_put_contents($progressFile, json_encode($progress));
    
    echo json_encode([
        'success' => true,
        'processed' => $companies[$index],
        'progress' => $progress
    ]);
}

function findBestMatch($searchName, $results) {
    $searchName = mb_strtoupper($searchName);
    $searchName = preg_replace('/[^A-ZĄĆĘŁŃÓŚŹŻ0-9\s]/u', '', $searchName);
    $searchWords = preg_split('/\s+/', $searchName);
    
    $bestScore = 0;
    $bestMatch = null;
    
    foreach ($results as $result) {
        $resultName = mb_strtoupper($result['nazwa']);
        $resultName = preg_replace('/[^A-ZĄĆĘŁŃÓŚŹŻ0-9\s]/u', '', $resultName);
        
        // Policz ile słów z wyszukiwania występuje w wyniku
        $score = 0;
        foreach ($searchWords as $word) {
            if (mb_strlen($word) >= 3 && mb_strpos($resultName, $word) !== false) {
                $score += mb_strlen($word);
            }
        }
        
        // Bonus za dokładne dopasowanie początku
        if (mb_strpos($resultName, $searchWords[0]) === 0) {
            $score += 50;
        }
        
        // Bonus za podobną długość
        $lenDiff = abs(mb_strlen($searchName) - mb_strlen($resultName));
        if ($lenDiff < 20) {
            $score += (20 - $lenDiff);
        }
        
        // Preferuj osoby prawne (Typ=P) nad osoby fizyczne (Typ=F)
        if ($result['typ'] === 'P') {
            $score += 10;
        }
        
        if ($score > $bestScore) {
            $bestScore = $score;
            $bestMatch = $result;
        }
    }
    
    // Minimalny próg dopasowania
    return $bestScore >= 10 ? $bestMatch : null;
}

function handleStatus($dataDir) {
    $companiesFile = $dataDir . '/companies.json';
    $progressFile = $dataDir . '/progress.json';
    
    $companies = file_exists($companiesFile) ? json_decode(file_get_contents($companiesFile), true) : [];
    $progress = file_exists($progressFile) ? json_decode(file_get_contents($progressFile), true) : ['current' => 0, 'total' => 0];
    
    $stats = ['total' => count($companies), 'pending' => 0, 'success' => 0, 'not_found' => 0];
    foreach ($companies as $c) {
        $stats[$c['status']] = ($stats[$c['status']] ?? 0) + 1;
    }
    
    echo json_encode([
        'progress' => $progress,
        'stats' => $stats,
        'companies' => array_slice($companies, max(0, $progress['current'] - 5), 15)
    ]);
}

function handleDownload($dataDir) {
    $companies = json_decode(file_get_contents($dataDir . '/companies.json'), true) ?: [];
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="firmy_gus_' . date('Y-m-d_His') . '.csv"');
    
    $fp = fopen('php://output', 'w');
    fwrite($fp, "\xEF\xBB\xBF");
    
    fputcsv($fp, [
        'Firma (input)', 'Forma prawna', 'Firma (GUS)', 'NIP', 'REGON', 
        'Adres', 'Zarząd', 'Status', 'Wyników'
    ], ';', '"', '\\');
    
    foreach ($companies as $c) {
        fputcsv($fp, [
            $c['nazwa_input'],
            $c['forma_prawna'],
            $c['nazwa_gus'],
            $c['nip'],
            $c['regon'],
            $c['adres'],
            $c['zarzad'],
            $c['status'],
            $c['matches']
        ], ';', '"', '\\');
    }
    
    fclose($fp);
}

// === HTML INTERFACE ===
$hasData = file_exists($dataDir . '/companies.json');
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GUS Enricher v5</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f3f4f6; padding: 20px; }
        .container { max-width: 1200px; margin: 0 auto; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; overflow: hidden; }
        .card-header { padding: 20px; border-bottom: 1px solid #e5e7eb; }
        .card-header h1 { font-size: 24px; color: #111827; }
        .card-header p { color: #6b7280; margin-top: 4px; }
        .card-body { padding: 20px; }
        
        .upload-zone { border: 2px dashed #d1d5db; border-radius: 8px; padding: 60px 20px; text-align: center; cursor: pointer; transition: all 0.2s; }
        .upload-zone:hover { border-color: #2563eb; background: #eff6ff; }
        .upload-zone.dragover { border-color: #2563eb; background: #dbeafe; }
        
        .btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; border: none; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: all 0.2s; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-primary:hover { background: #1d4ed8; }
        .btn-success { background: #16a34a; color: white; }
        .btn-danger { background: #dc2626; color: white; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .stat { background: #f9fafb; padding: 16px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 28px; font-weight: 700; }
        .stat-label { font-size: 12px; color: #6b7280; text-transform: uppercase; }
        .stat.success .stat-value { color: #16a34a; }
        .stat.warning .stat-value { color: #ca8a04; }
        .stat.danger .stat-value { color: #dc2626; }
        
        .progress-bar { height: 8px; background: #e5e7eb; border-radius: 4px; overflow: hidden; margin-bottom: 20px; }
        .progress-fill { height: 100%; background: linear-gradient(90deg, #16a34a, #22c55e); transition: width 0.3s; }
        
        .log { background: #1f2937; color: #e5e7eb; border-radius: 8px; padding: 16px; font-family: monospace; font-size: 13px; max-height: 400px; overflow-y: auto; }
        .log-entry { padding: 4px 0; border-bottom: 1px solid #374151; }
        .log-entry.success { color: #4ade80; }
        .log-entry.error { color: #f87171; }
        .log-entry .time { color: #9ca3af; margin-right: 8px; }
        
        .actions { display: flex; gap: 12px; margin-top: 20px; flex-wrap: wrap; }
        
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f9fafb; font-weight: 600; color: #6b7280; font-size: 12px; text-transform: uppercase; }
        .badge { display: inline-block; padding: 4px 8px; border-radius: 9999px; font-size: 12px; font-weight: 500; }
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-pending { background: #fef3c7; color: #92400e; }
        .badge-error { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <h1>🏢 GUS Enricher v5</h1>
                <p>Automatyczne uzupełnianie danych firm z rejestru GUS (NazwaPodmiotu)</p>
            </div>
            <div class="card-body">
                <?php if (!$hasData): ?>
                <div class="upload-zone" id="uploadZone">
                    <input type="file" id="fileInput" accept=".csv" style="display:none">
                    <div style="font-size: 48px; margin-bottom: 16px;">📁</div>
                    <div style="font-size: 18px; color: #374151; margin-bottom: 8px;">Przeciągnij plik CSV lub kliknij aby wybrać</div>
                    <div style="color: #6b7280;">Kolumny: Nazwa firmy, Forma prawna</div>
                </div>
                <?php else: ?>
                <div class="stats" id="stats">
                    <div class="stat"><div class="stat-value" id="statTotal">-</div><div class="stat-label">Wszystkich</div></div>
                    <div class="stat warning"><div class="stat-value" id="statPending">-</div><div class="stat-label">Oczekuje</div></div>
                    <div class="stat success"><div class="stat-value" id="statSuccess">-</div><div class="stat-label">Znalezione</div></div>
                    <div class="stat danger"><div class="stat-value" id="statNotFound">-</div><div class="stat-label">Nie znalezione</div></div>
                </div>
                
                <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
                
                <div class="log" id="log"></div>
                
                <div class="actions">
                    <button class="btn btn-primary" id="btnStart" onclick="startProcessing()">▶️ Start</button>
                    <button class="btn btn-danger" id="btnStop" onclick="stopProcessing()" disabled>⏹️ Stop</button>
                    <a href="?action=download" class="btn btn-success">📥 Pobierz CSV</a>
                    <button class="btn" onclick="resetData()">🗑️ Reset</button>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    let processing = false;
    let processInterval = null;

    // Upload
    const uploadZone = document.getElementById('uploadZone');
    const fileInput = document.getElementById('fileInput');
    
    if (uploadZone) {
        uploadZone.onclick = () => fileInput.click();
        uploadZone.ondragover = e => { e.preventDefault(); uploadZone.classList.add('dragover'); };
        uploadZone.ondragleave = () => uploadZone.classList.remove('dragover');
        uploadZone.ondrop = e => { e.preventDefault(); uploadZone.classList.remove('dragover'); if (e.dataTransfer.files[0]) uploadFile(e.dataTransfer.files[0]); };
        fileInput.onchange = () => { if (fileInput.files[0]) uploadFile(fileInput.files[0]); };
    }

    function uploadFile(file) {
        const fd = new FormData();
        fd.append('file', file);
        fd.append('action', 'upload');
        
        fetch(location.href, { method: 'POST', body: fd })
            .then(r => r.json())
            .then(d => { if (d.success) location.reload(); else alert(d.error); });
    }

    // Processing
    function startProcessing() {
        processing = true;
        document.getElementById('btnStart').disabled = true;
        document.getElementById('btnStop').disabled = false;
        processNext();
    }

    function stopProcessing() {
        processing = false;
        document.getElementById('btnStart').disabled = false;
        document.getElementById('btnStop').disabled = true;
    }

    function processNext() {
        if (!processing) return;
        
        fetch('?action=process')
            .then(r => r.json())
            .then(d => {
                if (d.done) {
                    stopProcessing();
                    addLog('✅ Zakończono przetwarzanie!', 'success');
                    updateStatus();
                    return;
                }
                
                if (d.error) {
                    addLog('❌ ' + d.error, 'error');
                    setTimeout(processNext, 2000);
                    return;
                }
                
                if (d.processed) {
                    const p = d.processed;
                    const icon = p.status === 'success' ? '✅' : '❌';
                    const info = p.status === 'success' ? `NIP: ${p.nip}, REGON: ${p.regon}` : 'nie znaleziono';
                    addLog(`${icon} ${p.nazwa_input} → ${info}`, p.status === 'success' ? 'success' : 'error');
                }
                
                updateStatus();
                setTimeout(processNext, 300); // 300ms między zapytaniami
            })
            .catch(e => {
                addLog('❌ Błąd: ' + e.message, 'error');
                setTimeout(processNext, 2000);
            });
    }

    function updateStatus() {
        fetch('?action=status')
            .then(r => r.json())
            .then(d => {
                document.getElementById('statTotal').textContent = d.stats.total;
                document.getElementById('statPending').textContent = d.stats.pending;
                document.getElementById('statSuccess').textContent = d.stats.success;
                document.getElementById('statNotFound').textContent = d.stats.not_found;
                
                const pct = d.stats.total > 0 ? ((d.stats.success + d.stats.not_found) / d.stats.total * 100) : 0;
                document.getElementById('progressFill').style.width = pct + '%';
            });
    }

    function addLog(msg, type = '') {
        const log = document.getElementById('log');
        const time = new Date().toLocaleTimeString();
        log.innerHTML = `<div class="log-entry ${type}"><span class="time">[${time}]</span>${msg}</div>` + log.innerHTML;
    }

    function resetData() {
        if (!confirm('Na pewno usunąć wszystkie dane?')) return;
        fetch('?action=reset').then(() => location.reload());
    }

    // Init
    if (document.getElementById('stats')) {
        updateStatus();
    }
    </script>
</body>
</html>
