<?php
/**
 * Test GUS BIR1 - ręczne żądania SOAP (bez WSDL)
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test GUS BIR1 (ręczny SOAP)</h1><pre>";

$gusApiKey = 'b0f0e889eff5497cbea4';
$serviceUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';

echo "=== KONFIGURACJA ===\n";
echo "URL: $serviceUrl\n";
echo "Klucz: " . substr($gusApiKey, 0, 8) . "...\n\n";

// === KROK 1: LOGOWANIE ===
echo "=== KROK 1: LOGOWANIE ===\n";

$loginEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $gusApiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $loginEnvelope, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj');

echo "HTTP Code: {$response['code']}\n";

if ($response['code'] != 200) {
    echo "❌ Błąd HTTP\n";
    echo "Response: " . htmlspecialchars(substr($response['body'], 0, 1000)) . "\n";
    echo "</pre>";
    exit;
}

// Parsuj SID z odpowiedzi
$sid = '';
if (preg_match('/<ZalogujResult>([^<]+)<\/ZalogujResult>/i', $response['body'], $m)) {
    $sid = $m[1];
}

if (empty($sid)) {
    echo "❌ Nie udało się pobrać SID\n";
    echo "Response:\n" . htmlspecialchars($response['body']) . "\n";
    echo "</pre>";
    exit;
}

echo "✅ SID: $sid\n";

// === KROK 2: WYSZUKIWANIE PO NAZWIE ===
echo "\n=== KROK 2: WYSZUKIWANIE 'Talex' ===\n";

$searchEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07" xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukaj>
            <ns:pParametryWyszukiwania>
                <dat:Nazwa>Talex</dat:Nazwa>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukaj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $searchEnvelope, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj', $sid);

echo "HTTP Code: {$response['code']}\n";

// Parsuj wynik
$result = '';
if (preg_match('/<DaneSzukajResult>(.+?)<\/DaneSzukajResult>/s', $response['body'], $m)) {
    $result = html_entity_decode($m[1]);
}

if (empty($result)) {
    echo "❌ Pusta odpowiedź\n";
    echo "Raw response:\n" . htmlspecialchars(substr($response['body'], 0, 2000)) . "\n";
} else {
    echo "✅ Odpowiedź:\n";
    echo htmlspecialchars($result) . "\n";
    
    // Parsuj XML
    $xml = @simplexml_load_string($result);
    if ($xml && isset($xml->dane)) {
        echo "\n=== ZNALEZIONE FIRMY ===\n";
        foreach ($xml->dane as $firma) {
            echo "\nNazwa: " . ($firma->Nazwa ?? 'brak') . "\n";
            echo "REGON: " . ($firma->Regon ?? 'brak') . "\n";
            echo "NIP: " . ($firma->Nip ?? 'brak') . "\n";
            echo "Miejscowość: " . ($firma->Miejscowosc ?? 'brak') . "\n";
        }
    }
}

// === KROK 3: WYSZUKIWANIE PO REGON ===
echo "\n\n=== KROK 3: WYSZUKIWANIE PO REGON (630303246) ===\n";

$searchEnvelope2 = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07" xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukaj>
            <ns:pParametryWyszukiwania>
                <dat:Regon>630303246</dat:Regon>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukaj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $searchEnvelope2, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj', $sid);

echo "HTTP Code: {$response['code']}\n";

$result = '';
if (preg_match('/<DaneSzukajResult>(.+?)<\/DaneSzukajResult>/s', $response['body'], $m)) {
    $result = html_entity_decode($m[1]);
}

if (!empty($result)) {
    echo "✅ Odpowiedź:\n";
    echo htmlspecialchars($result) . "\n";
}

// === KROK 4: PEŁNY RAPORT ===
echo "\n\n=== KROK 4: PEŁNY RAPORT (REGON 630303246) ===\n";

$reportEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DanePobierzPelnyRaport</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DanePobierzPelnyRaport>
            <ns:pRegon>630303246</ns:pRegon>
            <ns:pNazwaRaportu>PublDaneRaportPrawna</ns:pNazwaRaportu>
        </ns:DanePobierzPelnyRaport>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $reportEnvelope, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DanePobierzPelnyRaport', $sid);

echo "HTTP Code: {$response['code']}\n";

$result = '';
if (preg_match('/<DanePobierzPelnyRaportResult>(.+?)<\/DanePobierzPelnyRaportResult>/s', $response['body'], $m)) {
    $result = html_entity_decode($m[1]);
}

if (!empty($result)) {
    echo "✅ Raport:\n";
    echo htmlspecialchars(substr($result, 0, 2000)) . "\n";
}

// === WYLOGOWANIE ===
echo "\n=== WYLOGOWANIE ===\n";

$logoutEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Wyloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Wyloguj>
            <ns:pIdentyfikatorSesji>' . $sid . '</ns:pIdentyfikatorSesji>
        </ns:Wyloguj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $logoutEnvelope, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Wyloguj', $sid);
echo "✅ Wylogowano\n";

echo "\n</pre>";

// === FUNKCJA SOAP REQUEST ===
function soapRequest($url, $envelope, $action, $sid = null) {
    $headers = [
        'Content-Type: application/soap+xml; charset=utf-8',
        'SOAPAction: "' . $action . '"'
    ];
    
    if ($sid) {
        $headers[] = 'sid: ' . $sid;
    }
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $envelope,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => $headers
    ]);
    
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    return ['code' => $code, 'body' => $body, 'error' => $error];
}
