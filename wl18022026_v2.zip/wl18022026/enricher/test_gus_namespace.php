<?php
/**
 * Test GUS BIR1 - różne kombinacje namespace
 * Problem: "Nieokreślone Parametry Wyszukiwania" = zły namespace
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test namespace GUS BIR1</h1><pre>";

$gusApiKey = 'b0f0e889eff5497cbea4';
$serviceUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';
$testNip = '7820009289'; // Talex

// === LOGOWANIE ===
echo "=== LOGOWANIE ===\n";

$loginEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $gusApiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $loginEnvelope);
$sid = extractValue($response['body'], 'ZalogujResult');

if (empty($sid)) {
    echo "❌ Brak SID\n";
    echo "Response: " . htmlspecialchars($response['body']) . "\n";
    exit;
}
echo "✅ SID: $sid\n";

// === TESTY RÓŻNYCH NAMESPACE ===
$tests = [
    // Test 1: dat namespace (DataContract)
    [
        'name' => 'dat:Nip (DataContract)',
        'envelope' => '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:Nip>' . $testNip . '</dat:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>'
    ],
    
    // Test 2: ns namespace wszędzie
    [
        'name' => 'ns:Nip (główny namespace)',
        'envelope' => '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <ns:Nip>' . $testNip . '</ns:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>'
    ],
    
    // Test 3: Bez namespace dla parametrów
    [
        'name' => 'Nip bez namespace',
        'envelope' => '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <Nip>' . $testNip . '</Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>'
    ],
    
    // Test 4: Default namespace dla parametrów
    [
        'name' => 'Default namespace na pParametryWyszukiwania',
        'envelope' => '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania xmlns="http://CIS/BIR/PUBL/2014/07/DataContract">
                <Nip>' . $testNip . '</Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>'
    ],
    
    // Test 5: bir namespace
    [
        'name' => 'bir:Nip',
        'envelope' => '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:bir="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <bir:DaneSzukajPodmioty>
            <bir:pParametryWyszukiwania>
                <dat:Nip>' . $testNip . '</dat:Nip>
            </bir:pParametryWyszukiwania>
        </bir:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>'
    ],
    
    // Test 6: Stara metoda DaneSzukaj zamiast DaneSzukajPodmioty
    [
        'name' => 'DaneSzukaj (stara metoda) + dat:Nip',
        'envelope' => '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukaj>
            <ns:pParametryWyszukiwania>
                <dat:Nip>' . $testNip . '</dat:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukaj>
    </soap:Body>
</soap:Envelope>'
    ],
    
    // Test 7: Kombinacja z przykładów GUS
    [
        'name' => 'Format z dokumentacji GUS',
        'envelope' => '<?xml version="1.0" encoding="utf-8"?>
<soap12:Envelope xmlns:soap12="http://www.w3.org/2003/05/soap-envelope" 
                 xmlns:ns="http://CIS/BIR/PUBL/2014/07"
                 xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap12:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap12:Header>
    <soap12:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:Nip>' . $testNip . '</dat:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap12:Body>
</soap12:Envelope>'
    ],
    
    // Test 8: Z i:type attribute
    [
        'name' => 'Z atrybutem i:type',
        'envelope' => '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract"
               xmlns:i="http://www.w3.org/2001/XMLSchema-instance">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania i:type="dat:ParametryWyszukiwania">
                <dat:Nip>' . $testNip . '</dat:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>'
    ],
];

foreach ($tests as $i => $test) {
    echo "\n=== TEST " . ($i+1) . ": {$test['name']} ===\n";
    
    $response = soapRequest($serviceUrl, $test['envelope'], $sid);
    echo "HTTP: {$response['code']}\n";
    
    // Sprawdź wynik
    $result = extractValue($response['body'], 'DaneSzukajPodmiotyResult');
    if (empty($result)) {
        $result = extractValue($response['body'], 'DaneSzukajResult');
    }
    
    if (!empty($result) && strpos($result, '<') !== false) {
        echo "✅ SUKCES! Otrzymano dane:\n";
        echo htmlspecialchars(substr($result, 0, 800)) . "\n";
        
        // Parsuj XML
        $xml = @simplexml_load_string($result);
        if ($xml && isset($xml->dane)) {
            echo "\n--- FIRMA ---\n";
            foreach ($xml->dane->children() as $key => $val) {
                if ((string)$val) echo "$key: $val\n";
            }
        }
        break; // Znaleźliśmy działający format!
    } else {
        echo "❌ Brak danych\n";
        
        // Sprawdź błąd
        if (strpos($response['body'], 'Fault') !== false) {
            echo "SOAP Fault w odpowiedzi\n";
        }
    }
}

// Wyloguj
$logoutEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Wyloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Wyloguj>
            <ns:pIdentyfikatorSesji>' . $sid . '</ns:pIdentyfikatorSesji>
        </ns:Wyloguj>
    </soap:Body>
</soap:Envelope>';
soapRequest($serviceUrl, $logoutEnvelope, $sid);
echo "\n✅ Wylogowano\n";

echo "</pre>";

function soapRequest($url, $envelope, $sid = null) {
    $headers = ['Content-Type: application/soap+xml; charset=utf-8'];
    if ($sid) $headers[] = 'sid: ' . $sid;
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $envelope,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $headers
    ]);
    
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return ['code' => $code, 'body' => $body];
}

function extractValue($xml, $tag) {
    if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
        return html_entity_decode($m[1]);
    }
    return '';
}
