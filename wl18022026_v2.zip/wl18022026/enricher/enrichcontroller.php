<?php
/**
 * EnrichController v4 - GUS BIR + API KRS MS
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json; charset=utf-8');

// === KONFIGURACJA ===
define('GUS_API_KEY', 'b0f0e889eff5497cbea4');

// Ścieżki
$dataDir = __DIR__ . '/data';
$sessionFile = $dataDir . '/session.json';
$inputFile = $dataDir . '/input.json';
$outputFile = $dataDir . '/output.csv';

// Utwórz katalog
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0777, true);
}

// Akcja
$action = $_GET['action'] ?? $_POST['action'] ?? 'status';

try {
    switch ($action) {
        case 'status':
            echo json_encode(loadSession($sessionFile), JSON_UNESCAPED_UNICODE);
            break;
            
        case 'test':
            require_once __DIR__ . '/CompanyEnricher.php';
            $enricher = new CompanyEnricher(GUS_API_KEY);
            $loginOk = $enricher->loginGUS();
            
            echo json_encode([
                'success' => true,
                'php_version' => PHP_VERSION,
                'gus_login' => $loginOk ? 'OK' : 'FAILED',
                'gus_key' => substr(GUS_API_KEY, 0, 8) . '...',
                'data_writable' => is_writable($dataDir)
            ], JSON_UNESCAPED_UNICODE);
            
            $enricher->logoutGUS();
            break;
            
        case 'upload':
            handleUpload($inputFile, $sessionFile, $outputFile);
            break;
            
        case 'process':
            handleProcess($inputFile, $sessionFile, $outputFile);
            break;
            
        case 'download':
            handleDownload($outputFile);
            break;
            
        case 'reset':
            @unlink($sessionFile);
            @unlink($inputFile);
            @unlink($outputFile);
            echo json_encode(['success' => true, 'message' => 'Reset OK']);
            break;
            
        default:
            echo json_encode(['error' => 'Unknown action']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'error' => $e->getMessage(),
        'file' => basename($e->getFile()),
        'line' => $e->getLine()
    ], JSON_UNESCAPED_UNICODE);
}

// ========== FUNKCJE ==========

function handleUpload($inputFile, $sessionFile, $outputFile) {
    if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Brak pliku lub błąd uploadu');
    }
    
    $content = file_get_contents($_FILES['file']['tmp_name']);
    if ($content === false) {
        throw new Exception('Nie można odczytać pliku');
    }
    
    // Konwertuj kodowanie
    $content = convertEncoding($content);
    
    // Parsuj CSV
    $companies = parseCSVContent($content);
    
    if (empty($companies)) {
        throw new Exception('Nie znaleziono firm w pliku');
    }
    
    // Zapisz
    $json = json_encode($companies, JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        throw new Exception('Błąd kodowania JSON: ' . json_last_error_msg());
    }
    
    file_put_contents($inputFile, $json);
    @unlink($outputFile);
    
    $session = [
        'status' => 'ready',
        'total' => count($companies),
        'processed' => 0,
        'success' => 0,
        'failed' => 0,
        'offset' => 0,
        'updated_at' => date('Y-m-d H:i:s')
    ];
    saveSession($sessionFile, $session);
    
    echo json_encode([
        'success' => true,
        'message' => 'Załadowano ' . count($companies) . ' firm',
        'session' => $session
    ], JSON_UNESCAPED_UNICODE);
}

function handleProcess($inputFile, $sessionFile, $outputFile) {
    $session = loadSession($sessionFile);
    
    if ($session['status'] === 'idle') {
        throw new Exception('Najpierw załaduj plik CSV');
    }
    
    if ($session['status'] === 'completed') {
        echo json_encode(['message' => 'Zakończone', 'session' => $session], JSON_UNESCAPED_UNICODE);
        return;
    }
    
    if (!file_exists($inputFile)) {
        throw new Exception('Brak pliku wejściowego');
    }
    
    $companies = json_decode(file_get_contents($inputFile), true);
    if (empty($companies)) {
        throw new Exception('Lista firm jest pusta');
    }
    
    // Aktualizuj status
    if ($session['status'] === 'ready') {
        $session['status'] = 'processing';
        $session['started_at'] = date('Y-m-d H:i:s');
    }
    
    // Inicjalizuj enricher
    require_once __DIR__ . '/CompanyEnricher.php';
    $enricher = new CompanyEnricher(GUS_API_KEY);
    $enricher->setDelay(1);
    
    if (!$enricher->loginGUS()) {
        throw new Exception('Nie można zalogować do GUS BIR');
    }
    
    // Przetwórz partię
    $batchSize = min(max(1, (int)($_POST['batch_size'] ?? 10)), 20);
    $result = $enricher->processBatch($companies, $session['offset'], $batchSize);
    
    // Wyloguj z GUS
    $enricher->logoutGUS();
    
    // Policz sukcesy/błędy
    $batchSuccess = 0;
    $batchFailed = 0;
    foreach ($result['results'] as $r) {
        if ($r['status'] === 'success') {
            $batchSuccess++;
        } else {
            $batchFailed++;
        }
    }
    
    // Zapisz do CSV
    $isNewFile = !file_exists($outputFile);
    $enricher->saveToCSV($result['results'], $outputFile, !$isNewFile);
    
    // Aktualizuj sesję
    $session['offset'] = $result['next_offset'];
    $session['processed'] += $result['processed'];
    $session['success'] += $batchSuccess;
    $session['failed'] += $batchFailed;
    $session['updated_at'] = date('Y-m-d H:i:s');
    
    if ($result['remaining'] <= 0) {
        $session['status'] = 'completed';
        $session['completed_at'] = date('Y-m-d H:i:s');
    }
    
    saveSession($sessionFile, $session);
    
    echo json_encode([
        'success' => true,
        'batch' => [
            'processed' => $result['processed'],
            'success' => $batchSuccess,
            'failed' => $batchFailed
        ],
        'session' => $session,
        'results' => $result['results']
    ], JSON_UNESCAPED_UNICODE);
}

function handleDownload($outputFile) {
    if (!file_exists($outputFile)) {
        throw new Exception('Brak pliku wyników');
    }
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="firmy_wzbogacone_' . date('Y-m-d') . '.csv"');
    readfile($outputFile);
    exit;
}

function convertEncoding($content) {
    $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
    
    if (mb_check_encoding($content, 'UTF-8') && !preg_match('/[\x80-\x9F]/', $content)) {
        return $content;
    }
    
    $converted = @iconv('Windows-1250', 'UTF-8//TRANSLIT//IGNORE', $content);
    return $converted !== false ? $converted : mb_convert_encoding($content, 'UTF-8', 'Windows-1250');
}

function parseCSVContent($content) {
    $lines = preg_split('/\r?\n/', $content);
    $companies = [];
    
    $firstLine = $lines[0] ?? '';
    $separator = (strpos($firstLine, ';') !== false) ? ';' : ',';
    
    $headers = str_getcsv($firstLine, $separator, '"', '\\');
    $headers = array_map('trim', $headers);
    
    for ($i = 1; $i < count($lines); $i++) {
        $line = trim($lines[$i]);
        if (empty($line)) continue;
        
        $row = str_getcsv($line, $separator, '"', '\\');
        if (empty($row[0])) continue;
        
        $company = [];
        foreach ($headers as $j => $header) {
            $company[$header] = isset($row[$j]) ? trim($row[$j]) : '';
        }
        
        if (!isset($company['Forma prawna'])) {
            $company['Forma prawna'] = '';
        }
        
        $companies[] = $company;
    }
    
    return $companies;
}

function loadSession($file) {
    if (file_exists($file)) {
        $data = json_decode(file_get_contents($file), true);
        if ($data) return $data;
    }
    return [
        'status' => 'idle',
        'total' => 0,
        'processed' => 0,
        'success' => 0,
        'failed' => 0,
        'offset' => 0
    ];
}

function saveSession($file, $data) {
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}
