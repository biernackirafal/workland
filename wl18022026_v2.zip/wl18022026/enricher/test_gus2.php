<?php
/**
 * Test GUS BIR API v2 - różne formaty zapytań
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test GUS BIR API v2</h1><pre>";

$testApiKey = 'abcde12345abcde12345';

// ŚRODOWISKO TESTOWE
$baseUrl = 'https://wyszukiwarkaregontest.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/';

// ŚRODOWISKO PRODUKCYJNE (odkomentuj jeśli masz klucz)
// $baseUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/';

echo "=== LOGOWANIE ===\n";

$ch = curl_init($baseUrl . 'Zaloguj');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['pKluczUzytkownika' => $testApiKey]),
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json']
]);
$response = curl_exec($ch);
curl_close($ch);

$data = json_decode($response, true);
$sid = $data['d'] ?? null;

if (!$sid) {
    echo "❌ Brak SID\n</pre>";
    exit;
}
echo "✅ SID: $sid\n";

// Test różnych metod wyszukiwania
$tests = [
    // Test 1: Szukaj po NIP (znany NIP z testu diagnostycznego)
    [
        'name' => 'Szukaj po NIP (7881994842 - Chemos)',
        'endpoint' => 'daneSzukajPodmioty',
        'data' => ['pParametryWyszukiwania' => ['Nip' => '7881994842']]
    ],
    // Test 2: Szukaj po REGON  
    [
        'name' => 'Szukaj po REGON (000454853 - Chemos)',
        'endpoint' => 'daneSzukajPodmioty',
        'data' => ['pParametryWyszukiwania' => ['Regon' => '000454853']]
    ],
    // Test 3: Szukaj po KRS
    [
        'name' => 'Szukaj po KRS (0000453434 - Chemos)',
        'endpoint' => 'daneSzukajPodmioty', 
        'data' => ['pParametryWyszukiwania' => ['Krs' => '0000453434']]
    ],
    // Test 4: Szukaj po nazwie - różne formaty
    [
        'name' => 'Szukaj po Nazwie (Chemos)',
        'endpoint' => 'daneSzukajPodmioty',
        'data' => ['pParametryWyszukiwania' => ['Nazwa' => 'Chemos']]
    ],
    // Test 5: DanePobierzPelnyRaport
    [
        'name' => 'Pobierz pełny raport po REGON',
        'endpoint' => 'DanePobierzPelnyRaport',
        'data' => ['pRegon' => '000454853', 'pNazwaRaportu' => 'BIR11OsPrawna']
    ],
];

foreach ($tests as $i => $test) {
    echo "\n=== TEST " . ($i+1) . ": {$test['name']} ===\n";
    
    $ch = curl_init($baseUrl . $test['endpoint']);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($test['data']),
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'sid: ' . $sid
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    echo "HTTP: $httpCode\n";
    
    $data = json_decode($response, true);
    $result = $data['d'] ?? '';
    
    if (empty($result)) {
        echo "❌ Pusta odpowiedź\n";
    } else if (strpos($result, '<') !== false) {
        echo "✅ Odpowiedź XML:\n";
        echo htmlspecialchars(substr($result, 0, 1500)) . "\n";
        
        // Parsuj XML
        $xml = @simplexml_load_string($result);
        if ($xml && isset($xml->dane)) {
            echo "\n--- DANE FIRMY ---\n";
            foreach ($xml->dane as $firma) {
                foreach ($firma->children() as $key => $value) {
                    if (!empty((string)$value)) {
                        echo "$key: $value\n";
                    }
                }
            }
        }
    } else {
        echo "Odpowiedź: " . htmlspecialchars(substr($result, 0, 500)) . "\n";
    }
}

// Sprawdź status ostatniego błędu
echo "\n=== STATUS BŁĘDU ===\n";
$ch = curl_init($baseUrl . 'GetValue');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['pNazwaParametru' => 'KomunikatBledu']),
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'sid: ' . $sid]
]);
$response = curl_exec($ch);
curl_close($ch);
$data = json_decode($response, true);
echo "Komunikat błędu: " . ($data['d'] ?? 'brak') . "\n";

echo "\n</pre>";
