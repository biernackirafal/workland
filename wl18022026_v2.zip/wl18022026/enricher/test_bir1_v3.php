<?php
/**
 * Test GUS BIR1 v3 - z komunikatami błędów
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test GUS BIR1 v3</h1><pre>";

$gusApiKey = 'b0f0e889eff5497cbea4';
$serviceUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';

// === LOGOWANIE ===
echo "=== LOGOWANIE ===\n";

$loginEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $gusApiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $loginEnvelope, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj');
$sid = extractValue($response['body'], 'ZalogujResult');

if (empty($sid)) {
    echo "❌ Brak SID\n";
    echo "</pre>";
    exit;
}
echo "✅ SID: $sid\n";

// === POBIERZ KOMUNIKAT BŁĘDU (przed wyszukiwaniem) ===
echo "\n=== STATUS PRZED WYSZUKIWANIEM ===\n";
checkStatus($serviceUrl, $sid);

// === TEST 1: Wyszukiwanie bez DataContract namespace ===
echo "\n=== TEST 1: Wyszukiwanie (bez DataContract) ===\n";

$search1 = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukaj>
            <ns:pParametryWyszukiwania>
                <ns:Regon>630303246</ns:Regon>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukaj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $search1, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj', $sid);
$result = extractValue($response['body'], 'DaneSzukajResult');
echo "Wynik: " . (empty($result) ? "PUSTE" : htmlspecialchars(substr($result, 0, 500))) . "\n";
checkStatus($serviceUrl, $sid);

// === TEST 2: Z pełnym namespace dat ===
echo "\n=== TEST 2: Z namespace dat ===\n";

$search2 = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukaj>
            <ns:pParametryWyszukiwania>
                <dat:Regon>630303246</dat:Regon>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukaj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $search2, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj', $sid);
$result = extractValue($response['body'], 'DaneSzukajResult');
echo "Wynik: " . (empty($result) ? "PUSTE" : htmlspecialchars(substr($result, 0, 500))) . "\n";
checkStatus($serviceUrl, $sid);

// === TEST 3: Regony9zn zamiast Regon ===
echo "\n=== TEST 3: Regony9zn ===\n";

$search3 = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukaj>
            <ns:pParametryWyszukiwania>
                <dat:Regony9zn>630303246</dat:Regony9zn>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukaj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $search3, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj', $sid);
$result = extractValue($response['body'], 'DaneSzukajResult');
echo "Wynik: " . (empty($result) ? "PUSTE" : htmlspecialchars(substr($result, 0, 500))) . "\n";
checkStatus($serviceUrl, $sid);

// === TEST 4: NIP ===
echo "\n=== TEST 4: Nip ===\n";

$search4 = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukaj>
            <ns:pParametryWyszukiwania>
                <dat:Nip>7820009289</dat:Nip>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukaj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $search4, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj', $sid);
$result = extractValue($response['body'], 'DaneSzukajResult');
echo "Wynik: " . (empty($result) ? "PUSTE" : htmlspecialchars(substr($result, 0, 500))) . "\n";
checkStatus($serviceUrl, $sid);

// === TEST 5: Środowisko TESTOWE dla porównania ===
echo "\n=== TEST 5: ŚRODOWISKO TESTOWE (dla porównania) ===\n";

$testUrl = 'https://wyszukiwarkaregontest.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';
$testKey = 'abcde12345abcde12345';

$loginTest = str_replace([$serviceUrl, $gusApiKey], [$testUrl, $testKey], $loginEnvelope);
$response = soapRequest($testUrl, $loginTest, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj');
$testSid = extractValue($response['body'], 'ZalogujResult');

if ($testSid) {
    echo "Test SID: $testSid\n";
    
    $searchTest = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $testUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukaj>
            <ns:pParametryWyszukiwania>
                <dat:Regon>000454853</dat:Regon>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukaj>
    </soap:Body>
</soap:Envelope>';

    $response = soapRequest($testUrl, $searchTest, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukaj', $testSid);
    $result = extractValue($response['body'], 'DaneSzukajResult');
    echo "Wynik TESTOWY: " . (empty($result) ? "PUSTE" : "DANE!") . "\n";
    if (!empty($result)) {
        echo htmlspecialchars(substr($result, 0, 800)) . "\n";
    }
}

echo "\n</pre>";

// === FUNKCJE ===

function soapRequest($url, $envelope, $action, $sid = null) {
    $headers = [
        'Content-Type: application/soap+xml; charset=utf-8'
    ];
    
    if ($sid) {
        $headers[] = 'sid: ' . $sid;
    }
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $envelope,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => $headers
    ]);
    
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return ['code' => $code, 'body' => $body];
}

function extractValue($xml, $tag) {
    if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
        return html_entity_decode($m[1]);
    }
    if (preg_match('/<' . $tag . '[^>]*\/>/s', $xml)) {
        return ''; // Empty self-closing tag
    }
    return '';
}

function checkStatus($url, $sid) {
    // Pobierz GetValue - KomunikatBledu
    $getValueEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $url . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/GetValue</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:GetValue>
            <ns:pNazwaParametru>KomunikatBledu</ns:pNazwaParametru>
        </ns:GetValue>
    </soap:Body>
</soap:Envelope>';

    $response = soapRequest($url, $getValueEnvelope, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/GetValue', $sid);
    $error = extractValue($response['body'], 'GetValueResult');
    echo "KomunikatBledu: " . ($error ?: "(brak)") . "\n";
    
    // StatusSesji
    $getValueEnvelope2 = str_replace('KomunikatBledu', 'StatusSesji', $getValueEnvelope);
    $response = soapRequest($url, $getValueEnvelope2, 'http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/GetValue', $sid);
    $status = extractValue($response['body'], 'GetValueResult');
    echo "StatusSesji: " . ($status ?: "(brak)") . "\n";
}
