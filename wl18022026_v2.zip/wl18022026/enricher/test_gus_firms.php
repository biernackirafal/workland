<?php
/**
 * Test GUS BIR1 - sprawdzenie różnych NIP/REGON
 * Format: dat:Nip (DataContract) - działa!
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test GUS - różne firmy</h1><pre>";

$gusApiKey = 'b0f0e889eff5497cbea4';
$serviceUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';

// Znane NIP-y dużych firm
$testCases = [
    ['type' => 'Nip', 'value' => '5261040828', 'name' => 'PKN Orlen'],
    ['type' => 'Nip', 'value' => '5250007738', 'name' => 'PKO BP'],
    ['type' => 'Nip', 'value' => '5213017228', 'name' => 'PZU'],
    ['type' => 'Nip', 'value' => '7781454968', 'name' => 'Allegro'],
    ['type' => 'Nip', 'value' => '7811767828', 'name' => 'Żabka'],
    ['type' => 'Regon', 'value' => '630303246', 'name' => 'Talex (REGON)'],
    ['type' => 'Regon', 'value' => '610188201', 'name' => 'PKN Orlen (REGON)'],
    ['type' => 'Krs', 'value' => '0000028860', 'name' => 'PKN Orlen (KRS)'],
];

// === LOGOWANIE ===
echo "=== LOGOWANIE ===\n";

$loginEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $gusApiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $loginEnvelope);
$sid = extractValue($response['body'], 'ZalogujResult');

if (empty($sid)) {
    echo "❌ Brak SID\n";
    exit;
}
echo "✅ SID: $sid\n\n";

// === TESTY ===
foreach ($testCases as $test) {
    echo "=== {$test['name']} ({$test['type']}: {$test['value']}) ===\n";
    
    $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:' . $test['type'] . '>' . $test['value'] . '</dat:' . $test['type'] . '>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';

    $response = soapRequest($serviceUrl, $envelope, $sid);
    $result = extractValue($response['body'], 'DaneSzukajPodmiotyResult');
    
    if (!empty($result)) {
        $xml = @simplexml_load_string($result);
        if ($xml && isset($xml->dane)) {
            $errorCode = (string)($xml->dane->ErrorCode ?? '');
            if ($errorCode && $errorCode !== '0') {
                echo "❌ ErrorCode: $errorCode\n";
            } else {
                echo "✅ ZNALEZIONO!\n";
                echo "   Nazwa: " . ($xml->dane->Nazwa ?? 'brak') . "\n";
                echo "   REGON: " . ($xml->dane->Regon ?? 'brak') . "\n";
                echo "   NIP: " . ($xml->dane->Nip ?? 'brak') . "\n";
                echo "   Miejscowość: " . ($xml->dane->Miejscowosc ?? 'brak') . "\n";
            }
        }
    } else {
        echo "❌ Pusta odpowiedź\n";
    }
    echo "\n";
}

// === TEST NAZWY ===
echo "=== TEST: Szukanie po nazwie 'ORLEN' ===\n";

$envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:Nazwa>ORLEN</dat:Nazwa>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $envelope, $sid);
$result = extractValue($response['body'], 'DaneSzukajPodmiotyResult');

if (!empty($result)) {
    $xml = @simplexml_load_string($result);
    if ($xml && isset($xml->dane)) {
        $errorCode = (string)($xml->dane->ErrorCode ?? '');
        if ($errorCode && $errorCode !== '0') {
            echo "❌ ErrorCode: $errorCode - " . ($xml->dane->ErrorMessagePl ?? '') . "\n";
        } else {
            $count = count($xml->dane);
            echo "✅ Znaleziono $count wyników!\n";
            foreach ($xml->dane as $i => $firma) {
                if ($i >= 3) { echo "   ... i więcej\n"; break; }
                echo "   - " . ($firma->Nazwa ?? 'brak') . " (NIP: " . ($firma->Nip ?? '-') . ")\n";
            }
        }
    }
} else {
    echo "❌ Pusta odpowiedź\n";
}

// Wyloguj
echo "\n✅ Wylogowano\n";
echo "</pre>";

function soapRequest($url, $envelope, $sid = null) {
    $headers = ['Content-Type: application/soap+xml; charset=utf-8'];
    if ($sid) $headers[] = 'sid: ' . $sid;
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $envelope,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $headers
    ]);
    
    $body = curl_exec($ch);
    curl_close($ch);
    
    return ['body' => $body];
}

function extractValue($xml, $tag) {
    if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
        return html_entity_decode($m[1]);
    }
    return '';
}
