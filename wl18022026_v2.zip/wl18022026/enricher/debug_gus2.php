<?php
/**
 * Debug GUS v2 - testuje różne endpointy i wersje API
 */

header('Content-Type: text/html; charset=utf-8');

$gusApiKey = 'b0f0e889eff5497cbea4';

echo "<h1>🔍 Debug GUS v2 - różne endpointy</h1><pre>";

$baseUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/';

// === LOGOWANIE ===
echo "=== LOGOWANIE ===\n";
$loginResponse = post($baseUrl . 'Zaloguj', json_encode(['pKluczUzytkownika' => $gusApiKey]));
echo "Response: {$loginResponse['body']}\n";

$data = json_decode($loginResponse['body'], true);
$sid = $data['d'] ?? null;

if (!$sid) {
    echo "❌ Brak SID\n</pre>";
    exit;
}
echo "✅ SID: $sid\n";

// === SPRAWDŹ STATUS SESJI ===
echo "\n=== STATUS SESJI ===\n";

$statusParams = ['StanDanych', 'StatusSesji', 'KomunikatBledu', 'KomunikatUslugi'];
foreach ($statusParams as $param) {
    $resp = post($baseUrl . 'GetValue', json_encode(['pNazwaParametru' => $param]), $sid);
    $d = json_decode($resp['body'], true);
    echo "$param: " . ($d['d'] ?? 'błąd') . "\n";
}

// === TEST RÓŻNYCH ENDPOINTÓW WYSZUKIWANIA ===
echo "\n=== TEST ENDPOINTÓW ===\n";

$regon = '630303246'; // Talex
$nip = '7820009289'; // Talex NIP

$endpoints = [
    // Endpoint 1: daneSzukajPodmioty (nowy)
    [
        'name' => 'daneSzukajPodmioty + Regon',
        'url' => $baseUrl . 'daneSzukajPodmioty',
        'data' => ['pParametryWyszukiwania' => ['Regon' => $regon]]
    ],
    // Endpoint 2: daneSzukaj (stary?)
    [
        'name' => 'daneSzukaj + Regon',
        'url' => $baseUrl . 'daneSzukaj',
        'data' => ['pParametryWyszukiwania' => ['Regon' => $regon]]
    ],
    // Endpoint 3: DaneSzukajPodmioty (inna wielkość liter)
    [
        'name' => 'DaneSzukajPodmioty',
        'url' => $baseUrl . 'DaneSzukajPodmioty',
        'data' => ['pParametryWyszukiwania' => ['Regon' => $regon]]
    ],
    // Endpoint 4: szukaj z NIP
    [
        'name' => 'daneSzukajPodmioty + Nip',
        'url' => $baseUrl . 'daneSzukajPodmioty',
        'data' => ['pParametryWyszukiwania' => ['Nip' => $nip]]
    ],
    // Endpoint 5: szukaj z Nipy (liczba mnoga)
    [
        'name' => 'daneSzukajPodmioty + Nipy',
        'url' => $baseUrl . 'daneSzukajPodmioty',
        'data' => ['pParametryWyszukiwania' => ['Nipy' => $nip]]
    ],
    // Endpoint 6: szukaj z Regony9zn
    [
        'name' => 'daneSzukajPodmioty + Regony9zn',
        'url' => $baseUrl . 'daneSzukajPodmioty',
        'data' => ['pParametryWyszukiwania' => ['Regony9zn' => $regon]]
    ],
    // Endpoint 7: DanePobierzPelnyRaport bezpośrednio
    [
        'name' => 'DanePobierzPelnyRaport',
        'url' => $baseUrl . 'DanePobierzPelnyRaport',
        'data' => ['pRegon' => $regon, 'pNazwaRaportu' => 'BIR11OsPrawna']
    ],
    // Endpoint 8: DanePobierzRaportZbiorczy
    [
        'name' => 'DanePobierzRaportZbiorczy',
        'url' => $baseUrl . 'DanePobierzRaportZbiorczy',
        'data' => ['pRegon' => $regon, 'pNazwaRaportu' => 'BIR11OsPrawna']
    ],
];

foreach ($endpoints as $i => $test) {
    echo "\n--- TEST " . ($i+1) . ": {$test['name']} ---\n";
    
    $resp = post($test['url'], json_encode($test['data']), $sid);
    echo "HTTP: {$resp['code']}\n";
    
    $data = json_decode($resp['body'], true);
    $result = $data['d'] ?? '';
    
    if (empty($result)) {
        echo "❌ Pusta odpowiedź\n";
        
        // Sprawdź błąd
        $errResp = post($baseUrl . 'GetValue', json_encode(['pNazwaParametru' => 'KomunikatBledu']), $sid);
        $errData = json_decode($errResp['body'], true);
        $err = $errData['d'] ?? '';
        if ($err && strpos($err, 'Invalid') === false) {
            echo "Błąd GUS: $err\n";
        }
    } else if (strpos($result, 'ErrorCode') !== false && strpos($result, '>0<') === false) {
        echo "⚠️ Błąd w odpowiedzi\n";
        echo htmlspecialchars(substr($result, 0, 400)) . "\n";
    } else if (strpos($result, '<dane>') !== false || strpos($result, '<root>') !== false) {
        echo "✅ ODPOWIEDŹ:\n";
        echo htmlspecialchars(substr($result, 0, 1000)) . "\n";
    } else {
        echo "? " . htmlspecialchars(substr($result, 0, 300)) . "\n";
    }
}

// === TEST NA ŚRODOWISKU TESTOWYM DLA PORÓWNANIA ===
echo "\n\n=== PORÓWNANIE: ŚRODOWISKO TESTOWE ===\n";
$testBaseUrl = 'https://wyszukiwarkaregontest.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/';
$testKey = 'abcde12345abcde12345';

$loginResp = post($testBaseUrl . 'Zaloguj', json_encode(['pKluczUzytkownika' => $testKey]));
$testData = json_decode($loginResp['body'], true);
$testSid = $testData['d'] ?? null;

if ($testSid) {
    echo "Testowy SID: $testSid\n";
    
    // Ten sam REGON na środowisku testowym
    $resp = post($testBaseUrl . 'daneSzukajPodmioty', 
        json_encode(['pParametryWyszukiwania' => ['Regon' => '000454853']]), // Chemos z testu
        $testSid
    );
    $data = json_decode($resp['body'], true);
    echo "Test Regon 000454853 (środowisko testowe):\n";
    echo htmlspecialchars(substr($data['d'] ?? '', 0, 500)) . "\n";
}

echo "\n</pre>";

function post($url, $data, $sid = null) {
    $ch = curl_init($url);
    $headers = ['Content-Type: application/json'];
    if ($sid) $headers[] = 'sid: ' . $sid;
    
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $headers
    ]);
    
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    return ['code' => $code, 'body' => $body];
}
