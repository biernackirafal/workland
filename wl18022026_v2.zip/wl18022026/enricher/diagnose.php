<?php
/**
 * Diagnostyka połączeń - sprawdza czy serwer może łączyć się z API
 */

header('Content-Type: text/html; charset=utf-8');

echo "<h1>🔍 Diagnostyka połączeń</h1>";
echo "<pre style='background:#f5f5f5; padding:15px; font-size:14px;'>";

// 1. Info o PHP
echo "=== PHP INFO ===\n";
echo "PHP Version: " . PHP_VERSION . "\n";
echo "cURL enabled: " . (function_exists('curl_init') ? 'TAK' : 'NIE') . "\n";
echo "allow_url_fopen: " . ini_get('allow_url_fopen') . "\n";
echo "\n";

// 2. Test podstawowy - Google
echo "=== TEST 1: Google (podstawowy) ===\n";
$result = testUrl('https://www.google.com', 'GET');
printResult($result);

// 3. Test API KRS - wyszukiwarka
echo "\n=== TEST 2: Wyszukiwarka KRS MS ===\n";
$postData = json_encode([
    'nazwaLubNumer' => 'Chemos',
    'stronicowanie' => ['iloscWynikowNaStronie' => 5, 'numerStrony' => 0]
]);
$result = testUrl('https://wyszukiwarka-krs.ms.gov.pl/api/wyszukaj', 'POST', $postData, [
    'Content-Type: application/json',
    'Accept: application/json'
]);
printResult($result);

// 4. Test API KRS - odpis
echo "\n=== TEST 3: API KRS MS (odpis) ===\n";
$result = testUrl('https://api-krs.ms.gov.pl/api/krs/OdpisAktualny/0000453434?rejestr=P&format=json', 'GET', null, [
    'Accept: application/json'
]);
printResult($result);

// 5. Test rejestr.io
echo "\n=== TEST 4: Rejestr.io ===\n";
$result = testUrl('https://rejestr.io/szukaj?q=Chemos', 'GET');
printResult($result);

// 6. Test Portal Rejestrów Sądowych
echo "\n=== TEST 5: Portal Rejestrów Sądowych API ===\n";
$result = testUrl('https://prs.ms.gov.pl/krs/openApi', 'GET');
printResult($result);

echo "</pre>";

// === FUNKCJE ===

function testUrl($url, $method = 'GET', $postData = null, $headers = []) {
    $ch = curl_init();
    
    $defaultHeaders = [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language: pl-PL,pl;q=0.9'
    ];
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => array_merge($defaultHeaders, $headers),
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HEADER => true
    ]);
    
    if ($method === 'POST' && $postData) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $errno = curl_errno($ch);
    $headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    
    curl_close($ch);
    
    $headers = substr($response, 0, $headerSize);
    $body = substr($response, $headerSize);
    
    return [
        'url' => $url,
        'method' => $method,
        'http_code' => $httpCode,
        'error' => $error,
        'errno' => $errno,
        'body_length' => strlen($body),
        'body_preview' => substr($body, 0, 500),
        'response_headers' => $headers
    ];
}

function printResult($result) {
    echo "URL: {$result['url']}\n";
    echo "Method: {$result['method']}\n";
    echo "HTTP Code: {$result['http_code']}\n";
    
    if ($result['error']) {
        echo "❌ CURL Error [{$result['errno']}]: {$result['error']}\n";
    } else {
        echo "✅ Połączenie OK\n";
    }
    
    echo "Response length: {$result['body_length']} bytes\n";
    
    if ($result['body_length'] > 0) {
        echo "Preview: " . htmlspecialchars(substr($result['body_preview'], 0, 200)) . "...\n";
    }
}
