<?php
/**
 * Test GUS - NazwaPodmiotu (działający parametr!)
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test GUS - NazwaPodmiotu</h1><pre>";

$gusApiKey = 'b0f0e889eff5497cbea4';
$serviceUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc';

// === LOGOWANIE ===
$loginEnvelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:ns="http://CIS/BIR/PUBL/2014/07">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/Zaloguj</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:Zaloguj>
            <ns:pKluczUzytkownika>' . $gusApiKey . '</ns:pKluczUzytkownika>
        </ns:Zaloguj>
    </soap:Body>
</soap:Envelope>';

$response = soapRequest($serviceUrl, $loginEnvelope);
$sid = extractValue($response['body'], 'ZalogujResult');
echo "✅ SID: $sid\n\n";

// Testy wyszukiwania
$searchTerms = [
    'Finansowy Broker',
    'Finansowy Broker Rafał Biernacki',
    'Rafał Biernacki',
    'Work Land',
    'WORK LAND',
    'Chemos',
    'CHEMOS',
    'Merazet',
    'MERAZET',
    'Agrobex',
    'AGROBEX',
    'Talex',
    'TALEX',
];

foreach ($searchTerms as $term) {
    echo "=== Szukam: '$term' ===\n";
    
    $envelope = '<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" 
               xmlns:ns="http://CIS/BIR/PUBL/2014/07"
               xmlns:dat="http://CIS/BIR/PUBL/2014/07/DataContract">
    <soap:Header xmlns:wsa="http://www.w3.org/2005/08/addressing">
        <wsa:To>' . $serviceUrl . '</wsa:To>
        <wsa:Action>http://CIS/BIR/PUBL/2014/07/IUslugaBIRzewnPubl/DaneSzukajPodmioty</wsa:Action>
    </soap:Header>
    <soap:Body>
        <ns:DaneSzukajPodmioty>
            <ns:pParametryWyszukiwania>
                <dat:NazwaPodmiotu>' . htmlspecialchars($term) . '</dat:NazwaPodmiotu>
            </ns:pParametryWyszukiwania>
        </ns:DaneSzukajPodmioty>
    </soap:Body>
</soap:Envelope>';

    $response = soapRequest($serviceUrl, $envelope, $sid);
    $result = extractValue($response['body'], 'DaneSzukajPodmiotyResult');
    
    if (!empty($result) && strpos($result, '<') !== false) {
        $xml = @simplexml_load_string($result);
        if ($xml && isset($xml->dane)) {
            $errorCode = (string)($xml->dane->ErrorCode ?? '');
            if ($errorCode && $errorCode !== '0') {
                echo "❌ Nie znaleziono\n";
            } else {
                $count = 0;
                foreach ($xml->dane as $firma) {
                    $count++;
                    if ($count <= 5) {
                        $nazwa = (string)($firma->Nazwa ?? '');
                        $regon = (string)($firma->Regon ?? '');
                        $nip = (string)($firma->Nip ?? '');
                        $miasto = (string)($firma->Miejscowosc ?? '');
                        $typ = (string)($firma->Typ ?? '');
                        echo "✅ $nazwa\n";
                        echo "   NIP: $nip | REGON: $regon | $miasto | Typ: $typ\n";
                    }
                }
                if ($count > 5) {
                    echo "   ... i " . ($count - 5) . " więcej wyników\n";
                }
                echo "Razem: $count wyników\n";
            }
        }
    } else {
        echo "❌ Pusta odpowiedź\n";
    }
    echo "\n";
}

echo "</pre>";

function soapRequest($url, $envelope, $sid = null) {
    $headers = ['Content-Type: application/soap+xml; charset=utf-8'];
    if ($sid) $headers[] = 'sid: ' . $sid;
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $envelope,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => $headers
    ]);
    
    $body = curl_exec($ch);
    curl_close($ch);
    
    return ['body' => $body];
}

function extractValue($xml, $tag) {
    if (preg_match('/<' . $tag . '>(.+?)<\/' . $tag . '>/s', $xml, $m)) {
        return html_entity_decode($m[1]);
    }
    return '';
}
