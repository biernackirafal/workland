<?php
/**
 * Test GUS BIR API - wyszukiwanie firm po nazwie
 * Testowy klucz: abcde12345abcde12345
 */

header('Content-Type: text/html; charset=utf-8');
echo "<h1>🔍 Test GUS BIR API</h1><pre>";

// Testowy klucz API GUS (działa na środowisku testowym)
$testApiKey = 'abcde12345abcde12345';
$searchName = 'Chemos';

// Środowisko testowe
$loginUrl = 'https://wyszukiwarkaregontest.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/Zaloguj';
$searchUrl = 'https://wyszukiwarkaregontest.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/daneSzukajPodmioty';

// Środowisko produkcyjne (wymaga własnego klucza)
// $loginUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/Zaloguj';
// $searchUrl = 'https://wyszukiwarkaregon.stat.gov.pl/wsBIR/UslugaBIRzewnPubl.svc/ajaxEndpoint/daneSzukajPodmioty';

echo "=== KROK 1: Logowanie do GUS BIR ===\n";

$loginData = json_encode(['pKluczUzytkownika' => $testApiKey]);

$ch = curl_init($loginUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $loginData,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Accept: application/json'
    ]
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "URL: $loginUrl\n";
echo "HTTP Code: $httpCode\n";

if ($error) {
    echo "❌ CURL Error: $error\n";
    echo "</pre>";
    exit;
}

echo "Response: $response\n";

// Parsuj SID z odpowiedzi
$data = json_decode($response, true);
$sid = $data['d'] ?? null;

if (!$sid) {
    echo "❌ Nie udało się uzyskać SID\n";
    echo "</pre>";
    exit;
}

echo "✅ SID: $sid\n";

echo "\n=== KROK 2: Wyszukiwanie firmy '$searchName' ===\n";

// Parametry wyszukiwania
$searchParams = json_encode([
    'pParametryWyszukiwania' => [
        'Nazwa' => $searchName
    ]
]);

$ch = curl_init($searchUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => $searchParams,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Accept: application/json',
        'sid: ' . $sid
    ]
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

echo "URL: $searchUrl\n";
echo "HTTP Code: $httpCode\n";

if ($error) {
    echo "❌ CURL Error: $error\n";
} else {
    echo "✅ Połączenie OK\n";
    echo "\nResponse:\n";
    
    $data = json_decode($response, true);
    if (isset($data['d'])) {
        // Odpowiedź jest w XML wewnątrz JSON
        $xml = $data['d'];
        echo htmlspecialchars(substr($xml, 0, 2000)) . "\n";
        
        // Parsuj XML
        if ($xml && strpos($xml, '<') !== false) {
            $xmlDoc = @simplexml_load_string($xml);
            if ($xmlDoc) {
                echo "\n=== ZNALEZIONE FIRMY ===\n";
                foreach ($xmlDoc->dane as $firma) {
                    echo "\nNazwa: " . ($firma->Nazwa ?? 'brak') . "\n";
                    echo "NIP: " . ($firma->Nip ?? 'brak') . "\n";
                    echo "REGON: " . ($firma->Regon ?? 'brak') . "\n";
                    echo "Adres: " . ($firma->Ulica ?? '') . " " . ($firma->NrNieruchomosci ?? '') . ", ";
                    echo ($firma->KodPocztowy ?? '') . " " . ($firma->Miejscowosc ?? '') . "\n";
                }
            }
        }
    } else {
        echo htmlspecialchars($response) . "\n";
    }
}

echo "\n</pre>";
