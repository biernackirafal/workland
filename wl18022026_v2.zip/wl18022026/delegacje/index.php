<?php
/**
 * Moduł Delegacji - Lista delegacji
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Filtry
$miesiac = isset($_GET['miesiac']) ? (int)$_GET['miesiac'] : (int)date('m');
$rok = isset($_GET['rok']) ? (int)$_GET['rok'] : (int)date('Y');
$pracownikFilter = $_GET['pracownik'] ?? '';

// Pobierz pracowników do filtra
$pracownicy = $db->query("SELECT id, imie, nazwisko, kod FROM pracownicy WHERE data_zwolnienia IS NULL OR data_zwolnienia = '' ORDER BY nazwisko, imie")->fetchAll();

// Pobierz delegacje
$where = ["d.rok = ? AND d.miesiac = ?"];
$params = [$rok, $miesiac];

if ($pracownikFilter) {
    $where[] = "d.pracownik_id = ?";
    $params[] = $pracownikFilter;
}

$whereClause = implode(' AND ', $where);

$stmt = $db->prepare("
    SELECT d.*, 
           p.imie, p.nazwisko, p.kod as pracownik_kod,
           l.nazwa as lokalizacja_nazwa, l.kilometry,
           u.name as utworzyl
    FROM delegacje d
    JOIN pracownicy p ON d.pracownik_id = p.id
    JOIN delegacje_lokalizacje l ON d.lokalizacja_id = l.id
    LEFT JOIN users u ON d.created_by = u.id
    WHERE $whereClause
    ORDER BY p.nazwisko, p.imie
");
$stmt->execute($params);
$delegacje = $stmt->fetchAll();

// Pobierz zakresy dla każdej delegacji
foreach ($delegacje as &$del) {
    $zakresyStmt = $db->prepare("SELECT * FROM delegacje_zakresy WHERE delegacja_id = ? ORDER BY data_od");
    $zakresyStmt->execute([$del['id']]);
    $del['zakresy'] = $zakresyStmt->fetchAll();
    $del['dni'] = obliczDniDelegacji($del['zakresy']);
    $del['noclegi'] = obliczNoclegi($del['zakresy']);
    $del['zakresy_tekst'] = formatujZakresy($del['zakresy']);
    $del['wyjazdy'] = count($del['zakresy']); // każdy zakres = jeden wyjazd
}

// Usuwanie delegacji
if (isset($_POST['action']) && $_POST['action'] === 'delete') {
    $delId = (int)$_POST['delegacja_id'];
    $db->prepare("DELETE FROM delegacje WHERE id = ?")->execute([$delId]);
    header("Location: index.php?miesiac=$miesiac&rok=$rok&msg=deleted");
    exit;
}

$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delegacje - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #7c3aed; color: white; }
        
        header { margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; }
        
        .filters-card { background: white; padding: 18px 22px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); }
        .filters-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.8rem; color: #64748b; font-weight: 600; }
        .filter-group select, .filter-group input { padding: 10px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; min-width: 140px; }
        
        .btn { padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-secondary { background: #f1f5f9; color: #374151; }
        .btn-danger { background: #dc2626; color: white; }
        .btn-small { padding: 6px 12px; font-size: 0.8rem; }
        
        .stats-bar { display: flex; gap: 15px; flex-wrap: wrap; margin-bottom: 25px; }
        .stat-box { background: white; padding: 18px; border-radius: 10px; min-width: 130px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); text-align: center; }
        .stat-box .value { font-size: 1.8rem; font-weight: 700; }
        .stat-box .label { font-size: 0.8rem; color: #64748b; margin-top: 5px; }
        
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 12px 15px; background: #f8fafc; color: #64748b; font-size: 0.8rem; font-weight: 600; text-transform: uppercase; }
        td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; }
        tr:hover { background: #f8fafc; }
        
        .badge { display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
        .badge-draft { background: #fef3c7; color: #d97706; }
        .badge-gotowe { background: #dcfce7; color: #16a34a; }
        
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; border-left: 4px solid #16a34a; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../crm/">🎯 CRM</a>
                <a href="../kandydaci/">👥 Kandydaci</a>
                <a href="./" class="active">🚗 Delegacje</a>
                <a href="lokalizacje.php">📍 Lokalizacje</a>
            </div>
        </nav>
        
        <?php if (isset($_GET['msg'])): ?>
            <div class="alert alert-success">
                <?php if ($_GET['msg'] === 'created'): ?>✅ Delegacja została utworzona<?php endif; ?>
                <?php if ($_GET['msg'] === 'deleted'): ?>✅ Delegacja została usunięta<?php endif; ?>
            </div>
        <?php endif; ?>
        
        <header>
            <div>
                <h1>🚗 Delegacje</h1>
                <p style="color: #64748b; margin: 0;"><?= $miesiacNazwy[$miesiac] ?> <?= $rok ?></p>
            </div>
            <a href="dodaj.php" class="btn btn-primary">➕ Nowa delegacja</a>
        </header>
        
        <!-- Filtry -->
        <div class="filters-card">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group">
                        <label>Miesiąc</label>
                        <select name="miesiac">
                            <?php for ($m = 1; $m <= 12; $m++): ?>
                                <option value="<?= $m ?>" <?= $m == $miesiac ? 'selected' : '' ?>><?= $miesiacNazwy[$m] ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Rok</label>
                        <select name="rok">
                            <?php for ($y = date('Y') - 2; $y <= date('Y') + 1; $y++): ?>
                                <option value="<?= $y ?>" <?= $y == $rok ? 'selected' : '' ?>><?= $y ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Pracownik</label>
                        <select name="pracownik">
                            <option value="">-- wszyscy --</option>
                            <?php foreach ($pracownicy as $pr): ?>
                                <option value="<?= $pr['id'] ?>" <?= $pracownikFilter == $pr['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($pr['nazwisko'] . ' ' . $pr['imie']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">Filtruj</button>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- Statystyki -->
        <?php 
        $sumaDni = 0;
        $sumaKwot = 0;
        foreach ($delegacje as $d) {
            $sumaDni += $d['dni'];
            $dieta = $d['dni'] * $d['dieta_stawka'];
            $przejazdy = $d['kilometry'] * 2 * $d['wyjazdy'] * $d['stawka_km']; // wyjazdy, nie dni!
            $noclegi = $d['noclegi'] * $d['noclegi_stawka'];
            $sumaKwot += $dieta + $przejazdy + $noclegi;
        }
        ?>
        <div class="stats-bar">
            <div class="stat-box">
                <div class="value" style="color: #1e293b;"><?= count($delegacje) ?></div>
                <div class="label">Delegacji</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #2563eb;"><?= $sumaDni ?></div>
                <div class="label">Dni łącznie</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #16a34a;"><?= number_format($sumaKwot, 0, ',', ' ') ?> zł</div>
                <div class="label">Szacowana suma</div>
            </div>
        </div>
        
        <!-- Lista delegacji -->
        <div class="card">
            <div class="card-header">
                <span>📋 Lista delegacji</span>
            </div>
            
            <?php if (empty($delegacje)): ?>
                <div style="padding: 40px; text-align: center; color: #64748b;">
                    Brak delegacji w wybranym okresie
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nr</th>
                            <th>Typ</th>
                            <th>Pracownik</th>
                            <th>Lokalizacja</th>
                            <th>Dni</th>
                            <th>Noclegi</th>
                            <th>km</th>
                            <th>Szacowana kwota</th>
                            <th>Status</th>
                            <th>Akcje</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($delegacje as $d): 
                            $dieta = $d['dni'] * $d['dieta_stawka'];
                            $przejazdyKm = $d['kilometry'] * 2 * $d['wyjazdy']; // wyjazdy, nie dni!
                            $przejazdy = $przejazdyKm * $d['stawka_km'];
                            $noclegi = $d['noclegi'] * $d['noclegi_stawka'];
                            $kwota = $dieta + $przejazdy + $noclegi;
                            $typDel = $d['typ_delegacji'] ?? 'krajowa';
                        ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($d['nr_delegacji']) ?></strong></td>
                            <td>
                                <?php if ($typDel === 'zagraniczna'): ?>
                                    <span style="background: #ede9fe; color: #5b21b6; padding: 3px 8px; border-radius: 10px; font-size: 0.8rem;">🇩🇪</span>
                                <?php else: ?>
                                    <span style="background: #dcfce7; color: #166534; padding: 3px 8px; border-radius: 10px; font-size: 0.8rem;">🇵🇱</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($d['imie'] . ' ' . $d['nazwisko']) ?>
                                <br><small style="color: #64748b;"><?= htmlspecialchars($d['pracownik_kod']) ?></small>
                            </td>
                            <td>
                                📍 <?= htmlspecialchars($d['lokalizacja_nazwa']) ?>
                                <br><small style="color: #64748b;"><?= $d['kilometry'] ?> km</small>
                            </td>
                            <td>
                                <strong><?= $d['dni'] ?></strong>
                                <br><small style="color: #64748b;"><?= $d['zakresy_tekst'] ?></small>
                            </td>
                            <td><?= $d['noclegi'] ?></td>
                            <td><?= $przejazdyKm ?></td>
                            <td style="font-weight: 600; color: #16a34a;">
                                <?= number_format($kwota, 2, ',', ' ') ?> zł
                            </td>
                            <td>
                                <span class="badge badge-<?= $d['status'] ?>">
                                    <?= $d['status'] === 'draft' ? '📝 Szkic' : '✅ Gotowe' ?>
                                </span>
                            </td>
                            <td>
                                <a href="generuj.php?id=<?= $d['id'] ?>" class="btn btn-small btn-success" title="Generuj dokument">📄</a>
                                <a href="edytuj.php?id=<?= $d['id'] ?>" class="btn btn-small btn-secondary" title="Edytuj">✏️</a>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Usunąć delegację?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="delegacja_id" value="<?= $d['id'] ?>">
                                    <button type="submit" class="btn btn-small btn-danger">🗑️</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
