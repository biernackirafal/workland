<?php
/**
 * Moduł Delegacji - Edycja delegacji
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Pobierz delegację
$stmt = $db->prepare("SELECT * FROM delegacje WHERE id = ?");
$stmt->execute([$id]);
$del = $stmt->fetch();

if (!$del) {
    header('Location: index.php');
    exit;
}

// Pobierz zakresy
$zakresyStmt = $db->prepare("SELECT * FROM delegacje_zakresy WHERE delegacja_id = ? ORDER BY data_od");
$zakresyStmt->execute([$id]);
$zakresy = $zakresyStmt->fetchAll();

// Pobierz pracowników
$pracownicy = $db->query("
    SELECT p.id, p.imie, p.nazwisko, p.kod,
           o.id as oddelegowanie_id, k.nazwa as klient_nazwa, o.stanowisko
    FROM pracownicy p
    LEFT JOIN oddelegowania o ON p.id = o.pracownik_id AND o.active = 1
    LEFT JOIN klienci k ON o.klient_id = k.id
    WHERE p.data_zwolnienia IS NULL OR p.data_zwolnienia = '' OR p.id = {$del['pracownik_id']}
    ORDER BY p.nazwisko, p.imie
")->fetchAll();

// Pobierz lokalizacje
$lokalizacje = getLokalizacjeDelegacji($db);

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pracownikId = (int)$_POST['pracownik_id'];
    $lokalizacjaId = (int)$_POST['lokalizacja_id'];
    $miesiac = (int)$_POST['miesiac'];
    $rok = (int)$_POST['rok'];
    $celWyjazdu = sanitize($_POST['cel_wyjazdu'] ?? '');
    $dietaStawka = floatval(str_replace(',', '.', $_POST['dieta_stawka'] ?? 45));
    $stawkaKm = floatval(str_replace(',', '.', $_POST['stawka_km'] ?? 1.15));
    $noclegiStawka = floatval(str_replace(',', '.', $_POST['noclegi_stawka'] ?? 67.50));
    $zaliczka = floatval(str_replace(',', '.', $_POST['zaliczka'] ?? 0));
    $inneWydatki = floatval(str_replace(',', '.', $_POST['inne_wydatki'] ?? 0));
    
    // Zakresy dat
    $noweZakresy = [];
    if (isset($_POST['zakres_od']) && is_array($_POST['zakres_od'])) {
        foreach ($_POST['zakres_od'] as $i => $od) {
            $do = $_POST['zakres_do'][$i] ?? $od;
            if (!empty($od) && !empty($do)) {
                $noweZakresy[] = ['od' => $od, 'do' => $do];
            }
        }
    }
    
    // Walidacja
    if (!$pracownikId) $errors[] = 'Wybierz pracownika';
    if (!$lokalizacjaId) $errors[] = 'Wybierz lokalizację';
    if (empty($noweZakresy)) $errors[] = 'Dodaj przynajmniej jeden zakres dat';
    
    if (empty($errors)) {
        // Aktualizuj numer delegacji
        $nrDelegacji = str_pad($miesiac, 2, '0', STR_PAD_LEFT) . '/' . $rok;
        $dataZlecenia = getPierwszyDzienRoboczy($rok, $miesiac);
        
        // Aktualizuj delegację
        $stmt = $db->prepare("
            UPDATE delegacje SET 
                nr_delegacji = ?, pracownik_id = ?, miesiac = ?, rok = ?, lokalizacja_id = ?,
                cel_wyjazdu = ?, data_zlecenia = ?, dieta_stawka = ?, stawka_km = ?,
                noclegi_stawka = ?, zaliczka = ?, inne_wydatki = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $stmt->execute([
            $nrDelegacji, $pracownikId, $miesiac, $rok, $lokalizacjaId,
            $celWyjazdu, $dataZlecenia, $dietaStawka, $stawkaKm,
            $noclegiStawka, $zaliczka, $inneWydatki, $id
        ]);
        
        // Usuń stare zakresy i wstaw nowe
        $db->prepare("DELETE FROM delegacje_zakresy WHERE delegacja_id = ?")->execute([$id]);
        
        $zakresStmt = $db->prepare("INSERT INTO delegacje_zakresy (delegacja_id, data_od, data_do) VALUES (?, ?, ?)");
        foreach ($noweZakresy as $z) {
            $zakresStmt->execute([$id, $z['od'], $z['do']]);
        }
        
        header("Location: index.php?miesiac=$miesiac&rok=$rok&msg=updated");
        exit;
    }
}

$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edycja delegacji - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 900px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #7c3aed; color: white; }
        
        header { margin-bottom: 25px; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 20px; }
        
        .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-group.full-width { grid-column: span 2; }
        .form-group label { font-weight: 600; color: #374151; font-size: 0.9rem; }
        .form-group input, .form-group select, .form-group textarea { 
            padding: 12px 15px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 1rem; 
        }
        .form-group input:focus, .form-group select:focus { border-color: #2563eb; outline: none; }
        .form-group small { color: #64748b; font-size: 0.8rem; }
        
        .btn { padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.95rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-secondary { background: #f1f5f9; color: #374151; }
        .btn-success { background: #16a34a; color: white; }
        .btn-small { padding: 8px 14px; font-size: 0.85rem; }
        .btn-danger { background: #dc2626; color: white; }
        
        .error-box { background: #fee2e2; border-left: 4px solid #dc2626; color: #991b1b; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        
        .zakresy-container { border: 2px dashed #e2e8f0; border-radius: 8px; padding: 15px; }
        .zakres-row { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; }
        .zakres-row input { flex: 1; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="./" class="active">🚗 Delegacje</a>
                <a href="lokalizacje.php">📍 Lokalizacje</a>
            </div>
        </nav>
        
        <header>
            <h1>✏️ Edycja delegacji: <?= htmlspecialchars($del['nr_delegacji']) ?></h1>
        </header>
        
        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <strong>Błędy:</strong>
                <ul style="margin: 10px 0 0 20px;">
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" id="delegacjaForm" onsubmit="return validateSubmit(event)">
            <div class="card">
                <div class="card-header">📅 Okres delegacji</div>
                <div class="card-body">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Miesiąc</label>
                            <select name="miesiac" required>
                                <?php for ($m = 1; $m <= 12; $m++): ?>
                                    <option value="<?= $m ?>" <?= $m == $del['miesiac'] ? 'selected' : '' ?>><?= $miesiacNazwy[$m] ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Rok</label>
                            <select name="rok" required>
                                <?php for ($y = date('Y') - 1; $y <= date('Y') + 1; $y++): ?>
                                    <option value="<?= $y ?>" <?= $y == $del['rok'] ? 'selected' : '' ?>><?= $y ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group full-width">
                            <label>Zakresy dat (dni delegacji)</label>
                            <div class="zakresy-container" id="zakresy-container">
                                <?php foreach ($zakresy as $z): ?>
                                <div class="zakres-row">
                                    <input type="date" name="zakres_od[]" value="<?= $z['data_od'] ?>" required>
                                    <span>do</span>
                                    <input type="date" name="zakres_do[]" value="<?= $z['data_do'] ?>" required>
                                    <button type="button" class="btn btn-small btn-danger" onclick="usunZakres(this)">🗑️</button>
                                </div>
                                <?php endforeach; ?>
                                <?php if (empty($zakresy)): ?>
                                <div class="zakres-row">
                                    <input type="date" name="zakres_od[]" required>
                                    <span>do</span>
                                    <input type="date" name="zakres_do[]" required>
                                    <button type="button" class="btn btn-small btn-danger" onclick="usunZakres(this)">🗑️</button>
                                </div>
                                <?php endif; ?>
                            </div>
                            <button type="button" class="btn btn-small btn-secondary" onclick="dodajZakres()" style="margin-top: 10px;">
                                ➕ Dodaj kolejny zakres
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">👤 Pracownik i miejsce</div>
                <div class="card-body">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Pracownik *</label>
                            <select name="pracownik_id" required>
                                <?php foreach ($pracownicy as $pr): ?>
                                    <option value="<?= $pr['id'] ?>" <?= $pr['id'] == $del['pracownik_id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($pr['nazwisko'] . ' ' . $pr['imie']) ?> 
                                        (<?= htmlspecialchars($pr['kod']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Lokalizacja *</label>
                            <select name="lokalizacja_id" required>
                                <?php foreach ($lokalizacje as $l): ?>
                                    <option value="<?= $l['id'] ?>" <?= $l['id'] == $del['lokalizacja_id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($l['nazwa']) ?> (<?= $l['kilometry'] ?> km)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group full-width">
                            <label>Cel wyjazdu</label>
                            <input type="text" name="cel_wyjazdu" value="<?= htmlspecialchars($del['cel_wyjazdu']) ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">💰 Stawki i koszty</div>
                <div class="card-body">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Dieta (zł/dzień)</label>
                            <input type="text" name="dieta_stawka" value="<?= number_format($del['dieta_stawka'], 2, ',', '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Stawka za km (zł)</label>
                            <input type="text" name="stawka_km" value="<?= number_format($del['stawka_km'], 2, ',', '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Nocleg (zł/noc)</label>
                            <input type="text" name="noclegi_stawka" value="<?= number_format($del['noclegi_stawka'], 2, ',', '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Inne wydatki (zł)</label>
                            <input type="text" name="inne_wydatki" value="<?= number_format($del['inne_wydatki'], 2, ',', '') ?>">
                        </div>
                        <div class="form-group">
                            <label>Zaliczka (zł)</label>
                            <input type="text" name="zaliczka" value="<?= number_format($del['zaliczka'], 2, ',', '') ?>">
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 15px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary">💾 Zapisz zmiany</button>
                <a href="./" class="btn btn-secondary">← Anuluj</a>
            </div>
        </form>
    </div>
    
    <script>
    // Flaga - czy użytkownik kliknął przycisk submit
    let submitClicked = false;
    
    function validateSubmit(event) {
        console.log('Form submit triggered, submitClicked:', submitClicked);
        if (!submitClicked) {
            console.log('BLOCKED - submit nie został wywołany przez przycisk!');
            event.preventDefault();
            return false;
        }
        submitClicked = false; // Reset
        return true;
    }
    
    function dodajZakres() {
        const container = document.getElementById('zakresy-container');
        const row = document.createElement('div');
        row.className = 'zakres-row';
        row.innerHTML = `
            <input type="date" name="zakres_od[]" required>
            <span>do</span>
            <input type="date" name="zakres_do[]" required>
            <button type="button" class="btn btn-small btn-danger" onclick="usunZakres(this)">🗑️</button>
        `;
        container.appendChild(row);
        
        // Dodaj event listenery do nowych pól date
        row.querySelectorAll('input[type="date"]').forEach(addDateProtection);
    }
    
    function usunZakres(btn) {
        const container = document.getElementById('zakresy-container');
        if (container.children.length > 1) {
            btn.parentElement.remove();
        }
    }
    
    // Ochrona pól date przed przypadkowym submit
    function addDateProtection(input) {
        // Blokuj Enter
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        });
        
        // Loguj wszystkie eventy dla debugowania
        input.addEventListener('click', function(e) {
            console.log('Date click:', this.name);
            e.stopPropagation();
        });
        
        input.addEventListener('focus', function(e) {
            console.log('Date focus:', this.name);
        });
        
        input.addEventListener('change', function(e) {
            console.log('Date change:', this.name, this.value);
        });
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('delegacjaForm');
        
        // Dodaj ochronę do wszystkich pól date
        document.querySelectorAll('input[type="date"]').forEach(addDateProtection);
        
        // Oznacz przycisk submit
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.addEventListener('click', function() {
                console.log('Submit button clicked');
                submitClicked = true;
            });
        }
        
        // Blokuj submit przez Enter na wszystkich polach
        form.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
                console.log('Enter blocked on:', e.target.name || e.target.tagName);
                e.preventDefault();
                return false;
            }
        });
        
        // Loguj każdy submit formularza
        form.addEventListener('submit', function(e) {
            console.log('Form submit event fired');
        });
    });
    </script>
</body>
</html>
