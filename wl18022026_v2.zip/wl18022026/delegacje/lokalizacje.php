<?php
/**
 * Moduł Delegacji - Zarządzanie lokalizacjami
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$msg = '';

// Obsługa formularzy
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $nazwa = sanitize($_POST['nazwa'] ?? '');
        $kilometry = (int)$_POST['kilometry'];
        
        if ($nazwa && $kilometry > 0) {
            try {
                $stmt = $db->prepare("INSERT INTO delegacje_lokalizacje (nazwa, kilometry) VALUES (?, ?)");
                $stmt->execute([$nazwa, $kilometry]);
                $msg = 'success:Lokalizacja została dodana';
            } catch (PDOException $e) {
                $msg = 'error:Lokalizacja o tej nazwie już istnieje';
            }
        }
    }
    
    if ($action === 'edit') {
        $id = (int)$_POST['id'];
        $nazwa = sanitize($_POST['nazwa'] ?? '');
        $kilometry = (int)$_POST['kilometry'];
        
        if ($id && $nazwa && $kilometry > 0) {
            $stmt = $db->prepare("UPDATE delegacje_lokalizacje SET nazwa = ?, kilometry = ? WHERE id = ?");
            $stmt->execute([$nazwa, $kilometry, $id]);
            $msg = 'success:Lokalizacja została zaktualizowana';
        }
    }
    
    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        // Sprawdź czy nie jest używana
        $used = $db->prepare("SELECT COUNT(*) FROM delegacje WHERE lokalizacja_id = ?");
        $used->execute([$id]);
        if ($used->fetchColumn() > 0) {
            $msg = 'error:Nie można usunąć - lokalizacja jest używana w delegacjach';
        } else {
            $db->prepare("DELETE FROM delegacje_lokalizacje WHERE id = ?")->execute([$id]);
            $msg = 'success:Lokalizacja została usunięta';
        }
    }
    
    header("Location: lokalizacje.php" . ($msg ? "?msg=" . urlencode($msg) : ''));
    exit;
}

if (isset($_GET['msg'])) {
    $msg = $_GET['msg'];
}

// Pobierz lokalizacje
$lokalizacje = $db->query("SELECT * FROM delegacje_lokalizacje ORDER BY nazwa")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lokalizacje - Delegacje - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 900px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #7c3aed; color: white; }
        
        header { margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 20px; }
        
        .form-row { display: flex; gap: 15px; align-items: flex-end; flex-wrap: wrap; }
        .form-group { display: flex; flex-direction: column; gap: 5px; }
        .form-group label { font-weight: 600; color: #374151; font-size: 0.85rem; }
        .form-group input { padding: 10px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.95rem; }
        
        .btn { padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-secondary { background: #f1f5f9; color: #374151; }
        .btn-danger { background: #dc2626; color: white; }
        .btn-small { padding: 6px 12px; font-size: 0.8rem; }
        
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 12px 15px; background: #f8fafc; color: #64748b; font-size: 0.8rem; font-weight: 600; text-transform: uppercase; }
        td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; }
        tr:hover { background: #f8fafc; }
        
        .alert { padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; border-left: 4px solid #16a34a; }
        .alert-error { background: #fee2e2; color: #991b1b; border-left: 4px solid #dc2626; }
        
        .edit-form { display: none; }
        .edit-form.active { display: table-row; }
        
        .km-badge { background: #dbeafe; color: #1d4ed8; padding: 4px 10px; border-radius: 6px; font-weight: 600; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="./">🚗 Delegacje</a>
                <a href="lokalizacje.php" class="active">📍 Lokalizacje</a>
            </div>
        </nav>
        
        <?php if ($msg): 
            list($type, $text) = explode(':', $msg, 2);
        ?>
            <div class="alert alert-<?= $type ?>"><?= htmlspecialchars($text) ?></div>
        <?php endif; ?>
        
        <header>
            <div>
                <h1>📍 Lokalizacje delegacji</h1>
                <p style="color: #64748b; margin: 0;">Zarządzaj miejscami docelowymi i odległościami</p>
            </div>
        </header>
        
        <!-- Formularz dodawania -->
        <div class="card">
            <div class="card-header">➕ Dodaj nową lokalizację</div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="form-row">
                        <div class="form-group" style="flex: 2;">
                            <label>Nazwa miejscowości</label>
                            <input type="text" name="nazwa" placeholder="np. Kraków" required>
                        </div>
                        <div class="form-group" style="flex: 1;">
                            <label>Odległość (km od Plewisk)</label>
                            <input type="number" name="kilometry" placeholder="np. 350" min="1" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success">➕ Dodaj</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Lista lokalizacji -->
        <div class="card">
            <div class="card-header">📋 Lista lokalizacji</div>
            
            <?php if (empty($lokalizacje)): ?>
                <div style="padding: 40px; text-align: center; color: #64748b;">
                    Brak zdefiniowanych lokalizacji
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nazwa</th>
                            <th>Odległość</th>
                            <th>Trasa tam i z powrotem</th>
                            <th>Akcje</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($lokalizacje as $l): ?>
                        <tr id="row-<?= $l['id'] ?>">
                            <td><strong>📍 <?= htmlspecialchars($l['nazwa']) ?></strong></td>
                            <td><span class="km-badge"><?= $l['kilometry'] ?> km</span></td>
                            <td><?= $l['kilometry'] * 2 ?> km</td>
                            <td>
                                <button type="button" class="btn btn-small btn-secondary" onclick="toggleEdit(<?= $l['id'] ?>)">✏️ Edytuj</button>
                                <form method="POST" style="display: inline;" onsubmit="return confirm('Usunąć lokalizację?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="id" value="<?= $l['id'] ?>">
                                    <button type="submit" class="btn btn-small btn-danger">🗑️</button>
                                </form>
                            </td>
                        </tr>
                        <tr id="edit-<?= $l['id'] ?>" class="edit-form">
                            <td colspan="4" style="background: #f8fafc;">
                                <form method="POST" style="display: flex; gap: 15px; align-items: center;">
                                    <input type="hidden" name="action" value="edit">
                                    <input type="hidden" name="id" value="<?= $l['id'] ?>">
                                    <input type="text" name="nazwa" value="<?= htmlspecialchars($l['nazwa']) ?>" required style="padding: 8px 12px; border: 2px solid #e2e8f0; border-radius: 6px;">
                                    <input type="number" name="kilometry" value="<?= $l['kilometry'] ?>" min="1" required style="padding: 8px 12px; border: 2px solid #e2e8f0; border-radius: 6px; width: 100px;">
                                    <span>km</span>
                                    <button type="submit" class="btn btn-small btn-primary">💾 Zapisz</button>
                                    <button type="button" class="btn btn-small btn-secondary" onclick="toggleEdit(<?= $l['id'] ?>)">Anuluj</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <div style="text-align: center; color: #94a3b8; font-size: 0.85rem; padding: 20px;">
            Punkt startowy: <strong>Plewiska</strong> (dla wszystkich tras)
        </div>
    </div>
    
    <script>
    function toggleEdit(id) {
        const editRow = document.getElementById('edit-' + id);
        editRow.classList.toggle('active');
    }
    </script>
</body>
</html>
