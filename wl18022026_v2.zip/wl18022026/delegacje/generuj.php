<?php
/**
 * Moduł Delegacji - Generowanie dokumentu do druku
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Pobierz delegację
$stmt = $db->prepare("
    SELECT d.*, 
           p.imie, p.nazwisko, p.kod as pracownik_kod, p.adres as pracownik_adres,
           l.nazwa as lokalizacja_nazwa, l.kilometry,
           o.stanowisko, k.nazwa as klient_nazwa
    FROM delegacje d
    JOIN pracownicy p ON d.pracownik_id = p.id
    JOIN delegacje_lokalizacje l ON d.lokalizacja_id = l.id
    LEFT JOIN oddelegowania o ON p.id = o.pracownik_id AND o.active = 1
    LEFT JOIN klienci k ON o.klient_id = k.id
    WHERE d.id = ?
");
$stmt->execute([$id]);
$del = $stmt->fetch();

if (!$del) {
    header('Location: index.php');
    exit;
}

// Pobierz zakresy
$zakresyStmt = $db->prepare("SELECT * FROM delegacje_zakresy WHERE delegacja_id = ? ORDER BY data_od");
$zakresyStmt->execute([$id]);
$zakresy = $zakresyStmt->fetchAll();

// Typ delegacji
$typDelegacji = $del['typ_delegacji'] ?? 'krajowa';
$czyZagraniczna = ($typDelegacji === 'zagraniczna');

// Kursy EUR z bazy (JSON)
$kursy = [];
if ($czyZagraniczna && !empty($del['kurs_eur'])) {
    $kursy = json_decode($del['kurs_eur'], true) ?: [];
}

// Obliczenia
$iloscWyjazdow = count($zakresy);
$stawkaKm = $del['stawka_km'] ?? 1.15;

// Dla delegacji zagranicznej - oblicz koszty z różnymi kursami
$szczegoly = [];
$sumaDieta = 0;
$sumaNoclegi = 0;
$sumaDni = 0;
$sumaNoclegowAll = 0;

if ($czyZagraniczna) {
    foreach ($zakresy as $i => $zakres) {
        $kurs = isset($kursy[$i]) ? $kursy[$i]['kurs'] : 4.30;
        $dataKursu = isset($kursy[$i]) ? $kursy[$i]['data_kursu'] : null;
        
        // Oblicz dni w zakresie
        $od = new DateTime($zakres['data_od']);
        $do = new DateTime($zakres['data_do']);
        $dni = $od->diff($do)->days + 1;
        
        // Oblicz noclegi (dni - 1, minus weekendy)
        $noclegiZakres = max(0, $dni - 1);
        
        // Przelicz na PLN
        $dietaEur = DIETA_EUR * $dni;
        $dietaPln = $dietaEur * $kurs;
        
        $noclegiEur = NOCLEG_EUR * $noclegiZakres;
        $noclegiPln = $noclegiEur * $kurs;
        
        $szczegoly[] = [
            'zakres' => date('d.m', strtotime($zakres['data_od'])) . '-' . date('d.m', strtotime($zakres['data_do'])),
            'data_od' => date('d.m.Y', strtotime($zakres['data_od'])),
            'dni' => $dni,
            'noclegi' => $noclegiZakres,
            'kurs' => $kurs,
            'data_kursu' => $dataKursu ? date('d.m.Y', strtotime($dataKursu)) : null,
            'dieta_eur' => $dietaEur,
            'dieta_pln' => $dietaPln,
            'noclegi_eur' => $noclegiEur,
            'noclegi_pln' => $noclegiPln
        ];
        
        $sumaDieta += $dietaPln;
        $sumaNoclegi += $noclegiPln;
        $sumaDni += $dni;
        $sumaNoclegowAll += $noclegiZakres;
    }
} else {
    // Delegacja krajowa - prostsza logika
    $sumaDni = obliczDniDelegacji($zakresy);
    $sumaNoclegowAll = obliczNoclegi($zakresy);
    $dietaStawka = $del['dieta_stawka'] ?? 45;
    $noclegiStawka = $del['noclegi_stawka'] ?? 67.50;
    $sumaDieta = $sumaDni * $dietaStawka;
    $sumaNoclegi = $sumaNoclegowAll * $noclegiStawka;
}

// Przejazdy (wspólne dla obu typów)
$przejazdyKm = ($del['kilometry'] ?? 0) * 2 * $iloscWyjazdow;
$przejazdyKwota = $przejazdyKm * $stawkaKm;

// Podsumowanie
$inneWydatki = $del['inne_wydatki'] ?? 0;
$zaliczka = $del['zaliczka'] ?? 0;
$ogolem = $sumaDieta + $przejazdyKwota + $sumaNoclegi + $inneWydatki;
$doWyplaty = max(0, $ogolem - $zaliczka);

// Cel wyjazdu
$celWyjazdu = $del['cel_wyjazdu'];
if (empty($celWyjazdu) && !empty($del['klient_nazwa'])) {
    $celWyjazdu = 'Praca - ' . $del['klient_nazwa'];
    if (!empty($del['stanowisko'])) {
        $celWyjazdu .= ' (' . $del['stanowisko'] . ')';
    }
}
if (empty($celWyjazdu)) {
    $celWyjazdu = 'Praca';
}

// Daty
$zakresyTekst = formatujZakresy($zakresy);
$dataOd = '';
$dataDo = '';
if (!empty($zakresy)) {
    $dataOd = date('d.m.Y', strtotime($zakresy[0]['data_od']));
    $ostatniZakres = end($zakresy);
    $dataDo = date('d.m.Y', strtotime($ostatniZakres['data_do']));
}

$dataZlecenia = !empty($del['data_zlecenia']) ? date('d.m.Y', strtotime($del['data_zlecenia'])) : '—';

function fmtMoney($val) {
    return number_format((float)$val, 2, ',', ' ');
}

// Logo jako base64
$logoPath = __DIR__ . '/logo.png';
$logoBase64 = '';
if (file_exists($logoPath)) {
    $logoBase64 = 'data:image/png;base64,' . base64_encode(file_get_contents($logoPath));
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Delegacja <?= htmlspecialchars($del['nr_delegacji']) ?></title>
    <style>
        @page { size: A4; margin: 15mm; }
        @media print { body { margin: 0; } .no-print { display: none !important; } }
        * { box-sizing: border-box; }
        body { font-family: Arial, sans-serif; font-size: 10pt; line-height: 1.3; margin: 0; padding: 20px; background: #f5f5f5; }
        .page { background: white; max-width: 210mm; margin: 0 auto; padding: 12mm; box-shadow: 0 2px 10px rgba(0,0,0,0.1); position: relative; }
        .logo { position: absolute; top: 12mm; right: 12mm; width: 70px; height: auto; }
        h1 { text-align: center; font-size: 14pt; margin: 0 0 3px 0; text-transform: uppercase; }
        h2 { text-align: center; font-size: 11pt; font-weight: normal; margin: 0 0 3px 0; }
        .typ-badge { text-align: center; margin-bottom: 15px; }
        .typ-badge span { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 9pt; font-weight: bold; }
        .typ-badge.krajowa span { background: #dcfce7; color: #166534; }
        .typ-badge.zagraniczna span { background: #ede9fe; color: #5b21b6; }
        .section-title { background: #e8e8e8; padding: 5px 8px; font-weight: bold; margin: 12px 0 8px 0; font-size: 9pt; }
        table { width: 100%; border-collapse: collapse; margin: 8px 0; }
        .info-table td { padding: 3px 6px; border: none; vertical-align: top; font-size: 9pt; }
        .info-table .label { width: 140px; font-weight: bold; }
        .costs-table th, .costs-table td { border: 1px solid #333; padding: 4px 6px; text-align: left; font-size: 9pt; }
        .costs-table th { background: #f0f0f0; font-weight: bold; }
        .costs-table .right { text-align: right; }
        .costs-table .center { text-align: center; }
        .costs-table .section-row td { background: #f5f5f5; font-weight: bold; }
        .costs-table .total-row td { background: #e0f0e0; font-weight: bold; }
        .costs-table .subtotal td { background: #fef3c7; }
        .eur-info { font-size: 8pt; color: #666; }
        .kurs-box { background: #ede9fe; border: 1px solid #c4b5fd; padding: 8px; border-radius: 6px; margin: 10px 0; font-size: 9pt; }
        .kurs-box strong { color: #5b21b6; }
        .kurs-table { margin: 5px 0; }
        .kurs-table th, .kurs-table td { padding: 3px 8px; font-size: 8pt; border: 1px solid #ddd; }
        .kurs-table th { background: #f0f0f0; }
        .signatures { margin-top: 30px; display: flex; justify-content: space-between; }
        .signature-box { width: 45%; text-align: center; }
        .signature-line { border-top: 1px solid #333; margin-top: 50px; padding-top: 4px; font-size: 8pt; }
        .footer { margin-top: 20px; text-align: center; font-size: 7pt; color: #666; }
        .print-btn { position: fixed; top: 20px; right: 20px; padding: 12px 24px; background: #2563eb; color: white; border: none; border-radius: 8px; font-size: 14px; cursor: pointer; }
        .back-link { position: fixed; top: 20px; left: 20px; padding: 12px 24px; background: #64748b; color: white; border-radius: 8px; text-decoration: none; }
    </style>
</head>
<body>
    <a href="index.php" class="back-link no-print">← Powrót</a>
    <button onclick="window.print()" class="print-btn no-print">🖨️ Drukuj</button>
    
    <div class="page">
        <?php if ($logoBase64): ?>
            <img src="<?= $logoBase64 ?>" alt="Work Land" class="logo">
        <?php endif; ?>
        
        <h1>Polecenie wyjazdu służbowego</h1>
        <h2>Nr <?= htmlspecialchars($del['nr_delegacji']) ?></h2>
        
        <div class="typ-badge <?= $typDelegacji ?>">
            <span><?= $czyZagraniczna ? '🇩🇪 Delegacja zagraniczna' : '🇵🇱 Delegacja krajowa' ?></span>
        </div>
        
        <table class="info-table">
            <tr><td class="label">Pracownik:</td><td><strong><?= htmlspecialchars($del['imie'] . ' ' . $del['nazwisko']) ?></strong> (<?= htmlspecialchars($del['pracownik_kod']) ?>)</td></tr>
            <tr><td class="label">Miejsce delegacji:</td><td><strong><?= htmlspecialchars($del['lokalizacja_nazwa']) ?></strong></td></tr>
            <tr><td class="label">Cel wyjazdu:</td><td><?= htmlspecialchars($celWyjazdu) ?></td></tr>
            <tr><td class="label">Termin delegacji:</td><td><strong><?= $dataOd ?> – <?= $dataDo ?></strong> (dni: <?= $zakresyTekst ?>)</td></tr>
            <tr><td class="label">Środek transportu:</td><td><?= $del['transport_samochod'] ? 'Samochód prywatny' : 'Inny' ?></td></tr>
            <tr><td class="label">Data zlecenia:</td><td><?= $dataZlecenia ?></td></tr>
        </table>
        
        <?php if ($czyZagraniczna && !empty($szczegoly)): ?>
            <div class="kurs-box">
                <strong>💶 Kursy EUR z NBP (Tabela A) dla każdego wyjazdu:</strong>
                <table class="kurs-table">
                    <tr>
                        <th>Wyjazd</th>
                        <th>Dni</th>
                        <th>Kurs EUR</th>
                        <th>Data kursu</th>
                        <th>Dieta (<?= DIETA_EUR ?> EUR)</th>
                        <th>Noclegi (<?= NOCLEG_EUR ?> EUR)</th>
                    </tr>
                    <?php foreach ($szczegoly as $sz): ?>
                    <tr>
                        <td><?= $sz['zakres'] ?></td>
                        <td class="center"><?= $sz['dni'] ?> dni / <?= $sz['noclegi'] ?> nocy</td>
                        <td class="center"><strong><?= number_format($sz['kurs'], 4, ',', ' ') ?></strong></td>
                        <td class="center"><?= $sz['data_kursu'] ?: '—' ?></td>
                        <td class="right"><?= $sz['dieta_eur'] ?> EUR = <strong><?= fmtMoney($sz['dieta_pln']) ?> zł</strong></td>
                        <td class="right"><?= $sz['noclegi_eur'] ?> EUR = <strong><?= fmtMoney($sz['noclegi_pln']) ?> zł</strong></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        <?php endif; ?>
        
        <div class="section-title">ROZLICZENIE KOSZTÓW</div>
        
        <table class="costs-table">
            <tr>
                <th>Pozycja</th>
                <th class="center" style="width: 80px;">Ilość</th>
                <th class="center" style="width: 100px;">Stawka</th>
                <th class="right" style="width: 110px;">Kwota</th>
            </tr>
            
            <?php if ($czyZagraniczna): ?>
                <!-- Delegacja zagraniczna - szczegółowe rozbicie -->
                <tr class="section-row">
                    <td colspan="4">Dieta (<?= $sumaDni ?> dni łącznie)</td>
                </tr>
                <?php foreach ($szczegoly as $sz): ?>
                <tr>
                    <td style="padding-left: 20px;">↳ <?= $sz['data_od'] ?> (<?= $sz['dni'] ?> dni × <?= DIETA_EUR ?> EUR × <?= number_format($sz['kurs'], 4, ',', ' ') ?>)</td>
                    <td class="center"><?= $sz['dieta_eur'] ?> EUR</td>
                    <td class="center"><?= number_format($sz['kurs'], 4, ',', ' ') ?></td>
                    <td class="right"><?= fmtMoney($sz['dieta_pln']) ?> zł</td>
                </tr>
                <?php endforeach; ?>
                <tr class="subtotal">
                    <td colspan="3" style="text-align: right;"><strong>Suma diet:</strong></td>
                    <td class="right"><strong><?= fmtMoney($sumaDieta) ?> zł</strong></td>
                </tr>
                
                <tr class="section-row">
                    <td colspan="4">Noclegi (<?= $sumaNoclegowAll ?> nocy łącznie)</td>
                </tr>
                <?php foreach ($szczegoly as $sz): if ($sz['noclegi'] > 0): ?>
                <tr>
                    <td style="padding-left: 20px;">↳ <?= $sz['data_od'] ?> (<?= $sz['noclegi'] ?> nocy × <?= NOCLEG_EUR ?> EUR × <?= number_format($sz['kurs'], 4, ',', ' ') ?>)</td>
                    <td class="center"><?= $sz['noclegi_eur'] ?> EUR</td>
                    <td class="center"><?= number_format($sz['kurs'], 4, ',', ' ') ?></td>
                    <td class="right"><?= fmtMoney($sz['noclegi_pln']) ?> zł</td>
                </tr>
                <?php endif; endforeach; ?>
                <tr class="subtotal">
                    <td colspan="3" style="text-align: right;"><strong>Suma noclegów:</strong></td>
                    <td class="right"><strong><?= fmtMoney($sumaNoclegi) ?> zł</strong></td>
                </tr>
            <?php else: ?>
                <!-- Delegacja krajowa - prosta tabela -->
                <tr>
                    <td><strong>Dieta</strong> (<?= htmlspecialchars($del['dieta_kraj'] ?? 'Polska') ?>)</td>
                    <td class="center"><?= $sumaDni ?> dni</td>
                    <td class="center"><?= fmtMoney($del['dieta_stawka'] ?? 45) ?> zł</td>
                    <td class="right"><?= fmtMoney($sumaDieta) ?> zł</td>
                </tr>
                <tr>
                    <td><strong>Noclegi</strong></td>
                    <td class="center"><?= $sumaNoclegowAll ?> nocy</td>
                    <td class="center"><?= fmtMoney($del['noclegi_stawka'] ?? 67.50) ?> zł</td>
                    <td class="right"><?= fmtMoney($sumaNoclegi) ?> zł</td>
                </tr>
            <?php endif; ?>
            
            <tr class="section-row">
                <td colspan="4">Przejazdy (<?= $iloscWyjazdow ?> <?= $iloscWyjazdow == 1 ? 'wyjazd' : 'wyjazdów' ?>)</td>
            </tr>
            <tr>
                <td>Plewiska → <?= htmlspecialchars($del['lokalizacja_nazwa']) ?> → Plewiska</td>
                <td class="center"><?= $przejazdyKm ?> km</td>
                <td class="center"><?= fmtMoney($stawkaKm) ?> zł/km</td>
                <td class="right"><?= fmtMoney($przejazdyKwota) ?> zł</td>
            </tr>
            
            <tr>
                <td><strong>Inne wydatki</strong></td>
                <td class="center">—</td>
                <td class="center">—</td>
                <td class="right"><?= fmtMoney($inneWydatki) ?> zł</td>
            </tr>
            <tr class="total-row">
                <td colspan="3"><strong>OGÓŁEM</strong></td>
                <td class="right"><strong><?= fmtMoney($ogolem) ?> zł</strong></td>
            </tr>
            <tr>
                <td colspan="3">Zaliczka</td>
                <td class="right"><?= fmtMoney($zaliczka) ?> zł</td>
            </tr>
            <tr class="total-row">
                <td colspan="3"><strong>DO WYPŁATY</strong></td>
                <td class="right"><strong><?= fmtMoney($doWyplaty) ?> zł</strong></td>
            </tr>
        </table>
        
        <div class="signatures">
            <div class="signature-box"><div class="signature-line">Podpis zlecającego</div></div>
            <div class="signature-box"><div class="signature-line">Podpis delegowanego</div></div>
        </div>
        
        <div class="footer">Wygenerowano: <?= date('d.m.Y H:i') ?> | Work Land</div>
    </div>
</body>
</html>
