/**
 * Generator dokumentu delegacji DOCX
 * Użycie: node generuj_docx.js '<JSON_DATA>' output.docx
 */

const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        AlignmentType, BorderStyle, WidthType, HeadingLevel } = require('docx');
const fs = require('fs');

// Pobierz argumenty
const jsonData = process.argv[2];
const outputPath = process.argv[3] || 'delegacja.docx';

if (!jsonData) {
    console.error('Brak danych JSON');
    process.exit(1);
}

const data = JSON.parse(jsonData);

// Pomocnicza funkcja formatowania kwoty
function formatMoney(val) {
    return Number(val).toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' zł';
}

// Style obramowania tabeli
const border = { style: BorderStyle.SINGLE, size: 1, color: "000000" };
const borders = { top: border, bottom: border, left: border, right: border };
const noBorders = { top: { style: BorderStyle.NONE }, bottom: { style: BorderStyle.NONE }, 
                   left: { style: BorderStyle.NONE }, right: { style: BorderStyle.NONE } };

// Tworzenie dokumentu
const doc = new Document({
    styles: {
        default: {
            document: {
                run: { font: "Arial", size: 22 } // 11pt
            }
        }
    },
    sections: [{
        properties: {
            page: {
                size: { width: 11906, height: 16838 }, // A4
                margin: { top: 720, right: 720, bottom: 720, left: 720 } // 0.5 inch
            }
        },
        children: [
            // Nagłówek
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { after: 200 },
                children: [
                    new TextRun({ text: "POLECENIE WYJAZDU SŁUŻBOWEGO", bold: true, size: 28 })
                ]
            }),
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { after: 400 },
                children: [
                    new TextRun({ text: `Nr ${data.nr_delegacji}`, size: 24 })
                ]
            }),

            // Dane podstawowe - tabela bez obramowania
            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                columnWidths: [3000, 7000],
                rows: [
                    createInfoRow("Pracownik:", `${data.pracownik} (${data.pracownik_kod})`),
                    createInfoRow("Miejsce delegacji:", data.lokalizacja),
                    createInfoRow("Cel wyjazdu:", data.cel_wyjazdu || "Praca"),
                    createInfoRow("Termin delegacji:", `${data.data_od} - ${data.data_do} (dni: ${data.zakresy_tekst})`),
                    createInfoRow("Środek transportu:", data.transport_samochod ? "Samochód prywatny" : "Inny"),
                    createInfoRow("Data zlecenia:", data.data_zlecenia || "—"),
                ]
            }),

            new Paragraph({ spacing: { before: 400, after: 200 }, children: [] }),

            // Rozliczenie kosztów - nagłówek
            new Paragraph({
                spacing: { before: 200, after: 200 },
                shading: { fill: "E0E0E0" },
                children: [
                    new TextRun({ text: "ROZLICZENIE KOSZTÓW", bold: true, size: 24 })
                ]
            }),

            // Tabela kosztów
            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                columnWidths: [4500, 1500, 2000, 2000],
                rows: [
                    // Nagłówek
                    new TableRow({
                        children: [
                            createHeaderCell("Pozycja"),
                            createHeaderCell("Ilość", AlignmentType.CENTER),
                            createHeaderCell("Stawka", AlignmentType.CENTER),
                            createHeaderCell("Kwota", AlignmentType.RIGHT),
                        ]
                    }),
                    // Dieta
                    new TableRow({
                        children: [
                            createCell(`Dieta (${data.dieta_kraj})`),
                            createCell(`${data.dni} dni`, AlignmentType.CENTER),
                            createCell(formatMoney(data.dieta_stawka), AlignmentType.CENTER),
                            createCell(formatMoney(data.dieta_kwota), AlignmentType.RIGHT),
                        ]
                    }),
                    // Przejazdy nagłówek
                    new TableRow({
                        children: [
                            new TableCell({
                                borders,
                                columnSpan: 4,
                                shading: { fill: "F5F5F5" },
                                children: [new Paragraph({ 
                                    children: [new TextRun({ text: `Przejazdy (${data.ilosc_wyjazdow} ${data.ilosc_wyjazdow == 1 ? 'wyjazd' : 'wyjazdów'})`, bold: true })]
                                })]
                            })
                        ]
                    }),
                    // Przejazdy
                    new TableRow({
                        children: [
                            createCell(`Plewiska → ${data.lokalizacja} → Plewiska`),
                            createCell(`${data.przejazdy_km} km`, AlignmentType.CENTER),
                            createCell(formatMoney(data.stawka_km) + "/km", AlignmentType.CENTER),
                            createCell(formatMoney(data.przejazdy_kwota), AlignmentType.RIGHT),
                        ]
                    }),
                    // Noclegi
                    new TableRow({
                        children: [
                            createCell("Noclegi", true),
                            createCell(`${data.noclegi} nocy`, AlignmentType.CENTER),
                            createCell(formatMoney(data.noclegi_stawka), AlignmentType.CENTER),
                            createCell(formatMoney(data.noclegi_kwota), AlignmentType.RIGHT),
                        ]
                    }),
                    // Inne wydatki
                    new TableRow({
                        children: [
                            createCell("Inne wydatki", true),
                            createCell("—", AlignmentType.CENTER),
                            createCell("—", AlignmentType.CENTER),
                            createCell(formatMoney(data.inne_wydatki), AlignmentType.RIGHT),
                        ]
                    }),
                    // OGÓŁEM
                    new TableRow({
                        children: [
                            new TableCell({
                                borders,
                                columnSpan: 3,
                                shading: { fill: "E8F4E8" },
                                children: [new Paragraph({ 
                                    children: [new TextRun({ text: "OGÓŁEM", bold: true })]
                                })]
                            }),
                            new TableCell({
                                borders,
                                shading: { fill: "E8F4E8" },
                                children: [new Paragraph({ 
                                    alignment: AlignmentType.RIGHT,
                                    children: [new TextRun({ text: formatMoney(data.ogolem), bold: true })]
                                })]
                            })
                        ]
                    }),
                    // Zaliczka
                    new TableRow({
                        children: [
                            new TableCell({
                                borders,
                                columnSpan: 3,
                                children: [new Paragraph({ children: [new TextRun("Zaliczka")] })]
                            }),
                            createCell(formatMoney(data.zaliczka), AlignmentType.RIGHT)
                        ]
                    }),
                    // DO WYPŁATY
                    new TableRow({
                        children: [
                            new TableCell({
                                borders,
                                columnSpan: 3,
                                shading: { fill: "E8F4E8" },
                                children: [new Paragraph({ 
                                    children: [new TextRun({ text: "DO WYPŁATY", bold: true })]
                                })]
                            }),
                            new TableCell({
                                borders,
                                shading: { fill: "E8F4E8" },
                                children: [new Paragraph({ 
                                    alignment: AlignmentType.RIGHT,
                                    children: [new TextRun({ text: formatMoney(data.do_wyplaty), bold: true })]
                                })]
                            })
                        ]
                    }),
                ]
            }),

            // Podpisy
            new Paragraph({ spacing: { before: 800 }, children: [] }),

            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                columnWidths: [5000, 5000],
                rows: [
                    new TableRow({
                        children: [
                            new TableCell({
                                borders: noBorders,
                                children: [
                                    new Paragraph({ spacing: { before: 600 }, children: [] }),
                                    new Paragraph({
                                        alignment: AlignmentType.CENTER,
                                        children: [new TextRun("_________________________")]
                                    }),
                                    new Paragraph({
                                        alignment: AlignmentType.CENTER,
                                        children: [new TextRun({ text: "Podpis zlecającego", size: 18 })]
                                    })
                                ]
                            }),
                            new TableCell({
                                borders: noBorders,
                                children: [
                                    new Paragraph({ spacing: { before: 600 }, children: [] }),
                                    new Paragraph({
                                        alignment: AlignmentType.CENTER,
                                        children: [new TextRun("_________________________")]
                                    }),
                                    new Paragraph({
                                        alignment: AlignmentType.CENTER,
                                        children: [new TextRun({ text: "Podpis delegowanego", size: 18 })]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),

            // Stopka
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { before: 600 },
                children: [
                    new TextRun({ text: `Wygenerowano: ${data.data_generowania} | Work Land`, size: 16, color: "666666" })
                ]
            })
        ]
    }]
});

// Funkcje pomocnicze
function createInfoRow(label, value) {
    return new TableRow({
        children: [
            new TableCell({
                borders: noBorders,
                width: { size: 3000, type: WidthType.DXA },
                children: [new Paragraph({ 
                    children: [new TextRun({ text: label, bold: true })]
                })]
            }),
            new TableCell({
                borders: noBorders,
                width: { size: 7000, type: WidthType.DXA },
                children: [new Paragraph({ children: [new TextRun(value || "—")] })]
            })
        ]
    });
}

function createHeaderCell(text, alignment = AlignmentType.LEFT) {
    return new TableCell({
        borders,
        shading: { fill: "F0F0F0" },
        children: [new Paragraph({ 
            alignment,
            children: [new TextRun({ text, bold: true })]
        })]
    });
}

function createCell(text, alignment = AlignmentType.LEFT, bold = false) {
    return new TableCell({
        borders,
        children: [new Paragraph({ 
            alignment,
            children: [new TextRun({ text: String(text), bold })]
        })]
    });
}

// Zapisz dokument
Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync(outputPath, buffer);
    console.log('OK:' + outputPath);
}).catch(err => {
    console.error('ERROR:' + err.message);
    process.exit(1);
});
