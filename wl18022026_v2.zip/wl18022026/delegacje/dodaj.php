<?php
/**
 * Moduł Delegacji - Dodawanie nowej delegacji
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Pobierz pracowników (aktywnych)
$pracownicy = $db->query("
    SELECT p.id, p.imie, p.nazwisko, p.kod,
           o.id as oddelegowanie_id, k.nazwa as klient_nazwa, o.stanowisko
    FROM pracownicy p
    LEFT JOIN oddelegowania o ON p.id = o.pracownik_id AND o.active = 1
    LEFT JOIN klienci k ON o.klient_id = k.id
    WHERE p.data_zwolnienia IS NULL OR p.data_zwolnienia = ''
    ORDER BY p.nazwisko, p.imie
")->fetchAll();

// Pobierz lokalizacje
$lokalizacje = getLokalizacjeDelegacji($db);

// Domyślne wartości
$miesiac = isset($_GET['miesiac']) ? (int)$_GET['miesiac'] : (int)date('m');
$rok = isset($_GET['rok']) ? (int)$_GET['rok'] : (int)date('Y');

// Sprawdź czy są zapamiętane zakresy w sesji
$zapamietaneZakresy = isset($_SESSION['zapamiętane_zakresy']) ? $_SESSION['zapamiętane_zakresy'] : [];

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pracownikId = (int)$_POST['pracownik_id'];
    $lokalizacjaId = (int)$_POST['lokalizacja_id'];
    $miesiac = (int)$_POST['miesiac'];
    $rok = (int)$_POST['rok'];
    $typDelegacji = $_POST['typ_delegacji'] ?? 'krajowa';
    $celWyjazdu = sanitize($_POST['cel_wyjazdu'] ?? '');
    $dietaStawka = floatval(str_replace(',', '.', $_POST['dieta_stawka'] ?? 45));
    $stawkaKm = floatval(str_replace(',', '.', $_POST['stawka_km'] ?? 1.15));
    $noclegiStawka = floatval(str_replace(',', '.', $_POST['noclegi_stawka'] ?? 67.50));
    $zapamietajDni = isset($_POST['zapamietaj_dni']);
    
    // Zakresy dat
    $zakresy = [];
    if (isset($_POST['zakres_od']) && is_array($_POST['zakres_od'])) {
        foreach ($_POST['zakres_od'] as $i => $od) {
            $do = $_POST['zakres_do'][$i] ?? $od;
            if (!empty($od) && !empty($do)) {
                $zakresy[] = ['od' => $od, 'do' => $do];
            }
        }
    }
    
    // Walidacja
    if (!$pracownikId) $errors[] = 'Wybierz pracownika';
    if (!$lokalizacjaId) $errors[] = 'Wybierz lokalizację';
    if (empty($zakresy)) $errors[] = 'Dodaj przynajmniej jeden zakres dat';
    
    // Dla delegacji zagranicznej - pobierz kursy EUR dla każdego zakresu
    $kursyJson = null;
    $kursEurSredni = null;
    
    if ($typDelegacji === 'zagraniczna' && !empty($zakresy)) {
        $kursy = pobierzKursyDlaZakresow($zakresy);
        
        if (empty($kursy)) {
            $errors[] = 'Nie udało się pobrać kursów EUR z NBP';
        } else {
            $kursyJson = json_encode($kursy);
            // Średni kurs dla informacji
            $sumaKursow = array_sum(array_column($kursy, 'kurs'));
            $kursEurSredni = $sumaKursow / count($kursy);
        }
    }
    
    // Zapamiętaj zakresy dla kolejnej delegacji
    if ($zapamietajDni && !empty($zakresy)) {
        $_SESSION['zapamiętane_zakresy'] = $zakresy;
    } else {
        unset($_SESSION['zapamiętane_zakresy']);
    }
    
    if (empty($errors)) {
        // Generuj numer delegacji
        $nrDelegacji = str_pad($miesiac, 2, '0', STR_PAD_LEFT) . '/' . $rok;
        
        // Data zlecenia = pierwszy dzień roboczy miesiąca
        $dataZlecenia = getPierwszyDzienRoboczy($rok, $miesiac);
        
        // Kraj diety
        $dietaKraj = $typDelegacji === 'zagraniczna' ? 'Niemcy' : 'Polska';
        
        // Dla zagranicznej - ustaw stawki domyślne (będą przeliczane przy generowaniu)
        if ($typDelegacji === 'zagraniczna') {
            $dietaStawka = DIETA_EUR;  // W EUR
            $noclegiStawka = NOCLEG_EUR;  // W EUR
        }
        
        // Wstaw delegację
        $stmt = $db->prepare("
            INSERT INTO delegacje (nr_delegacji, pracownik_id, miesiac, rok, lokalizacja_id, cel_wyjazdu,
                                   data_zlecenia, typ_delegacji, kurs_eur, dieta_kraj, dieta_stawka, 
                                   stawka_km, noclegi_stawka, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $nrDelegacji, $pracownikId, $miesiac, $rok, $lokalizacjaId, $celWyjazdu,
            $dataZlecenia, $typDelegacji, $kursyJson, $dietaKraj, $dietaStawka, 
            $stawkaKm, $noclegiStawka, $currentUser['id']
        ]);
        
        $delegacjaId = $db->lastInsertId();
        
        // Wstaw zakresy
        $zakresStmt = $db->prepare("INSERT INTO delegacje_zakresy (delegacja_id, data_od, data_do) VALUES (?, ?, ?)");
        foreach ($zakresy as $z) {
            $zakresStmt->execute([$delegacjaId, $z['od'], $z['do']]);
        }
        
        // Jeśli zapamiętano dni, przekieruj na dodawanie kolejnej delegacji
        if ($zapamietajDni) {
            header("Location: dodaj.php?miesiac=$miesiac&rok=$rok&msg=created_next");
        } else {
            header("Location: index.php?miesiac=$miesiac&rok=$rok&msg=created");
        }
        exit;
    }
}

$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];

$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nowa delegacja - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 900px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #7c3aed; color: white; }
        
        header { margin-bottom: 25px; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 20px; }
        
        .form-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-group.full-width { grid-column: span 2; }
        .form-group label { font-weight: 600; color: #374151; font-size: 0.9rem; }
        .form-group input, .form-group select, .form-group textarea { 
            padding: 12px 15px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 1rem; 
        }
        .form-group input:focus, .form-group select:focus { border-color: #2563eb; outline: none; }
        .form-group small { color: #64748b; font-size: 0.8rem; }
        
        .btn { padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.95rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-secondary { background: #f1f5f9; color: #374151; }
        .btn-success { background: #16a34a; color: white; }
        .btn-small { padding: 8px 14px; font-size: 0.85rem; }
        .btn-danger { background: #dc2626; color: white; }
        
        .error-box { background: #fee2e2; border-left: 4px solid #dc2626; color: #991b1b; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .success-box { background: #dcfce7; border-left: 4px solid #16a34a; color: #166534; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        
        .zakresy-container { border: 2px dashed #e2e8f0; border-radius: 8px; padding: 15px; }
        .zakres-row { display: flex; gap: 10px; align-items: center; margin-bottom: 10px; }
        .zakres-row input { flex: 1; }
        
        #pracownik-info { background: #dbeafe; padding: 15px; border-radius: 8px; margin-top: 10px; display: none; }
        #lokalizacja-info { background: #dcfce7; padding: 15px; border-radius: 8px; margin-top: 10px; display: none; }
        
        .typ-wybor { display: flex; gap: 15px; margin-bottom: 15px; }
        .typ-btn { flex: 1; padding: 15px; border: 2px solid #e2e8f0; border-radius: 10px; cursor: pointer; text-align: center; transition: all 0.2s; }
        .typ-btn:hover { border-color: #93c5fd; background: #f0f9ff; }
        .typ-btn.active { border-color: #2563eb; background: #dbeafe; }
        .typ-btn.krajowa.active { border-color: #16a34a; background: #dcfce7; }
        .typ-btn.zagraniczna.active { border-color: #7c3aed; background: #ede9fe; }
        .typ-btn .icon { font-size: 2rem; display: block; margin-bottom: 8px; }
        .typ-btn .title { font-weight: 600; font-size: 1.1rem; }
        .typ-btn .desc { font-size: 0.85rem; color: #64748b; margin-top: 5px; }
        
        .stawki-info { background: #fef3c7; padding: 12px; border-radius: 8px; margin-bottom: 15px; font-size: 0.9rem; }
        .stawki-info.zagraniczna { background: #ede9fe; }
        
        .checkbox-group { display: flex; align-items: center; gap: 10px; padding: 15px; background: #f0fdf4; border-radius: 8px; border: 2px solid #86efac; }
        .checkbox-group input[type="checkbox"] { width: 20px; height: 20px; cursor: pointer; }
        .checkbox-group label { cursor: pointer; font-weight: 500; }
        .checkbox-group small { display: block; color: #64748b; margin-top: 3px; }
        
        .zapamiętane-info { background: #dbeafe; padding: 12px; border-radius: 8px; margin-bottom: 15px; border: 2px solid #93c5fd; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="./" class="active">🚗 Delegacje</a>
                <a href="lokalizacje.php">📍 Lokalizacje</a>
            </div>
        </nav>
        
        <header>
            <h1>➕ Nowa delegacja</h1>
        </header>
        
        <?php if ($msg === 'created_next'): ?>
            <div class="success-box">
                ✅ Delegacja została zapisana. Zakresy dat zostały zapamiętane - wybierz kolejnego pracownika.
            </div>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
            <div class="error-box">
                <strong>Błędy:</strong>
                <ul style="margin: 10px 0 0 20px;">
                    <?php foreach ($errors as $e): ?>
                        <li><?= htmlspecialchars($e) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="card">
                <div class="card-header">🌍 Typ delegacji</div>
                <div class="card-body">
                    <div class="typ-wybor">
                        <div class="typ-btn krajowa active" onclick="wybierzTyp('krajowa')">
                            <span class="icon">🇵🇱</span>
                            <span class="title">Krajowa</span>
                            <span class="desc">Dieta 45 zł, Nocleg 67,50 zł</span>
                        </div>
                        <div class="typ-btn zagraniczna" onclick="wybierzTyp('zagraniczna')">
                            <span class="icon">🇩🇪</span>
                            <span class="title">Zagraniczna</span>
                            <span class="desc">Dieta 49 EUR, Nocleg 170 EUR</span>
                        </div>
                    </div>
                    <input type="hidden" name="typ_delegacji" id="typ_delegacji" value="krajowa">
                    <div id="kurs-info" style="display: none;" class="stawki-info zagraniczna">
                        💶 Kurs EUR zostanie pobrany z NBP <strong>osobno dla każdego dnia wyjazdu</strong><br>
                        <small>Dieta i nocleg będą przeliczane wg kursu z pierwszego dnia każdego zakresu</small>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">📅 Okres delegacji</div>
                <div class="card-body">
                    <?php if (!empty($zapamietaneZakresy)): ?>
                        <div class="zapamiętane-info">
                            📋 <strong>Zapamiętane zakresy dat:</strong> 
                            <?php 
                            $teksty = [];
                            foreach ($zapamietaneZakresy as $z) {
                                $teksty[] = date('d.m', strtotime($z['od'])) . '-' . date('d.m', strtotime($z['do']));
                            }
                            echo implode(', ', $teksty);
                            ?>
                            <a href="dodaj.php?clear=1" style="margin-left: 15px; color: #dc2626;">✕ Wyczyść</a>
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Miesiąc</label>
                            <select name="miesiac" required>
                                <?php for ($m = 1; $m <= 12; $m++): ?>
                                    <option value="<?= $m ?>" <?= $m == $miesiac ? 'selected' : '' ?>><?= $miesiacNazwy[$m] ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Rok</label>
                            <select name="rok" required>
                                <?php for ($y = date('Y') - 1; $y <= date('Y') + 1; $y++): ?>
                                    <option value="<?= $y ?>" <?= $y == $rok ? 'selected' : '' ?>><?= $y ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group full-width">
                            <label>Zakresy dat (dni delegacji)</label>
                            <small>Możesz dodać kilka zakresów, np. 2-4, 8-10, 15-18</small>
                            <div class="zakresy-container" id="zakresy-container">
                                <?php if (!empty($zapamietaneZakresy)): ?>
                                    <?php foreach ($zapamietaneZakresy as $z): ?>
                                        <div class="zakres-row">
                                            <input type="date" name="zakres_od[]" value="<?= $z['od'] ?>" required>
                                            <span>do</span>
                                            <input type="date" name="zakres_do[]" value="<?= $z['do'] ?>" required>
                                            <button type="button" class="btn btn-small btn-danger" onclick="usunZakres(this)">🗑️</button>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="zakres-row">
                                        <input type="date" name="zakres_od[]" required>
                                        <span>do</span>
                                        <input type="date" name="zakres_do[]" required>
                                        <button type="button" class="btn btn-small btn-danger" onclick="usunZakres(this)">🗑️</button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <button type="button" class="btn btn-small btn-secondary" onclick="dodajZakres()" style="margin-top: 10px;">
                                ➕ Dodaj kolejny zakres
                            </button>
                        </div>
                        
                        <div class="form-group full-width">
                            <div class="checkbox-group">
                                <input type="checkbox" name="zapamietaj_dni" id="zapamietaj_dni" <?= !empty($zapamietaneZakresy) ? 'checked' : '' ?>>
                                <div>
                                    <label for="zapamietaj_dni">🔄 Zapamiętaj dni dla kolejnej delegacji</label>
                                    <small>Po zapisaniu, zakresy dat przeniosą się na formularz kolejnej delegacji</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">👤 Pracownik i miejsce</div>
                <div class="card-body">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Pracownik *</label>
                            <select name="pracownik_id" id="pracownik_id" required onchange="pokazInfoPracownik()">
                                <option value="">-- wybierz pracownika --</option>
                                <?php foreach ($pracownicy as $pr): ?>
                                    <option value="<?= $pr['id'] ?>" 
                                            data-klient="<?= htmlspecialchars($pr['klient_nazwa'] ?? '') ?>"
                                            data-stanowisko="<?= htmlspecialchars($pr['stanowisko'] ?? '') ?>">
                                        <?= htmlspecialchars($pr['nazwisko'] . ' ' . $pr['imie']) ?> 
                                        (<?= htmlspecialchars($pr['kod']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div id="pracownik-info"></div>
                        </div>
                        <div class="form-group">
                            <label>Lokalizacja *</label>
                            <select name="lokalizacja_id" id="lokalizacja_id" required onchange="pokazInfoLokalizacja()">
                                <option value="">-- wybierz lokalizację --</option>
                                <?php foreach ($lokalizacje as $l): ?>
                                    <option value="<?= $l['id'] ?>" data-km="<?= $l['kilometry'] ?>">
                                        <?= htmlspecialchars($l['nazwa']) ?> (<?= $l['kilometry'] ?> km)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div id="lokalizacja-info"></div>
                        </div>
                        <div class="form-group full-width">
                            <label>Cel wyjazdu</label>
                            <input type="text" name="cel_wyjazdu" id="cel_wyjazdu" placeholder="Zostanie uzupełnione automatycznie z oddelegowania">
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card" id="stawki-card">
                <div class="card-header">💰 Stawki</div>
                <div class="card-body">
                    <div id="stawki-krajowa-info" class="stawki-info">
                        🇵🇱 Delegacja krajowa - stawki w PLN
                    </div>
                    <div id="stawki-zagraniczna-info" class="stawki-info zagraniczna" style="display: none;">
                        🇩🇪 Delegacja zagraniczna - stawki w EUR (będą przeliczone wg kursów NBP)<br>
                        <small>Dieta: 49 EUR/dzień | Nocleg: 170 EUR/noc - każdy zakres wg kursu z dnia wyjazdu</small>
                    </div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label id="dieta-label">Dieta (zł/dzień)</label>
                            <input type="text" name="dieta_stawka" id="dieta_stawka" value="45,00" required>
                        </div>
                        <div class="form-group">
                            <label>Stawka za km (zł)</label>
                            <input type="text" name="stawka_km" value="1,15" required>
                        </div>
                        <div class="form-group">
                            <label id="nocleg-label">Nocleg (zł/noc)</label>
                            <input type="text" name="noclegi_stawka" id="noclegi_stawka" value="67,50" required>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="display: flex; gap: 15px; margin-top: 20px;">
                <button type="submit" class="btn btn-primary">💾 Zapisz delegację</button>
                <a href="./" class="btn btn-secondary">← Anuluj</a>
            </div>
        </form>
    </div>
    
    <script>
    function wybierzTyp(typ) {
        document.getElementById('typ_delegacji').value = typ;
        
        document.querySelectorAll('.typ-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelector('.typ-btn.' + typ).classList.add('active');
        
        document.getElementById('kurs-info').style.display = typ === 'zagraniczna' ? 'block' : 'none';
        document.getElementById('stawki-krajowa-info').style.display = typ === 'krajowa' ? 'block' : 'none';
        document.getElementById('stawki-zagraniczna-info').style.display = typ === 'zagraniczna' ? 'block' : 'none';
        
        if (typ === 'krajowa') {
            document.getElementById('dieta_stawka').value = '45,00';
            document.getElementById('noclegi_stawka').value = '67,50';
            document.getElementById('dieta-label').textContent = 'Dieta (zł/dzień)';
            document.getElementById('nocleg-label').textContent = 'Nocleg (zł/noc)';
            document.getElementById('dieta_stawka').readOnly = false;
            document.getElementById('noclegi_stawka').readOnly = false;
        } else {
            document.getElementById('dieta_stawka').value = '49,00';
            document.getElementById('noclegi_stawka').value = '170,00';
            document.getElementById('dieta-label').textContent = 'Dieta (EUR/dzień)';
            document.getElementById('nocleg-label').textContent = 'Nocleg (EUR/noc)';
            document.getElementById('dieta_stawka').readOnly = true;
            document.getElementById('noclegi_stawka').readOnly = true;
        }
    }
    
    function dodajZakres() {
        const container = document.getElementById('zakresy-container');
        const row = document.createElement('div');
        row.className = 'zakres-row';
        row.innerHTML = `
            <input type="date" name="zakres_od[]" required>
            <span>do</span>
            <input type="date" name="zakres_do[]" required>
            <button type="button" class="btn btn-small btn-danger" onclick="usunZakres(this)">🗑️</button>
        `;
        container.appendChild(row);
        
        // Dodaj event listener do nowych pól date
        row.querySelectorAll('input[type="date"]').forEach(addDateListener);
    }
    
    function usunZakres(btn) {
        const container = document.getElementById('zakresy-container');
        if (container.children.length > 1) {
            btn.parentElement.remove();
        }
    }
    
    // Funkcja dodająca listener do pól date - zapobiega submitowaniu przez Enter
    function addDateListener(input) {
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const inputs = Array.from(document.querySelectorAll('input, select, button[type="submit"]'));
                const idx = inputs.indexOf(this);
                if (idx > -1 && idx < inputs.length - 1) {
                    inputs[idx + 1].focus();
                }
            }
        });
    }
    
    // Dodaj listenery przy załadowaniu strony
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('input[type="date"]').forEach(addDateListener);
    });
    
    function pokazInfoPracownik() {
        const select = document.getElementById('pracownik_id');
        const info = document.getElementById('pracownik-info');
        const celInput = document.getElementById('cel_wyjazdu');
        
        const option = select.options[select.selectedIndex];
        const klient = option.dataset.klient;
        const stanowisko = option.dataset.stanowisko;
        
        if (klient) {
            info.style.display = 'block';
            info.innerHTML = `<strong>🏢 Oddelegowanie:</strong> ${klient}${stanowisko ? ' - ' + stanowisko : ''}`;
            celInput.value = `Praca - ${klient}${stanowisko ? ' (' + stanowisko + ')' : ''}`;
        } else {
            info.style.display = 'none';
            celInput.value = '';
        }
    }
    
    function pokazInfoLokalizacja() {
        const select = document.getElementById('lokalizacja_id');
        const info = document.getElementById('lokalizacja-info');
        
        const option = select.options[select.selectedIndex];
        const km = option.dataset.km;
        
        if (km) {
            const trasaTam = parseInt(km);
            info.style.display = 'block';
            info.innerHTML = `<strong>🚗 Trasa:</strong> Plewiska ↔ ${option.text.split(' (')[0]}<br>
                              <strong>📏 Dystans:</strong> ${trasaTam} km (w jedną stronę), ${trasaTam * 2} km (powrót)`;
        } else {
            info.style.display = 'none';
        }
    }
    </script>
</body>
</html>
<?php
// Wyczyść zapamiętane zakresy jeśli kliknięto "wyczyść"
if (isset($_GET['clear'])) {
    unset($_SESSION['zapamiętane_zakresy']);
    header('Location: dodaj.php?miesiac=' . $miesiac . '&rok=' . $rok);
    exit;
}
?>
