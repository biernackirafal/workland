<?php
/**
 * Diagnostyka KRS API - sprawdzenie formatu danych
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Test KRS API dla konkretnego numeru
$krs = $_GET['krs'] ?? '0000311174'; // All Fred Logistics

$url = "https://api-krs.ms.gov.pl/api/krs/OdpisAktualny/$krs?rejestr=P&format=json";

$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_HTTPHEADER => ['Accept: application/json']
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

header('Content-Type: text/html; charset=utf-8');

echo "<h1>Diagnostyka KRS API</h1>";
echo "<p>KRS: <strong>$krs</strong></p>";
echo "<p>HTTP Code: <strong>$httpCode</strong></p>";

if ($httpCode !== 200) {
    echo "<p style='color:red'>Błąd HTTP!</p>";
    exit;
}

$data = json_decode($response, true);

if (!$data) {
    echo "<p style='color:red'>Błąd parsowania JSON!</p>";
    echo "<pre>" . htmlspecialchars($response) . "</pre>";
    exit;
}

echo "<h2>Struktura odpowiedzi:</h2>";

// Sprawdź ścieżkę do zarządu
$odpis = $data['odpis'] ?? [];
$dane = $odpis['dane'] ?? [];
$dzial2 = $dane['dzial2'] ?? [];

echo "<h3>dzial2 keys:</h3>";
echo "<pre>" . print_r(array_keys($dzial2), true) . "</pre>";

// Reprezentacja
if (isset($dzial2['reprezentacja'])) {
    echo "<h3>reprezentacja:</h3>";
    echo "<pre>" . print_r($dzial2['reprezentacja'], true) . "</pre>";
}

// Prokurenci
if (isset($dzial2['prokurenci'])) {
    echo "<h3>prokurenci:</h3>";
    echo "<pre>" . print_r($dzial2['prokurenci'], true) . "</pre>";
}

// Pełna struktura dla debugowania
echo "<h2>Pełna struktura dzial2:</h2>";
echo "<pre>" . print_r($dzial2, true) . "</pre>";

echo "<h2>Raw JSON (fragment):</h2>";
echo "<pre>" . htmlspecialchars(substr($response, 0, 5000)) . "</pre>";
?>
