<?php
/**
 * Strona logowania
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
$error = '';

// Jeśli już zalogowany - przekieruj
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($login) || empty($password)) {
        $error = 'Wypełnij wszystkie pola.';
    } else {
        $stmt = $db->prepare("SELECT * FROM users WHERE login = ? AND active = 1");
        $stmt->execute([$login]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            // Zaloguj
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_login'] = $user['login'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role'] ?? 'viewer';
            $_SESSION['is_admin'] = ($user['role'] === 'admin') ? 1 : 0;
            
            // Aktualizuj ostatnie logowanie
            $db->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?")->execute([$user['id']]);
            
            // Loguj do historii
            logChange($db, 'LOGIN', 'users', $user['id'], "Logowanie użytkownika: {$user['login']}");
            
            // Przekieruj rekrutera na kandydatów, resztę na główną
            if ($user['role'] === 'rekruter') {
                header('Location: kandydaci/');
            } else {
                header('Location: index.php');
            }
            exit;
        } else {
            $error = 'Nieprawidłowy login lub hasło.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background: linear-gradient(135deg, #1e3a5f 0%, #2563eb 100%);
        }
        .login-box {
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 400px;
        }
        .login-box h1 {
            text-align: center;
            margin-bottom: 10px;
            color: #1e293b;
        }
        .login-box .subtitle {
            text-align: center;
            margin-bottom: 30px;
            color: #64748b;
        }
        .login-box .form-group {
            margin-bottom: 20px;
        }
        .login-box label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #1e293b;
        }
        .login-box input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.2s;
        }
        .login-box input:focus {
            outline: none;
            border-color: #2563eb;
        }
        .login-box .btn {
            width: 100%;
            padding: 14px;
            font-size: 1.1rem;
            margin-top: 10px;
        }
        .login-box .error {
            background: #fee2e2;
            color: #991b1b;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .logo {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <div class="logo">📋</div>
        <h1>Work Land</h1>
        <p class="subtitle">System Ewidencji Pracowników</p>
        
        <?php if ($error): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="login">Login</label>
                <input type="text" id="login" name="login" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>" required autofocus>
            </div>
            <div class="form-group">
                <label for="password">Hasło</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">🔐 Zaloguj się</button>
        </form>
    </div>
</body>
</html>
