<?php
/**
 * Generator listy obecności / karty ewidencji czasu pracy
 * Z możliwością edycji godzin pracy
 */

require_once 'includes/db.php';
$db = initDatabase();
requireLogin();

$pracownicy = $db->query("
    SELECT id, imie, nazwisko, kod
    FROM pracownicy 
    WHERE data_zwolnienia IS NULL OR data_zwolnienia = ''
    ORDER BY nazwisko, imie
")->fetchAll();

$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];

// Święta polskie
function getSwietaStale() {
    return [[1,1], [1,6], [5,1], [5,3], [8,15], [11,1], [11,11], [12,25], [12,26]];
}

function obliczWielkanoc($rok) {
    $a = $rok % 19;
    $b = intdiv($rok, 100);
    $c = $rok % 100;
    $d = intdiv($b, 4);
    $e = $b % 4;
    $f = intdiv($b + 8, 25);
    $g = intdiv($b - $f + 1, 3);
    $h = (19 * $a + $b - $d - $g + 15) % 30;
    $i = intdiv($c, 4);
    $k = $c % 4;
    $l = (32 + 2 * $e + 2 * $i - $h - $k) % 7;
    $m = intdiv($a + 11 * $h + 22 * $l, 451);
    $month = intdiv($h + $l - 7 * $m + 114, 31);
    $day = (($h + $l - 7 * $m + 114) % 31) + 1;
    return mktime(0, 0, 0, $month, $day, $rok);
}

function pobierzSwieta($rok) {
    $swieta = [];
    foreach (getSwietaStale() as $sw) {
        $swieta[] = mktime(0, 0, 0, $sw[0], $sw[1], $rok);
    }
    $wielkanoc = obliczWielkanoc($rok);
    $swieta[] = $wielkanoc;
    $swieta[] = strtotime('+1 day', $wielkanoc);
    $swieta[] = strtotime('+49 days', $wielkanoc);
    $swieta[] = strtotime('+60 days', $wielkanoc);
    return $swieta;
}

function czyWolny($timestamp, $swieta) {
    $dzienTyg = date('N', $timestamp);
    if ($dzienTyg >= 6) return true;
    foreach ($swieta as $sw) {
        if (date('Y-m-d', $timestamp) == date('Y-m-d', $sw)) return true;
    }
    return false;
}

$error = '';

// Generowanie dokumentu
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generuj'])) {
    $pracownikId = (int)$_POST['pracownik_id'];
    $miesiac = (int)$_POST['miesiac'];
    $rok = (int)$_POST['rok'];
    $godzStart = $_POST['godz_start'] ?? '8:00';
    $godzKoniec = $_POST['godz_koniec'] ?? '16:00';
    
    // Wczytaj godziny dla poszczególnych dni (obsługa wartości dziesiętnych)
    $customGodziny = [];
    if (isset($_POST['custom_godz'])) {
        foreach ($_POST['custom_godz'] as $dzien => $godz) {
            $val = floatval(str_replace(',', '.', $godz));
            $customGodziny[(int)$dzien] = $val;
        }
    }
    
    if (!$pracownikId) {
        $error = 'Wybierz pracownika';
    } else {
        $stmt = $db->prepare("SELECT imie, nazwisko, kod FROM pracownicy WHERE id = ?");
        $stmt->execute([$pracownikId]);
        $p = $stmt->fetch();
        
        if ($p) {
            $swieta = pobierzSwieta($rok);
            $dniWMiesiacu = cal_days_in_month(CAL_GREGORIAN, $miesiac, $rok);
            
            $fname = sprintf('lista_obecnosci_%s_%s_%02d_%d',
                str_replace(' ', '_', $p['nazwisko']),
                str_replace(' ', '_', $p['imie']),
                $miesiac, $rok
            );
            
            $format = $_POST['format'] ?? 'html';
            
            if ($format === 'xls') {
                header('Content-Type: application/vnd.ms-excel; charset=utf-8');
                header('Content-Disposition: attachment; filename="' . $fname . '.xls"');
                echo "\xEF\xBB\xBF";
            }
            ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Lista obecności - <?= htmlspecialchars($p['nazwisko'] . ' ' . $p['imie']) ?></title>
    <style>
        @page { size: A4 portrait; margin: 10mm; }
        @media print { .no-print { display: none !important; } }
        body { font-family: Arial, sans-serif; font-size: 10pt; margin: 0; padding: 20px; }
        h1 { text-align: center; font-size: 14pt; margin: 0 0 5px 0; }
        h2 { text-align: center; font-size: 12pt; font-weight: normal; margin: 0 0 15px 0; }
        .info td { padding: 2px 10px 2px 0; }
        .info .label { font-weight: bold; }
        table.lista { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table.lista th, table.lista td { border: 1px solid #333; padding: 4px 6px; text-align: center; }
        table.lista th { background: #e0e0e0; font-weight: bold; font-size: 9pt; }
        table.lista .wolny { background: #c0c0c0; }
        table.lista .left { text-align: left; }
        .suma td { padding: 3px 10px; }
        .podpisy table { width: 100%; margin-top: 40px; }
        .podpisy td { width: 50%; text-align: center; }
        .podpis-linia { border-top: 1px solid #333; margin-top: 50px; padding-top: 5px; font-size: 9pt; }
        .print-btn { position: fixed; top: 20px; right: 20px; padding: 10px 20px; background: #2563eb; color: white; border: none; border-radius: 6px; cursor: pointer; }
        .back-btn { position: fixed; top: 20px; left: 20px; padding: 10px 20px; background: #64748b; color: white; border-radius: 6px; text-decoration: none; }
    </style>
</head>
<body>
    <?php if ($format === 'html'): ?>
    <a href="lista_obecnosci_gen.php" class="back-btn no-print">← Powrót</a>
    <button onclick="window.print()" class="print-btn no-print">🖨️ Drukuj</button>
    <?php endif; ?>
    
    <h1>LISTA OBECNOŚCI</h1>
    <h2>KARTA EWIDENCJI CZASU PRACY</h2>
    
    <table class="info">
        <tr><td class="label">Imię:</td><td><?= htmlspecialchars($p['imie']) ?></td><td width="50"></td><td class="label">Miesiąc:</td><td><?= sprintf('%02d.%d', $miesiac, $rok) ?></td></tr>
        <tr><td class="label">Nazwisko:</td><td><?= htmlspecialchars($p['nazwisko']) ?></td></tr>
    </table>
    
    <table class="lista">
        <tr>
            <th style="width:50px">DATA</th>
            <th style="width:80px">GODZ.<br>ROZPOCZĘCIA</th>
            <th style="width:80px">GODZ.<br>WYJŚCIA</th>
            <th style="width:120px">PODPIS</th>
            <th>UWAGI</th>
            <th style="width:60px">Ilość<br>godzin</th>
            <th style="width:60px">Nieob.</th>
        </tr>
        <?php 
        $sumaGodzin = 0;
        $nieobecnosci = [
            'Uw' => 0, // Urlop wypoczynkowy
            'Uo' => 0, // Urlop okolicznościowy
            'Ub' => 0, // Urlop bezpłatny
            'Ch' => 0, // Choroba
            'Op' => 0, // Opieka
            'NU' => 0, // Nieobecność usprawiedliwiona
            'Del' => 0, // Delegacja
            'NN' => 0  // Nieobecność nieusprawiedliwiona
        ];
        
        // Wczytaj nieobecności z POST
        $customNieob = [];
        if (isset($_POST['custom_nieob'])) {
            foreach ($_POST['custom_nieob'] as $dzien => $nieob) {
                if (!empty($nieob)) {
                    $customNieob[(int)$dzien] = $nieob;
                }
            }
        }
        
        for ($dzien = 1; $dzien <= $dniWMiesiacu; $dzien++): 
            $timestamp = mktime(0, 0, 0, $miesiac, $dzien, $rok);
            $wolny = czyWolny($timestamp, $swieta);
            $klasa = $wolny ? 'wolny' : '';
            
            // Pobierz godziny dla tego dnia
            $godzinyDnia = isset($customGodziny[$dzien]) ? $customGodziny[$dzien] : 0;
            $sumaGodzin += $godzinyDnia;
            
            // Czy pokazać godziny start/koniec
            $pokazGodziny = $godzinyDnia > 0;
            
            // Formatuj godziny (bez .00 dla całkowitych)
            $godzinyStr = '';
            if ($godzinyDnia > 0) {
                $godzinyStr = ($godzinyDnia == floor($godzinyDnia)) ? (int)$godzinyDnia : number_format($godzinyDnia, 2, ',', '');
            }
            
            // Oblicz godzinę zakończenia na podstawie godziny startu + liczby godzin
            $godzKoniecDnia = '';
            if ($pokazGodziny && $godzinyDnia > 0) {
                // Parsuj godzinę startu (format "8:00" lub "8")
                $startParts = explode(':', $godzStart);
                $startH = (int)$startParts[0];
                $startM = isset($startParts[1]) ? (int)$startParts[1] : 0;
                
                // Dodaj godziny pracy
                $totalMinutes = ($startH * 60) + $startM + ($godzinyDnia * 60);
                $endH = floor($totalMinutes / 60);
                $endM = $totalMinutes % 60;
                
                // Formatuj godzinę zakończenia
                $godzKoniecDnia = sprintf('%d:%02d', $endH, $endM);
            }
            
            // Sprawdź nieobecność dla tego dnia
            $nieobDnia = isset($customNieob[$dzien]) ? $customNieob[$dzien] : '';
            if (!empty($nieobDnia) && isset($nieobecnosci[$nieobDnia])) {
                $nieobecnosci[$nieobDnia]++;
            }
        ?>
        <tr>
            <td class="<?= $klasa ?>"><?= $dzien ?></td>
            <td class="<?= $klasa ?>"><?= $pokazGodziny ? $godzStart : '' ?></td>
            <td class="<?= $klasa ?>"><?= $pokazGodziny ? $godzKoniecDnia : '' ?></td>
            <td class="<?= $klasa ?>"></td>
            <td class="<?= $klasa ?> left"></td>
            <td class="<?= $klasa ?>"><?= $godzinyStr ?></td>
            <td class="<?= $klasa ?>"><?= $nieobDnia ?></td>
        </tr>
        <?php endfor; 
        // Formatuj sumę
        $sumaStr = ($sumaGodzin == floor($sumaGodzin)) ? (int)$sumaGodzin : number_format($sumaGodzin, 2, ',', '');
        ?>
    </table>
    
    <table class="suma">
        <tr>
            <td style="text-align:right; font-weight:bold;">SUMA GODZIN:</td>
            <td style="font-weight:bold; border:1px solid #333; padding:5px 15px;"><?= $sumaStr ?></td>
        </tr>
    </table>
    
    <!-- Tabelka: Faktyczny czas pracy -->
    <table class="podsumowanie" style="width:100%; border-collapse:collapse; margin-top:15px; font-size:9pt;">
        <tr>
            <th colspan="2" style="border:1px solid #333; background:#e0e0e0; padding:4px;">Faktyczny<br>czas pracy</th>
            <th colspan="5" style="border:1px solid #333; background:#e0e0e0; padding:4px;">Czas przepracowany w godzinach<br>- odpowiednio</th>
        </tr>
        <tr>
            <th style="border:1px solid #333; padding:4px; width:60px;">dni</th>
            <th style="border:1px solid #333; padding:4px; width:60px;">godziny</th>
            <th style="border:1px solid #333; padding:4px;">w niedzielę<br>i święta</th>
            <th style="border:1px solid #333; padding:4px;">w dodatkowe<br>dni wolne</th>
            <th style="border:1px solid #333; padding:4px;">w porze<br>nocnej</th>
            <th style="border:1px solid #333; padding:4px;">w godz.<br>nadliczbowych</th>
            <th style="border:1px solid #333; padding:4px;">na<br>dyżurze</th>
        </tr>
        <tr>
            <?php 
            // Oblicz liczbę dni z godzinami > 0
            $dniPracy = 0;
            for ($d = 1; $d <= $dniWMiesiacu; $d++) {
                $g = isset($customGodziny[$d]) ? $customGodziny[$d] : 0;
                if ($g > 0) $dniPracy++;
            }
            ?>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $dniPracy ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $sumaStr ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"></td>
        </tr>
    </table>
    
    <!-- Tabelka: Nieobecności -->
    <table class="podsumowanie" style="width:100%; border-collapse:collapse; margin-top:10px; font-size:9pt;">
        <tr>
            <th colspan="8" style="border:1px solid #333; background:#e0e0e0; padding:4px;">Czas nieobecności w pracy<br>według przyczyn</th>
        </tr>
        <tr>
            <th style="border:1px solid #333; padding:4px; width:12.5%;">Uw</th>
            <th style="border:1px solid #333; padding:4px; width:12.5%;">Uo</th>
            <th style="border:1px solid #333; padding:4px; width:12.5%;">Ub</th>
            <th style="border:1px solid #333; padding:4px; width:12.5%;">Ch</th>
            <th style="border:1px solid #333; padding:4px; width:12.5%;">Op</th>
            <th style="border:1px solid #333; padding:4px; width:12.5%;">NU</th>
            <th style="border:1px solid #333; padding:4px; width:12.5%;">Del</th>
            <th style="border:1px solid #333; padding:4px; width:12.5%;">NN</th>
        </tr>
        <tr>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $nieobecnosci['Uw'] ?: '' ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $nieobecnosci['Uo'] ?: '' ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $nieobecnosci['Ub'] ?: '' ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $nieobecnosci['Ch'] ?: '' ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $nieobecnosci['Op'] ?: '' ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $nieobecnosci['NU'] ?: '' ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $nieobecnosci['Del'] ?: '' ?></td>
            <td style="border:1px solid #333; padding:4px; text-align:center;"><?= $nieobecnosci['NN'] ?: '' ?></td>
        </tr>
    </table>
    
    <div style="font-size:8pt; margin-top:8px; color:#666;">
        <strong>Legenda:</strong> Uw - urlop wypoczynkowy, Uo - urlop okolicznościowy, Ub - urlop bezpłatny, 
        Ch - choroba, Op - opieka, NU - nieobecność usprawiedliwiona, Del - delegacja, NN - nieobecność nieusprawiedliwiona
    </div>
    
    <div class="podpisy">
        <table><tr>
            <td><div class="podpis-linia">Podpis pracownika</div></td>
            <td><div class="podpis-linia">Podpis przełożonego</div></td>
        </tr></table>
    </div>
</body>
</html>
            <?php
            exit;
        }
    }
}

// Podgląd dni miesiąca (AJAX)
if (isset($_GET['ajax']) && $_GET['ajax'] === 'dni') {
    $miesiac = (int)$_GET['miesiac'];
    $rok = (int)$_GET['rok'];
    $swieta = pobierzSwieta($rok);
    $dniWMiesiacu = cal_days_in_month(CAL_GREGORIAN, $miesiac, $rok);
    
    $dni = [];
    for ($d = 1; $d <= $dniWMiesiacu; $d++) {
        $ts = mktime(0, 0, 0, $miesiac, $d, $rok);
        $dni[] = [
            'dzien' => $d,
            'wolny' => czyWolny($ts, $swieta),
            'nazwa' => date('D', $ts)
        ];
    }
    header('Content-Type: application/json');
    echo json_encode($dni);
    exit;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista obecności - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        .container { max-width: 1000px; margin: 0 auto; padding: 20px; }
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); flex-wrap: wrap; gap: 10px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #2563eb; color: white; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        header p { margin: 0; color: #64748b; }
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 20px; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; align-items: end; }
        .form-group { display: flex; flex-direction: column; gap: 6px; }
        .form-group.full-width { grid-column: 1 / -1; }
        .form-group label { font-weight: 600; color: #374151; font-size: 0.9rem; }
        .form-group input, .form-group select { padding: 10px 12px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 1rem; }
        .form-group input:focus, .form-group select:focus { border-color: #2563eb; outline: none; }
        .btn { padding: 10px 18px; border-radius: 8px; font-weight: 600; font-size: 0.95rem; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-group { display: flex; gap: 10px; flex-wrap: wrap; }
        .alert-error { background: #fee2e2; border-left: 4px solid #dc2626; color: #991b1b; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .info-box { background: #dbeafe; padding: 15px; border-radius: 8px; margin-top: 15px; }
        .info-box h4 { margin: 0 0 10px 0; color: #1e40af; }
        .info-box ul { margin: 0; padding-left: 20px; color: #1e3a8a; }
        
        .dni-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 5px; margin-top: 15px; }
        .dzien-box { padding: 8px; border: 1px solid #e2e8f0; border-radius: 6px; text-align: center; font-size: 0.85rem; }
        .dzien-box.wolny { background: #f1f5f9; color: #94a3b8; }
        .dzien-box.roboczy { background: white; }
        .dzien-box input { width: 45px; padding: 4px; text-align: center; border: 1px solid #d1d5db; border-radius: 4px; font-size: 0.85rem; }
        .dzien-box input:focus { border-color: #2563eb; outline: none; }
        .dzien-box .numer { font-weight: bold; margin-bottom: 3px; }
        .dzien-header { font-weight: bold; padding: 5px; text-align: center; background: #e2e8f0; border-radius: 4px; font-size: 0.8rem; }
        
        .quick-fill { background: #f8fafc; padding: 12px; border-radius: 8px; margin-bottom: 15px; }
        .quick-fill-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-bottom: 10px; }
        .quick-fill-row label { font-weight: 600; font-size: 0.9rem; }
        .quick-fill-row input { padding: 6px 10px; border: 2px solid #e2e8f0; border-radius: 6px; font-size: 0.9rem; }
        .btn-small { padding: 6px 12px; border-radius: 6px; font-size: 0.85rem; border: none; cursor: pointer; font-weight: 500; }
        .btn-fill { background: #2563eb; color: white; }
        .btn-fill:hover { background: #1d4ed8; }
        .btn-fill-all { background: #7c3aed; color: white; }
        .btn-fill-all:hover { background: #6d28d9; }
        .btn-clear { background: #ef4444; color: white; }
        .btn-clear:hover { background: #dc2626; }
        
        .quick-presets { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .quick-presets span { font-size: 0.85rem; color: #64748b; }
        .preset-btn { padding: 4px 10px; border: 1px solid #d1d5db; border-radius: 4px; background: white; cursor: pointer; font-size: 0.85rem; }
        .preset-btn:hover { background: #f1f5f9; border-color: #2563eb; }
        
        .suma-godzin { margin-top: 15px; padding: 10px; background: #dcfce7; border-radius: 6px; text-align: center; font-size: 1rem; }
        
        .dzien-checkbox { display: inline-flex; align-items: center; gap: 4px; padding: 6px 10px; background: #f1f5f9; border-radius: 6px; cursor: pointer; font-size: 0.85rem; border: 2px solid transparent; transition: all 0.2s; }
        .dzien-checkbox:hover { background: #e2e8f0; }
        .dzien-checkbox:has(input:checked) { background: #ddd6fe; border-color: #7c3aed; }
        .dzien-checkbox input { margin: 0; cursor: pointer; }
        
        .nieob-select { width: 100%; padding: 2px; border: 1px solid #d1d5db; border-radius: 4px; font-size: 0.75rem; margin-top: 3px; background: white; cursor: pointer; }
        .nieob-select:focus { border-color: #dc2626; outline: none; }
        .dzien-box.has-nieob { background: #fef2f2 !important; border-color: #fca5a5; }
        .dzien-box.has-nieob .nieob-select { background: #fee2e2; color: #dc2626; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="index.php"><img src="assets/logo.png" alt="Work Land"></a>
            </div>
            <div class="nav-links">
                <a href="index.php">📋 Pracownicy</a>
                <a href="delegacje/">🚗 Delegacje</a>
                <a href="lista_obecnosci_gen.php" class="active">📝 Lista obecności</a>
                <a href="rachunek_gen.php">💰 Rachunki</a>
            </div>
        </nav>
        
        <header style="margin-bottom: 25px;">
            <h1>📝 Lista obecności</h1>
            <p>Generator karty ewidencji czasu pracy</p>
        </header>
        
        <?php if ($error): ?>
            <div class="alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <form method="POST" id="mainForm">
            <input type="hidden" name="format" id="formatField" value="html">
            
            <div class="card">
                <div class="card-header">📄 Dane podstawowe</div>
                <div class="card-body">
                    <div class="form-grid">
                        <div class="form-group" style="grid-column: span 2;">
                            <label>Pracownik *</label>
                            <select name="pracownik_id" required>
                                <option value="">-- wybierz pracownika --</option>
                                <?php foreach ($pracownicy as $pr): ?>
                                    <option value="<?= $pr['id'] ?>"><?= htmlspecialchars($pr['nazwisko'] . ' ' . $pr['imie']) ?> (<?= htmlspecialchars($pr['kod']) ?>)</option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Miesiąc</label>
                            <select name="miesiac" id="miesiac" required onchange="ladujDni()">
                                <?php for ($m = 1; $m <= 12; $m++): ?>
                                    <option value="<?= $m ?>" <?= $m == date('m') ? 'selected' : '' ?>><?= $miesiacNazwy[$m] ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Rok</label>
                            <select name="rok" id="rok" required onchange="ladujDni()">
                                <?php for ($y = date('Y') - 1; $y <= date('Y') + 1; $y++): ?>
                                    <option value="<?= $y ?>" <?= $y == date('Y') ? 'selected' : '' ?>><?= $y ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">⏰ Godziny pracy</div>
                <div class="card-body">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Godzina rozpoczęcia</label>
                            <input type="text" name="godz_start" id="godzStart" value="8:00" placeholder="8:00">
                        </div>
                        <div class="form-group">
                            <label>Godzina zakończenia</label>
                            <input type="text" name="godz_koniec" id="godzKoniec" value="16:00" placeholder="16:00">
                        </div>
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <div class="btn-group">
                                <button type="submit" name="generuj" value="1" class="btn btn-primary" onclick="document.getElementById('formatField').value='html'">🖨️ Podgląd</button>
                                <button type="submit" name="generuj" value="1" class="btn btn-success" onclick="document.getElementById('formatField').value='xls'">📥 XLS</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="info-box" style="margin-top: 20px;">
                        <h4>📅 Edycja godzin dla poszczególnych dni</h4>
                        <p style="margin: 0 0 15px 0; font-size: 0.9rem;">Wpisz liczbę godzin dla każdego dnia (np. 8, 4, 2, 0.5). Szare dni to weekendy i święta.</p>
                        
                        <div class="quick-fill">
                            <div class="quick-fill-row">
                                <label>Wypełnij wartością:</label>
                                <input type="text" id="fillValue" value="8" placeholder="np. 8, 2, 0.5" style="width: 80px;">
                                <button type="button" class="btn-small btn-fill" onclick="wypelnijRobocze()">📝 Dni robocze</button>
                                <button type="button" class="btn-small btn-fill-all" onclick="wypelnijWszystkie()">📋 Wszystkie dni</button>
                                <button type="button" class="btn-small btn-clear" onclick="wyczysc()">🗑️ Wyczyść</button>
                            </div>
                            <div class="quick-fill-row" style="margin-top:10px; padding-top:10px; border-top:1px dashed #cbd5e1;">
                                <label>Tylko wybrane dni:</label>
                                <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                                    <label class="dzien-checkbox"><input type="checkbox" id="dzienPn" value="1"> Pn</label>
                                    <label class="dzien-checkbox"><input type="checkbox" id="dzienWt" value="2"> Wt</label>
                                    <label class="dzien-checkbox"><input type="checkbox" id="dzienSr" value="3"> Śr</label>
                                    <label class="dzien-checkbox"><input type="checkbox" id="dzienCz" value="4"> Cz</label>
                                    <label class="dzien-checkbox"><input type="checkbox" id="dzienPt" value="5"> Pt</label>
                                    <label class="dzien-checkbox"><input type="checkbox" id="dzienSo" value="6"> So</label>
                                    <label class="dzien-checkbox"><input type="checkbox" id="dzienNd" value="0"> Nd</label>
                                    <button type="button" class="btn-small" style="background:#7c3aed; color:white;" onclick="wypelnijWybraneDni()">✓ Wypełnij wybrane</button>
                                </div>
                            </div>
                            <div class="quick-presets">
                                <span>Szybkie:</span>
                                <button type="button" class="preset-btn" onclick="ustawPreset(8)">8h</button>
                                <button type="button" class="preset-btn" onclick="ustawPreset(4)">4h</button>
                                <button type="button" class="preset-btn" onclick="ustawPreset(2)">2h</button>
                                <button type="button" class="preset-btn" onclick="ustawPreset(1)">1h</button>
                                <button type="button" class="preset-btn" onclick="ustawPreset(0.5)">0.5h</button>
                                <button type="button" class="preset-btn" onclick="ustawPreset(0)">0</button>
                            </div>
                        </div>
                        
                        <div class="dni-grid">
                            <div class="dzien-header">Pn</div>
                            <div class="dzien-header">Wt</div>
                            <div class="dzien-header">Śr</div>
                            <div class="dzien-header">Cz</div>
                            <div class="dzien-header">Pt</div>
                            <div class="dzien-header">So</div>
                            <div class="dzien-header">Nd</div>
                        </div>
                        <div class="dni-grid" id="dniContainer">
                            <!-- Dni będą ładowane przez JS -->
                        </div>
                        
                        <div class="suma-godzin">
                            Suma godzin: <strong id="sumaGodzin">0</strong> | 
                            Dni pracy: <strong id="dniPracy">0</strong>
                        </div>
                        
                        <div class="nieob-section" style="margin-top:15px; padding-top:15px; border-top:1px solid #e2e8f0;">
                            <div class="nieob-suma" style="background:#fef2f2; padding:10px; border-radius:6px; font-size:0.9rem; margin-bottom:10px;">
                                <strong>📋 Nieobecności:</strong>
                                <span id="nieobSuma">brak</span>
                            </div>
                            <div style="font-size:0.8rem; color:#64748b;">
                                <strong>Legenda:</strong> Uw - urlop wypoczynkowy, Uo - okolicznościowy, Ub - bezpłatny, 
                                Ch - choroba, Op - opieka, NU - nieobecność uspr., Del - delegacja, NN - nieobecność nieuspr.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    
    <script>
    const dniTygodnia = ['Nd', 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So'];
    let dniData = []; // Przechowujemy dane o dniach
    
    function ladujDni() {
        const miesiac = document.getElementById('miesiac').value;
        const rok = document.getElementById('rok').value;
        const fillValue = document.getElementById('fillValue').value || '8';
        
        fetch(`?ajax=dni&miesiac=${miesiac}&rok=${rok}`)
            .then(r => r.json())
            .then(dni => {
                dniData = dni;
                const container = document.getElementById('dniContainer');
                container.innerHTML = '';
                
                // Pierwszy dzień miesiąca - dzień tygodnia (0=Nd, 1=Pn, ...)
                const pierwszyDzien = new Date(rok, miesiac - 1, 1).getDay();
                // Konwertuj na format Pn=0, Nd=6
                const offset = pierwszyDzien === 0 ? 6 : pierwszyDzien - 1;
                
                // Puste komórki na początku
                for (let i = 0; i < offset; i++) {
                    const empty = document.createElement('div');
                    empty.className = 'dzien-box';
                    empty.style.visibility = 'hidden';
                    container.appendChild(empty);
                }
                
                dni.forEach(d => {
                    const box = document.createElement('div');
                    box.className = 'dzien-box ' + (d.wolny ? 'wolny' : 'roboczy');
                    box.dataset.dzien = d.dzien;
                    const defaultVal = d.wolny ? '0' : fillValue;
                    box.innerHTML = `
                        <div class="numer">${d.dzien}</div>
                        <input type="text" name="custom_godz[${d.dzien}]" 
                               value="${defaultVal}" 
                               data-dzien="${d.dzien}"
                               data-wolny="${d.wolny ? '1' : '0'}"
                               onchange="przeliczSume()"
                               oninput="this.value = this.value.replace(',', '.')"
                               title="Godziny dla dnia ${d.dzien}">
                        <select name="custom_nieob[${d.dzien}]" 
                                data-nieob-dzien="${d.dzien}" 
                                class="nieob-select"
                                onchange="onNieobChange(${d.dzien}, this.value)">
                            <option value="">-</option>
                            <option value="Uw">Uw</option>
                            <option value="Uo">Uo</option>
                            <option value="Ub">Ub</option>
                            <option value="Ch">Ch</option>
                            <option value="Op">Op</option>
                            <option value="NU">NU</option>
                            <option value="Del">Del</option>
                            <option value="NN">NN</option>
                        </select>
                    `;
                    container.appendChild(box);
                });
                
                przeliczSume();
                przeliczNieobecnosci();
            });
    }
    
    function onNieobChange(dzien, typ) {
        const godzInput = document.querySelector(`input[data-dzien="${dzien}"]`);
        const box = document.querySelector(`.dzien-box[data-dzien="${dzien}"]`);
        
        if (typ) {
            // Nieobecność wybrana - ustaw 0 godzin i podświetl
            if (godzInput) godzInput.value = '0';
            if (box) box.classList.add('has-nieob');
        } else {
            // Usunięto nieobecność - przywróć godziny
            if (box) box.classList.remove('has-nieob');
            if (godzInput && godzInput.dataset.wolny === '0') {
                godzInput.value = document.getElementById('fillValue').value || '8';
            }
        }
        
        przeliczSume();
        przeliczNieobecnosci();
    }
    
    function przeliczSume() {
        let suma = 0;
        let dniPracy = 0;
        document.querySelectorAll('#dniContainer input[name^="custom_godz"]').forEach(inp => {
            const val = parseFloat(inp.value.replace(',', '.')) || 0;
            suma += val;
            if (val > 0) dniPracy++;
        });
        document.getElementById('sumaGodzin').textContent = suma.toFixed(suma % 1 === 0 ? 0 : 2);
        document.getElementById('dniPracy').textContent = dniPracy;
    }
    
    function przeliczNieobecnosci() {
        const nieob = {Uw:0, Uo:0, Ub:0, Ch:0, Op:0, NU:0, Del:0, NN:0};
        document.querySelectorAll('select[data-nieob-dzien]').forEach(sel => {
            if (sel.value && nieob.hasOwnProperty(sel.value)) {
                nieob[sel.value]++;
            }
        });
        
        const parts = [];
        for (const [key, val] of Object.entries(nieob)) {
            if (val > 0) parts.push(`${key}: ${val}`);
        }
        document.getElementById('nieobSuma').textContent = parts.length ? parts.join(', ') : 'brak';
    }
    
    function wypelnijRobocze() {
        const val = document.getElementById('fillValue').value.replace(',', '.') || '8';
        document.querySelectorAll('#dniContainer input[name^="custom_godz"]').forEach(inp => {
            if (inp.dataset.wolny === '0') {
                // Sprawdź czy nie ma nieobecności
                const dzien = inp.dataset.dzien;
                const nieobSelect = document.querySelector(`select[data-nieob-dzien="${dzien}"]`);
                if (!nieobSelect || !nieobSelect.value) {
                    inp.value = val;
                }
            }
        });
        przeliczSume();
    }
    
    function wypelnijWszystkie() {
        const val = document.getElementById('fillValue').value.replace(',', '.') || '8';
        document.querySelectorAll('#dniContainer input[name^="custom_godz"]').forEach(inp => {
            const dzien = inp.dataset.dzien;
            const nieobSelect = document.querySelector(`select[data-nieob-dzien="${dzien}"]`);
            if (!nieobSelect || !nieobSelect.value) {
                inp.value = val;
            }
        });
        przeliczSume();
    }
    
    function wypelnijWybraneDni() {
        const val = document.getElementById('fillValue').value.replace(',', '.') || '8';
        
        // Pobierz zaznaczone dni tygodnia (0=Nd, 1=Pn, 2=Wt, 3=Śr, 4=Cz, 5=Pt, 6=So)
        const wybraneDni = [];
        if (document.getElementById('dzienPn').checked) wybraneDni.push(1);
        if (document.getElementById('dzienWt').checked) wybraneDni.push(2);
        if (document.getElementById('dzienSr').checked) wybraneDni.push(3);
        if (document.getElementById('dzienCz').checked) wybraneDni.push(4);
        if (document.getElementById('dzienPt').checked) wybraneDni.push(5);
        if (document.getElementById('dzienSo').checked) wybraneDni.push(6);
        if (document.getElementById('dzienNd').checked) wybraneDni.push(0);
        
        if (wybraneDni.length === 0) {
            alert('Zaznacz przynajmniej jeden dzień tygodnia!');
            return;
        }
        
        const miesiac = parseInt(document.getElementById('miesiac').value);
        const rok = parseInt(document.getElementById('rok').value);
        
        let wypelniono = 0;
        
        // Dla każdego dnia w miesiącu sprawdź czy pasuje do wybranych dni tygodnia
        document.querySelectorAll('#dniContainer input[name^="custom_godz"]').forEach(inp => {
            const dzien = parseInt(inp.dataset.dzien);
            const nieobSelect = document.querySelector(`select[data-nieob-dzien="${dzien}"]`);
            
            // Sprawdź dzień tygodnia (0=Nd, 1=Pn, ...)
            const data = new Date(rok, miesiac - 1, dzien);
            const dzienTygodnia = data.getDay();
            
            if (wybraneDni.includes(dzienTygodnia)) {
                // Jeśli nie ma nieobecności, ustaw godziny
                if (!nieobSelect || !nieobSelect.value) {
                    inp.value = val;
                    wypelniono++;
                }
            }
        });
        
        przeliczSume();
        
        if (wypelniono > 0) {
            const nazwyDni = [];
            if (wybraneDni.includes(1)) nazwyDni.push('Pn');
            if (wybraneDni.includes(2)) nazwyDni.push('Wt');
            if (wybraneDni.includes(3)) nazwyDni.push('Śr');
            if (wybraneDni.includes(4)) nazwyDni.push('Cz');
            if (wybraneDni.includes(5)) nazwyDni.push('Pt');
            if (wybraneDni.includes(6)) nazwyDni.push('So');
            if (wybraneDni.includes(0)) nazwyDni.push('Nd');
            console.log(`Wypełniono ${wypelniono} dni (${nazwyDni.join(', ')}) wartością ${val}h`);
        }
    }
    
    function wyczysc() {
        document.querySelectorAll('#dniContainer input[name^="custom_godz"]').forEach(inp => {
            inp.value = '0';
        });
        // Wyczyść nieobecności
        document.querySelectorAll('select[data-nieob-dzien]').forEach(sel => {
            sel.value = '';
        });
        document.querySelectorAll('.dzien-box').forEach(el => {
            el.classList.remove('has-nieob');
        });
        przeliczSume();
        przeliczNieobecnosci();
    }
    
    function ustawPreset(val) {
        document.getElementById('fillValue').value = val;
        wypelnijRobocze();
    }
    
    // Ładuj dni przy starcie
    ladujDni();
    </script>
</body>
</html>
