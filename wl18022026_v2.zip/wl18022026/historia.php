<?php
/**
 * Historia zmian - tylko dla administratora
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

// Tylko admin może widzieć historię
if (!canViewHistory()) {
    header('Location: index.php?msg=noperm');
    exit;
}

$currentUser = getCurrentUser();

// Filtrowanie
$filterAkcja = isset($_GET['akcja']) ? trim($_GET['akcja']) : '';
$filterUser = isset($_GET['user']) ? (int)$_GET['user'] : 0;
$filterData = isset($_GET['data']) ? trim($_GET['data']) : '';

// Budowanie zapytania
$where = [];
$params = [];

if (!empty($filterAkcja)) {
    $where[] = "akcja = :akcja";
    $params[':akcja'] = $filterAkcja;
}

if ($filterUser > 0) {
    $where[] = "user_id = :user_id";
    $params[':user_id'] = $filterUser;
}

if (!empty($filterData)) {
    $where[] = "DATE(created_at) = :data";
    $params[':data'] = $filterData;
}

$whereClause = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

// Paginacja
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 50;
$offset = ($page - 1) * $perPage;

// Pobierz historię
$sql = "SELECT * FROM historia_zmian {$whereClause} ORDER BY created_at DESC LIMIT {$perPage} OFFSET {$offset}";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$historia = $stmt->fetchAll();

// Liczba wszystkich rekordów
$countSql = "SELECT COUNT(*) FROM historia_zmian {$whereClause}";
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalCount = $countStmt->fetchColumn();
$totalPages = ceil($totalCount / $perPage);

// Lista użytkowników do filtra
$users = $db->query("SELECT DISTINCT user_id, user_name FROM historia_zmian WHERE user_id IS NOT NULL ORDER BY user_name")->fetchAll();

// Backup bazy
$backupMessage = '';
if (isset($_POST['create_backup'])) {
    if (createBackup()) {
        $backupMessage = '<div class="alert success">Backup został utworzony pomyślnie.</div>';
        logChange($db, 'BACKUP', 'system', null, 'Utworzono backup bazy danych');
    } else {
        $backupMessage = '<div class="alert error">Błąd podczas tworzenia backupu.</div>';
    }
}

$backups = getBackups();

// Tłumaczenie akcji
function translateAction($akcja) {
    $actions = [
        'CREATE' => '➕ Dodanie',
        'UPDATE' => '✏️ Edycja',
        'DELETE' => '🗑️ Usunięcie',
        'IMPORT' => '📥 Import',
        'LOGIN' => '🔑 Logowanie',
        'LOGOUT' => '🚪 Wylogowanie',
        'BACKUP' => '💾 Backup'
    ];
    return $actions[$akcja] ?? $akcja;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historia zmian - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .history-table { font-size: 0.9rem; }
        .history-table td { vertical-align: top; }
        .action-badge { padding: 3px 8px; border-radius: 4px; font-size: 0.8rem; font-weight: 500; }
        .action-CREATE { background: #dcfce7; color: #166534; }
        .action-UPDATE { background: #fef3c7; color: #92400e; }
        .action-DELETE { background: #fee2e2; color: #dc2626; }
        .action-IMPORT { background: #dbeafe; color: #1d4ed8; }
        .action-LOGIN { background: #f3e8ff; color: #7c3aed; }
        .action-BACKUP { background: #e0e7ff; color: #4338ca; }
        .filters { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .filters-row { display: flex; gap: 15px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.85rem; color: #64748b; }
        .filter-group select, .filter-group input { padding: 8px 12px; border: 2px solid #e2e8f0; border-radius: 6px; }
        .pagination { display: flex; gap: 5px; justify-content: center; margin-top: 20px; }
        .pagination a, .pagination span { padding: 8px 12px; border-radius: 4px; text-decoration: none; }
        .pagination a { background: #e2e8f0; color: #1e293b; }
        .pagination a:hover { background: #2563eb; color: white; }
        .pagination .current { background: #2563eb; color: white; }
        .backup-section { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .backup-list { max-height: 200px; overflow-y: auto; }
        .backup-item { display: flex; justify-content: space-between; padding: 8px; border-bottom: 1px solid #e2e8f0; font-size: 0.9rem; }
        .details-json { font-size: 0.75rem; color: #64748b; max-width: 300px; overflow: hidden; text-overflow: ellipsis; }
        details summary { cursor: pointer; color: #2563eb; font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <span>👤 <?php echo sanitize($currentUser['name']); ?></span>
            <div class="nav-links">
                <a href="users.php">👥 Użytkownicy</a>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>📜 Historia zmian</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <?php echo $backupMessage; ?>
        
        <!-- Sekcja backupu -->
        <div class="backup-section">
            <h3>💾 Kopie zapasowe bazy danych</h3>
            <p class="muted">Baza danych: <code>data/pracownicy.db</code></p>
            
            <form method="POST" style="margin: 15px 0;">
                <button type="submit" name="create_backup" class="btn btn-primary" onclick="return confirm('Utworzyć nową kopię zapasową?')">💾 Utwórz backup teraz</button>
            </form>
            
            <?php if (!empty($backups)): ?>
                <h4>Istniejące kopie:</h4>
                <div class="backup-list">
                    <?php foreach (array_slice($backups, 0, 10) as $backup): ?>
                        <div class="backup-item">
                            <span><?php echo htmlspecialchars($backup['file']); ?></span>
                            <span class="muted"><?php echo date('d.m.Y H:i', $backup['date']); ?> (<?php echo round($backup['size']/1024); ?> KB)</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="muted">Brak kopii zapasowych.</p>
            <?php endif; ?>
        </div>
        
        <!-- Filtry -->
        <div class="filters">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group">
                        <label>Akcja</label>
                        <select name="akcja">
                            <option value="">-- Wszystkie --</option>
                            <option value="CREATE" <?php echo $filterAkcja === 'CREATE' ? 'selected' : ''; ?>>Dodanie</option>
                            <option value="UPDATE" <?php echo $filterAkcja === 'UPDATE' ? 'selected' : ''; ?>>Edycja</option>
                            <option value="DELETE" <?php echo $filterAkcja === 'DELETE' ? 'selected' : ''; ?>>Usunięcie</option>
                            <option value="IMPORT" <?php echo $filterAkcja === 'IMPORT' ? 'selected' : ''; ?>>Import</option>
                            <option value="LOGIN" <?php echo $filterAkcja === 'LOGIN' ? 'selected' : ''; ?>>Logowanie</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Użytkownik</label>
                        <select name="user">
                            <option value="">-- Wszyscy --</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?php echo $u['user_id']; ?>" <?php echo $filterUser == $u['user_id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($u['user_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Data</label>
                        <input type="date" name="data" value="<?php echo htmlspecialchars($filterData); ?>">
                    </div>
                    
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">🔍 Filtruj</button>
                        <?php if ($filterAkcja || $filterUser || $filterData): ?>
                            <a href="historia.php" class="btn btn-secondary">✕ Wyczyść</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        
        <div class="stats" style="margin-bottom: 15px;">
            <span>Znaleziono: <strong><?php echo $totalCount; ?></strong> wpisów</span>
        </div>
        
        <?php if (empty($historia)): ?>
            <div class="empty-state">
                <p>Brak wpisów w historii zmian.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>Data i czas</th>
                            <th>Użytkownik</th>
                            <th>Akcja</th>
                            <th>Opis</th>
                            <th>IP</th>
                            <th>Szczegóły</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($historia as $h): ?>
                        <tr>
                            <td><?php echo date('d.m.Y H:i:s', strtotime($h['created_at'])); ?></td>
                            <td><?php echo sanitize($h['user_name'] ?? 'System'); ?></td>
                            <td><span class="action-badge action-<?php echo $h['akcja']; ?>"><?php echo translateAction($h['akcja']); ?></span></td>
                            <td><?php echo sanitize($h['opis']); ?></td>
                            <td><small class="muted"><?php echo sanitize($h['ip_address']); ?></small></td>
                            <td>
                                <?php if ($h['stare_dane'] || $h['nowe_dane']): ?>
                                    <details>
                                        <summary>Pokaż</summary>
                                        <?php if ($h['stare_dane']): ?>
                                            <div class="details-json"><strong>Przed:</strong> <?php echo htmlspecialchars(mb_substr($h['stare_dane'], 0, 200)); ?>...</div>
                                        <?php endif; ?>
                                        <?php if ($h['nowe_dane']): ?>
                                            <div class="details-json"><strong>Po:</strong> <?php echo htmlspecialchars(mb_substr($h['nowe_dane'], 0, 200)); ?>...</div>
                                        <?php endif; ?>
                                    </details>
                                <?php else: ?>
                                    <span class="muted">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Paginacja -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=1&akcja=<?php echo urlencode($filterAkcja); ?>&user=<?php echo $filterUser; ?>&data=<?php echo urlencode($filterData); ?>">« Pierwsza</a>
                        <a href="?page=<?php echo $page-1; ?>&akcja=<?php echo urlencode($filterAkcja); ?>&user=<?php echo $filterUser; ?>&data=<?php echo urlencode($filterData); ?>">‹ Poprzednia</a>
                    <?php endif; ?>
                    
                    <span class="current">Strona <?php echo $page; ?> z <?php echo $totalPages; ?></span>
                    
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?php echo $page+1; ?>&akcja=<?php echo urlencode($filterAkcja); ?>&user=<?php echo $filterUser; ?>&data=<?php echo urlencode($filterData); ?>">Następna ›</a>
                        <a href="?page=<?php echo $totalPages; ?>&akcja=<?php echo urlencode($filterAkcja); ?>&user=<?php echo $filterUser; ?>&data=<?php echo urlencode($filterData); ?>">Ostatnia »</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <footer><p>Work Land © <?php echo date('Y'); ?> | Historia zmian | v<?= WORKLAND_VERSION ?></p></footer>
    </div>
</body>
</html>
