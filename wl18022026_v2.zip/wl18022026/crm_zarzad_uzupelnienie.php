<?php
/**
 * CRM - Uzupełnianie danych zarządu
 * 
 * Prosta wersja - kopiuj dane z rejestr.io i wklej
 * 
 * WGRAJ DO: /kadry/crm_zarzad_uzupelnienie.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once __DIR__ . '/includes/db.php';
requireLogin();

$db = initDatabase();

// Migracja
try { $db->exec("ALTER TABLE crm_klienci ADD COLUMN dane_uzupelnione INTEGER DEFAULT 0"); } catch (PDOException $e) {}

// === API: Zapisz dane ===
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save') {
    header('Content-Type: application/json; charset=utf-8');
    
    $klientId = (int)($_POST['klient_id'] ?? 0);
    $osobyText = trim($_POST['osoby_text'] ?? '');
    
    if (!$klientId || !$osobyText) {
        echo json_encode(['error' => 'Brak danych']);
        exit;
    }
    
    // Parsuj tekst - szukamy wzorców imię + nazwisko
    $osoby = [];
    $debug = [];
    
    // Normalizuj tekst
    $cleanText = preg_replace('/\s+/', ' ', $osobyText);
    
    // Wzorzec 1: Proste "Imię Nazwisko" (dwa słowa z wielkiej litery + małe)
    preg_match_all('/\b([A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+)\s+([A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]+(?:-[A-Za-ząćęłńóśźż]+)?)\b/u', $cleanText, $matches, PREG_SET_ORDER);
    
    // Słowa do pominięcia
    $skipWords = ['zarząd', 'zarządu', 'spółka', 'spółki', 'prezes', 'wiceprezes', 'członek', 'organ', 'skład', 'prokura', 'sposób', 'reprezentacji', 'prokurent', 'oddzielna', 'łączna', 'samoistna', 'spółdzielnia', 'rada', 'nadzorcza'];
    
    foreach ($matches as $m) {
        $imie = trim($m[1]);
        $nazwisko = trim($m[2]);
        
        // Filtruj fałszywe trafienia
        if (in_array(mb_strtolower($imie), $skipWords) || in_array(mb_strtolower($nazwisko), $skipWords)) {
            $debug[] = "Pominięto (stopword): $imie $nazwisko";
            continue;
        }
        
        // Sprawdź minimalną długość
        if (mb_strlen($imie) < 2 || mb_strlen($nazwisko) < 2) {
            continue;
        }
        
        $osoby[] = ['imie' => $imie, 'nazwisko' => $nazwisko];
        $debug[] = "Znaleziono: $imie $nazwisko";
    }
    
    if (empty($osoby)) {
        echo json_encode(['error' => 'Nie rozpoznano żadnych osób. Spróbuj skopiować tylko imiona i nazwiska.', 'debug' => $debug]);
        exit;
    }
    
    // Pobierz zamaskowane osoby
    $stmt = $db->prepare("
        SELECT id, imie, nazwisko 
        FROM crm_osoby 
        WHERE klient_id = ? 
        AND (imie LIKE '%*%' OR nazwisko LIKE '%*%')
    ");
    $stmt->execute([$klientId]);
    $masked = $stmt->fetchAll();
    
    $updated = 0;
    $log = [];
    
    foreach ($masked as $m) {
        $maskedImie = trim($m['imie']);
        $maskedNazwisko = trim($m['nazwisko']);
        $maskedFirst = mb_strtoupper(mb_substr($maskedImie, 0, 1));
        $maskedLastFirst = mb_strtoupper(mb_substr($maskedNazwisko, 0, 1));
        
        $debug[] = "Szukam dopasowania dla: '$maskedImie' '$maskedNazwisko' → litery: $maskedFirst, $maskedLastFirst";
        
        foreach ($osoby as $idx => $o) {
            $fullFirst = mb_strtoupper(mb_substr($o['imie'], 0, 1));
            $fullLastFirst = mb_strtoupper(mb_substr($o['nazwisko'], 0, 1));
            
            if ($maskedFirst === $fullFirst && $maskedLastFirst === $fullLastFirst) {
                $db->prepare("UPDATE crm_osoby SET imie = ?, nazwisko = ? WHERE id = ?")
                   ->execute([$o['imie'], $o['nazwisko'], $m['id']]);
                $log[] = "{$maskedImie} {$maskedNazwisko} → {$o['imie']} {$o['nazwisko']}";
                $updated++;
                unset($osoby[$idx]);
                break;
            }
        }
    }
    
    $db->prepare("UPDATE crm_klienci SET dane_uzupelnione = 1 WHERE id = ?")->execute([$klientId]);
    
    echo json_encode([
        'success' => true,
        'updated' => $updated,
        'found' => count($debug),
        'log' => $log,
        'debug' => $debug
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Reset
if (isset($_GET['action']) && $_GET['action'] === 'reset') {
    $db->exec("UPDATE crm_klienci SET dane_uzupelnione = 0");
    header('Location: crm_zarzad_uzupelnienie.php?msg=reset');
    exit;
}

// Statystyki
$stats = $db->query("
    SELECT 
        (SELECT COUNT(*) FROM crm_osoby WHERE imie LIKE '%*%' OR nazwisko LIKE '%*%') as zamaskowane,
        (SELECT COUNT(DISTINCT klient_id) FROM crm_osoby WHERE imie LIKE '%*%' OR nazwisko LIKE '%*%') as firmy_zamaskowane,
        (SELECT COUNT(*) FROM crm_klienci WHERE dane_uzupelnione = 1 AND krs_numer IS NOT NULL) as przetworzone
")->fetch();

// Lista firm
$firmy = $db->query("
    SELECT k.id, k.nazwa, k.krs_numer, k.dane_uzupelnione,
           (SELECT GROUP_CONCAT(imie || ' ' || nazwisko, ', ') 
            FROM crm_osoby 
            WHERE klient_id = k.id AND (imie LIKE '%*%' OR nazwisko LIKE '%*%')
           ) as osoby_zamaskowane
    FROM crm_klienci k
    WHERE k.krs_numer IS NOT NULL AND k.krs_numer != ''
    AND EXISTS (
        SELECT 1 FROM crm_osoby o 
        WHERE o.klient_id = k.id 
        AND (o.imie LIKE '%*%' OR o.nazwisko LIKE '%*%')
    )
    ORDER BY k.dane_uzupelnione ASC, k.nazwa ASC
    LIMIT 100
")->fetchAll();

$msgParam = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uzupełnianie danych zarządu</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        
        .header { background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); color: white; padding: 25px; border-radius: 12px; margin-bottom: 20px; }
        .header h1 { margin: 0; font-size: 22px; }
        .header p { margin: 10px 0 0; opacity: 0.9; }
        
        .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 20px; }
        .stat { background: white; padding: 20px; border-radius: 10px; text-align: center; }
        .stat-value { font-size: 32px; font-weight: 700; }
        .stat-value.orange { color: #ea580c; }
        .stat-value.green { color: #16a34a; }
        .stat-label { font-size: 12px; color: #6b7280; text-transform: uppercase; margin-top: 5px; }
        
        .card { background: white; border-radius: 12px; margin-bottom: 15px; overflow: hidden; }
        
        .how-to { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 20px; margin-bottom: 20px; border-radius: 0 8px 8px 0; }
        .how-to h3 { margin: 0 0 15px; color: #92400e; }
        .how-to ol { margin: 0; padding-left: 20px; }
        .how-to li { margin-bottom: 10px; line-height: 1.5; }
        .how-to code { background: #fef3c7; padding: 2px 6px; border-radius: 4px; }
        
        .firma-row { display: grid; grid-template-columns: 1fr auto; gap: 15px; padding: 15px 20px; border-bottom: 1px solid #f1f5f9; align-items: center; }
        .firma-row:last-child { border-bottom: none; }
        .firma-row:hover { background: #f8fafc; }
        .firma-row.done { background: #f0fdf4; }
        .firma-row.active { background: #eff6ff; border-left: 4px solid #2563eb; }
        
        .firma-name { font-weight: 600; color: #1e293b; margin-bottom: 4px; }
        .firma-meta { font-size: 12px; color: #6b7280; }
        .firma-meta a { color: #2563eb; }
        .masked { color: #dc2626; font-family: monospace; font-size: 11px; }
        
        .btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border: none; border-radius: 8px; font-size: 13px; font-weight: 500; cursor: pointer; text-decoration: none; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-outline { background: white; border: 1px solid #d1d5db; color: #374151; }
        .btn:hover { opacity: 0.9; }
        .btn-sm { padding: 6px 12px; font-size: 12px; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        
        .badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 500; }
        .badge-success { background: #dcfce7; color: #166534; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        
        .edit-panel { display: none; background: #f8fafc; padding: 20px; border-top: 1px solid #e2e8f0; }
        .edit-panel.active { display: block; }
        .edit-panel h4 { margin: 0 0 15px; }
        
        textarea { width: 100%; padding: 12px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 14px; font-family: inherit; resize: vertical; }
        textarea:focus { border-color: #2563eb; outline: none; }
        
        .edit-actions { display: flex; gap: 10px; margin-top: 15px; align-items: center; }
        .edit-result { margin-left: 15px; font-size: 13px; }
        .edit-result.success { color: #16a34a; }
        .edit-result.error { color: #dc2626; }
        
        .alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 15px; }
        .alert-success { background: #dcfce7; color: #166534; }
        
        @media (max-width: 768px) {
            .stats { grid-template-columns: 1fr; }
            .firma-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="container">
    
    <div class="header">
        <h1>🔄 Uzupełnianie danych zarządu</h1>
        <p>Zamień zamaskowane dane (R**** B********) na pełne imiona i nazwiska</p>
    </div>
    
    <?php if ($msgParam === 'reset'): ?>
    <div class="alert alert-success">✅ Zresetowano</div>
    <?php endif; ?>
    
    <div class="stats">
        <div class="stat">
            <div class="stat-value orange"><?= $stats['zamaskowane'] ?></div>
            <div class="stat-label">Zamaskowanych osób</div>
        </div>
        <div class="stat">
            <div class="stat-value orange"><?= $stats['firmy_zamaskowane'] ?></div>
            <div class="stat-label">Firm do uzupełnienia</div>
        </div>
        <div class="stat">
            <div class="stat-value green"><?= $stats['przetworzone'] ?></div>
            <div class="stat-label">Uzupełnionych</div>
        </div>
    </div>
    
    <div class="how-to">
        <h3>📋 Jak używać:</h3>
        <ol>
            <li>Kliknij <strong>"Otwórz rejestr.io"</strong> przy firmie</li>
            <li>Na stronie znajdź sekcję <strong>"Reprezentacja"</strong> lub <strong>"Zarząd"</strong></li>
            <li>Zaznacz i <strong>skopiuj</strong> imiona i nazwiska (Ctrl+C)</li>
            <li>Wróć tutaj, kliknij <strong>"Uzupełnij"</strong> i <strong>wklej</strong> tekst</li>
            <li>Kliknij <strong>"Zapisz"</strong> - system automatycznie dopasuje dane</li>
        </ol>
    </div>
    
    <?php if (empty($firmy)): ?>
    <div class="card" style="text-align: center; padding: 60px;">
        <div style="font-size: 64px;">🎉</div>
        <div style="font-size: 20px; margin-top: 10px; color: #16a34a;">Wszystkie dane uzupełnione!</div>
    </div>
    <?php else: ?>
    <div class="card">
        <?php foreach ($firmy as $f): 
            $krsClean = ltrim($f['krs_numer'], '0');
        ?>
        <div class="firma-row <?= $f['dane_uzupelnione'] ? 'done' : '' ?>" id="row-<?= $f['id'] ?>">
            <div>
                <div class="firma-name"><?= htmlspecialchars($f['nazwa']) ?></div>
                <div class="firma-meta">
                    KRS: <?= $f['krs_numer'] ?> · 
                    <a href="https://rejestr.io/krs/<?= $krsClean ?>" target="_blank">rejestr.io</a> · 
                    <a href="https://www.aleo.com/pl/firma/<?= $krsClean ?>" target="_blank">aleo.com</a>
                </div>
                <div class="masked"><?= htmlspecialchars($f['osoby_zamaskowane']) ?></div>
            </div>
            <div>
                <?php if ($f['dane_uzupelnione']): ?>
                    <span class="badge badge-success">✅ Gotowe</span>
                <?php else: ?>
                    <a href="https://rejestr.io/krs/<?= $krsClean ?>" target="_blank" class="btn btn-outline btn-sm">
                        🔗 Otwórz rejestr.io
                    </a>
                    <button class="btn btn-primary btn-sm" onclick="toggleEdit(<?= $f['id'] ?>)">
                        ✏️ Uzupełnij
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <div class="edit-panel" id="edit-<?= $f['id'] ?>">
            <h4>Wklej dane zarządu dla: <?= htmlspecialchars($f['nazwa']) ?></h4>
            <textarea id="text-<?= $f['id'] ?>" rows="6" placeholder="Wklej tutaj skopiowany tekst z rejestr.io...

Przykład:
Jan Kowalski - PREZES ZARZĄDU
Anna Nowak - CZŁONEK ZARZĄDU"></textarea>
            <div class="edit-actions">
                <button class="btn btn-success" onclick="saveData(<?= $f['id'] ?>)">💾 Zapisz</button>
                <button class="btn btn-outline" onclick="toggleEdit(<?= $f['id'] ?>)">Anuluj</button>
                <span class="edit-result" id="result-<?= $f['id'] ?>"></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    
    <div style="text-align: center; margin-top: 20px;">
        <a href="?action=reset" class="btn btn-outline" onclick="return confirm('Zresetować status wszystkich firm?')">🔄 Reset</a>
        <a href="crm_zarzad.php" class="btn btn-outline">← Zarząd KRS</a>
    </div>
    <?php endif; ?>
    
</div>

<script>
let activeEdit = null;

function toggleEdit(id) {
    // Zamknij poprzedni
    if (activeEdit && activeEdit !== id) {
        document.getElementById('edit-' + activeEdit).classList.remove('active');
        document.getElementById('row-' + activeEdit).classList.remove('active');
    }
    
    const panel = document.getElementById('edit-' + id);
    const row = document.getElementById('row-' + id);
    
    if (panel.classList.contains('active')) {
        panel.classList.remove('active');
        row.classList.remove('active');
        activeEdit = null;
    } else {
        panel.classList.add('active');
        row.classList.add('active');
        activeEdit = id;
        document.getElementById('text-' + id).focus();
    }
}

function saveData(id) {
    const text = document.getElementById('text-' + id).value.trim();
    const result = document.getElementById('result-' + id);
    
    if (!text) {
        result.textContent = '❌ Wklej tekst z danymi';
        result.className = 'edit-result error';
        return;
    }
    
    result.textContent = '⏳ Zapisuję...';
    result.className = 'edit-result';
    
    fetch(location.href, {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=save&klient_id=' + id + '&osoby_text=' + encodeURIComponent(text)
    })
    .then(r => r.json())
    .then(data => {
        if (data.error) {
            result.textContent = '❌ ' + data.error;
            result.className = 'edit-result error';
            if (data.debug && data.debug.length > 0) {
                console.log('Debug:', data.debug);
            }
        } else if (data.updated > 0) {
            result.textContent = '✅ Zaktualizowano ' + data.updated + ' osób!';
            result.className = 'edit-result success';
            console.log('Log:', data.log);
            console.log('Debug:', data.debug);
            
            // Po chwili przeładuj
            setTimeout(() => location.reload(), 1500);
        } else {
            let msg = '⚠️ Nie znaleziono dopasowań';
            if (data.debug) {
                msg += '\n\nZnalezione osoby:\n' + data.debug.filter(d => d.startsWith('Znaleziono')).join('\n');
                msg += '\n\nSzukane (zamaskowane):\n' + data.debug.filter(d => d.startsWith('Szukam')).join('\n');
            }
            result.innerHTML = msg.replace(/\n/g, '<br>');
            result.className = 'edit-result error';
            console.log('Debug:', data.debug);
        }
    })
    .catch(e => {
        result.textContent = '❌ Błąd: ' + e.message;
        result.className = 'edit-result error';
    });
}
</script>
</body>
</html>
