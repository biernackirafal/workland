<?php
/**
 * Skrypt powiadomień email o kończących się terminach
 * System Ewidencji Pracowników - Work Land
 * 
 * Uruchom codziennie przez CRON:
 * 0 8 * * * php /path/to/cron_powiadomienia.php
 */

// Konfiguracja
$CONFIG = [
    'email_to' => 'biuro@work-land.pl',
    'email_from' => 'system@work-land.pl',
    'email_from_name' => 'System Ewidencji Pracowników',
    'days_warning' => 30,  // Ile dni przed wygaśnięciem powiadamiać
    'base_url' => 'http://kadry.work-land.pl'
];

require_once __DIR__ . '/includes/db.php';

$db = initDatabase();

// Pobierz pracowników z kończącymi się terminami
$warningDate = date('Y-m-d', strtotime('+' . $CONFIG['days_warning'] . ' days'));
$today = date('Y-m-d');

// Badania lekarskie
$badania = $db->prepare("SELECT id, kod, imie, nazwisko, badania_lekarskie 
    FROM pracownicy 
    WHERE badania_lekarskie IS NOT NULL 
    AND badania_lekarskie != '' 
    AND badania_lekarskie <= ? 
    AND badania_lekarskie >= ?
    AND (data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > ?)
    ORDER BY badania_lekarskie");
$badania->execute([$warningDate, $today, $today]);
$badaniaList = $badania->fetchAll();

// Szkolenie BHP
$bhp = $db->prepare("SELECT id, kod, imie, nazwisko, szkolenie_bhp 
    FROM pracownicy 
    WHERE szkolenie_bhp IS NOT NULL 
    AND szkolenie_bhp != '' 
    AND szkolenie_bhp <= ? 
    AND szkolenie_bhp >= ?
    AND (data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > ?)
    ORDER BY szkolenie_bhp");
$bhp->execute([$warningDate, $today, $today]);
$bhpList = $bhp->fetchAll();

// Zezwolenie na pracę
$zezwolenia = $db->prepare("SELECT id, kod, imie, nazwisko, zezwolenie_do 
    FROM pracownicy 
    WHERE zezwolenie_do IS NOT NULL 
    AND zezwolenie_do != '' 
    AND zezwolenie_do <= ? 
    AND zezwolenie_do >= ?
    AND (data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > ?)
    ORDER BY zezwolenie_do");
$zezwolenia->execute([$warningDate, $today, $today]);
$zezwoleniaList = $zezwolenia->fetchAll();

// Data zakończenia pobytu
$pobyt = $db->prepare("SELECT id, kod, imie, nazwisko, data_zakonczenia_pobytu 
    FROM pracownicy 
    WHERE data_zakonczenia_pobytu IS NOT NULL 
    AND data_zakonczenia_pobytu != '' 
    AND data_zakonczenia_pobytu <= ? 
    AND data_zakonczenia_pobytu >= ?
    AND (data_zwolnienia IS NULL OR data_zwolnienia = '' OR data_zwolnienia > ?)
    ORDER BY data_zakonczenia_pobytu");
$pobyt->execute([$warningDate, $today, $today]);
$pobytList = $pobyt->fetchAll();

// Jeśli są jakieś powiadomienia, wyślij email
$total = count($badaniaList) + count($bhpList) + count($zezwoleniaList) + count($pobytList);

if ($total == 0) {
    echo "Brak powiadomień do wysłania.\n";
    exit(0);
}

// Funkcja formatowania daty
function fd($date) {
    return date('d.m.Y', strtotime($date));
}

function daysLeft($date) {
    $diff = strtotime($date) - strtotime('today');
    $days = floor($diff / 86400);
    if ($days < 0) return '<span style="color:#dc2626;font-weight:bold;">WYGASŁO!</span>';
    if ($days == 0) return '<span style="color:#dc2626;font-weight:bold;">DZISIAJ!</span>';
    if ($days <= 7) return '<span style="color:#f59e0b;font-weight:bold;">' . $days . ' dni</span>';
    return $days . ' dni';
}

// Budowanie treści emaila
$html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #1e293b; }
        .header { background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
        .content { background: #f8fafc; padding: 20px; }
        .section { background: white; padding: 15px; margin-bottom: 15px; border-radius: 8px; border-left: 4px solid #2563eb; }
        .section h3 { margin: 0 0 15px 0; color: #1e293b; }
        .section.warning { border-left-color: #f59e0b; }
        .section.danger { border-left-color: #dc2626; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #e2e8f0; }
        th { background: #f1f5f9; font-weight: 600; }
        .badge { padding: 3px 8px; border-radius: 4px; font-size: 0.85rem; }
        .badge-danger { background: #fee2e2; color: #dc2626; }
        .badge-warning { background: #fef3c7; color: #92400e; }
        .footer { background: #1e293b; color: #94a3b8; padding: 15px; text-align: center; font-size: 0.85rem; border-radius: 0 0 8px 8px; }
        a { color: #2563eb; }
    </style>
</head>
<body>
    <div class="header">
        <h1 style="margin:0;">⚠️ Powiadomienie o kończących się terminach</h1>
        <p style="margin:5px 0 0 0;">System Ewidencji Pracowników - Work Land</p>
    </div>
    <div class="content">
        <p>Poniżej znajduje się lista pracowników, którym wkrótce kończą się ważne dokumenty lub terminy.</p>
        <p><strong>Data raportu:</strong> ' . date('d.m.Y H:i') . '</p>';

// Badania lekarskie
if (!empty($badaniaList)) {
    $html .= '<div class="section danger">
        <h3>🩺 Badania lekarskie (' . count($badaniaList) . ')</h3>
        <table>
            <tr><th>Kod</th><th>Pracownik</th><th>Ważne do</th><th>Pozostało</th></tr>';
    foreach ($badaniaList as $p) {
        $html .= '<tr>
            <td><code>' . htmlspecialchars($p['kod']) . '</code></td>
            <td><a href="' . $CONFIG['base_url'] . '/view.php?id=' . $p['id'] . '">' . htmlspecialchars($p['imie'] . ' ' . $p['nazwisko']) . '</a></td>
            <td>' . fd($p['badania_lekarskie']) . '</td>
            <td>' . daysLeft($p['badania_lekarskie']) . '</td>
        </tr>';
    }
    $html .= '</table></div>';
}

// Szkolenie BHP
if (!empty($bhpList)) {
    $html .= '<div class="section warning">
        <h3>🦺 Szkolenie BHP (' . count($bhpList) . ')</h3>
        <table>
            <tr><th>Kod</th><th>Pracownik</th><th>Ważne do</th><th>Pozostało</th></tr>';
    foreach ($bhpList as $p) {
        $html .= '<tr>
            <td><code>' . htmlspecialchars($p['kod']) . '</code></td>
            <td><a href="' . $CONFIG['base_url'] . '/view.php?id=' . $p['id'] . '">' . htmlspecialchars($p['imie'] . ' ' . $p['nazwisko']) . '</a></td>
            <td>' . fd($p['szkolenie_bhp']) . '</td>
            <td>' . daysLeft($p['szkolenie_bhp']) . '</td>
        </tr>';
    }
    $html .= '</table></div>';
}

// Zezwolenia na pracę
if (!empty($zezwoleniaList)) {
    $html .= '<div class="section danger">
        <h3>📄 Zezwolenie na pracę (' . count($zezwoleniaList) . ')</h3>
        <table>
            <tr><th>Kod</th><th>Pracownik</th><th>Ważne do</th><th>Pozostało</th></tr>';
    foreach ($zezwoleniaList as $p) {
        $html .= '<tr>
            <td><code>' . htmlspecialchars($p['kod']) . '</code></td>
            <td><a href="' . $CONFIG['base_url'] . '/view.php?id=' . $p['id'] . '">' . htmlspecialchars($p['imie'] . ' ' . $p['nazwisko']) . '</a></td>
            <td>' . fd($p['zezwolenie_do']) . '</td>
            <td>' . daysLeft($p['zezwolenie_do']) . '</td>
        </tr>';
    }
    $html .= '</table></div>';
}

// Data zakończenia pobytu
if (!empty($pobytList)) {
    $html .= '<div class="section warning">
        <h3>🛂 Data zakończenia pobytu (' . count($pobytList) . ')</h3>
        <table>
            <tr><th>Kod</th><th>Pracownik</th><th>Ważne do</th><th>Pozostało</th></tr>';
    foreach ($pobytList as $p) {
        $html .= '<tr>
            <td><code>' . htmlspecialchars($p['kod']) . '</code></td>
            <td><a href="' . $CONFIG['base_url'] . '/view.php?id=' . $p['id'] . '">' . htmlspecialchars($p['imie'] . ' ' . $p['nazwisko']) . '</a></td>
            <td>' . fd($p['data_zakonczenia_pobytu']) . '</td>
            <td>' . daysLeft($p['data_zakonczenia_pobytu']) . '</td>
        </tr>';
    }
    $html .= '</table></div>';
}

$html .= '
        <p style="margin-top:20px;">
            <a href="' . $CONFIG['base_url'] . '" style="display:inline-block;background:#2563eb;color:white;padding:10px 20px;border-radius:6px;text-decoration:none;">
                🔗 Otwórz system ewidencji
            </a>
        </p>
    </div>
    <div class="footer">
        <p>Ta wiadomość została wygenerowana automatycznie przez System Ewidencji Pracowników Work Land.</p>
        <p>W razie pytań skontaktuj się z administratorem systemu.</p>
    </div>
</body>
</html>';

// Wyślij email
$subject = "⚠️ Powiadomienie: {$total} kończących się terminów - " . date('d.m.Y');

$headers = [
    'MIME-Version: 1.0',
    'Content-type: text/html; charset=UTF-8',
    'From: ' . $CONFIG['email_from_name'] . ' <' . $CONFIG['email_from'] . '>',
    'Reply-To: ' . $CONFIG['email_from'],
    'X-Mailer: PHP/' . phpversion()
];

$result = mail($CONFIG['email_to'], $subject, $html, implode("\r\n", $headers));

if ($result) {
    echo "Email wysłany pomyślnie do: {$CONFIG['email_to']}\n";
    echo "Powiadomienia: Badania: " . count($badaniaList) . ", BHP: " . count($bhpList) . ", Zezwolenia: " . count($zezwoleniaList) . ", Pobyt: " . count($pobytList) . "\n";
    
    // Loguj do historii
    logChange($db, 'EMAIL', 'system', null, "Wysłano powiadomienie email o {$total} kończących się terminach");
} else {
    echo "Błąd wysyłania emaila!\n";
    exit(1);
}
