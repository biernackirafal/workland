<?php
/**
 * Dodawanie pracownika
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$errors = [];
$success = false;

// Generuj nowy kod
$suggestedKod = generateKod($db);

// Pobierz listę klientów dla oddelegowania
$klienci = $db->query("SELECT id, nazwa FROM klienci WHERE active = 1 ORDER BY nazwa")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Walidacja
    $kod = sanitize($_POST['kod'] ?? '');
    $imie = sanitize($_POST['imie'] ?? '');
    $nazwisko = sanitize($_POST['nazwisko'] ?? '');
    
    if (empty($kod)) $errors[] = 'Kod pracownika jest wymagany.';
    if (empty($imie)) $errors[] = 'Imię jest wymagane.';
    if (empty($nazwisko)) $errors[] = 'Nazwisko jest wymagane.';
    
    // Sprawdź unikalność kodu
    if (!empty($kod)) {
        $stmt = $db->prepare("SELECT COUNT(*) FROM pracownicy WHERE kod = ?");
        $stmt->execute([$kod]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = 'Pracownik o takim kodzie już istnieje.';
        }
    }
    
    if (empty($errors)) {
        try {
            $stmt = $db->prepare("INSERT INTO pracownicy (
                kod, imie, nazwisko, narodowosc, dane_personalne, dokument_tozsamosci,
                dokument_typ, dokument_numer,
                data_urodzenia, pesel, nip, telefon, email, data_przyjecia, data_zwolnienia,
                okres_zatrudnienia_do, zezwolenie_do,
                stawka_wynagrodzenia, skladki, skladki_typ, forma_umowy, wymiar_czasu_pracy, typ_zleceniobiorcy, koszty_typ,
                urlop_bezplatny_od, urlop_bezplatny_do, grupa_inwalidzka,
                stanowisko, badania_lekarskie, szkolenie_bhp, data_zakonczenia_pobytu,
                konto_bankowe, adres, uwagi, prawo_jazdy, wozek_widlowy, wysoki_sklad, notatki
            ) VALUES (
                :kod, :imie, :nazwisko, :narodowosc, :dane_personalne, :dokument_tozsamosci,
                :dokument_typ, :dokument_numer,
                :data_urodzenia, :pesel, :nip, :telefon, :email, :data_przyjecia, :data_zwolnienia,
                :okres_zatrudnienia_do, :zezwolenie_do,
                :stawka_wynagrodzenia, :skladki, :skladki_typ, :forma_umowy, :wymiar_czasu_pracy, :typ_zleceniobiorcy, :koszty_typ,
                :urlop_bezplatny_od, :urlop_bezplatny_do, :grupa_inwalidzka,
                :stanowisko, :badania_lekarskie, :szkolenie_bhp, :data_zakonczenia_pobytu,
                :konto_bankowe, :adres, :uwagi, :prawo_jazdy, :wozek_widlowy, :wysoki_sklad, :notatki
            )");
            
            $stmt->execute([
                ':kod' => $kod,
                ':imie' => $imie,
                ':nazwisko' => $nazwisko,
                ':narodowosc' => sanitize($_POST['narodowosc'] ?? ''),
                ':dane_personalne' => sanitize($_POST['dane_personalne'] ?? ''),
                ':dokument_tozsamosci' => sanitize($_POST['dokument_tozsamosci'] ?? ''),
                ':dokument_typ' => sanitize($_POST['dokument_typ'] ?? 'dowód osobisty'),
                ':dokument_numer' => sanitize($_POST['dokument_tozsamosci'] ?? ''),
                ':data_urodzenia' => $_POST['data_urodzenia'] ?: null,
                ':pesel' => sanitize($_POST['pesel'] ?? ''),
                ':nip' => sanitize($_POST['nip'] ?? ''),
                ':telefon' => sanitize($_POST['telefon'] ?? ''),
                ':email' => sanitize($_POST['email'] ?? ''),
                ':data_przyjecia' => $_POST['data_przyjecia'] ?: null,
                ':data_zwolnienia' => $_POST['data_zwolnienia'] ?: null,
                ':okres_zatrudnienia_do' => $_POST['okres_zatrudnienia_do'] ?: null,
                ':zezwolenie_do' => $_POST['zezwolenie_do'] ?: null,
                ':stawka_wynagrodzenia' => !empty($_POST['stawka_wynagrodzenia']) ? str_replace(',', '.', $_POST['stawka_wynagrodzenia']) : null,
                ':skladki' => sanitize($_POST['skladki'] ?? ''),
                ':skladki_typ' => sanitize($_POST['skladki_typ'] ?? 'brutto'),
                ':forma_umowy' => sanitize($_POST['forma_umowy'] ?? ''),
                ':wymiar_czasu_pracy' => sanitize($_POST['wymiar_czasu_pracy'] ?? ''),
                ':typ_zleceniobiorcy' => sanitize($_POST['typ_zleceniobiorcy'] ?? 'standardowy'),
                ':koszty_typ' => sanitize($_POST['koszty_typ'] ?? 'standardowe'),
                ':urlop_bezplatny_od' => $_POST['urlop_bezplatny_od'] ?: null,
                ':urlop_bezplatny_do' => $_POST['urlop_bezplatny_do'] ?: null,
                ':grupa_inwalidzka' => sanitize($_POST['grupa_inwalidzka'] ?? ''),
                ':stanowisko' => sanitize($_POST['stanowisko'] ?? ''),
                ':badania_lekarskie' => $_POST['badania_lekarskie'] ?: null,
                ':szkolenie_bhp' => $_POST['szkolenie_bhp'] ?: null,
                ':data_zakonczenia_pobytu' => $_POST['data_zakonczenia_pobytu'] ?: null,
                ':konto_bankowe' => sanitize($_POST['konto_bankowe'] ?? ''),
                ':adres' => sanitize($_POST['adres'] ?? ''),
                ':uwagi' => sanitize($_POST['uwagi'] ?? ''),
                ':prawo_jazdy' => sanitize($_POST['prawo_jazdy'] ?? ''),
                ':wozek_widlowy' => !empty($_POST['wozek_widlowy']) ? 1 : 0,
                ':wysoki_sklad' => !empty($_POST['wysoki_sklad']) ? 1 : 0,
                ':notatki' => sanitize($_POST['notatki'] ?? ''),
            ]);
            
            $newId = $db->lastInsertId();
            logChange($db, 'CREATE', 'pracownicy', $newId, 
                "Dodano pracownika: {$imie} {$nazwisko} (kod: {$kod})");
            
            // Zapisz oddelegowanie jeśli wybrano klienta
            $klient_id = (int)($_POST['klient_id'] ?? 0);
            if ($klient_id > 0) {
                $oddelegowanie_od = $_POST['oddelegowanie_od'] ?: date('Y-m-d');
                $oddelegowanie_do = $_POST['oddelegowanie_do'] ?: null;
                $oddelegowanie_stanowisko = sanitize($_POST['oddelegowanie_stanowisko'] ?? '');
                
                $stmt = $db->prepare("INSERT INTO oddelegowania (pracownik_id, klient_id, data_od, data_do, stanowisko, active) VALUES (?, ?, ?, ?, ?, 1)");
                $stmt->execute([$newId, $klient_id, $oddelegowanie_od, $oddelegowanie_do, $oddelegowanie_stanowisko]);
                
                logChange($db, 'CREATE', 'oddelegowania', $db->lastInsertId(), "Oddelegowano pracownika {$imie} {$nazwisko}");
            }
            
            // Obsługa uploadowanych plików
            if (!empty($_FILES['pliki']['name'][0])) {
                $uploadDir = __DIR__ . '/data/uploads/' . $newId . '/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }
                
                foreach ($_FILES['pliki']['name'] as $index => $originalName) {
                    if ($_FILES['pliki']['error'][$index] === UPLOAD_ERR_OK) {
                        $tmpName = $_FILES['pliki']['tmp_name'][$index];
                        $fileSize = $_FILES['pliki']['size'][$index];
                        $typ = sanitize($_POST['pliki_typ'][$index] ?? 'inny');
                        $nazwa = sanitize($_POST['pliki_nazwa'][$index] ?? '') ?: $originalName;
                        
                        $fileName = uniqid() . '_' . preg_replace('/[^a-zA-Z0-9_.-]/', '_', $originalName);
                        $filePath = $uploadDir . $fileName;
                        
                        if (move_uploaded_file($tmpName, $filePath)) {
                            $stmt = $db->prepare("INSERT INTO pliki_pracownika (pracownik_id, nazwa, typ, nazwa_pliku, rozmiar) VALUES (?, ?, ?, ?, ?)");
                            $stmt->execute([$newId, $nazwa, $typ, $fileName, $fileSize]);
                            
                            logChange($db, 'CREATE', 'pliki_pracownika', $db->lastInsertId(), "Dodano plik: {$nazwa}");
                        }
                    }
                }
            }
            
            // Zapisz stawkę do historii jeśli jest podana
            $stawka = !empty($_POST['stawka_wynagrodzenia']) ? floatval(str_replace(',', '.', $_POST['stawka_wynagrodzenia'])) : 0;
            $stawkaMiesiac = (int)($_POST['stawka_miesiac'] ?? date('m'));
            $stawkaRok = (int)($_POST['stawka_rok'] ?? date('Y'));
            
            if ($stawka > 0) {
                try {
                    $stmtStawka = $db->prepare("INSERT INTO historia_stawek (pracownik_id, miesiac, rok, stawka, uwagi) VALUES (?, ?, ?, ?, ?)");
                    $stmtStawka->execute([$newId, $stawkaMiesiac, $stawkaRok, $stawka, '']);
                } catch (PDOException $e) {}
            }
            
            header('Location: index.php?msg=added');
            exit;
        } catch (PDOException $e) {
            $errors[] = 'Błąd bazy danych: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj pracownika - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>➕ Dodaj pracownika</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <?php if (!empty($errors)): ?>
            <div class="alert error">
                <strong>Wystąpiły błędy:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form method="POST" class="employee-form" enctype="multipart/form-data">
            <!-- Dane podstawowe -->
            <fieldset>
                <legend>📋 Dane podstawowe</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="kod">Kod pracownika *</label>
                        <input type="text" id="kod" name="kod" value="<?= $_POST['kod'] ?? $suggestedKod ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="imie">Imię *</label>
                        <input type="text" id="imie" name="imie" value="<?= $_POST['imie'] ?? '' ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="nazwisko">Nazwisko *</label>
                        <input type="text" id="nazwisko" name="nazwisko" value="<?= $_POST['nazwisko'] ?? '' ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="narodowosc">Narodowość</label>
                        <input type="text" id="narodowosc" name="narodowosc" value="<?= $_POST['narodowosc'] ?? '' ?>" list="narodowosc-list">
                        <datalist id="narodowosc-list">
                            <option value="Polska">
                            <option value="Ukraina">
                            <option value="Białoruś">
                            <option value="Rosja">
                            <option value="Mołdawia">
                            <option value="Gruzja">
                            <option value="Kazachstan">
                            <option value="Kirgistan">
                            <option value="Turkmenistan">
                            <option value="Uzbekistan">
                            <option value="Tadżykistan">
                            <option value="Azerbejdżan">
                            <option value="Armenia">
                            <option value="Indie">
                            <option value="Nepal">
                            <option value="Filipiny">
                            <option value="Bangladesz">
                            <option value="Wietnam">
                            <option value="Turcja">
                        </datalist>
                    </div>
                    <div class="form-group">
                        <label for="data_urodzenia">Data urodzenia</label>
                        <input type="date" id="data_urodzenia" name="data_urodzenia" value="<?= $_POST['data_urodzenia'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="stanowisko">Stanowisko</label>
                        <input type="text" id="stanowisko" name="stanowisko" value="<?= $_POST['stanowisko'] ?? '' ?>">
                    </div>
                </div>
            </fieldset>
            
            <!-- Dokumenty -->
            <fieldset>
                <legend>🪪 Dokumenty tożsamości</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="pesel">PESEL</label>
                        <input type="text" id="pesel" name="pesel" value="<?= $_POST['pesel'] ?? '' ?>" maxlength="11" pattern="[0-9]{11}">
                    </div>
                    <div class="form-group">
                        <label for="nip">NIP</label>
                        <input type="text" id="nip" name="nip" value="<?= $_POST['nip'] ?? '' ?>" maxlength="13">
                    </div>
                    <div class="form-group">
                        <label for="dokument_typ">Typ dokumentu tożsamości</label>
                        <select id="dokument_typ" name="dokument_typ">
                            <option value="dowód osobisty" <?= ($_POST['dokument_typ'] ?? '') == 'dowód osobisty' ? 'selected' : '' ?>>Dowód osobisty</option>
                            <option value="paszport" <?= ($_POST['dokument_typ'] ?? '') == 'paszport' ? 'selected' : '' ?>>Paszport</option>
                            <option value="karta pobytu" <?= ($_POST['dokument_typ'] ?? '') == 'karta pobytu' ? 'selected' : '' ?>>Karta pobytu</option>
                            <option value="inny dokument" <?= ($_POST['dokument_typ'] ?? '') == 'inny dokument' ? 'selected' : '' ?>>Inny dokument tożsamości</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="dokument_tozsamosci">Nr dokumentu (seria i numer)</label>
                        <input type="text" id="dokument_tozsamosci" name="dokument_tozsamosci" value="<?= $_POST['dokument_tozsamosci'] ?? '' ?>" placeholder="np. ABC123456">
                    </div>
                    <div class="form-group full-width">
                        <label for="dane_personalne">Dodatkowe dane personalne</label>
                        <textarea id="dane_personalne" name="dane_personalne" rows="2"><?= $_POST['dane_personalne'] ?? '' ?></textarea>
                    </div>
                </div>
            </fieldset>
            
            <!-- Zatrudnienie -->
            <fieldset>
                <legend>💼 Zatrudnienie</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="data_przyjecia">Data przyjęcia</label>
                        <input type="date" id="data_przyjecia" name="data_przyjecia" value="<?= $_POST['data_przyjecia'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="data_zwolnienia">Data zwolnienia</label>
                        <input type="date" id="data_zwolnienia" name="data_zwolnienia" value="<?= $_POST['data_zwolnienia'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="okres_zatrudnienia_do">Okres zatrudnienia do</label>
                        <input type="date" id="okres_zatrudnienia_do" name="okres_zatrudnienia_do" value="<?= $_POST['okres_zatrudnienia_do'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="forma_umowy">Forma umowy o pracę</label>
                        <select id="forma_umowy" name="forma_umowy">
                            <option value="">-- wybierz --</option>
                            <option value="umowa o pracę na czas określony" <?= ($_POST['forma_umowy'] ?? '') == 'umowa o pracę na czas określony' ? 'selected' : '' ?>>Umowa o pracę na czas określony</option>
                            <option value="umowa o pracę na czas nieokreślony" <?= ($_POST['forma_umowy'] ?? '') == 'umowa o pracę na czas nieokreślony' ? 'selected' : '' ?>>Umowa o pracę na czas nieokreślony</option>
                            <option value="umowa o pracę na okres próbny" <?= ($_POST['forma_umowy'] ?? '') == 'umowa o pracę na okres próbny' ? 'selected' : '' ?>>Umowa o pracę na okres próbny</option>
                            <option value="umowa zlecenie" <?= ($_POST['forma_umowy'] ?? '') == 'umowa zlecenie' ? 'selected' : '' ?>>Umowa zlecenie</option>
                            <option value="umowa o dzieło" <?= ($_POST['forma_umowy'] ?? '') == 'umowa o dzieło' ? 'selected' : '' ?>>Umowa o dzieło</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="wymiar_czasu_pracy">Wymiar czasu pracy</label>
                        <select id="wymiar_czasu_pracy" name="wymiar_czasu_pracy">
                            <option value="">-- wybierz --</option>
                            <option value="pełny etat" <?= ($_POST['wymiar_czasu_pracy'] ?? '') == 'pełny etat' ? 'selected' : '' ?>>Pełny etat</option>
                            <option value="3/4 etatu" <?= ($_POST['wymiar_czasu_pracy'] ?? '') == '3/4 etatu' ? 'selected' : '' ?>>3/4 etatu</option>
                            <option value="1/2 etatu" <?= ($_POST['wymiar_czasu_pracy'] ?? '') == '1/2 etatu' ? 'selected' : '' ?>>1/2 etatu</option>
                            <option value="1/4 etatu" <?= ($_POST['wymiar_czasu_pracy'] ?? '') == '1/4 etatu' ? 'selected' : '' ?>>1/4 etatu</option>
                            <option value="1/8 etatu" <?= ($_POST['wymiar_czasu_pracy'] ?? '') == '1/8 etatu' ? 'selected' : '' ?>>1/8 etatu</option>
                            <option value="1/16 etatu" <?= ($_POST['wymiar_czasu_pracy'] ?? '') == '1/16 etatu' ? 'selected' : '' ?>>1/16 etatu</option>
                            <option value="1/32 etatu" <?= ($_POST['wymiar_czasu_pracy'] ?? '') == '1/32 etatu' ? 'selected' : '' ?>>1/32 etatu</option>
                            <option value="1/40 etatu" <?= ($_POST['wymiar_czasu_pracy'] ?? '') == '1/40 etatu' ? 'selected' : '' ?>>1/40 etatu</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="typ_zleceniobiorcy">Typ zleceniobiorcy (do rachunków)</label>
                        <select id="typ_zleceniobiorcy" name="typ_zleceniobiorcy">
                            <option value="standardowy" <?= ($_POST['typ_zleceniobiorcy'] ?? 'standardowy') == 'standardowy' ? 'selected' : '' ?>>👤 Standardowy (>26 lat)</option>
                            <option value="student" <?= ($_POST['typ_zleceniobiorcy'] ?? '') == 'student' ? 'selected' : '' ?>>🎓 Student/uczeń do 26 lat</option>
                            <option value="standard_26" <?= ($_POST['typ_zleceniobiorcy'] ?? '') == 'standard_26' ? 'selected' : '' ?>>🧑 Do 26 lat (PIT-0)</option>
                            <option value="emeryt" <?= ($_POST['typ_zleceniobiorcy'] ?? '') == 'emeryt' ? 'selected' : '' ?>>👴 Emeryt/rencista</option>
                            <option value="inny_tytul" <?= ($_POST['typ_zleceniobiorcy'] ?? '') == 'inny_tytul' ? 'selected' : '' ?>>💼 Inny tytuł (tylko zdrow.)</option>
                            <option value="bez_zus_zdrow" <?= ($_POST['typ_zleceniobiorcy'] ?? '') == 'bez_zus_zdrow' ? 'selected' : '' ?>>📋 Bez składek (tylko podatek)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="koszty_typ">Koszty uzyskania przychodu</label>
                        <select id="koszty_typ" name="koszty_typ">
                            <option value="standardowe" <?= ($_POST['koszty_typ'] ?? 'standardowe') == 'standardowe' ? 'selected' : '' ?>>20% - standardowe</option>
                            <option value="autorskie" <?= ($_POST['koszty_typ'] ?? '') == 'autorskie' ? 'selected' : '' ?>>50% - prawa autorskie</option>
                        </select>
                    </div>
                </div>
            </fieldset>
            
            <!-- Wynagrodzenie -->
            <fieldset>
                <legend>💰 Wynagrodzenie i składki</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="stawka_wynagrodzenia">Stawka wynagrodzenia (zł)</label>
                        <input type="text" id="stawka_wynagrodzenia" name="stawka_wynagrodzenia" value="<?= $_POST['stawka_wynagrodzenia'] ?? '' ?>" placeholder="np. 4500,00">
                    </div>
                    <div class="form-group">
                        <label for="stawka_miesiac">Miesiąc obowiązywania</label>
                        <select id="stawka_miesiac" name="stawka_miesiac">
                            <?php 
                            $miesiace = [1=>'Styczeń',2=>'Luty',3=>'Marzec',4=>'Kwiecień',5=>'Maj',6=>'Czerwiec',7=>'Lipiec',8=>'Sierpień',9=>'Wrzesień',10=>'Październik',11=>'Listopad',12=>'Grudzień'];
                            $currentMonth = (int)date('m');
                            foreach ($miesiace as $num => $nazwa): ?>
                                <option value="<?= $num ?>" <?= $num == $currentMonth ? 'selected' : '' ?>><?= $nazwa ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="stawka_rok">Rok</label>
                        <select id="stawka_rok" name="stawka_rok">
                            <?php 
                            $currentYear = (int)date('Y');
                            for ($y = $currentYear - 2; $y <= $currentYear + 1; $y++): ?>
                                <option value="<?= $y ?>" <?= $y == $currentYear ? 'selected' : '' ?>><?= $y ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="skladki">Składki</label>
                        <input type="text" id="skladki" name="skladki" value="<?= $_POST['skladki'] ?? '' ?>">
                        <div style="margin-top: 6px;">
                            <select name="skladki_typ" style="width: 100px; padding: 6px 10px;">
                                <option value="brutto" <?= ($_POST['skladki_typ'] ?? 'brutto') == 'brutto' ? 'selected' : '' ?>>brutto</option>
                                <option value="netto" <?= ($_POST['skladki_typ'] ?? '') == 'netto' ? 'selected' : '' ?>>netto</option>
                            </select>
                        </div>
                    </div>
                </div>
                <p class="help-text" style="margin-top: 10px; color: #64748b; font-size: 0.85rem;">
                    💡 Wybierz miesiąc i rok, od którego obowiązuje ta stawka. Historia stawek jest zapisywana automatycznie.
                </p>
            </fieldset>
            
            <!-- Zezwolenia i badania -->
            <fieldset>
                <legend>📅 Zezwolenia i badania</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="zezwolenie_do">Zezwolenie na pracę ważne do</label>
                        <input type="date" id="zezwolenie_do" name="zezwolenie_do" value="<?= $_POST['zezwolenie_do'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="data_zakonczenia_pobytu">Data zakończenia pobytu</label>
                        <input type="date" id="data_zakonczenia_pobytu" name="data_zakonczenia_pobytu" value="<?= $_POST['data_zakonczenia_pobytu'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="badania_lekarskie">Badania lekarskie ważne do</label>
                        <input type="date" id="badania_lekarskie" name="badania_lekarskie" value="<?= $_POST['badania_lekarskie'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="szkolenie_bhp">Szkolenie BHP ważne do</label>
                        <input type="date" id="szkolenie_bhp" name="szkolenie_bhp" value="<?= $_POST['szkolenie_bhp'] ?? '' ?>">
                    </div>
                </div>
            </fieldset>
            
            <!-- Urlopy i inne -->
            <fieldset>
                <legend>🏖️ Urlopy i dodatkowe informacje</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="urlop_bezplatny_od">Urlop bezpłatny od</label>
                        <input type="date" id="urlop_bezplatny_od" name="urlop_bezplatny_od" value="<?= $_POST['urlop_bezplatny_od'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="urlop_bezplatny_do">Urlop bezpłatny do</label>
                        <input type="date" id="urlop_bezplatny_do" name="urlop_bezplatny_do" value="<?= $_POST['urlop_bezplatny_do'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="grupa_inwalidzka">Grupa inwalidzka</label>
                        <select id="grupa_inwalidzka" name="grupa_inwalidzka">
                            <option value="">-- brak --</option>
                            <option value="lekki" <?= ($_POST['grupa_inwalidzka'] ?? '') == 'lekki' ? 'selected' : '' ?>>Lekki stopień niepełnosprawności</option>
                            <option value="umiarkowany" <?= ($_POST['grupa_inwalidzka'] ?? '') == 'umiarkowany' ? 'selected' : '' ?>>Umiarkowany stopień niepełnosprawności</option>
                            <option value="znaczny" <?= ($_POST['grupa_inwalidzka'] ?? '') == 'znaczny' ? 'selected' : '' ?>>Znaczny stopień niepełnosprawności</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="konto_bankowe">Numer konta bankowego</label>
                        <input type="text" id="konto_bankowe" name="konto_bankowe" value="<?= $_POST['konto_bankowe'] ?? '' ?>" placeholder="XX XXXX XXXX XXXX XXXX XXXX XXXX">
                    </div>
                    <div class="form-group">
                        <label for="telefon">Numer telefonu</label>
                        <input type="tel" id="telefon" name="telefon" value="<?= $_POST['telefon'] ?? '' ?>" placeholder="+48 XXX XXX XXX">
                    </div>
                    <div class="form-group">
                        <label for="email">Adres e-mail</label>
                        <input type="email" id="email" name="email" value="<?= $_POST['email'] ?? '' ?>" placeholder="jan.kowalski@example.com">
                    </div>
                </div>
            </fieldset>
            
            <!-- Kwalifikacje i uprawnienia -->
            <fieldset>
                <legend>🎓 Kwalifikacje i uprawnienia</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="prawo_jazdy">Prawo jazdy (kategorie)</label>
                        <input type="text" id="prawo_jazdy" name="prawo_jazdy" value="<?= $_POST['prawo_jazdy'] ?? '' ?>" placeholder="np. B, C, C+E">
                    </div>
                    <div class="form-group">
                        <label>Dodatkowe uprawnienia</label>
                        <div class="checkbox-group">
                            <label class="checkbox-item">
                                <input type="checkbox" name="wozek_widlowy" value="1" <?= !empty($_POST['wozek_widlowy']) ? 'checked' : '' ?>>
                                Wózek widłowy
                            </label>
                            <label class="checkbox-item">
                                <input type="checkbox" name="wysoki_sklad" value="1" <?= !empty($_POST['wysoki_sklad']) ? 'checked' : '' ?>>
                                Wysoki skład
                            </label>
                        </div>
                    </div>
                </div>
            </fieldset>
            
            <!-- Adres i uwagi -->
            <fieldset>
                <legend>📍 Adres i uwagi</legend>
                <div class="form-grid">
                    <div class="form-group full-width">
                        <label for="adres">Adres zamieszkania</label>
                        <textarea id="adres" name="adres" rows="2"><?= $_POST['adres'] ?? '' ?></textarea>
                    </div>
                    <div class="form-group full-width">
                        <label for="uwagi">Uwagi</label>
                        <textarea id="uwagi" name="uwagi" rows="3"><?= $_POST['uwagi'] ?? '' ?></textarea>
                    </div>
                    <div class="form-group full-width">
                        <label for="notatki">📝 Notatki wewnętrzne</label>
                        <textarea id="notatki" name="notatki" rows="3" placeholder="Notatki widoczne tylko dla pracowników biura..."><?= $_POST['notatki'] ?? '' ?></textarea>
                    </div>
                </div>
            </fieldset>
            
            <!-- Oddelegowanie -->
            <fieldset>
                <legend>🏢 Oddelegowanie</legend>
                <div class="form-grid">
                    <div class="form-group">
                        <label for="klient_id">Przypisz do klienta (firmy)</label>
                        <select id="klient_id" name="klient_id">
                            <option value="">-- brak oddelegowania --</option>
                            <?php foreach ($klienci as $k): ?>
                                <option value="<?= $k['id'] ?>" <?= ($_POST['klient_id'] ?? '') == $k['id'] ? 'selected' : '' ?>><?= sanitize($k['nazwa']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <small><a href="klienci.php" target="_blank">+ Dodaj nowego klienta</a></small>
                    </div>
                    <div class="form-group">
                        <label for="oddelegowanie_stanowisko">Stanowisko u klienta</label>
                        <input type="text" id="oddelegowanie_stanowisko" name="oddelegowanie_stanowisko" value="<?= $_POST['oddelegowanie_stanowisko'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label for="oddelegowanie_od">Oddelegowanie od</label>
                        <input type="date" id="oddelegowanie_od" name="oddelegowanie_od" value="<?= $_POST['oddelegowanie_od'] ?? date('Y-m-d') ?>">
                    </div>
                    <div class="form-group">
                        <label for="oddelegowanie_do">Oddelegowanie do (opcjonalnie)</label>
                        <input type="date" id="oddelegowanie_do" name="oddelegowanie_do" value="<?= $_POST['oddelegowanie_do'] ?? '' ?>">
                    </div>
                </div>
                <p class="help-text" style="margin-top: 10px; color: #64748b; font-size: 0.85rem;">
                    💡 Jeśli wybierzesz klienta, pracownik zostanie od razu oddelegowany do tej firmy.
                </p>
            </fieldset>
            
            <!-- Dokumenty i pliki -->
            <fieldset>
                <legend>📎 Dokumenty i pliki</legend>
                <div id="pliki-container">
                    <div class="plik-row" style="display: flex; gap: 10px; margin-bottom: 10px; align-items: flex-end;">
                        <div class="form-group" style="flex: 2; margin-bottom: 0;">
                            <label>Plik</label>
                            <input type="file" name="pliki[]">
                        </div>
                        <div class="form-group" style="flex: 1; margin-bottom: 0;">
                            <label>Typ dokumentu</label>
                            <select name="pliki_typ[]">
                                <option value="dowód">Dowód osobisty</option>
                                <option value="paszport">Paszport</option>
                                <option value="zezwolenie">Zezwolenie na pracę</option>
                                <option value="badania">Badania lekarskie</option>
                                <option value="bhp">Szkolenie BHP</option>
                                <option value="sanepid">Sanepid</option>
                                <option value="umowa">Umowa</option>
                                <option value="prawo_jazdy">Prawo jazdy</option>
                                <option value="uprawnienia">Uprawnienia</option>
                                <option value="inny" selected>Inny</option>
                            </select>
                        </div>
                        <div class="form-group" style="flex: 1; margin-bottom: 0;">
                            <label>Nazwa (opcjonalnie)</label>
                            <input type="text" name="pliki_nazwa[]" placeholder="Własna nazwa">
                        </div>
                        <button type="button" class="btn btn-small btn-danger" onclick="usunPlik(this)" style="margin-bottom: 0; height: 38px;">🗑️</button>
                    </div>
                </div>
                <button type="button" class="btn btn-small" onclick="dodajPlik()" style="margin-top: 10px;">➕ Dodaj kolejny plik</button>
                <p class="help-text" style="margin-top: 10px; color: #64748b; font-size: 0.85rem;">
                    💡 Możesz dodać wiele dokumentów naraz - użyj przycisku "Dodaj kolejny plik".
                </p>
            </fieldset>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary btn-large">💾 Zapisz pracownika</button>
                <a href="index.php" class="btn btn-secondary">Anuluj</a>
            </div>
        </form>
        
        <footer>
            <p>Work Land © <?= date('Y') ?> | System Ewidencji Pracowników | v<?= WORKLAND_VERSION ?> (<?= WORKLAND_VERSION_DATE ?>)</p>
        </footer>
    </div>
    
    <script>
    function dodajPlik() {
        const container = document.getElementById('pliki-container');
        const row = document.createElement('div');
        row.className = 'plik-row';
        row.style.cssText = 'display: flex; gap: 10px; margin-bottom: 10px; align-items: flex-end;';
        row.innerHTML = `
            <div class="form-group" style="flex: 2; margin-bottom: 0;">
                <label>Plik</label>
                <input type="file" name="pliki[]">
            </div>
            <div class="form-group" style="flex: 1; margin-bottom: 0;">
                <label>Typ dokumentu</label>
                <select name="pliki_typ[]">
                    <option value="dowód">Dowód osobisty</option>
                    <option value="paszport">Paszport</option>
                    <option value="zezwolenie">Zezwolenie na pracę</option>
                    <option value="badania">Badania lekarskie</option>
                    <option value="bhp">Szkolenie BHP</option>
                    <option value="sanepid">Sanepid</option>
                    <option value="umowa">Umowa</option>
                    <option value="prawo_jazdy">Prawo jazdy</option>
                    <option value="uprawnienia">Uprawnienia</option>
                    <option value="inny" selected>Inny</option>
                </select>
            </div>
            <div class="form-group" style="flex: 1; margin-bottom: 0;">
                <label>Nazwa (opcjonalnie)</label>
                <input type="text" name="pliki_nazwa[]" placeholder="Własna nazwa">
            </div>
            <button type="button" class="btn btn-small btn-danger" onclick="usunPlik(this)" style="margin-bottom: 0; height: 38px;">🗑️</button>
        `;
        container.appendChild(row);
    }
    
    function usunPlik(btn) {
        const container = document.getElementById('pliki-container');
        if (container.children.length > 1) {
            btn.closest('.plik-row').remove();
        }
    }
    </script>
</body>
</html>
