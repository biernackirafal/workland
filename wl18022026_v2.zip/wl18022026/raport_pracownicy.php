<?php
// ======================================================
// EXPORT FLAGS FIX (XLSX + CSV)
// ======================================================

$exportXlsx =
    (isset($_GET['export']) && $_GET['export'] === 'xlsx') ||
    (isset($_POST['export']) && $_POST['export'] === 'xlsx');

$exportCsv =
    (isset($_GET['export']) && $_GET['export'] === 'csv') ||
    (isset($_POST['export']) && $_POST['export'] === 'csv');

?>

<?php
// ======================================================
// XLSX EXPORT — FINAL FIX
// Wywołanie: ?export=xlsx
// ======================================================

ini_set('display_errors', 1);
error_reporting(E_ALL);

$exportXlsx =
    (isset($_GET['export']) && $_GET['export'] === 'xlsx') ||
    (isset($_POST['export']) && $_POST['export'] === 'xlsx');

if ($exportXlsx) {

    if (!class_exists('ZipArchive')) {
        die('ZipArchive nie jest dostępny na serwerze');
    }

    $wybranePola = $wybranePola ?? [];

    if (empty($wybranePola)) {
        die('Brak wybranych pól do eksportu');
    }

    // ---------------- HEADERS ----------------
    $headers = ['Lp.'];

    foreach ($wybranePola as $pole) {
        foreach ($dostepnePola as $kat) {
            if (isset($kat['pola'][$pole])) {
                $headers[] = $kat['pola'][$pole];
                break;
            }
        }
    }

    // ---------------- ROWS ----------------
    $rows = [];
    $lp = 1;

    foreach ($pracownicy as $p) {
        $row = [$lp++];
        foreach ($wybranePola as $pole) {
            $row[] = $p[$pole] ?? '';
        }
        $rows[] = $row;
    }

    // ---------------- SHARED STRINGS ----------------
    $shared = [];
    $index = [];

    foreach (array_merge([$headers], $rows) as $row) {
        foreach ($row as $cell) {
            if (!is_numeric($cell)) {
                if (!isset($index[$cell])) {
                    $index[$cell] = count($shared);
                    $shared[] = $cell;
                }
            }
        }
    }

    // ---------------- ZIP ----------------
    $tmp = tempnam(sys_get_temp_dir(), 'xlsx_');

    $zip = new ZipArchive();
    $zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE);

    // Content Types
    $zip->addFromString('[Content_Types].xml',
'<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml"
ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml"
ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/sharedStrings.xml"
ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>');

    // RELS
    $zip->addFromString('_rels/.rels',
'<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1"
Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
Target="xl/workbook.xml"/>
</Relationships>');

    // Workbook
    $zip->addFromString('xl/workbook.xml',
'<?xml version="1.0" encoding="UTF-8"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>
<sheet name="Raport" sheetId="1" r:id="rId1"/>
</sheets>
</workbook>');

    $zip->addFromString('xl/_rels/workbook.xml.rels',
'<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1"
Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"
Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2"
Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings"
Target="sharedStrings.xml"/>
</Relationships>');

    // Shared Strings XML
    $sst = '<?xml version="1.0" encoding="UTF-8"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
count="'.count($shared).'"
uniqueCount="'.count($shared).'">';

    foreach ($shared as $s) {
        $sst .= '<si><t>'.htmlspecialchars($s, ENT_XML1).'</t></si>';
    }
    $sst .= '</sst>';

    $zip->addFromString('xl/sharedStrings.xml', $sst);

    // Sheet
    function col($i){
        $s='';
        while($i>=0){
            $s=chr($i%26+65).$s;
            $i=floor($i/26)-1;
        }
        return $s;
    }

    $sheet='<?xml version="1.0" encoding="UTF-8"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>';

    // Header row
    $sheet.='<row r="1">';
    foreach($headers as $c=>$v){
        $sheet.='<c r="'.col($c).'1" t="s"><v>'.$index[$v].'</v></c>';
    }
    $sheet.='</row>';

    // Data rows
    $r=2;
    foreach($rows as $row){
        $sheet.='<row r="'.$r.'">';
        foreach($row as $c=>$v){
            if(is_numeric($v)){
                $sheet.='<c r="'.col($c).$r.'"><v>'.$v.'</v></c>';
            }else{
                $sheet.='<c r="'.col($c).$r.'" t="s"><v>'.$index[$v].'</v></c>';
            }
        }
        $sheet.='</row>';
        $r++;
    }

    $sheet.='</sheetData></worksheet>';

    $zip->addFromString('xl/worksheets/sheet1.xml',$sheet);

    $zip->close();

    if (ob_get_length()) ob_end_clean();

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="raport_pracownicy.xlsx"');
    header('Content-Length: '.filesize($tmp));

    readfile($tmp);
    unlink($tmp);
    exit;
}
?>

<?php
/**
 * Moduł raportów pracowników z wyborem zakresu dat zatrudnienia i pól
 * System Ewidencji Pracowników - Work Land
 * Wersja: 2.3.0
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// Definicja dostępnych pól z podziałem na kategorie
$dostepnePola = [
    'podstawowe' => [
        'label' => '👤 Dane podstawowe',
        'pola' => [
            'kod' => 'Kod pracownika',
            'imie' => 'Imię',
            'nazwisko' => 'Nazwisko',
            'narodowosc' => 'Narodowość',
            'data_urodzenia' => 'Data urodzenia',
        ]
    ],
    'dokumenty' => [
        'label' => '📄 Dokumenty',
        'pola' => [
            'pesel' => 'PESEL',
            'nip' => 'NIP',
            'dokument_tozsamosci' => 'Nr dokumentu tożsamości',
            'dane_personalne' => 'Dodatkowe dane personalne',
        ]
    ],
    'zatrudnienie' => [
        'label' => '💼 Zatrudnienie',
        'pola' => [
            'data_przyjecia' => 'Data przyjęcia',
            'data_zwolnienia' => 'Data zwolnienia',
            'okres_zatrudnienia_od' => 'Okres zatrudnienia od',
            'okres_zatrudnienia_do' => 'Okres zatrudnienia do',
            'stanowisko' => 'Stanowisko',
            'forma_umowy' => 'Forma umowy',
            'wymiar_czasu_pracy' => 'Wymiar czasu pracy',
        ]
    ],
    'wynagrodzenie' => [
        'label' => '💰 Wynagrodzenie',
        'pola' => [
            'stawka_wynagrodzenia' => 'Stawka wynagrodzenia',
            'typ_zleceniobiorcy' => 'Typ zleceniobiorcy',
            'koszty_typ' => 'Typ kosztów',
        ]
    ],
    'skladki_rozliczenie' => [
        'label' => '📊 Składki (rozliczenie)',
        'pola' => [
            'rozl_brutto' => 'Kwota brutto',
            'rozl_netto' => 'Kwota netto',
            'rozl_emerytalne' => 'Składka emerytalna',
            'rozl_rentowe' => 'Składka rentowa',
            'rozl_chorobowe' => 'Składka chorobowa',
            'rozl_zdrowotna' => 'Składka zdrowotna',
            'rozl_podatek' => 'Podatek',
            'rozl_typ_zleceniobiorcy' => 'Typ zleceniobiorcy (rozl.)',
            'rozl_nieobecnosci' => 'Nieobecności w okresie',
        ]
    ],
    'terminy' => [
        'label' => '📅 Terminy i zezwolenia',
        'pola' => [
            'zezwolenie_do' => 'Zezwolenie ważne do',
            'data_zakonczenia_pobytu' => 'Data zakończenia pobytu',
            'badania_lekarskie' => 'Badania lekarskie do',
            'szkolenie_bhp' => 'Szkolenie BHP do',
        ]
    ],
    'kontakt' => [
        'label' => '📞 Kontakt i inne',
        'pola' => [
            'telefon' => 'Telefon',
            'konto_bankowe' => 'Nr konta bankowego',
            'adres' => 'Adres',
            'grupa_inwalidzka' => 'Grupa inwalidzka',
            'uwagi' => 'Uwagi',
            'notatki' => 'Notatki wewnętrzne',
        ]
    ],
    'oddelegowanie_skladki' => [
        'label' => '🏢 Oddelegowanie i rozliczenie',
        'pola' => [
            'oddelegowanie_nazwa'  => 'Oddelegowanie (pełna nazwa)',
            'skladki_tryb_stawka'  => 'Tryb / Stawka',
            'skladki_godziny'      => 'Godziny',
            'skladki_kwota'        => 'Kwota',
            'skladki_nb'           => 'N/B',
        ]
    ],
];

// Nazwy miesięcy
$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];

// Typy zleceniobiorców
$typyZleceniobiorcy = [
    'student' => 'Student/uczeń do 26 lat',
    'standard_26' => 'Do 26 lat (PIT-0)',
    'standardowy' => 'Standardowy (>26 lat)',
    'emeryt' => 'Emeryt/rencista',
    'inny_tytul' => 'Inny tytuł (tylko zdrow.)',
    'bez_zus_zdrow' => 'Bez składek (tylko podatek)'
];

// Pobierz parametry z GET/POST
$dataOd = isset($_REQUEST['data_od']) ? $_REQUEST['data_od'] : '';
$dataDo = isset($_REQUEST['data_do']) ? $_REQUEST['data_do'] : '';
$wybranePola = isset($_REQUEST['pola']) ? (array)$_REQUEST['pola'] : [];
$generujRaport = isset($_REQUEST['generuj']) && $_REQUEST['generuj'] == '1';
$exportXlsx = isset($_REQUEST['export']) && $_REQUEST['export'] === 'xlsx';
$tylkoAktywni = isset($_REQUEST['tylko_aktywni']) && $_REQUEST['tylko_aktywni'] == '1';

// Parametry okresu rozliczeniowego (dla składek)
$domyslnyMiesiac = (int)date('m') - 1;
$domyslnyRok = (int)date('Y');
if ($domyslnyMiesiac < 1) {
    $domyslnyMiesiac = 12;
    $domyslnyRok--;
}
$rozlMiesiac = isset($_REQUEST['rozl_miesiac']) ? (int)$_REQUEST['rozl_miesiac'] : $domyslnyMiesiac;
$rozlRok = isset($_REQUEST['rozl_rok']) ? (int)$_REQUEST['rozl_rok'] : $domyslnyRok;

// Oblicz zakres dat dla wybranego okresu rozliczeniowego
$okresStart = sprintf('%04d-%02d-01', $rozlRok, $rozlMiesiac);
$okresKoniec = date('Y-m-t', strtotime($okresStart));

// Funkcje pomocnicze
function formatujWartosc($pole, $wartosc) {
    if (empty($wartosc) || $wartosc === null) {
        return '-';
    }
    
    // Formatowanie dat
    $polaData = ['data_urodzenia', 'data_przyjecia', 'data_zwolnienia', 'okres_zatrudnienia_od', 
                  'okres_zatrudnienia_do', 'zezwolenie_do', 'data_zakonczenia_pobytu', 
                  'badania_lekarskie', 'szkolenie_bhp'];
    if (in_array($pole, $polaData)) {
        return date('d.m.Y', strtotime($wartosc));
    }
    
    // Formatowanie kwot
    if ($pole === 'stawka_wynagrodzenia') {
        return number_format((float)$wartosc, 2, ',', ' ') . ' zł';
    }
    
    // Formatowanie typu zleceniobiorcy
    if ($pole === 'typ_zleceniobiorcy' || $pole === 'rozl_typ_zleceniobiorcy') {
        global $typyZleceniobiorcy;
        return $typyZleceniobiorcy[$wartosc] ?? $wartosc;
    }
    
    // Formatowanie typu kosztów
    if ($pole === 'koszty_typ') {
        $typy = [
            'standardowe' => 'Standardowe 20%',
            'autorskie' => 'Autorskie 50%'
        ];
        return $typy[$wartosc] ?? $wartosc;
    }
    
    // Formatowanie kwot rozliczeniowych
    if (in_array($pole, ['rozl_brutto', 'rozl_netto', 'rozl_emerytalne', 'rozl_rentowe', 'rozl_chorobowe', 'rozl_zdrowotna', 'rozl_podatek'])) {
        return number_format((float)$wartosc, 2, ',', ' ') . ' zł';
    }
    
    // Formatowanie trybu/stawki składek
    if ($pole === 'skladki_tryb_stawka') {
        if (empty($wartosc)) return '-';
        if (strpos($wartosc, '|') !== false) {
            [$tryb, $stawka] = explode('|', $wartosc, 2);
            if ($tryb === 'stawka_godziny') {
                return 'S×G: ' . number_format((float)$stawka, 2, ',', ' ') . ' zł/h';
            }
            return 'Kwota';
        }
        return $wartosc;
    }
    
    // Formatowanie godzin składek
    if ($pole === 'skladki_godziny') {
        if (empty($wartosc) || $wartosc == 0) return '-';
        return number_format((float)$wartosc, 2, ',', ' ');
    }
    
    // Formatowanie kwoty składek
    if ($pole === 'skladki_kwota') {
        if (empty($wartosc) || $wartosc == 0) return '-';
        return number_format((float)$wartosc, 2, ',', ' ') . ' zł';
    }
    
    // Formatowanie N/B
    if ($pole === 'skladki_nb') {
        if (empty($wartosc)) return '-';
        return strtoupper($wartosc);
    }
    
    // Adres - usuń nowe linie dla export
    if ($pole === 'adres' || $pole === 'uwagi' || $pole === 'notatki' || $pole === 'dane_personalne' || $pole === 'rozl_nieobecnosci') {
        return str_replace(["\r\n", "\r", "\n"], ' ', $wartosc);
    }
    
    return $wartosc;
}

function obliczStazPracy($dataPrzyjecia, $dataZwolnienia = null) {
    if (empty($dataPrzyjecia)) return '-';
    
    $start = new DateTime($dataPrzyjecia);
    $koniec = !empty($dataZwolnienia) ? new DateTime($dataZwolnienia) : new DateTime();
    $diff = $start->diff($koniec);
    
    $lata = $diff->y;
    $miesiace = $diff->m;
    
    if ($lata > 0) {
        return $lata . ' lat ' . $miesiace . ' mies.';
    }
    return $miesiace . ' mies.';
}

// Sprawdź czy wybrano pola składkowe
$maPolaSkladkowe = false;
foreach ($wybranePola as $pole) {
    if (strpos($pole, 'rozl_') === 0) {
        $maPolaSkladkowe = true;
        break;
    }
}

// Sprawdź czy wybrano pola oddelegowania/rozliczenia z nowej kategorii
$maPolaOddelegowania = false;
$nowePolaOddelegowania = ['oddelegowanie_nazwa', 'skladki_tryb_stawka', 'skladki_godziny', 'skladki_kwota', 'skladki_nb'];
foreach ($wybranePola as $pole) {
    if (in_array($pole, $nowePolaOddelegowania)) {
        $maPolaOddelegowania = true;
        break;
    }
}

// Generowanie raportu
$pracownicy = [];
$nieobecnosciMap = [];

if ($generujRaport || $exportXlsx) {
    // Budowanie zapytania SQL
    if ($maPolaSkladkowe || $maPolaOddelegowania) {
        // Z danymi rozliczeń i/lub oddelegowań
        $joinOddel = $maPolaOddelegowania ? "
                LEFT JOIN oddelegowania o ON o.pracownik_id = p.id
                    AND o.active = 1
                    AND (o.data_od IS NULL OR o.data_od <= :okres_koniec2)
                    AND (o.data_do IS NULL OR o.data_do >= :okres_start2)
                LEFT JOIN klienci k ON k.id = o.klient_id" : "";
        
        $selectOddel = $maPolaOddelegowania ? ",
                       k.nazwa AS oddelegowanie_nazwa,
                       CASE WHEN r2.tryb = 'stawka_godziny' THEN r2.tryb || '|' || COALESCE(r2.stawka_godzinowa, 0)
                            WHEN r2.tryb IS NOT NULL THEN r2.tryb
                            ELSE NULL END AS skladki_tryb_stawka,
                       r2.liczba_godzin AS skladki_godziny,
                       r2.kwota_brutto AS skladki_kwota,
                       r2.typ_kwoty AS skladki_nb" : "";
        
        $joinRozl2 = $maPolaOddelegowania ? "
                LEFT JOIN rozliczenia_miesieczne r2 ON p.id = r2.pracownik_id
                    AND r2.miesiac = :rozl_miesiac2 AND r2.rok = :rozl_rok2" : "";
        
        $rozlJoin = $maPolaSkladkowe ? "
                LEFT JOIN rozliczenia_miesieczne r ON p.id = r.pracownik_id 
                    AND r.miesiac = :rozl_miesiac AND r.rok = :rozl_rok" : "";
        
        $rozlSelect = $maPolaSkladkowe ? ",
                       r.kwota_brutto as rozl_brutto, r.kwota_netto as rozl_netto,
                       r.emerytalne as rozl_emerytalne, r.rentowe as rozl_rentowe, 
                       r.chorobowe as rozl_chorobowe, r.zdrowotna as rozl_zdrowotna, 
                       r.podatek as rozl_podatek,
                       r.typ_zleceniobiorcy as rozl_typ_zleceniobiorcy" : "";
        
        $sql = "SELECT p.*{$rozlSelect}{$selectOddel}
                FROM pracownicy p
                {$rozlJoin}{$joinRozl2}{$joinOddel}
                WHERE 1=1";
        
        $params = [];
        if ($maPolaSkladkowe) {
            $params[':rozl_miesiac'] = $rozlMiesiac;
            $params[':rozl_rok'] = $rozlRok;
        }
        if ($maPolaOddelegowania) {
            $params[':rozl_miesiac2'] = $rozlMiesiac;
            $params[':rozl_rok2'] = $rozlRok;
            $params[':okres_koniec2'] = $okresKoniec;
            $params[':okres_start2'] = $okresStart;
        }
        
        // AUTOMATYCZNE filtrowanie pracowników aktywnych w wybranym okresie rozliczeniowym
        $sql .= " AND (p.data_przyjecia IS NULL OR p.data_przyjecia = '' OR p.data_przyjecia <= :okres_koniec)";
        $sql .= " AND (p.data_zwolnienia IS NULL OR p.data_zwolnienia = '' OR p.data_zwolnienia >= :okres_start)";
        
        $params[':okres_start'] = $okresStart;
        $params[':okres_koniec'] = $okresKoniec;
    } else {
        $sql = "SELECT * FROM pracownicy WHERE 1=1";
        $params = [];
    }
    if (!empty($dataOd)) {
        $tblPrefix = ($maPolaSkladkowe || $maPolaOddelegowania) ? 'p.' : '';
        $sql .= " AND ({$tblPrefix}data_przyjecia IS NOT NULL AND {$tblPrefix}data_przyjecia >= :data_od)";
        $params[':data_od'] = $dataOd;
    }
    if (!empty($dataDo)) {
        $tblPrefix = ($maPolaSkladkowe || $maPolaOddelegowania) ? 'p.' : '';
        $sql .= " AND ({$tblPrefix}data_przyjecia IS NOT NULL AND {$tblPrefix}data_przyjecia <= :data_do)";
        $params[':data_do'] = $dataDo;
    }
    
    // Tylko aktywni (bez daty zwolnienia) - dodatkowy filtr
    if ($tylkoAktywni) {
        $tbl = ($maPolaSkladkowe || $maPolaOddelegowania) ? 'p.' : '';
        $sql .= " AND ({$tbl}data_zwolnienia IS NULL OR {$tbl}data_zwolnienia = '')";
    }
    
    $tbl = ($maPolaSkladkowe || $maPolaOddelegowania) ? 'p.' : '';
    if ($maPolaOddelegowania) {
        $sql .= " ORDER BY CASE WHEN LOWER(k.nazwa) LIKE '%administracja%' THEN 0 ELSE 1 END ASC, k.nazwa ASC, {$tbl}nazwisko ASC, {$tbl}imie ASC";
    } else {
        $sql .= " ORDER BY {$tbl}nazwisko, {$tbl}imie";
    }
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $pracownicy = $stmt->fetchAll();
    
    // Pobierz nieobecności jeśli potrzebne
    if (in_array('rozl_nieobecnosci', $wybranePola)) {
        $pierwszyDzien = sprintf('%04d-%02d-01', $rozlRok, $rozlMiesiac);
        $ostatniDzien = date('Y-m-t', strtotime($pierwszyDzien));
        
        $stmtNieob = $db->prepare("SELECT u.*, p.id as pracownik_id
            FROM urlopy u 
            JOIN pracownicy p ON u.pracownik_id = p.id
            WHERE (u.data_od <= :ostatni AND u.data_do >= :pierwszy)
               OR (u.data_od >= :pierwszy2 AND u.data_od <= :ostatni2)
            ORDER BY u.data_od");
        $stmtNieob->execute([
            ':pierwszy' => $pierwszyDzien,
            ':ostatni' => $ostatniDzien,
            ':pierwszy2' => $pierwszyDzien,
            ':ostatni2' => $ostatniDzien
        ]);
        $nieobecnosci = $stmtNieob->fetchAll();
        
        $typyNieobecnosci = [
            'bezpłatny' => 'Urlop bezpłatny',
            'wypoczynkowy' => 'Urlop wypoczynkowy',
            'chorobowy' => 'L4/Chorobowy',
            'macierzyński' => 'Macierzyński',
            'rodzicielski' => 'Rodzicielski',
            'ojcowski' => 'Ojcowski',
            'wychowawczy' => 'Wychowawczy',
            'okolicznościowy' => 'Okolicznościowy',
            'usprawiedliwiona' => 'Usprawiedliwiona',
            'nieusprawiedliwiona' => 'Nieusprawiedliwiona'
        ];
        
        foreach ($nieobecnosci as $n) {
            $typLabel = $typyNieobecnosci[$n['typ']] ?? $n['typ'];
            $tekst = $typLabel . ': ' . date('d.m', strtotime($n['data_od']));
            if ($n['data_do'] != $n['data_od']) {
                $tekst .= '-' . date('d.m', strtotime($n['data_do']));
            }
            
            if (!isset($nieobecnosciMap[$n['pracownik_id']])) {
                $nieobecnosciMap[$n['pracownik_id']] = [];
            }
            $nieobecnosciMap[$n['pracownik_id']][] = $tekst;
        }
        
        // Dodaj nieobecności do pracowników
        foreach ($pracownicy as &$p) {
            $p['rozl_nieobecnosci'] = isset($nieobecnosciMap[$p['id']]) 
                ? implode('; ', $nieobecnosciMap[$p['id']]) 
                : '';
        }
        unset($p);
    }
}

// Export do Excel (format HTML - automatyczne dopasowanie szerokości kolumn)
if ($exportCsv && !empty($wybranePola)) {
    $nazwaPliku = 'raport_pracownicy_' . date('Y-m-d_H-i') . '.xls';
    
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nazwaPliku . '"');
    header('Cache-Control: max-age=0');
    
    // Nagłówki kolumn
    $headers = ['Lp.'];
    foreach ($wybranePola as $pole) {
        foreach ($dostepnePola as $kategoria) {
            if (isset($kategoria['pola'][$pole])) {
                $headers[] = $kategoria['pola'][$pole];
                break;
            }
        }
    }
    if (in_array('data_przyjecia', $wybranePola)) {
        $headers[] = 'Staż pracy';
    }
    
    // Generuj HTML/Excel
    echo '<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style>
    table { border-collapse: collapse; }
    th, td { 
        border: 1px solid #000; 
        padding: 5px 10px; 
        white-space: nowrap;
    }
    th { 
        background-color: #4472C4; 
        color: white; 
        font-weight: bold;
        text-align: center;
    }
    tr:nth-child(even) { background-color: #D9E2F3; }
    .number { text-align: center; }
    .date { text-align: center; }
    .money { text-align: right; }
    .text { mso-number-format:"\@"; text-align: left; }
</style>
</head>
<body>
<table>';
    
    // Nagłówki
    echo '<tr>';
    foreach ($headers as $header) {
        echo '<th>' . htmlspecialchars($header) . '</th>';
    }
    echo '</tr>';
    
    // Pola które mają być traktowane jako tekst (mogą zaczynać się od 0)
    $polaTextowe = ['pesel', 'nip', 'konto_bankowe', 'dokument_tozsamosci', 'dokument_numer', 'telefon'];
    
    // Dane
    $lp = 1;
    foreach ($pracownicy as $p) {
        echo '<tr>';
        echo '<td class="number">' . $lp++ . '</td>';
        
        foreach ($wybranePola as $pole) {
            $wartosc = formatujWartosc($pole, $p[$pole] ?? '');
            $class = '';
            
            // Określ klasę CSS dla odpowiedniego wyrównania/formatu
            if (in_array($pole, $polaTextowe)) {
                $class = 'text';
            } elseif (in_array($pole, ['data_urodzenia', 'data_przyjecia', 'data_zwolnienia', 
                'okres_zatrudnienia_od', 'okres_zatrudnienia_do', 'zezwolenie_do', 
                'data_zakonczenia_pobytu', 'badania_lekarskie', 'szkolenie_bhp'])) {
                $class = 'date';
            } elseif ($pole === 'stawka_wynagrodzenia') {
                $class = 'money';
            }
            
            echo '<td' . ($class ? ' class="' . $class . '"' : '') . '>' . htmlspecialchars($wartosc) . '</td>';
        }
        
        if (in_array('data_przyjecia', $wybranePola)) {
            echo '<td class="date">' . htmlspecialchars(obliczStazPracy($p['data_przyjecia'], $p['data_zwolnienia'])) . '</td>';
        }
        echo '</tr>';
    }
    
    echo '</table>
</body>
</html>';
    exit;
}

// Nazwy miesięcy po polsku
$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];
$dniTygodnia = ['Niedziela', 'Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota'];
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raport pracowników - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .date-info {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            color: white;
            padding: 20px 25px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .date-info .today { font-size: 1.1rem; }
        .date-info .today strong { font-size: 1.3rem; }
        
        .report-config {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 25px;
            overflow: hidden;
        }
        .config-header {
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            padding: 15px 20px;
            border-bottom: 1px solid #e2e8f0;
            font-weight: 600;
            font-size: 1.1rem;
        }
        .config-body {
            padding: 20px;
        }
        
        .date-range-selector {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            align-items: end;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e2e8f0;
        }
        .date-input-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .date-input-group label {
            font-weight: 600;
            color: #475569;
            font-size: 0.9rem;
        }
        .date-input-group input[type="date"] {
            padding: 10px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            min-width: 180px;
            transition: border-color 0.2s;
        }
        .date-input-group input[type="date"]:focus,
        .date-input-group select:focus {
            border-color: #059669;
            outline: none;
        }
        .date-input-group select,
        .month-select {
            padding: 10px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            min-width: 150px;
            background: white;
            cursor: pointer;
            transition: border-color 0.2s;
        }
        .month-select:hover {
            border-color: #8b5cf6;
        }
        
        .checkbox-option {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 5px 0;
        }
        .checkbox-option input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
            accent-color: #059669;
        }
        .checkbox-option label {
            cursor: pointer;
            user-select: none;
        }
        
        .fields-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
        }
        .field-category {
            background: #f8fafc;
            border-radius: 10px;
            padding: 15px;
            border: 1px solid #e2e8f0;
        }
        .field-category-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 12px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e2e8f0;
        }
        .field-category-title {
            font-weight: 600;
            color: #1e293b;
        }
        .select-all-btn {
            font-size: 0.75rem;
            padding: 4px 10px;
            background: #e2e8f0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            color: #475569;
            transition: all 0.2s;
        }
        .select-all-btn:hover {
            background: #059669;
            color: white;
        }
        
        .quick-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
        .quick-action-btn {
            padding: 8px 16px;
            background: #e2e8f0;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.2s;
        }
        .quick-action-btn:hover {
            background: #059669;
            color: white;
        }
        
        .generate-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
        }
        
        .report-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 25px;
        }
        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            text-align: center;
        }
        .summary-card .number {
            font-size: 2rem;
            font-weight: 700;
            color: #059669;
        }
        .summary-card .label {
            color: #64748b;
            font-size: 0.85rem;
            margin-top: 5px;
        }
        
        .report-table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 25px;
        }
        .report-table-header {
            background: linear-gradient(135deg, #059669 0%, #047857 100%);
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }
        .report-table-title {
            font-weight: 600;
            font-size: 1.1rem;
        }
        .table-actions {
            display: flex;
            gap: 10px;
        }
        .table-actions .btn {
            background: rgba(255,255,255,0.2);
            border: 1px solid rgba(255,255,255,0.3);
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.85rem;
            text-decoration: none;
            transition: all 0.2s;
        }
        .table-actions .btn:hover {
            background: rgba(255,255,255,0.3);
        }
        
        .report-table {
            width: 100%;
            border-collapse: collapse;
        }
        .report-table th {
            background: #f8fafc;
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            color: #475569;
            border-bottom: 2px solid #e2e8f0;
            white-space: nowrap;
            position: sticky;
            top: 0;
        }
        .report-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e2e8f0;
            color: #1e293b;
        }
        .report-table tr:hover {
            background: #f0fdf4;
        }
        .report-table tr:last-child td {
            border-bottom: none;
        }
        
        .filter-info {
            background: #fef3c7;
            border: 1px solid #fbbf24;
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 20px;
            color: #92400e;
        }
        
        @media (max-width: 768px) {
            .fields-grid {
                grid-template-columns: 1fr;
            }
            .date-range-selector {
                flex-direction: column;
                align-items: stretch;
            }
        }
        
        @media print {
            .top-nav, .report-config, .report-table-header .table-actions, footer { 
                display: none !important; 
            }
            .date-info { 
                background: #f1f5f9 !important; 
                color: #1e293b !important; 
            }
            .report-table-header {
                background: #f1f5f9 !important;
                color: #1e293b !important;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <img src="assets/logo.png" alt="Work Land">
                <div class="user-info">
                    👤 <?php echo sanitize($currentUser['name']); ?>
                </div>
            </div>
            <div class="nav-links">
                <a href="raport.php">📊 Raport miesięczny</a>
                <a href="raport_nieobecnosci.php">🏥 Raport nieobecności</a>
                <?php if (canManageUsers()): ?><a href="users.php">👥 Użytkownicy</a><?php endif; ?>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>📋 Generator raportów pracowników</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <!-- Aktualna data -->
        <div class="date-info">
            <div class="today">
                📅 Dzisiaj: <strong><?php echo date('d.m.Y'); ?></strong>
                <br><small><?php echo $dniTygodnia[(int)date('w')]; ?>, <?php echo $miesiacNazwy[(int)date('m')]; ?> <?php echo date('Y'); ?></small>
            </div>
            <div>
                🕐 Godzina: <strong><?php echo date('H:i'); ?></strong>
            </div>
        </div>
        
        <!-- Konfiguracja raportu -->
        <form method="GET" id="reportForm">
            <input type="hidden" name="generuj" value="1">
            
            <div class="report-config">
                <div class="config-header">
                    📅 Zakres dat zatrudnienia
                </div>
                <div class="config-body">
                    <!-- Szybki wybór miesiąca -->
                    <div class="quick-month-selector" style="margin-bottom: 15px; padding: 12px; background: #f0fdf4; border-radius: 8px; border: 1px solid #86efac;">
                        <label style="font-weight: 600; color: #166534; margin-right: 10px;">⚡ Szybki wybór miesiąca:</label>
                        <select id="szybki_miesiac" class="month-select" style="min-width: 130px;">
                            <option value="">-- wybierz --</option>
                            <?php for ($m = 1; $m <= 12; $m++): ?>
                                <option value="<?= $m ?>"><?= $miesiacNazwy[$m] ?></option>
                            <?php endfor; ?>
                        </select>
                        <select id="szybki_rok" class="month-select" style="min-width: 90px;">
                            <?php for ($y = date('Y') - 2; $y <= date('Y') + 1; $y++): ?>
                                <option value="<?= $y ?>" <?= $y == date('Y') ? 'selected' : '' ?>><?= $y ?></option>
                            <?php endfor; ?>
                        </select>
                        <button type="button" class="btn" style="margin-left: 10px; padding: 8px 15px; background: #059669; color: white;" 
                                onclick="ustawZakresMiesiaca()">Ustaw</button>
                        <button type="button" class="btn" style="margin-left: 5px; padding: 8px 15px; background: #e2e8f0; color: #475569;" 
                                onclick="wyczyscDaty()">Wyczyść</button>
                    </div>
                    
                    <div class="date-range-selector">
                        <div class="date-input-group">
                            <label for="data_od">Data zatrudnienia OD:</label>
                            <input type="date" id="data_od" name="data_od" value="<?php echo sanitize($dataOd); ?>">
                        </div>
                        <div class="date-input-group">
                            <label for="data_do">Data zatrudnienia DO:</label>
                            <input type="date" id="data_do" name="data_do" value="<?php echo sanitize($dataDo); ?>">
                        </div>
                        <div class="checkbox-option" style="padding-bottom: 12px;">
                            <input type="checkbox" id="tylko_aktywni" name="tylko_aktywni" value="1" <?php echo $tylkoAktywni ? 'checked' : ''; ?>>
                            <label for="tylko_aktywni">Tylko aktualnie zatrudnieni (bez zwolnionych)</label>
                        </div>
                    </div>
                    
                    <p style="color: #64748b; margin-bottom: 15px; font-size: 0.9rem;">
                        💡 Pozostaw pola dat puste, aby uwzględnić wszystkich pracowników.
                    </p>
                </div>
            </div>
            
            <!-- Okres rozliczeniowy dla składek -->
            <div class="report-config" style="border-left: 4px solid #8b5cf6;">
                <div class="config-header" style="background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);">
                    📊 Okres rozliczeniowy (dla danych składkowych)
                </div>
                <div class="config-body">
                    <div class="date-range-selector">
                        <div class="date-input-group">
                            <label for="rozl_miesiac">Miesiąc:</label>
                            <select id="rozl_miesiac" name="rozl_miesiac" class="month-select">
                                <?php for ($m = 1; $m <= 12; $m++): ?>
                                    <option value="<?= $m ?>" <?= $m == $rozlMiesiac ? 'selected' : '' ?>><?= $miesiacNazwy[$m] ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="date-input-group">
                            <label for="rozl_rok">Rok:</label>
                            <select id="rozl_rok" name="rozl_rok" class="month-select">
                                <?php for ($y = date('Y') - 2; $y <= date('Y') + 1; $y++): ?>
                                    <option value="<?= $y ?>" <?= $y == $rozlRok ? 'selected' : '' ?>><?= $y ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>
                    
                    <p style="color: #166534; margin-top: 12px; font-size: 0.9rem; padding: 10px; background: #dcfce7; border-radius: 6px;">
                        ✅ <strong>Automatyczne filtrowanie:</strong> Gdy wybierzesz pola składkowe (brutto/netto/składki), raport pokaże tylko pracowników aktywnych w wybranym miesiącu.
                    </p>
                    <p style="color: #64748b; margin-top: 8px; font-size: 0.85rem;">
                        💡 Pracownik jest aktywny jeśli: zatrudniony przed końcem miesiąca I niezwolniony przed początkiem miesiąca.
                    </p>
                </div>
            </div>
            
            <div class="report-config">
                <div class="config-header">
                    ✅ Wybierz pola do raportu
                </div>
                <div class="config-body">
                    <!-- Szybkie akcje -->
                    <div class="quick-actions">
                        <button type="button" class="quick-action-btn" onclick="zaznaczWszystkie()">✅ Zaznacz wszystkie</button>
                        <button type="button" class="quick-action-btn" onclick="odznaczWszystkie()">❌ Odznacz wszystkie</button>
                        <button type="button" class="quick-action-btn" onclick="zaznaczPodstawowe()">👤 Tylko podstawowe</button>
                        <button type="button" class="quick-action-btn" onclick="zaznaczZatrudnienie()">💼 Dane zatrudnienia</button>
                        <button type="button" class="quick-action-btn" onclick="zaznaczKontaktowe()">📞 Dane kontaktowe</button>
                        <button type="button" class="quick-action-btn" onclick="zaznaczKsiegowa()" style="background: #8b5cf6; color: white;">📊 Księgowa</button>
                    </div>
                    
                    <!-- Siatka pól -->
                    <div class="fields-grid">
                        <?php foreach ($dostepnePola as $kategoriaId => $kategoria): ?>
                        <div class="field-category" data-category="<?php echo $kategoriaId; ?>">
                            <div class="field-category-header">
                                <span class="field-category-title"><?php echo $kategoria['label']; ?></span>
                                <button type="button" class="select-all-btn" onclick="toggleCategory('<?php echo $kategoriaId; ?>')">
                                    Zaznacz
                                </button>
                            </div>
                            <?php foreach ($kategoria['pola'] as $poleId => $poleNazwa): ?>
                            <div class="checkbox-option">
                                <input type="checkbox" 
                                       id="pole_<?php echo $poleId; ?>" 
                                       name="pola[]" 
                                       value="<?php echo $poleId; ?>"
                                       data-category="<?php echo $kategoriaId; ?>"
                                       <?php echo in_array($poleId, $wybranePola) ? 'checked' : ''; ?>>
                                <label for="pole_<?php echo $poleId; ?>"><?php echo $poleNazwa; ?></label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Przyciski generowania -->
                    <div class="generate-buttons">
                        <button type="submit" class="btn btn-primary" style="background: #059669;">
                            📊 Generuj raport
                        </button>
                        <button type="button" class="btn" onclick="exportExcel()" style="background: #0ea5e9; color: white;">
                            📥 Eksportuj do Excel
                        </button>
                        <button type="button" class="btn" onclick="window.print()" style="background: #8b5cf6; color: white;">
                            🖨️ Drukuj
                        </button>
                    </div>
                </div>
            </div>
        </form>
        
        <?php if ($generujRaport): ?>
            <!-- Informacja o filtrach -->
            <?php if (!empty($dataOd) || !empty($dataDo) || $tylkoAktywni): ?>
            <div class="filter-info">
                🔍 <strong>Aktywne filtry:</strong>
                <?php if (!empty($dataOd)): ?>
                    Data zatrudnienia od: <?php echo date('d.m.Y', strtotime($dataOd)); ?>
                <?php endif; ?>
                <?php if (!empty($dataDo)): ?>
                    <?php echo !empty($dataOd) ? ' | ' : ''; ?>
                    Data zatrudnienia do: <?php echo date('d.m.Y', strtotime($dataDo)); ?>
                <?php endif; ?>
                <?php if ($tylkoAktywni): ?>
                    <?php echo (!empty($dataOd) || !empty($dataDo)) ? ' | ' : ''; ?>
                    Tylko aktualnie zatrudnieni
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <!-- Podsumowanie -->
            <div class="report-summary">
                <div class="summary-card">
                    <div class="number"><?php echo count($pracownicy); ?></div>
                    <div class="label">Znalezionych pracowników</div>
                </div>
                <div class="summary-card">
                    <div class="number"><?php echo count($wybranePola); ?></div>
                    <div class="label">Wybranych pól</div>
                </div>
                <?php 
                $sumaWynagrodzen = 0;
                foreach ($pracownicy as $p) {
                    $sumaWynagrodzen += floatval($p['stawka_wynagrodzenia'] ?? 0);
                }
                ?>
                <div class="summary-card">
                    <div class="number"><?php echo number_format($sumaWynagrodzen, 0, ',', ' '); ?> zł</div>
                    <div class="label">Suma wynagrodzeń</div>
                </div>
            </div>
            
            <?php if (empty($wybranePola)): ?>
                <div class="alert" style="background: #fef3c7; border-color: #fbbf24; color: #92400e;">
                    ⚠️ Nie wybrano żadnych pól do raportu. Zaznacz przynajmniej jedno pole powyżej.
                </div>
            <?php elseif (empty($pracownicy)): ?>
                <div class="alert">
                    📭 Brak pracowników spełniających kryteria wyszukiwania.
                </div>
            <?php else: ?>
                <!-- Tabela wyników -->
                <div class="report-table-container">
                    <div class="report-table-header">
                        <span class="report-table-title">
                            📋 Wyniki raportu (<?php echo count($pracownicy); ?> rekordów)
                        </span>
                        <div class="table-actions">
                            <a href="?<?php echo http_build_query(array_merge($_GET, ['export' => 'csv'])); ?>" class="btn">
                                📥 Pobierz Excel
                            </a>
                            <button type="button" class="btn" onclick="window.print()">
                                🖨️ Drukuj
                            </button>
                        </div>
                    </div>
                    
                    <div style="overflow-x: auto;">
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>Lp.</th>
                                    <?php foreach ($wybranePola as $pole): ?>
                                        <?php foreach ($dostepnePola as $kategoria): ?>
                                            <?php if (isset($kategoria['pola'][$pole])): ?>
                                                <th><?php echo $kategoria['pola'][$pole]; ?></th>
                                            <?php endif; ?>
                                        <?php endforeach; ?>
                                    <?php endforeach; ?>
                                    <?php if (in_array('data_przyjecia', $wybranePola)): ?>
                                        <th>Staż pracy</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $lp = 1; foreach ($pracownicy as $p): ?>
                                <tr>
                                    <td><?php echo $lp++; ?></td>
                                    <?php foreach ($wybranePola as $pole): ?>
                                        <td><?php echo sanitize(formatujWartosc($pole, $p[$pole] ?? '')); ?></td>
                                    <?php endforeach; ?>
                                    <?php if (in_array('data_przyjecia', $wybranePola)): ?>
                                        <td style="font-weight: 600; color: #059669;">
                                            <?php echo obliczStazPracy($p['data_przyjecia'], $p['data_zwolnienia']); ?>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <footer>
            <p>Work Land © <?php echo date('Y'); ?> | v<?= WORKLAND_VERSION ?> | Generator raportów | <?php echo date('d.m.Y H:i:s'); ?></p>
        </footer>
    </div>
    
    <script>
        // Funkcje zarządzania checkboxami
        function zaznaczWszystkie() {
            document.querySelectorAll('input[name="pola[]"]').forEach(cb => cb.checked = true);
        }
        
        function odznaczWszystkie() {
            document.querySelectorAll('input[name="pola[]"]').forEach(cb => cb.checked = false);
        }
        
        function zaznaczPodstawowe() {
            odznaczWszystkie();
            ['kod', 'imie', 'nazwisko', 'narodowosc', 'pesel'].forEach(pole => {
                const cb = document.getElementById('pole_' + pole);
                if (cb) cb.checked = true;
            });
        }
        
        function zaznaczZatrudnienie() {
            odznaczWszystkie();
            ['imie', 'nazwisko', 'data_przyjecia', 'data_zwolnienia', 'stanowisko', 'forma_umowy', 'stawka_wynagrodzenia'].forEach(pole => {
                const cb = document.getElementById('pole_' + pole);
                if (cb) cb.checked = true;
            });
        }
        
        function zaznaczKontaktowe() {
            odznaczWszystkie();
            ['imie', 'nazwisko', 'telefon', 'adres', 'konto_bankowe'].forEach(pole => {
                const cb = document.getElementById('pole_' + pole);
                if (cb) cb.checked = true;
            });
        }
        
        function zaznaczKsiegowa() {
            odznaczWszystkie();
            [
                // Dane podstawowe
                'kod', 'imie', 'nazwisko', 'narodowosc', 'data_urodzenia',
                // Dokumenty
                'pesel', 'nip',
                // Zatrudnienie
                'data_przyjecia', 'data_zwolnienia', 'okres_zatrudnienia_od', 'okres_zatrudnienia_do',
                'stanowisko', 'forma_umowy', 'wymiar_czasu_pracy',
                // Wynagrodzenie
                'stawka_wynagrodzenia', 'typ_zleceniobiorcy', 'koszty_typ',
                // Składki
                'rozl_brutto', 'rozl_netto', 'rozl_nieobecnosci'
            ].forEach(pole => {
                const cb = document.getElementById('pole_' + pole);
                if (cb) cb.checked = true;
            });
        }
        
        // Funkcje dla szybkiego wyboru miesiąca zatrudnienia
        function ustawZakresMiesiaca() {
            const miesiac = document.getElementById('szybki_miesiac').value;
            const rok = document.getElementById('szybki_rok').value;
            
            if (!miesiac) {
                alert('Wybierz miesiąc');
                return;
            }
            
            // Oblicz pierwszy i ostatni dzień miesiąca
            const pierwszyDzien = rok + '-' + miesiac.padStart(2, '0') + '-01';
            const ostatniDzien = new Date(rok, miesiac, 0); // dzień 0 następnego miesiąca = ostatni dzień tego miesiąca
            const ostatniDzienStr = rok + '-' + miesiac.padStart(2, '0') + '-' + ostatniDzien.getDate().toString().padStart(2, '0');
            
            document.getElementById('data_od').value = pierwszyDzien;
            document.getElementById('data_do').value = ostatniDzienStr;
        }
        
        function wyczyscDaty() {
            document.getElementById('data_od').value = '';
            document.getElementById('data_do').value = '';
            document.getElementById('szybki_miesiac').value = '';
        }
        
        function toggleCategory(categoryId) {
            const checkboxes = document.querySelectorAll(`input[data-category="${categoryId}"]`);
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            checkboxes.forEach(cb => cb.checked = !allChecked);
        }
        
        function exportExcel() {
            const form = document.getElementById('reportForm');
            const originalAction = form.action;
            
            // Dodaj parametr export
            const exportInput = document.createElement('input');
            exportInput.type = 'hidden';
            exportInput.name = 'export';
            exportInput.value = 'csv';
            form.appendChild(exportInput);
            
            form.submit();
            
            // Usuń parametr po wysłaniu
            setTimeout(() => {
                form.removeChild(exportInput);
            }, 100);
        }
        
        // Zachowaj zaznaczone pola po odświeżeniu
        document.addEventListener('DOMContentLoaded', function() {
            // Jeśli brak wybranych pól, zaznacz podstawowe
            const wybranych = document.querySelectorAll('input[name="pola[]"]:checked').length;
            if (wybranych === 0 && !window.location.search.includes('generuj=1')) {
                zaznaczPodstawowe();
            }
        });
    </script>
</body>
</html>
