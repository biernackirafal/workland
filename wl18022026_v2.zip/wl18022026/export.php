<?php
/**
 * Eksport pracowników do Excel (XLS i CSV)
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

// Nagłówki kolumn dla eksportu
$exportHeaders = [
    'Kod', 'Imię', 'Nazwisko', 'Narodowość', 'Dane personalne', 'Paszport/Dowód',
    'Data urodzenia', 'PESEL', 'NIP', 'Data przyjęcia', 'Data zwolnienia',
    'Okres zatrudnienia od', 'Okres zatrudnienia do', 'Zezwolenie do',
    'Stawka wynagrodzenia', 'Typ zleceniobiorcy', 'Forma umowy', 'Wymiar czasu pracy',
    'Grupa inwalidzka', 'Stanowisko', 'Badania lekarskie', 'Szkolenie BHP',
    'Data zakończenia pobytu', 'Telefon', 'Konto bankowe', 'Adres', 'Uwagi'
];

// Funkcja przygotowania danych
function przygotujDane($db) {
    $stmt = $db->query("SELECT * FROM pracownicy ORDER BY nazwisko, imie");
    $pracownicy = $stmt->fetchAll();
    
    $rows = [];
    foreach ($pracownicy as $p) {
        $rows[] = [
            $p['kod'] ?? '', 
            $p['imie'] ?? '', 
            $p['nazwisko'] ?? '', 
            $p['narodowosc'] ?? '',
            $p['dane_personalne'] ?? '', 
            $p['dokument_tozsamosci'] ?? '', 
            $p['data_urodzenia'] ?? '',
            $p['pesel'] ?? '', 
            $p['nip'] ?? '', 
            $p['data_przyjecia'] ?? '', 
            $p['data_zwolnienia'] ?? '',
            $p['okres_zatrudnienia_od'] ?? '', 
            $p['okres_zatrudnienia_do'] ?? '', 
            $p['zezwolenie_do'] ?? '',
            $p['stawka_wynagrodzenia'] ?? '', 
            $p['typ_zleceniobiorcy'] ?? '', 
            $p['forma_umowy'] ?? '',
            $p['wymiar_czasu_pracy'] ?? '', 
            $p['grupa_inwalidzka'] ?? '', 
            $p['stanowisko'] ?? '',
            $p['badania_lekarskie'] ?? '', 
            $p['szkolenie_bhp'] ?? '', 
            $p['data_zakonczenia_pobytu'] ?? '',
            $p['telefon'] ?? '', 
            $p['konto_bankowe'] ?? '', 
            $p['adres'] ?? '', 
            $p['uwagi'] ?? ''
        ];
    }
    return $rows;
}

// Eksport do CSV
if (isset($_GET['download']) && $_GET['download'] == 'csv') {
    $rows = przygotujDane($db);
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="pracownicy_' . date('Y-m-d_H-i') . '.csv"');
    
    echo "\xEF\xBB\xBF"; // BOM dla Excel (UTF-8)
    
    $output = fopen('php://output', 'w');
    fputcsv($output, $GLOBALS['exportHeaders'], ';');
    
    foreach ($rows as $row) {
        fputcsv($output, $row, ';');
    }
    
    fclose($output);
    exit;
}

// Eksport do Excel (format HTML - niezawodny)
if (isset($_GET['download']) && $_GET['download'] == 'xls') {
    $rows = przygotujDane($db);
    $headers = $GLOBALS['exportHeaders'];
    
    $nazwaPliku = 'pracownicy_' . date('Y-m-d_H-i') . '.xls';
    
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $nazwaPliku . '"');
    header('Cache-Control: max-age=0');
    
    echo '<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<style>
    table { border-collapse: collapse; }
    th { 
        border: 1px solid #000; 
        padding: 8px 12px; 
        background-color: #059669;
        color: white;
        font-weight: bold;
        white-space: nowrap;
    }
    td { 
        border: 1px solid #000; 
        padding: 5px 10px; 
        white-space: nowrap;
    }
</style>
</head>
<body>
<table>';
    
    // Nagłówki
    echo '<tr>';
    echo '<th>Lp.</th>';
    foreach ($headers as $header) {
        echo '<th>' . htmlspecialchars($header) . '</th>';
    }
    echo '</tr>';
    
    // Dane
    $lp = 1;
    foreach ($rows as $row) {
        echo '<tr>';
        echo '<td>' . $lp++ . '</td>';
        foreach ($row as $cell) {
            echo '<td>' . htmlspecialchars($cell) . '</td>';
        }
        echo '</tr>';
    }
    
    echo '</table>
</body>
</html>';
    exit;
}

// Stara obsługa dla kompatybilności
if (isset($_GET['download']) && $_GET['download'] == '1') {
    header('Location: export.php?download=csv');
    exit;
}

$currentUser = getCurrentUser();
$stats = $db->query("SELECT COUNT(*) as total FROM pracownicy")->fetch();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eksport danych - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <span>👤 <?= sanitize($currentUser['name']) ?></span>
            <div class="nav-links">
                <?php if (isAdmin()): ?>
                    <a href="users.php">👥 Użytkownicy</a>
                <?php endif; ?>
                <a href="logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <h1>📤 Eksport danych</h1>
            <a href="index.php" class="btn btn-secondary">← Powrót do listy</a>
        </header>
        
        <div class="export-box">
            <div class="export-info">
                <h2>Eksport listy pracowników</h2>
                <p>Pobierz wszystkich pracowników w wybranym formacie.</p>
                <p><strong>Liczba pracowników w bazie:</strong> <?= $stats['total'] ?></p>
            </div>
            
            <div class="export-buttons">
                <a href="export.php?download=xls" class="btn btn-primary btn-large">
                    📊 Pobierz Excel (.xls)
                </a>
                <a href="export.php?download=csv" class="btn btn-secondary btn-large">
                    📄 Pobierz CSV
                </a>
            </div>
            
            <div class="export-note">
                <h3>Wskazówki:</h3>
                <ul>
                    <li><strong>Excel (.xls)</strong> - otwiera się bezpośrednio w Excel, polskie znaki OK</li>
                    <li><strong>CSV</strong> - separator średnik (;), kodowanie UTF-8</li>
                </ul>
            </div>
        </div>
        
        <footer>
            <p>Work Land © <?= date('Y') ?> | System Ewidencji Pracowników | v<?= WORKLAND_VERSION ?> (<?= WORKLAND_VERSION_DATE ?>)</p>
        </footer>
    </div>
    
    <style>
        .export-box {
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 600px;
            margin: 0 auto;
        }
        .export-info { margin-bottom: 30px; }
        .export-info h2 { margin-bottom: 15px; }
        .export-info p { color: #64748b; margin-bottom: 10px; }
        .export-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .btn-large {
            padding: 15px 30px;
            font-size: 1.1rem;
        }
        .export-note {
            margin-top: 30px;
            text-align: left;
            background: #f8fafc;
            padding: 20px;
            border-radius: 6px;
        }
        .export-note h3 { font-size: 0.9rem; margin-bottom: 10px; color: #64748b; }
        .export-note ul { margin-left: 20px; color: #64748b; font-size: 0.9rem; }
        .export-note li { margin-bottom: 5px; }
    </style>
</body>
</html>
