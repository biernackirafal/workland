<?php
/**
 * Moduł Składki - rozliczenia miesięczne pracowników
 * System Ewidencji Pracowników - Work Land
 * 
 * Funkcje:
 * - Lista pracowników aktywnych w danym miesiącu
 * - Wprowadzanie: stawka × godziny LUB kwota całkowita
 * - Wybór: netto / brutto
 * - Generowanie rachunków dla umów zlecenie
 * - Filtrowanie jak w ewidencji
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();

// === PARAMETRY ===
// Domyślnie pokazujemy poprzedni miesiąc (bo w lutym rozliczamy styczeń itd.)
$domyslnyMiesiac = (int)date('m') - 1;
$domyslnyRok = (int)date('Y');
if ($domyslnyMiesiac < 1) {
    $domyslnyMiesiac = 12;
    $domyslnyRok--;
}

$miesiac = isset($_GET['miesiac']) ? (int)$_GET['miesiac'] : $domyslnyMiesiac;
$rok = isset($_GET['rok']) ? (int)$_GET['rok'] : $domyslnyRok;

// Filtry (jak w index.php)
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filterNarodowosc = isset($_GET['narodowosc']) ? trim($_GET['narodowosc']) : '';
$filterKlient = isset($_GET['klient']) ? (int)$_GET['klient'] : 0;
$filterTypUmowy = isset($_GET['typ_umowy']) ? trim($_GET['typ_umowy']) : '';

// === STAWKI ZUS I PODATKÓW 2025 ===
define('STAWKA_EMERYTALNA', 0.0976);
define('STAWKA_RENTOWA', 0.015);
define('STAWKA_CHOROBOWA', 0.0245);
define('STAWKA_ZDROWOTNA', 0.09);
define('STAWKA_PODATKU', 0.12);
define('KOSZTY_STANDARDOWE', 0.20);
define('KOSZTY_AUTORSKIE', 0.50);

$typyZleceniobiorcy = [
    'student' => ['nazwa' => 'Student/uczeń do 26 lat', 'zus' => false, 'zdrowotna' => false, 'podatek' => false, 'ikona' => '🎓'],
    'standard_26' => ['nazwa' => 'Do 26 lat (PIT-0)', 'zus' => true, 'zdrowotna' => true, 'podatek' => false, 'ikona' => '🧑'],
    'standardowy' => ['nazwa' => 'Standardowy (>26 lat)', 'zus' => true, 'zdrowotna' => true, 'podatek' => true, 'ikona' => '👤'],
    'emeryt' => ['nazwa' => 'Emeryt/rencista', 'zus' => true, 'zdrowotna' => true, 'podatek' => true, 'ikona' => '👴'],
    'inny_tytul' => ['nazwa' => 'Inny tytuł (tylko zdrow.)', 'zus' => false, 'zdrowotna' => true, 'podatek' => true, 'ikona' => '💼'],
    'bez_zus_zdrow' => ['nazwa' => 'Bez składek (tylko podatek)', 'zus' => false, 'zdrowotna' => false, 'podatek' => true, 'ikona' => '📋']
];

$miesiacNazwy = [
    1 => 'Styczeń', 2 => 'Luty', 3 => 'Marzec', 4 => 'Kwiecień',
    5 => 'Maj', 6 => 'Czerwiec', 7 => 'Lipiec', 8 => 'Sierpień',
    9 => 'Wrzesień', 10 => 'Październik', 11 => 'Listopad', 12 => 'Grudzień'
];

// === FUNKCJE OBLICZENIOWE ===
function obliczRachunekOdBrutto($brutto, $typ, $kosztyTyp = 'standardowe', $zChorobowym = true) {
    global $typyZleceniobiorcy;
    
    $config = $typyZleceniobiorcy[$typ];
    $kosztyStawka = ($kosztyTyp === 'autorskie') ? KOSZTY_AUTORSKIE : KOSZTY_STANDARDOWE;
    
    $wynik = [
        'brutto' => $brutto,
        'emerytalne' => 0, 'rentowe' => 0, 'chorobowe' => 0, 'zus_suma' => 0,
        'zdrowotna' => 0, 'koszty' => 0, 'podatek' => 0, 'netto' => 0
    ];
    
    // Składki ZUS
    if ($config['zus']) {
        $wynik['emerytalne'] = round($brutto * STAWKA_EMERYTALNA, 2);
        $wynik['rentowe'] = round($brutto * STAWKA_RENTOWA, 2);
        if ($zChorobowym) {
            $wynik['chorobowe'] = round($brutto * STAWKA_CHOROBOWA, 2);
        }
        $wynik['zus_suma'] = round($wynik['emerytalne'] + $wynik['rentowe'] + $wynik['chorobowe'], 2);
    }
    
    // Podstawa zdrowotnej
    $podstawaZdrow = round($brutto - $wynik['zus_suma'], 2);
    
    // Zdrowotna
    if ($config['zdrowotna']) {
        $wynik['zdrowotna'] = round($podstawaZdrow * STAWKA_ZDROWOTNA, 2);
    }
    
    // Podatek
    if ($config['podatek']) {
        $wynik['koszty'] = round($podstawaZdrow * $kosztyStawka, 2);
        $podstawaOpodatkowania = round($podstawaZdrow - $wynik['koszty'], 0);
        $wynik['podatek'] = round($podstawaOpodatkowania * STAWKA_PODATKU, 0);
    }
    
    // Netto
    $wynik['netto'] = round($brutto - $wynik['zus_suma'] - $wynik['zdrowotna'] - $wynik['podatek'], 2);
    
    return $wynik;
}

function obliczRachunekOdNetto($netto, $typ, $kosztyTyp = 'standardowe', $zChorobowym = true) {
    // Iteracyjne przybliżanie brutto
    $brutto = $netto;
    for ($i = 0; $i < 100; $i++) {
        $wynik = obliczRachunekOdBrutto($brutto, $typ, $kosztyTyp, $zChorobowym);
        $roznica = $netto - $wynik['netto'];
        if (abs($roznica) < 0.01) break;
        $brutto += $roznica;
    }
    return obliczRachunekOdBrutto(round($brutto, 2), $typ, $kosztyTyp, $zChorobowym);
}

// === OBSŁUGA FORMULARZA - ZAPIS ROZLICZEŃ ===
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Zapisanie pojedynczego rozliczenia
    if ($action === 'zapisz_rozliczenie') {
        $pracownik_id = (int)$_POST['pracownik_id'];
        $m = (int)$_POST['miesiac'];
        $r = (int)$_POST['rok'];
        $tryb = $_POST['tryb'] ?? 'kwota';
        $typ_kwoty = $_POST['typ_kwoty'] ?? 'brutto';
        $typ_zleceniobiorcy = $_POST['typ_zleceniobiorcy'] ?? 'standardowy';
        $koszty_typ = $_POST['koszty_typ'] ?? 'standardowe';
        $z_chorobowym = isset($_POST['z_chorobowym']) ? 1 : 0;
        
        $stawka_godzinowa = null;
        $liczba_godzin = null;
        $kwota = 0;
        
        if ($tryb === 'stawka_godziny') {
            $stawka_godzinowa = floatval(str_replace(',', '.', $_POST['stawka_godzinowa'] ?? 0));
            $liczba_godzin = floatval(str_replace(',', '.', $_POST['liczba_godzin'] ?? 0));
            $kwota = round($stawka_godzinowa * $liczba_godzin, 2);
        } else {
            $kwota = floatval(str_replace(',', '.', $_POST['kwota'] ?? 0));
        }
        
        if ($kwota > 0) {
            // Oblicz rachunek
            if ($typ_kwoty === 'netto') {
                $wynik = obliczRachunekOdNetto($kwota, $typ_zleceniobiorcy, $koszty_typ, $z_chorobowym);
            } else {
                $wynik = obliczRachunekOdBrutto($kwota, $typ_zleceniobiorcy, $koszty_typ, $z_chorobowym);
            }
            
            // Zapisz do bazy
            $stmt = $db->prepare("INSERT OR REPLACE INTO rozliczenia_miesieczne 
                (pracownik_id, miesiac, rok, tryb, stawka_godzinowa, liczba_godzin, 
                 kwota_brutto, kwota_netto, typ_kwoty, typ_zleceniobiorcy, koszty_typ, z_chorobowym,
                 emerytalne, rentowe, chorobowe, zdrowotna, podatek, koszty_uzyskania,
                 uwagi, created_by, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
            
            $stmt->execute([
                $pracownik_id, $m, $r, $tryb, $stawka_godzinowa, $liczba_godzin,
                $wynik['brutto'], $wynik['netto'], $typ_kwoty, $typ_zleceniobiorcy, $koszty_typ, $z_chorobowym,
                $wynik['emerytalne'], $wynik['rentowe'], $wynik['chorobowe'], $wynik['zdrowotna'], $wynik['podatek'], $wynik['koszty'],
                sanitize($_POST['uwagi'] ?? ''), $currentUser['id']
            ]);
            
            $message = "Zapisano rozliczenie: brutto " . number_format($wynik['brutto'], 2, ',', ' ') . " zł → netto " . number_format($wynik['netto'], 2, ',', ' ') . " zł";
            $messageType = 'success';
        }
    }
    
    // Masowy zapis
    if ($action === 'zapisz_wszystkie') {
        $zapisano = 0;
        $m = (int)$_POST['miesiac'];
        $r = (int)$_POST['rok'];
        
        foreach ($_POST['rozliczenie'] as $pracownik_id => $dane) {
            if (empty($dane['kwota']) && empty($dane['stawka_godzinowa'])) continue;
            
            $tryb = $dane['tryb'] ?? 'kwota';
            $typ_kwoty = $dane['typ_kwoty'] ?? 'brutto';
            $typ_zleceniobiorcy = $dane['typ_zleceniobiorcy'] ?? 'standardowy';
            $koszty_typ = $dane['koszty_typ'] ?? 'standardowe';
            $z_chorobowym = isset($dane['z_chorobowym']) ? 1 : 0;
            
            $stawka_godzinowa = null;
            $liczba_godzin = null;
            $kwota = 0;
            
            if ($tryb === 'stawka_godziny') {
                $stawka_godzinowa = floatval(str_replace(',', '.', $dane['stawka_godzinowa'] ?? 0));
                $liczba_godzin = floatval(str_replace(',', '.', $dane['liczba_godzin'] ?? 0));
                $kwota = round($stawka_godzinowa * $liczba_godzin, 2);
            } else {
                $kwota = floatval(str_replace(',', '.', $dane['kwota'] ?? 0));
            }
            
            if ($kwota <= 0) continue;
            
            // Oblicz rachunek
            if ($typ_kwoty === 'netto') {
                $wynik = obliczRachunekOdNetto($kwota, $typ_zleceniobiorcy, $koszty_typ, $z_chorobowym);
            } else {
                $wynik = obliczRachunekOdBrutto($kwota, $typ_zleceniobiorcy, $koszty_typ, $z_chorobowym);
            }
            
            $stmt = $db->prepare("INSERT OR REPLACE INTO rozliczenia_miesieczne 
                (pracownik_id, miesiac, rok, tryb, stawka_godzinowa, liczba_godzin, 
                 kwota_brutto, kwota_netto, typ_kwoty, typ_zleceniobiorcy, koszty_typ, z_chorobowym,
                 emerytalne, rentowe, chorobowe, zdrowotna, podatek, koszty_uzyskania,
                 uwagi, created_by, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
            
            $stmt->execute([
                $pracownik_id, $m, $r, $tryb, $stawka_godzinowa, $liczba_godzin,
                $wynik['brutto'], $wynik['netto'], $typ_kwoty, $typ_zleceniobiorcy, $koszty_typ, $z_chorobowym,
                $wynik['emerytalne'], $wynik['rentowe'], $wynik['chorobowe'], $wynik['zdrowotna'], $wynik['podatek'], $wynik['koszty'],
                '', $currentUser['id']
            ]);
            
            // Aktualizuj typ zleceniobiorcy w karcie pracownika
            $stmtUpdate = $db->prepare("UPDATE pracownicy SET typ_zleceniobiorcy = ? WHERE id = ?");
            $stmtUpdate->execute([$typ_zleceniobiorcy, $pracownik_id]);
            
            $zapisano++;
        }
        
        if ($zapisano > 0) {
            $message = "Zapisano $zapisano rozliczeń";
            $messageType = 'success';
        }
    }
    
    // Usunięcie rozliczenia
    if ($action === 'usun_rozliczenie') {
        $rozliczenie_id = (int)$_POST['rozliczenie_id'];
        $db->prepare("DELETE FROM rozliczenia_miesieczne WHERE id = ?")->execute([$rozliczenie_id]);
        $message = "Usunięto rozliczenie";
        $messageType = 'success';
    }
    
    // Dodanie nieobecności
    if ($action === 'dodaj_nieobecnosc') {
        $pracownik_id = (int)$_POST['pracownik_id'];
        $typ = $_POST['typ_nieobecnosci'] ?? 'chorobowy';
        $data_od = $_POST['data_od'] ?? '';
        $data_do = $_POST['data_do'] ?? '';
        $uwagi = sanitize($_POST['uwagi_nieobecnosci'] ?? '');
        
        if ($pracownik_id > 0 && !empty($data_od) && !empty($data_do)) {
            $stmt = $db->prepare("INSERT INTO urlopy (pracownik_id, typ, data_od, data_do, uwagi) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$pracownik_id, $typ, $data_od, $data_do, $uwagi]);
            
            $pracownik = $db->prepare("SELECT imie, nazwisko FROM pracownicy WHERE id = ?")->execute([$pracownik_id]);
            $p = $db->query("SELECT imie, nazwisko FROM pracownicy WHERE id = $pracownik_id")->fetch();
            
            $message = "Dodano nieobecność dla " . ($p ? $p['imie'] . ' ' . $p['nazwisko'] : 'pracownika');
            $messageType = 'success';
        } else {
            $message = "Nieprawidłowe dane nieobecności";
            $messageType = 'error';
        }
    }
    
    // Usunięcie nieobecności
    if ($action === 'usun_nieobecnosc') {
        $nieobecnosc_id = (int)$_POST['nieobecnosc_id'];
        $db->prepare("DELETE FROM urlopy WHERE id = ?")->execute([$nieobecnosc_id]);
        $message = "Usunięto nieobecność";
        $messageType = 'success';
    }
}

// === BUDOWANIE ZAPYTANIA - LISTA PRACOWNIKÓW ===
$where = [];
$params = [];

// Pracownicy aktywni w danym miesiącu
$pierwszyDzien = sprintf('%04d-%02d-01', $rok, $miesiac);
$ostatniDzien = date('Y-m-t', strtotime($pierwszyDzien));

// Aktywni = data_przyjecia <= ostatni dzień miesiąca AND (brak zwolnienia LUB zwolnienie po pierwszym dniu miesiąca)
$where[] = "(p.data_przyjecia IS NULL OR p.data_przyjecia <= :ostatni_dzien)";
$where[] = "(p.data_zwolnienia IS NULL OR p.data_zwolnienia = '' OR p.data_zwolnienia >= :pierwszy_dzien)";
$params[':pierwszy_dzien'] = $pierwszyDzien;
$params[':ostatni_dzien'] = $ostatniDzien;

if (!empty($search)) {
    $where[] = "(p.kod LIKE :search OR p.imie LIKE :search OR p.nazwisko LIKE :search OR p.pesel LIKE :search)";
    $params[':search'] = "%{$search}%";
}

if (!empty($filterNarodowosc)) {
    $where[] = "p.narodowosc = :narodowosc";
    $params[':narodowosc'] = $filterNarodowosc;
}

if ($filterKlient > 0) {
    $where[] = "o.klient_id = :klient_id AND o.active = 1";
    $params[':klient_id'] = $filterKlient;
}

if (!empty($filterTypUmowy)) {
    $where[] = "p.forma_umowy LIKE :typ_umowy";
    $params[':typ_umowy'] = "%{$filterTypUmowy}%";
}

$whereClause = 'WHERE ' . implode(' AND ', $where);

$sql = "SELECT p.*, p.typ_zleceniobiorcy as pracownik_typ_zleceniobiorcy,
               p.uwagi as pracownik_uwagi, p.notatki as pracownik_notatki,
               k.nazwa as klient_nazwa, o.stanowisko as oddelegowanie_stanowisko,
               r.id as rozliczenie_id, r.tryb, r.stawka_godzinowa, r.liczba_godzin,
               r.kwota_brutto, r.kwota_netto, r.typ_kwoty, r.typ_zleceniobiorcy as rozliczenie_typ_zleceniobiorcy, 
               r.koszty_typ, r.z_chorobowym,
               r.emerytalne, r.rentowe, r.chorobowe, r.zdrowotna, r.podatek
        FROM pracownicy p
        LEFT JOIN oddelegowania o ON p.id = o.pracownik_id AND o.active = 1
        LEFT JOIN klienci k ON o.klient_id = k.id
        LEFT JOIN rozliczenia_miesieczne r ON p.id = r.pracownik_id AND r.miesiac = :rm AND r.rok = :rr
        {$whereClause}
        GROUP BY p.id
        ORDER BY p.nazwisko, p.imie";

$params[':rm'] = $miesiac;
$params[':rr'] = $rok;

$stmt = $db->prepare($sql);
$stmt->execute($params);
$pracownicy = $stmt->fetchAll();

// Pobierz nieobecności dla wszystkich pracowników w danym miesiącu
$nieobecnosciMap = [];
$pierwszyDzienMiesiaca = sprintf('%04d-%02d-01', $rok, $miesiac);
$ostatniDzienMiesiaca = date('Y-m-t', strtotime($pierwszyDzienMiesiaca));

$stmtNieob = $db->prepare("SELECT u.*, p.imie, p.nazwisko, p.kod 
    FROM urlopy u 
    JOIN pracownicy p ON u.pracownik_id = p.id
    WHERE (u.data_od <= :ostatni AND u.data_do >= :pierwszy)
       OR (u.data_od >= :pierwszy2 AND u.data_od <= :ostatni2)
    ORDER BY u.data_od");
$stmtNieob->execute([
    ':pierwszy' => $pierwszyDzienMiesiaca,
    ':ostatni' => $ostatniDzienMiesiaca,
    ':pierwszy2' => $pierwszyDzienMiesiaca,
    ':ostatni2' => $ostatniDzienMiesiaca
]);
$wszystkieNieobecnosci = $stmtNieob->fetchAll();

foreach ($wszystkieNieobecnosci as $n) {
    if (!isset($nieobecnosciMap[$n['pracownik_id']])) {
        $nieobecnosciMap[$n['pracownik_id']] = [];
    }
    $nieobecnosciMap[$n['pracownik_id']][] = $n;
}

// Listy do filtrów
$narodowosci = $db->query("SELECT DISTINCT narodowosc FROM pracownicy WHERE narodowosc IS NOT NULL AND narodowosc != '' ORDER BY narodowosc")->fetchAll(PDO::FETCH_COLUMN);
$klienciLista = $db->query("SELECT id, nazwa FROM klienci WHERE active = 1 ORDER BY nazwa")->fetchAll();

// Statystyki
$sumaBrutto = 0;
$sumaNetto = 0;
$zliczoneCount = 0;
foreach ($pracownicy as $p) {
    if ($p['rozliczenie_id']) {
        $sumaBrutto += $p['kwota_brutto'];
        $sumaNetto += $p['kwota_netto'];
        $zliczoneCount++;
    }
}

$hasFilters = !empty($search) || !empty($filterNarodowosc) || $filterKlient > 0 || !empty($filterTypUmowy);
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Składki - <?= $miesiacNazwy[$miesiac] ?> <?= $rok ?> - Work Land</title>
    <link rel="stylesheet" href="assets/style.css">
    <style>
        .skladki-container { max-width: 1600px; margin: 0 auto; }
        
        .month-selector { 
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            color: white; 
            padding: 20px; 
            border-radius: 12px; 
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 15px;
        }
        .month-selector h2 { margin: 0; font-size: 1.5rem; }
        .month-nav { display: flex; gap: 10px; align-items: center; }
        .month-nav select { padding: 8px 12px; border-radius: 6px; border: none; font-size: 1rem; }
        .month-nav .btn { background: rgba(255,255,255,0.2); border: none; color: white; }
        .month-nav .btn:hover { background: rgba(255,255,255,0.3); }
        
        .stats-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .stat-card .label { color: #64748b; font-size: 0.85rem; margin-bottom: 5px; }
        .stat-card .value { font-size: 1.5rem; font-weight: 700; color: #1e40af; }
        .stat-card .value.green { color: #059669; }
        
        .filters { 
            background: white; 
            padding: 15px 20px; 
            border-radius: 10px; 
            margin-bottom: 20px; 
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .filters-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 4px; }
        .filter-group label { font-size: 0.8rem; color: #64748b; font-weight: 500; }
        .filter-group select, .filter-group input { 
            padding: 8px 12px; 
            border: 2px solid #e2e8f0; 
            border-radius: 6px; 
            font-size: 0.9rem;
            min-width: 150px;
        }
        
        .pracownicy-table {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }
        .pracownicy-table table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
        .pracownicy-table th { 
            background: #f8fafc; 
            padding: 12px 10px; 
            text-align: left; 
            font-weight: 600;
            color: #475569;
            border-bottom: 2px solid #e2e8f0;
            white-space: nowrap;
        }
        .pracownicy-table td { 
            padding: 10px; 
            border-bottom: 1px solid #f1f5f9;
            vertical-align: middle;
        }
        .pracownicy-table tr:hover { background: #f8fafc; }
        .pracownicy-table tr.has-rozliczenie { background: #f0fdf4; }
        .pracownicy-table tr.has-rozliczenie:hover { background: #dcfce7; }
        
        .pracownik-info { min-width: 180px; }
        .pracownik-info .name { font-weight: 600; color: #1e293b; }
        .pracownik-info .meta { font-size: 0.8rem; color: #64748b; }
        .pracownik-info .klient { 
            display: inline-block;
            background: #dbeafe; 
            color: #1d4ed8; 
            padding: 2px 6px; 
            border-radius: 4px; 
            font-size: 0.75rem;
            margin-top: 3px;
        }
        
        .daty-zatrudnienia {
            font-size: 0.85rem;
            white-space: nowrap;
        }
        .daty-zatrudnienia .data-przyjecia { color: #059669; }
        .daty-zatrudnienia .data-zwolnienia { margin-top: 2px; }
        
        .typ-umowy-badge {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 500;
        }
        .typ-zlecenie { background: #fef3c7; color: #b45309; }
        .typ-praca { background: #dbeafe; color: #1d4ed8; }
        .typ-dzielo { background: #f3e8ff; color: #7c3aed; }
        
        .typ-badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.75rem;
            background: #f1f5f9;
            color: #475569;
            cursor: help;
            white-space: nowrap;
        }
        .typ-badge.typ-student { background: #dbeafe; color: #1d4ed8; }
        .typ-badge.typ-standard_26 { background: #d1fae5; color: #059669; }
        .typ-badge.typ-emeryt { background: #fef3c7; color: #d97706; }
        .typ-badge.typ-inny_tytul { background: #e0e7ff; color: #4f46e5; }
        .typ-badge.typ-bez_zus_zdrow { background: #f3f4f6; color: #6b7280; }
        
        .btn-disabled {
            opacity: 0.3;
            cursor: not-allowed;
        }
        
        .tryb-toggle {
            display: flex;
            gap: 5px;
        }
        .tryb-toggle label {
            padding: 4px 8px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            background: #f1f5f9;
            transition: all 0.2s;
        }
        .tryb-toggle input { display: none; }
        .tryb-toggle input:checked + span {
            background: #2563eb;
            color: white;
        }
        .tryb-toggle label:has(input:checked) {
            background: #2563eb;
            color: white;
        }
        
        .input-group {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .input-small { 
            width: 70px; 
            padding: 6px 8px; 
            border: 1px solid #e2e8f0; 
            border-radius: 4px;
            text-align: right;
        }
        .input-small:focus { border-color: #2563eb; outline: none; }
        
        .netto-brutto-toggle {
            display: flex;
            border-radius: 6px;
            overflow: hidden;
            border: 1px solid #e2e8f0;
        }
        .netto-brutto-toggle label {
            padding: 5px 10px;
            cursor: pointer;
            font-size: 0.8rem;
            background: white;
            transition: all 0.2s;
        }
        .netto-brutto-toggle input { display: none; }
        .netto-brutto-toggle label:has(input:checked) {
            background: #2563eb;
            color: white;
        }
        
        .wynik-box {
            background: #f0fdf4;
            border: 1px solid #86efac;
            padding: 6px 10px;
            border-radius: 6px;
            min-width: 100px;
            text-align: center;
        }
        .wynik-box .brutto { font-weight: 600; color: #166534; }
        .wynik-box .netto { font-size: 0.85rem; color: #15803d; }
        .wynik-box.empty { background: #f8fafc; border-color: #e2e8f0; }
        .wynik-box.empty .brutto { color: #94a3b8; }
        
        .actions-cell { white-space: nowrap; }
        .btn-icon { 
            padding: 6px 10px; 
            border-radius: 6px; 
            border: none; 
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.2s;
        }
        .btn-save { background: #dcfce7; color: #166534; }
        .btn-save:hover { background: #bbf7d0; }
        .btn-rachunek { background: #dbeafe; color: #1d4ed8; }
        .btn-rachunek:hover { background: #bfdbfe; }
        .btn-delete { background: #fee2e2; color: #dc2626; }
        .btn-delete:hover { background: #fecaca; }
        
        .typ-select { 
            width: 120px; 
            padding: 5px; 
            border: 1px solid #e2e8f0; 
            border-radius: 4px;
            font-size: 0.8rem;
        }
        
        .chorobowe-check {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.8rem;
            color: #64748b;
        }
        .chorobowe-check input { width: 16px; height: 16px; }
        
        .bulk-actions {
            background: #1e40af;
            color: white;
            padding: 15px 20px;
            border-radius: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            position: sticky;
            bottom: 20px;
            box-shadow: 0 4px 20px rgba(30, 64, 175, 0.3);
        }
        .bulk-actions .btn {
            background: white;
            color: #1e40af;
            padding: 10px 25px;
            font-weight: 600;
        }
        .bulk-actions .btn:hover { background: #f0f9ff; }
        
        .alert { padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; }
        .alert.success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
        .alert.error { background: #fee2e2; color: #dc2626; border: 1px solid #fca5a5; }
        
        .hidden-fields { display: none; }
        .show-stawka .stawka-fields { display: flex !important; }
        .show-stawka .kwota-field { display: none !important; }
        .show-kwota .kwota-field { display: block !important; }
        .show-kwota .stawka-fields { display: none !important; }
        
        /* Style dla selecta typu zleceniobiorcy */
        .typ-select {
            padding: 6px 8px;
            border: 2px solid #e2e8f0;
            border-radius: 6px;
            font-size: 0.85rem;
            background: white;
            cursor: pointer;
            min-width: 180px;
        }
        .typ-select:focus {
            border-color: #2563eb;
            outline: none;
        }
        .typ-select:hover {
            border-color: #cbd5e1;
        }
        
        /* Wiersz z informacjami o pracowniku */
        .info-row {
            background: #fffbeb !important;
        }
        .info-row:hover {
            background: #fef3c7 !important;
        }
        .pracownik-info-details {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            padding: 5px 10px;
        }
        .info-box {
            background: white;
            border-radius: 8px;
            padding: 10px 15px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            flex: 1;
            min-width: 250px;
        }
        .info-box .info-label {
            font-weight: 600;
            color: #475569;
            display: block;
            margin-bottom: 5px;
            font-size: 0.85rem;
        }
        .info-box .info-content {
            color: #64748b;
            font-size: 0.9rem;
            line-height: 1.4;
        }
        .uwagi-box {
            border-left: 4px solid #f59e0b;
        }
        .notatki-box {
            border-left: 4px solid #8b5cf6;
        }
        .nieobecnosci-box {
            border-left: 4px solid #ef4444;
            flex: 2;
            min-width: 400px;
        }
        .nieobecnosci-lista {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 5px;
        }
        .nieobecnosc-item {
            background: #fee2e2;
            color: #991b1b;
            padding: 4px 10px;
            border-radius: 5px;
            font-size: 0.85rem;
        }
        .nieobecnosc-item strong {
            color: #dc2626;
        }
        .nieobecnosc-item em {
            color: #b91c1c;
            font-style: normal;
            font-size: 0.8rem;
        }
        
        /* Przycisk usuwania nieobecności */
        .btn-usun-nieobecnosc {
            background: #dc2626;
            color: white;
            border: none;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 14px;
            line-height: 1;
            cursor: pointer;
            margin-left: 5px;
            padding: 0;
            vertical-align: middle;
        }
        .btn-usun-nieobecnosc:hover {
            background: #991b1b;
        }
        
        /* Przycisk nieobecności w akcjach */
        .btn-nieobecnosc {
            background: #f59e0b !important;
            color: white;
        }
        .btn-nieobecnosc:hover {
            background: #d97706 !important;
        }
        
        /* Modal */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }
        .modal-content {
            background: white;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            animation: modalSlide 0.3s ease;
        }
        @keyframes modalSlide {
            from { transform: translateY(-30px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        .modal-header {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            padding: 15px 20px;
            border-radius: 12px 12px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-header h3 {
            margin: 0;
            font-size: 1.2rem;
        }
        .modal-close {
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            padding: 0;
            line-height: 1;
        }
        .modal-body {
            padding: 20px;
        }
        .modal-footer {
            padding: 15px 20px;
            border-top: 1px solid #e2e8f0;
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 5px;
            color: #374151;
        }
        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 12px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
        }
        .form-group input:focus, .form-group select:focus {
            border-color: #ef4444;
            outline: none;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .pracownik-nazwa-display {
            font-weight: 700;
            font-size: 1.1rem;
            color: #1e40af;
            padding: 8px 0;
        }
        .hint {
            font-size: 0.85rem;
            color: #64748b;
            margin: 10px 0;
            padding: 8px 12px;
            background: #fef3c7;
            border-radius: 6px;
        }
        .btn-cancel {
            background: #e2e8f0;
            color: #475569;
        }
        .btn-save {
            background: #059669;
            color: white;
        }
        .btn-save:hover {
            background: #047857;
        }
        
        @media (max-width: 1200px) {
            .pracownicy-table { overflow-x: auto; }
            .pracownicy-table table { min-width: 1000px; }
        }
    </style>
</head>
<body>
    <div class="container skladki-container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="index.php"><img src="assets/logo.png" alt="Work Land"></a>
                <div class="user-info">
                    👤 <?= sanitize($currentUser['name']) ?>
                </div>
            </div>
            <div class="nav-links">
                <a href="index.php">📋 Pracownicy</a>
                <a href="crm/">🎯 CRM</a>
                <a href="kandydaci/">👥 Kandydaci</a>
                <a href="rachunek_gen.php">💰 Rachunki</a>
                <a href="lista_obecnosci_gen.php">📝 Lista obecności</a>
            </div>
        </nav>
        
        <!-- Wybór miesiąca -->
        <div class="month-selector">
            <h2>💰 Składki i rozliczenia</h2>
            <form method="get" class="month-nav">
                <a href="?miesiac=<?= $miesiac == 1 ? 12 : $miesiac - 1 ?>&rok=<?= $miesiac == 1 ? $rok - 1 : $rok ?>" class="btn">◀</a>
                <select name="miesiac" onchange="this.form.submit()">
                    <?php for ($m = 1; $m <= 12; $m++): ?>
                        <option value="<?= $m ?>" <?= $m == $miesiac ? 'selected' : '' ?>><?= $miesiacNazwy[$m] ?></option>
                    <?php endfor; ?>
                </select>
                <select name="rok" onchange="this.form.submit()">
                    <?php for ($y = date('Y') - 1; $y <= date('Y') + 1; $y++): ?>
                        <option value="<?= $y ?>" <?= $y == $rok ? 'selected' : '' ?>><?= $y ?></option>
                    <?php endfor; ?>
                </select>
                <a href="?miesiac=<?= $miesiac == 12 ? 1 : $miesiac + 1 ?>&rok=<?= $miesiac == 12 ? $rok + 1 : $rok ?>" class="btn">▶</a>
            </form>
        </div>
        
        <?php if ($message): ?>
            <div class="alert <?= $messageType ?>"><?= $message ?></div>
        <?php endif; ?>
        
        <!-- Statystyki -->
        <div class="stats-summary">
            <div class="stat-card">
                <div class="label">Pracowników w miesiącu</div>
                <div class="value"><?= count($pracownicy) ?></div>
            </div>
            <div class="stat-card">
                <div class="label">Rozliczonych</div>
                <div class="value"><?= $zliczoneCount ?> / <?= count($pracownicy) ?></div>
            </div>
            <div class="stat-card">
                <div class="label">Suma brutto</div>
                <div class="value"><?= number_format($sumaBrutto, 2, ',', ' ') ?> zł</div>
            </div>
            <div class="stat-card">
                <div class="label">Suma netto</div>
                <div class="value green"><?= number_format($sumaNetto, 2, ',', ' ') ?> zł</div>
            </div>
        </div>
        
        <!-- Filtry -->
        <div class="filters">
            <form method="get" class="filters-row">
                <input type="hidden" name="miesiac" value="<?= $miesiac ?>">
                <input type="hidden" name="rok" value="<?= $rok ?>">
                
                <div class="filter-group">
                    <label>🔍 Szukaj</label>
                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Imię, nazwisko, kod...">
                </div>
                
                <div class="filter-group">
                    <label>🌍 Narodowość</label>
                    <select name="narodowosc">
                        <option value="">-- Wszystkie --</option>
                        <?php foreach ($narodowosci as $n): ?>
                            <option value="<?= htmlspecialchars($n) ?>" <?= $filterNarodowosc === $n ? 'selected' : '' ?>><?= htmlspecialchars($n) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>🏢 Klient</label>
                    <select name="klient">
                        <option value="">-- Wszyscy --</option>
                        <?php foreach ($klienciLista as $k): ?>
                            <option value="<?= $k['id'] ?>" <?= $filterKlient == $k['id'] ? 'selected' : '' ?>><?= htmlspecialchars($k['nazwa']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>📄 Typ umowy</label>
                    <select name="typ_umowy">
                        <option value="">-- Wszystkie --</option>
                        <option value="zlecenie" <?= $filterTypUmowy === 'zlecenie' ? 'selected' : '' ?>>Zlecenie</option>
                        <option value="praca" <?= $filterTypUmowy === 'praca' ? 'selected' : '' ?>>O pracę</option>
                        <option value="dzieło" <?= $filterTypUmowy === 'dzieło' ? 'selected' : '' ?>>O dzieło</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <button type="submit" class="btn btn-primary">🔍 Filtruj</button>
                    <?php if ($hasFilters): ?>
                        <a href="?miesiac=<?= $miesiac ?>&rok=<?= $rok ?>" class="btn btn-secondary">✕ Wyczyść</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        
        <!-- Tabela pracowników -->
        <form method="post" id="mainForm">
            <input type="hidden" name="action" value="zapisz_wszystkie">
            <input type="hidden" name="miesiac" value="<?= $miesiac ?>">
            <input type="hidden" name="rok" value="<?= $rok ?>">
            
            <div class="pracownicy-table">
                <table>
                    <thead>
                        <tr>
                            <th>Pracownik</th>
                            <th>Zatrudnienie</th>
                            <th>Typ umowy</th>
                            <th>Tryb</th>
                            <th>Stawka / Godziny</th>
                            <th>Kwota</th>
                            <th>N/B</th>
                            <th>Typ zlec.</th>
                            <th>Chor.</th>
                            <th>Wynik</th>
                            <th>Akcje</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pracownicy as $p): 
                            $hasRozliczenie = !empty($p['rozliczenie_id']);
                            $typUmowy = strtolower($p['forma_umowy'] ?? '');
                            $isZlecenie = strpos($typUmowy, 'zlecen') !== false;
                            $tryb = $p['tryb'] ?? 'kwota';
                        ?>
                        <tr class="<?= $hasRozliczenie ? 'has-rozliczenie' : '' ?> <?= $tryb === 'stawka_godziny' ? 'show-stawka' : 'show-kwota' ?>" data-id="<?= $p['id'] ?>">
                            <td class="pracownik-info">
                                <div class="name"><?= sanitize($p['nazwisko'] . ' ' . $p['imie']) ?></div>
                                <div class="meta"><?= sanitize($p['kod']) ?></div>
                                <?php if (!empty($p['klient_nazwa'])): ?>
                                    <div class="klient">🏢 <?= sanitize($p['klient_nazwa']) ?></div>
                                <?php endif; ?>
                            </td>
                            
                            <td class="daty-zatrudnienia">
                                <div class="data-przyjecia" title="Data przyjęcia">
                                    📅 <?= !empty($p['data_przyjecia']) ? date('d.m.Y', strtotime($p['data_przyjecia'])) : '<span class="muted">—</span>' ?>
                                </div>
                                <?php if (!empty($p['data_zwolnienia'])): ?>
                                    <div class="data-zwolnienia" title="Data zwolnienia" style="color: #dc2626; font-size: 0.8rem;">
                                        ❌ <?= date('d.m.Y', strtotime($p['data_zwolnienia'])) ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            
                            <td>
                                <?php 
                                $badgeClass = 'typ-praca';
                                if ($isZlecenie) $badgeClass = 'typ-zlecenie';
                                elseif (strpos($typUmowy, 'dzieł') !== false) $badgeClass = 'typ-dzielo';
                                ?>
                                <span class="typ-umowy-badge <?= $badgeClass ?>"><?= sanitize($p['forma_umowy'] ?: 'brak') ?></span>
                            </td>
                            
                            <td>
                                <div class="tryb-toggle">
                                    <label>
                                        <input type="radio" name="rozliczenie[<?= $p['id'] ?>][tryb]" value="stawka_godziny" 
                                               <?= $tryb === 'stawka_godziny' ? 'checked' : '' ?> 
                                               onchange="toggleTryb(this, <?= $p['id'] ?>)">
                                        <span>S×G</span>
                                    </label>
                                    <label>
                                        <input type="radio" name="rozliczenie[<?= $p['id'] ?>][tryb]" value="kwota" 
                                               <?= $tryb === 'kwota' ? 'checked' : '' ?>
                                               onchange="toggleTryb(this, <?= $p['id'] ?>)">
                                        <span>Kwota</span>
                                    </label>
                                </div>
                            </td>
                            
                            <td>
                                <div class="input-group stawka-fields" style="<?= $tryb !== 'stawka_godziny' ? 'display:none' : '' ?>">
                                    <input type="text" name="rozliczenie[<?= $p['id'] ?>][stawka_godzinowa]" 
                                           value="<?= $p['stawka_godzinowa'] ? number_format($p['stawka_godzinowa'], 2, ',', '') : '' ?>" 
                                           placeholder="Stawka" class="input-small"
                                           onchange="obliczKwote(<?= $p['id'] ?>)">
                                    <span>×</span>
                                    <input type="text" name="rozliczenie[<?= $p['id'] ?>][liczba_godzin]" 
                                           value="<?= $p['liczba_godzin'] ? number_format($p['liczba_godzin'], 1, ',', '') : '' ?>" 
                                           placeholder="Godz." class="input-small"
                                           onchange="obliczKwote(<?= $p['id'] ?>)">
                                </div>
                            </td>
                            
                            <td>
                                <input type="text" name="rozliczenie[<?= $p['id'] ?>][kwota]" 
                                       value="<?= $hasRozliczenie ? number_format($p['typ_kwoty'] === 'netto' ? $p['kwota_netto'] : $p['kwota_brutto'], 2, ',', '') : '' ?>" 
                                       placeholder="0,00" class="input-small kwota-field"
                                       style="width: 90px; <?= $tryb === 'stawka_godziny' ? 'display:none' : '' ?>"
                                       data-pracownik="<?= $p['id'] ?>">
                            </td>
                            
                            <td>
                                <div class="netto-brutto-toggle">
                                    <label>
                                        <input type="radio" name="rozliczenie[<?= $p['id'] ?>][typ_kwoty]" value="brutto" 
                                               <?= ($p['typ_kwoty'] ?? 'brutto') === 'brutto' ? 'checked' : '' ?>>
                                        B
                                    </label>
                                    <label>
                                        <input type="radio" name="rozliczenie[<?= $p['id'] ?>][typ_kwoty]" value="netto"
                                               <?= ($p['typ_kwoty'] ?? '') === 'netto' ? 'checked' : '' ?>>
                                        N
                                    </label>
                                </div>
                            </td>
                            
                            <td>
                                <?php 
                                // Typ zleceniobiorcy - edytowalny select
                                $typZlec = $p['rozliczenie_typ_zleceniobiorcy'] ?? $p['pracownik_typ_zleceniobiorcy'] ?? 'standardowy';
                                ?>
                                <select name="rozliczenie[<?= $p['id'] ?>][typ_zleceniobiorcy]" class="typ-select" title="Zmień typ zleceniobiorcy">
                                    <?php foreach ($typyZleceniobiorcy as $key => $info): ?>
                                        <option value="<?= $key ?>" <?= $typZlec === $key ? 'selected' : '' ?>><?= $info['ikona'] ?> <?= $info['nazwa'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            
                            <td>
                                <label class="chorobowe-check" title="Dobrowolna składka chorobowa 2,45%">
                                    <input type="checkbox" name="rozliczenie[<?= $p['id'] ?>][z_chorobowym]" value="1"
                                           <?= ($p['z_chorobowym'] ?? 1) ? 'checked' : '' ?>>
                                    2,45%
                                </label>
                            </td>
                            
                            <td>
                                <div class="wynik-box <?= !$hasRozliczenie ? 'empty' : '' ?>">
                                    <?php if ($hasRozliczenie): ?>
                                        <div class="brutto"><?= number_format($p['kwota_brutto'], 2, ',', ' ') ?> zł</div>
                                        <div class="netto">→ <?= number_format($p['kwota_netto'], 2, ',', ' ') ?> zł</div>
                                    <?php else: ?>
                                        <div class="brutto">—</div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            
                            <td class="actions-cell">
                                <button type="button" class="btn-icon btn-nieobecnosc" title="Dodaj nieobecność"
                                        onclick="otworzModalNieobecnosci(<?= $p['id'] ?>, '<?= addslashes($p['imie'] . ' ' . $p['nazwisko']) ?>')">🏥</button>
                                <?php if ($isZlecenie && $hasRozliczenie): ?>
                                    <a href="rachunek_gen.php?pracownik_id=<?= $p['id'] ?>&miesiac=<?= $miesiac ?>&rok=<?= $rok ?>&kwota=<?= $p['kwota_brutto'] ?>&typ_zleceniobiorcy=<?= $typZlec ?>&drukuj=1" 
                                       class="btn-icon btn-rachunek" title="Drukuj rachunek" target="_blank">🖨️</a>
                                <?php elseif ($isZlecenie): ?>
                                    <span class="btn-icon btn-disabled" title="Najpierw zapisz rozliczenie">📄</span>
                                <?php endif; ?>
                                <?php if ($hasRozliczenie): ?>
                                    <button type="button" class="btn-icon btn-delete" title="Usuń rozliczenie"
                                            onclick="usunRozliczenie(<?= $p['rozliczenie_id'] ?>)">🗑️</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        
                        <?php 
                        // Pobierz nieobecności dla tego pracownika w tym miesiącu
                        $nieobecnosciPrac = $nieobecnosciMap[$p['id']] ?? [];
                        $maUwagi = !empty($p['pracownik_uwagi']);
                        $maNotatki = !empty($p['pracownik_notatki']);
                        $maNieobecnosci = count($nieobecnosciPrac) > 0;
                        
                        if ($maUwagi || $maNotatki || $maNieobecnosci): 
                        ?>
                        <tr class="info-row" data-parent="<?= $p['id'] ?>">
                            <td colspan="11">
                                <div class="pracownik-info-details">
                                    <?php if ($maUwagi): ?>
                                    <div class="info-box uwagi-box">
                                        <span class="info-label">📝 Uwagi:</span>
                                        <span class="info-content"><?= nl2br(sanitize($p['pracownik_uwagi'])) ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($maNotatki): ?>
                                    <div class="info-box notatki-box">
                                        <span class="info-label">📋 Notatki wewnętrzne:</span>
                                        <span class="info-content"><?= nl2br(sanitize($p['pracownik_notatki'])) ?></span>
                                    </div>
                                    <?php endif; ?>
                                    
                                    <?php if ($maNieobecnosci): ?>
                                    <div class="info-box nieobecnosci-box">
                                        <span class="info-label">🏥 Nieobecności w <?= $miesiacNazwy[$miesiac] ?>:</span>
                                        <div class="nieobecnosci-lista">
                                            <?php foreach ($nieobecnosciPrac as $nieob): 
                                                $typNieob = [
                                                    'bezpłatny' => '🏖️ Urlop bezpłatny',
                                                    'wypoczynkowy' => '🌴 Urlop wypoczynkowy',
                                                    'chorobowy' => '🏥 L4/Chorobowy',
                                                    'macierzyński' => '👶 Macierzyński',
                                                    'rodzicielski' => '👨‍👩‍👧 Rodzicielski',
                                                    'ojcowski' => '👨 Ojcowski',
                                                    'wychowawczy' => '🧒 Wychowawczy',
                                                    'okolicznościowy' => '📅 Okolicznościowy',
                                                    'usprawiedliwiona' => '✅ Usprawiedliwiona',
                                                    'nieusprawiedliwiona' => '❌ Nieusprawiedliwiona'
                                                ];
                                                $typLabel = $typNieob[$nieob['typ']] ?? $nieob['typ'];
                                            ?>
                                            <span class="nieobecnosc-item">
                                                <?= $typLabel ?>: 
                                                <strong><?= date('d.m', strtotime($nieob['data_od'])) ?><?= $nieob['data_do'] != $nieob['data_od'] ? ' - ' . date('d.m', strtotime($nieob['data_do'])) : '' ?></strong>
                                                <?php if (!empty($nieob['uwagi'])): ?>
                                                    <em>(<?= sanitize($nieob['uwagi']) ?>)</em>
                                                <?php endif; ?>
                                                <button type="button" class="btn-usun-nieobecnosc" title="Usuń nieobecność" 
                                                        onclick="usunNieobecnosc(<?= $nieob['id'] ?>)">×</button>
                                            </span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                        
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <?php if (count($pracownicy) > 0): ?>
            <div class="bulk-actions">
                <div>
                    📊 Wypełnij dane i kliknij "Zapisz wszystkie" aby zapisać rozliczenia dla <?= $miesiacNazwy[$miesiac] ?> <?= $rok ?>
                </div>
                <button type="submit" class="btn">💾 Zapisz wszystkie</button>
            </div>
            <?php endif; ?>
        </form>
        
        <!-- Ukryty formularz do usuwania -->
        <form id="deleteForm" method="post" style="display: none;">
            <input type="hidden" name="action" value="usun_rozliczenie">
            <input type="hidden" name="rozliczenie_id" id="deleteRozliczenieId">
        </form>
        
        <!-- Formularz do usuwania nieobecności -->
        <form id="deleteNieobecnoscForm" method="post" style="display: none;">
            <input type="hidden" name="action" value="usun_nieobecnosc">
            <input type="hidden" name="nieobecnosc_id" id="deleteNieobecnoscId">
        </form>
        
        <!-- Modal dodawania nieobecności -->
        <div id="modalNieobecnosc" class="modal-overlay" style="display: none;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>🏥 Dodaj nieobecność</h3>
                    <button type="button" class="modal-close" onclick="zamknijModal()">&times;</button>
                </div>
                <form method="post" id="formNieobecnosc">
                    <input type="hidden" name="action" value="dodaj_nieobecnosc">
                    <input type="hidden" name="pracownik_id" id="nieobecnosc_pracownik_id">
                    
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Pracownik:</label>
                            <div id="nieobecnosc_pracownik_nazwa" class="pracownik-nazwa-display"></div>
                        </div>
                        
                        <div class="form-group">
                            <label for="typ_nieobecnosci">Typ nieobecności:</label>
                            <select name="typ_nieobecnosci" id="typ_nieobecnosci" required>
                                <option value="chorobowy">🏥 L4 / Chorobowy</option>
                                <option value="wypoczynkowy">🌴 Urlop wypoczynkowy</option>
                                <option value="bezpłatny">🏖️ Urlop bezpłatny</option>
                                <option value="macierzyński">👶 Macierzyński</option>
                                <option value="rodzicielski">👨‍👩‍👧 Rodzicielski</option>
                                <option value="ojcowski">👨 Ojcowski</option>
                                <option value="wychowawczy">🧒 Wychowawczy</option>
                                <option value="okolicznościowy">📅 Okolicznościowy</option>
                                <option value="usprawiedliwiona">✅ Nieobecność usprawiedliwiona</option>
                                <option value="nieusprawiedliwiona">❌ Nieobecność nieusprawiedliwiona</option>
                            </select>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="data_od">Data od:</label>
                                <input type="date" name="data_od" id="data_od" required 
                                       value="<?= sprintf('%04d-%02d-01', $rok, $miesiac) ?>">
                            </div>
                            <div class="form-group">
                                <label for="data_do">Data do:</label>
                                <input type="date" name="data_do" id="data_do" required
                                       value="<?= date('Y-m-t', strtotime(sprintf('%04d-%02d-01', $rok, $miesiac))) ?>">
                            </div>
                        </div>
                        
                        <p class="hint">💡 Data może wykraczać poza wybrany miesiąc - nieobecność będzie widoczna we wszystkich miesiącach, które obejmuje.</p>
                        
                        <div class="form-group">
                            <label for="uwagi_nieobecnosci">Uwagi (opcjonalne):</label>
                            <input type="text" name="uwagi_nieobecnosci" id="uwagi_nieobecnosci" 
                                   placeholder="np. numer zwolnienia, powód...">
                        </div>
                    </div>
                    
                    <div class="modal-footer">
                        <button type="button" class="btn btn-cancel" onclick="zamknijModal()">Anuluj</button>
                        <button type="submit" class="btn btn-save">💾 Zapisz nieobecność</button>
                    </div>
                </form>
            </div>
        </div>
        
        <footer style="margin-top: 30px;">
            <p>Work Land © <?= date('Y') ?> | Moduł Składki | v<?= WORKLAND_VERSION ?> (<?= WORKLAND_VERSION_DATE ?>)</p>
        </footer>
    </div>
    
    <script>
    function toggleTryb(radio, pracownikId) {
        const row = document.querySelector(`tr[data-id="${pracownikId}"]`);
        if (radio.value === 'stawka_godziny') {
            row.classList.add('show-stawka');
            row.classList.remove('show-kwota');
        } else {
            row.classList.remove('show-stawka');
            row.classList.add('show-kwota');
        }
    }
    
    function obliczKwote(pracownikId) {
        const row = document.querySelector(`tr[data-id="${pracownikId}"]`);
        const stawka = parseFloat(row.querySelector(`input[name="rozliczenie[${pracownikId}][stawka_godzinowa]"]`).value.replace(',', '.')) || 0;
        const godziny = parseFloat(row.querySelector(`input[name="rozliczenie[${pracownikId}][liczba_godzin]"]`).value.replace(',', '.')) || 0;
        const kwotaInput = row.querySelector(`input[name="rozliczenie[${pracownikId}][kwota]"]`);
        
        if (stawka > 0 && godziny > 0) {
            kwotaInput.value = (stawka * godziny).toFixed(2).replace('.', ',');
        }
    }
    
    function usunRozliczenie(rozliczenieId) {
        if (confirm('Czy na pewno chcesz usunąć to rozliczenie?')) {
            document.getElementById('deleteRozliczenieId').value = rozliczenieId;
            document.getElementById('deleteForm').submit();
        }
    }
    
    // Funkcje dla nieobecności
    function otworzModalNieobecnosci(pracownikId, pracownikNazwa) {
        document.getElementById('nieobecnosc_pracownik_id').value = pracownikId;
        document.getElementById('nieobecnosc_pracownik_nazwa').textContent = pracownikNazwa;
        document.getElementById('modalNieobecnosc').style.display = 'flex';
        
        // Resetuj formularz
        document.getElementById('typ_nieobecnosci').value = 'chorobowy';
        document.getElementById('uwagi_nieobecnosci').value = '';
    }
    
    function zamknijModal() {
        document.getElementById('modalNieobecnosc').style.display = 'none';
    }
    
    function usunNieobecnosc(nieobecnoscId) {
        if (confirm('Czy na pewno chcesz usunąć tę nieobecność?')) {
            document.getElementById('deleteNieobecnoscId').value = nieobecnoscId;
            document.getElementById('deleteNieobecnoscForm').submit();
        }
    }
    
    // Zamknij modal po kliknięciu w tło
    document.getElementById('modalNieobecnosc').addEventListener('click', function(e) {
        if (e.target === this) {
            zamknijModal();
        }
    });
    
    // Zamknij modal przez Escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            zamknijModal();
        }
    });
    </script>
</body>
</html>
