<?php
/**
 * CVParser - Klasa do ekstrakcji danych z plików CV (PDF, DOC, DOCX, RTF)
 * 
 * Automatycznie rozpoznaje:
 * - Imię i nazwisko
 * - Email
 * - Telefon
 * - Data urodzenia
 * - Miejscowość
 * - Prawo jazdy (kategorie)
 * - Uprawnienia na wózki widłowe
 */

class CVParser {
    
    private $text = '';
    private $lines = [];
    
    /**
     * Parsuj plik CV i wyciągnij dane
     * Obsługuje: PDF, DOC, DOCX, RTF
     * @param string $filePath - ścieżka do pliku
     * @param string|null $originalName - oryginalna nazwa pliku (opcjonalna, dla określenia formatu)
     */
    public function parseFile($filePath, $originalName = null) {
        // Określ format pliku
        $extension = '';
        
        // Najpierw sprawdź rozszerzenie z nazwy pliku
        if ($originalName) {
            $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        }
        if (!$extension) {
            $extension = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        }
        
        // Jeśli nadal nie ma rozszerzenia, użyj MIME type
        if (!$extension || !in_array($extension, ['pdf', 'doc', 'docx', 'rtf'])) {
            $extension = $this->detectFormatByMime($filePath);
        }
        
        switch ($extension) {
            case 'pdf':
                $this->text = $this->extractTextFromPDF($filePath);
                break;
            case 'docx':
                $this->text = $this->extractTextFromDOCX($filePath);
                break;
            case 'doc':
                $this->text = $this->extractTextFromDOC($filePath);
                break;
            case 'rtf':
                $this->text = $this->extractTextFromRTF($filePath);
                break;
            default:
                throw new Exception("Nieobsługiwany format pliku: $extension");
        }
        
        $this->lines = array_filter(array_map('trim', explode("\n", $this->text)));
        
        return [
            'imie' => $this->extractImie(),
            'nazwisko' => $this->extractNazwisko(),
            'email' => $this->extractEmail(),
            'telefon' => $this->extractTelefon(),
            'data_urodzenia' => $this->extractDataUrodzenia(),
            'miejscowosc' => $this->extractMiejscowosc(),
            'prawo_jazdy' => $this->extractPrawoJazdy(),
            'wozki_widlowe' => $this->extractWozkiWidlowe(),
            'raw_text' => $this->text
        ];
    }
    
    /**
     * Wykryj format pliku na podstawie MIME type
     */
    private function detectFormatByMime($filePath) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $filePath);
        finfo_close($finfo);
        
        $mimeMap = [
            'application/pdf' => 'pdf',
            'application/msword' => 'doc',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'application/rtf' => 'rtf',
            'text/rtf' => 'rtf',
            'application/x-rtf' => 'rtf',
            'application/zip' => 'docx', // DOCX to ZIP
        ];
        
        return $mimeMap[$mimeType] ?? '';
    }
    
    /**
     * Ekstrakcja tekstu z DOCX (Office Open XML)
     */
    private function extractTextFromDOCX($filePath) {
        if (!file_exists($filePath)) {
            throw new Exception("Plik nie istnieje: $filePath");
        }
        
        $text = '';
        
        // DOCX to archiwum ZIP
        $zip = new ZipArchive();
        if ($zip->open($filePath) === true) {
            // Główna treść dokumentu
            $content = $zip->getFromName('word/document.xml');
            if ($content !== false) {
                // Usuń namespace, wyciągnij tekst z tagów <w:t>
                $content = str_replace('</w:t>', ' ', $content);
                $content = str_replace('</w:p>', "\n", $content);
                $text = strip_tags($content);
            }
            $zip->close();
        } else {
            // Fallback: antiword lub catdoc
            $tempFile = tempnam(sys_get_temp_dir(), 'cv_');
            exec("unzip -p " . escapeshellarg($filePath) . " word/document.xml 2>/dev/null | sed 's/<[^>]*>//g'", $output, $returnCode);
            if ($returnCode === 0) {
                $text = implode("\n", $output);
            }
        }
        
        return $this->cleanText($text);
    }
    
    /**
     * Ekstrakcja tekstu z DOC (stary format binarny)
     */
    private function extractTextFromDOC($filePath) {
        if (!file_exists($filePath)) {
            throw new Exception("Plik nie istnieje: $filePath");
        }
        
        $text = '';
        
        // Próba 1: antiword (najlepsza jakość dla .doc)
        exec("antiword " . escapeshellarg($filePath) . " 2>/dev/null", $output, $returnCode);
        if ($returnCode === 0 && !empty($output)) {
            $text = implode("\n", $output);
            if (!empty(trim($text))) {
                return $this->cleanText($text);
            }
        }
        
        // Próba 2: catdoc
        exec("catdoc " . escapeshellarg($filePath) . " 2>/dev/null", $output2, $returnCode2);
        if ($returnCode2 === 0 && !empty($output2)) {
            $text = implode("\n", $output2);
            if (!empty(trim($text))) {
                return $this->cleanText($text);
            }
        }
        
        // Próba 3: strings (ostateczność - wyciąga wszystkie ciągi tekstowe)
        exec("strings " . escapeshellarg($filePath) . " 2>/dev/null | grep -E '[A-Za-zżźćąśęłóńŻŹĆĄŚĘŁÓŃ]{3,}'", $output3, $returnCode3);
        if ($returnCode3 === 0 && !empty($output3)) {
            $text = implode("\n", $output3);
            if (!empty(trim($text))) {
                return $this->cleanText($text);
            }
        }
        
        // Próba 4: LibreOffice conversion
        $tempDir = sys_get_temp_dir();
        exec("libreoffice --headless --convert-to txt --outdir " . escapeshellarg($tempDir) . " " . escapeshellarg($filePath) . " 2>/dev/null", $output4, $returnCode4);
        $txtFile = $tempDir . '/' . pathinfo($filePath, PATHINFO_FILENAME) . '.txt';
        if (file_exists($txtFile)) {
            $text = file_get_contents($txtFile);
            unlink($txtFile);
            if (!empty(trim($text))) {
                return $this->cleanText($text);
            }
        }
        
        // Próba 5: Prosty parser binarny DOC
        $text = $this->simpleDOCExtract($filePath);
        
        return $this->cleanText($text);
    }
    
    /**
     * Prosty ekstraktor tekstu z pliku DOC (binarny)
     */
    private function simpleDOCExtract($filePath) {
        $content = file_get_contents($filePath);
        $text = '';
        
        // DOC zawiera tekst w określonych miejscach - szukamy ciągów ASCII/UTF-8
        // Szukaj tekstu między znacznikami
        if (preg_match_all('/[\x20-\x7E\xC0-\xFF]{4,}/', $content, $matches)) {
            $text = implode(' ', $matches[0]);
        }
        
        return $text;
    }
    
    /**
     * Ekstrakcja tekstu z RTF
     */
    private function extractTextFromRTF($filePath) {
        if (!file_exists($filePath)) {
            throw new Exception("Plik nie istnieje: $filePath");
        }
        
        $content = file_get_contents($filePath);
        
        // Próba 1: unrtf
        exec("unrtf --text " . escapeshellarg($filePath) . " 2>/dev/null", $output, $returnCode);
        if ($returnCode === 0 && !empty($output)) {
            $text = implode("\n", $output);
            // Usuń nagłówek unrtf
            $text = preg_replace('/^-+\n.*?-+\n/s', '', $text);
            if (!empty(trim($text))) {
                return $this->cleanText($text);
            }
        }
        
        // Próba 2: Własny parser RTF
        $text = $this->parseRTF($content);
        
        return $this->cleanText($text);
    }
    
    /**
     * Prosty parser RTF
     */
    private function parseRTF($rtf) {
        // Usuń grupy binarne i obrazy
        $rtf = preg_replace('/\{\\\\pict[^}]*\}/', '', $rtf);
        $rtf = preg_replace('/\{\\\\object[^}]*\}/', '', $rtf);
        
        // Zamień kontrolki RTF na tekst
        $rtf = preg_replace('/\\\\par\b/', "\n", $rtf);
        $rtf = preg_replace('/\\\\tab\b/', "\t", $rtf);
        $rtf = preg_replace('/\\\\line\b/', "\n", $rtf);
        
        // Dekoduj znaki Unicode \'XX
        $rtf = preg_replace_callback("/\\\\'([0-9a-fA-F]{2})/", function($m) {
            return chr(hexdec($m[1]));
        }, $rtf);
        
        // Dekoduj znaki Unicode \uNNNN
        $rtf = preg_replace_callback('/\\\\u(\d+)\s*\?/', function($m) {
            return mb_convert_encoding('&#' . $m[1] . ';', 'UTF-8', 'HTML-ENTITIES');
        }, $rtf);
        
        // Usuń pozostałe kontrolki RTF
        $rtf = preg_replace('/\\\\[a-z]+\d*\s?/i', '', $rtf);
        
        // Usuń nawiasy klamrowe
        $rtf = str_replace(['{', '}'], '', $rtf);
        
        return $rtf;
    }
    
    /**
     * Ekstrakcja tekstu z PDF używając pdftotext lub fallback
     */
    private function extractTextFromPDF($filePath) {
        // Sprawdź czy plik istnieje
        if (!file_exists($filePath)) {
            throw new Exception("Plik nie istnieje: $filePath");
        }
        
        // Próba 1: pdftotext (najlepsza jakość)
        $tempFile = tempnam(sys_get_temp_dir(), 'cv_');
        exec("pdftotext -layout " . escapeshellarg($filePath) . " " . escapeshellarg($tempFile) . " 2>&1", $output, $returnCode);
        
        if ($returnCode === 0 && file_exists($tempFile)) {
            $text = file_get_contents($tempFile);
            unlink($tempFile);
            if (!empty(trim($text))) {
                return $this->cleanText($text);
            }
        }
        
        // Próba 2: Prosty parser PDF (dla prostych PDF-ów)
        $text = $this->simplePDFExtract($filePath);
        if (!empty(trim($text))) {
            return $this->cleanText($text);
        }
        
        return '';
    }
    
    /**
     * Prosty parser PDF - wyciąga tekst z obiektów stream
     */
    private function simplePDFExtract($filePath) {
        $content = file_get_contents($filePath);
        $text = '';
        
        // Dekoduj streamy
        if (preg_match_all('/stream\s*\n(.+?)\nendstream/s', $content, $matches)) {
            foreach ($matches[1] as $stream) {
                // Próba dekompresji
                $decoded = @gzuncompress($stream);
                if ($decoded === false) {
                    $decoded = @gzinflate($stream);
                }
                if ($decoded === false) {
                    $decoded = $stream;
                }
                
                // Wyciągnij tekst z operatorów Tj i TJ
                if (preg_match_all('/\(([^)]+)\)\s*Tj/s', $decoded, $textMatches)) {
                    $text .= implode(' ', $textMatches[1]) . "\n";
                }
                if (preg_match_all('/\[([^\]]+)\]\s*TJ/s', $decoded, $textMatches)) {
                    foreach ($textMatches[1] as $arr) {
                        if (preg_match_all('/\(([^)]+)\)/', $arr, $arrMatches)) {
                            $text .= implode('', $arrMatches[1]) . ' ';
                        }
                    }
                    $text .= "\n";
                }
            }
        }
        
        return $text;
    }
    
    /**
     * Czyści tekst z artefaktów
     */
    private function cleanText($text) {
        // Usuń znaki sterujące
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', '', $text);
        // Normalizuj białe znaki
        $text = preg_replace('/[ \t]+/', ' ', $text);
        // Usuń puste linie
        $text = preg_replace('/\n\s*\n/', "\n", $text);
        return trim($text);
    }
    
    /**
     * Ekstrakcja imienia
     */
    private function extractImie() {
        $fullName = $this->extractFullName();
        if ($fullName) {
            $parts = explode(' ', $fullName);
            return $parts[0] ?? '';
        }
        return '';
    }
    
    /**
     * Ekstrakcja nazwiska
     */
    private function extractNazwisko() {
        $fullName = $this->extractFullName();
        if ($fullName) {
            $parts = explode(' ', $fullName);
            array_shift($parts); // Usuń imię
            return implode(' ', $parts);
        }
        return '';
    }
    
    /**
     * Ekstrakcja pełnego imienia i nazwiska
     */
    private function extractFullName() {
        // Wzorce dla imienia i nazwiska W JEDNEJ LINII
        $patterns = [
            // "Imię Nazwisko" na początku dokumentu
            '/^([A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]+)\s+([A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]+(?:-[A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]+)?)\s*$/um',
            // "IMIĘ NAZWISKO" (wszystkie wielkie)
            '/^([A-ZŻŹĆĄŚĘŁÓŃ]{2,})\s+([A-ZŻŹĆĄŚĘŁÓŃ]{2,}(?:-[A-ZŻŹĆĄŚĘŁÓŃ]+)?)\s*$/um',
        ];
        
        // Sprawdź pierwsze 10 linii - szukaj w jednej linii
        $checkLines = array_slice($this->lines, 0, 10);
        
        foreach ($checkLines as $line) {
            $line = trim($line);
            
            // Pomiń linie z "CV", "Curriculum", datami, emailami, telefonami
            if (preg_match('/^(CV|Curriculum|Życiorys|\d|@|\+48|tel|PODSUMOWANIE|UMIEJĘTNOŚCI|DOŚWIADCZENIE)/i', $line)) {
                continue;
            }
            
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $line, $matches)) {
                    $name = $matches[1] . ' ' . $matches[2];
                    // Konwertuj do Title Case jeśli wszystkie wielkie
                    if (mb_strtoupper($name) === $name) {
                        $name = mb_convert_case($name, MB_CASE_TITLE, 'UTF-8');
                    }
                    return $name;
                }
            }
        }
        
        // NOWE: Szukaj imienia i nazwiska w DWÓCH KOLEJNYCH LINIACH
        // Wzorzec: linia z imieniem (Title Case), następna linia z nazwiskiem (WIELKIE LITERY lub Title Case)
        for ($i = 0; $i < min(10, count($this->lines) - 1); $i++) {
            $line1 = trim($this->lines[$i]);
            $line2 = trim($this->lines[$i + 1]);
            
            // Pomiń linie z nagłówkami, emailami, telefonami
            if (preg_match('/^(CV|Curriculum|Życiorys|\d|@|\+48|tel|PODSUMOWANIE|UMIEJĘTNOŚCI|DOŚWIADCZENIE|DODATKOWE)/i', $line1)) {
                continue;
            }
            
            // Linia 1: Imię (Title Case, 2-15 znaków, same litery)
            // Linia 2: Nazwisko (WIELKIE LITERY lub Title Case, 2-20 znaków)
            if (preg_match('/^([A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]{1,14})$/u', $line1, $imieMatch) &&
                preg_match('/^([A-ZŻŹĆĄŚĘŁÓŃ]{2,20}|[A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćńółęąś]{1,19})$/u', $line2, $nazwiskoMatch)) {
                
                $imie = $imieMatch[1];
                $nazwisko = $nazwiskoMatch[1];
                
                // Konwertuj nazwisko do Title Case jeśli wszystkie wielkie
                if (mb_strtoupper($nazwisko) === $nazwisko) {
                    $nazwisko = mb_convert_case($nazwisko, MB_CASE_TITLE, 'UTF-8');
                }
                
                return $imie . ' ' . $nazwisko;
            }
        }
        
        return '';
    }
    
    /**
     * Ekstrakcja adresu email
     */
    private function extractEmail() {
        // 1. Standardowy wzorzec email (w jednej linii)
        if (preg_match('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', $this->text, $matches)) {
            return strtolower($matches[0]);
        }
        
        // 2. Usuń WSZYSTKIE białe znaki i nowe linie, potem szukaj
        $textNoSpaces = preg_replace('/\s+/', '', $this->text);
        if (preg_match('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', $textNoSpaces, $matches)) {
            return strtolower($matches[0]);
        }
        
        // 3. Szukaj części z @ i dopasuj do popularnych domen gdziekolwiek w tekście
        $popularDomains = ['gmail.com', 'wp.pl', 'o2.pl', 'onet.pl', 'interia.pl', 'op.pl', 'tlen.pl', 
                          'yahoo.com', 'outlook.com', 'hotmail.com', 'icloud.com', 'protonmail.com',
                          'mail.com', 'gmx.com', 'aol.com', 'live.com', 'me.com'];
        
        // Znajdź część przed @ (np. "esterabartoszek71@")
        if (preg_match('/([a-zA-Z0-9._%+-]+)@/', $this->text, $localMatch)) {
            $localPart = $localMatch[1];
            
            // Szukaj popularnych domen w całym tekście
            foreach ($popularDomains as $domain) {
                if (stripos($this->text, $domain) !== false) {
                    return strtolower($localPart . '@' . $domain);
                }
            }
            
            // Szukaj dowolnej domeny w tekście (pattern: słowo.2-4litery)
            if (preg_match('/\b([a-zA-Z0-9-]+\.[a-zA-Z]{2,4})\b/', $this->text, $domainMatch)) {
                // Upewnij się że to nie jest np. "sp.z" z "sp. z o.o."
                $potentialDomain = $domainMatch[1];
                if (!preg_match('/^(sp|ul|os|al|pl|nr)\./i', $potentialDomain)) {
                    return strtolower($localPart . '@' . $potentialDomain);
                }
            }
        }
        
        return '';
    }
    
    /**
     * Ekstrakcja numeru telefonu
     */
    private function extractTelefon() {
        $patterns = [
            // +48 123 456 789
            '/\+48\s*\d{3}\s*\d{3}\s*\d{3}/',
            // 123-456-789 lub 123 456 789
            '/(?<!\d)\d{3}[\s-]?\d{3}[\s-]?\d{3}(?!\d)/',
            // 12 345 67 89
            '/(?<!\d)\d{2}\s?\d{3}\s?\d{2}\s?\d{2}(?!\d)/',
            // 123456789 (9 cyfr)
            '/(?<!\d)\d{9}(?!\d)/',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $this->text, $matches)) {
                // Normalizuj format
                $phone = preg_replace('/[^\d+]/', '', $matches[0]);
                // Formatuj ładnie
                if (strlen($phone) === 9) {
                    return substr($phone, 0, 3) . ' ' . substr($phone, 3, 3) . ' ' . substr($phone, 6, 3);
                }
                return $matches[0];
            }
        }
        return '';
    }
    
    /**
     * Ekstrakcja daty urodzenia
     */
    private function extractDataUrodzenia() {
        $patterns = [
            // "Data urodzenia: 01.02.1990" lub podobne
            '/(?:data\s*urodzenia|urodzony|ur\.?)\s*:?\s*(\d{1,2}[\.\-\/]\d{1,2}[\.\-\/]\d{4})/iu',
            '/(?:data\s*urodzenia|urodzony|ur\.?)\s*:?\s*(\d{4}[\.\-\/]\d{1,2}[\.\-\/]\d{1,2})/iu',
            // Data w kontekście (po "urodzenia")
            '/urodzeni[aey]?\s*:?\s*(\d{1,2}[\.\-\/]\d{1,2}[\.\-\/]\d{4})/iu',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $this->text, $matches)) {
                return $this->normalizeDate($matches[1]);
            }
        }
        
        return '';
    }
    
    /**
     * Normalizacja daty do formatu YYYY-MM-DD
     */
    private function normalizeDate($dateStr) {
        // Zamień separatory na kropki
        $dateStr = preg_replace('/[\-\/]/', '.', $dateStr);
        
        // DD.MM.YYYY
        if (preg_match('/^(\d{1,2})\.(\d{1,2})\.(\d{4})$/', $dateStr, $m)) {
            return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
        }
        
        // YYYY.MM.DD
        if (preg_match('/^(\d{4})\.(\d{1,2})\.(\d{1,2})$/', $dateStr, $m)) {
            return sprintf('%04d-%02d-%02d', $m[1], $m[2], $m[3]);
        }
        
        return '';
    }
    
    /**
     * Ekstrakcja miejscowości
     */
    private function extractMiejscowosc() {
        // 1. NAJWYŻSZY PRIORYTET: Jawne "Miejscowość: X" lub "Miasto: X"
        if (preg_match('/(?:miejscowo[śs][ćc]|miasto)\s*:\s*([A-ZŻŹĆĄŚĘŁÓŃa-zżźćąśęłóń]+)/iu', $this->text, $matches)) {
            $city = trim($matches[1]);
            if (!empty($city) && !preg_match('/^(ul|ulica|os|osiedle|al|aleja)/i', $city)) {
                return $city;
            }
        }
        
        // 2. Kod pocztowy XX-XXX + miasto (MUSI mieć myślnik żeby nie łapać dat!)
        if (preg_match('/\b(\d{2}-\d{3})\s+([A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćąśęłóń]+)/u', $this->text, $matches)) {
            $city = trim($matches[2]);
            if (!preg_match('/^(ul|ulica|os|osiedle|al|aleja)/i', $city)) {
                return $city;
            }
        }
        
        // 3. Szukaj linii z kodem pocztowym (z myślnikiem) i weź miasto
        foreach ($this->lines as $i => $line) {
            if (preg_match('/\b(\d{2}-\d{3})\s*(.*)/', $line, $m)) {
                $afterCode = trim($m[2]);
                if (!empty($afterCode) && preg_match('/^([A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćąśęłóń]+)/u', $afterCode, $cityMatch)) {
                    return $cityMatch[1];
                }
                // Miasto w następnej linii
                if (isset($this->lines[$i + 1])) {
                    $nextLine = trim($this->lines[$i + 1]);
                    if (preg_match('/^([A-ZŻŹĆĄŚĘŁÓŃ][a-zżźćąśęłóń]+)/u', $nextLine, $cityMatch)) {
                        $city = $cityMatch[1];
                        if (!preg_match('/^(ul|ulica|os|osiedle|al|aleja|Umiejętności|Doświadczenie|Wykształcenie|Od|Do)/i', $city)) {
                            return $city;
                        }
                    }
                }
            }
        }
        
        return '';
    }
    
    /**
     * Ekstrakcja kategorii prawa jazdy
     */
    private function extractPrawoJazdy() {
        $categories = [];
        
        // Wzorce dla prawa jazdy
        $patterns = [
            '/prawo\s*jazdy[:\s]+(?:kat\.?\s*)?([A-Z0-9,\s\+]+)/iu',
            '/(?:kat(?:egori[ae])?|kategori[ae])\s*:?\s*([A-Z][0-9]?(?:[,\s\+]+[A-Z][0-9]?)*)/iu',
            '/(?:prawo\s*jazdy|kierowca)[^.]*\b(B|C|D|E|A[12]?|BE|CE|DE|C1|D1|C1E|D1E|T)\b/iu',
        ];
        
        $validCategories = ['AM', 'A1', 'A2', 'A', 'B1', 'B', 'C1', 'C', 'D1', 'D', 'BE', 'C1E', 'CE', 'D1E', 'DE', 'T'];
        
        foreach ($patterns as $pattern) {
            if (preg_match_all($pattern, $this->text, $matches)) {
                foreach ($matches[1] as $match) {
                    // Wyciągnij poszczególne kategorie
                    preg_match_all('/\b([A-Z][0-9]?E?)\b/i', $match, $cats);
                    foreach ($cats[1] as $cat) {
                        $cat = strtoupper($cat);
                        if (in_array($cat, $validCategories) && !in_array($cat, $categories)) {
                            $categories[] = $cat;
                        }
                    }
                }
            }
        }
        
        // Sprawdź też sam tekst
        foreach ($validCategories as $cat) {
            if (preg_match('/\bkat(?:egori[ae])?\s*\.?\s*' . preg_quote($cat) . '\b/i', $this->text)) {
                if (!in_array($cat, $categories)) {
                    $categories[] = $cat;
                }
            }
        }
        
        // Sortuj w logicznej kolejności
        usort($categories, function($a, $b) use ($validCategories) {
            return array_search($a, $validCategories) - array_search($b, $validCategories);
        });
        
        return implode(', ', $categories);
    }
    
    /**
     * Sprawdzenie uprawnień na wózki widłowe
     */
    private function extractWozkiWidlowe() {
        $patterns = [
            '/w[óo]z[eków]+\s*(widłow|jezdniow|podnośnik)/iu',
            '/uprawnienia\s*(?:na|do)?\s*w[óo]zk/iu',
            '/operator\s*w[óo]zk/iu',
            '/WJO/u',
            '/UDT.*w[óo]z/iu',
            '/forklift/i',
            '/reach\s*truck/i',
            '/heftruck/i',
        ];
        
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $this->text)) {
                return 1;
            }
        }
        
        return 0;
    }
    
    /**
     * Zwróć surowy tekst
     */
    public function getRawText() {
        return $this->text;
    }
}
