<?php
/**
 * Moduł Kandydatów - Zarządzanie ogłoszeniami rekrutacyjnymi
 * 
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$statusy = getOgloszeniaStatusy();
$typyUmowy = getTypyUmowy();
$wymiaryPracy = getWymiaryPracy();

$message = '';
$error = '';

// Obsługa formularza
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Dodawanie/edycja ogłoszenia
    if ($action === 'save') {
        $id = intval($_POST['id'] ?? 0);
        $data = [
            'tytul' => trim($_POST['tytul'] ?? ''),
            'stanowisko' => trim($_POST['stanowisko'] ?? ''),
            'lokalizacja' => trim($_POST['lokalizacja'] ?? ''),
            'opis' => trim($_POST['opis'] ?? ''),
            'wymagania' => trim($_POST['wymagania'] ?? ''),
            'oferujemy' => trim($_POST['oferujemy'] ?? ''),
            'wynagrodzenie_od' => floatval($_POST['wynagrodzenie_od'] ?? 0) ?: null,
            'wynagrodzenie_do' => floatval($_POST['wynagrodzenie_do'] ?? 0) ?: null,
            'typ_umowy' => $_POST['typ_umowy'] ?? '',
            'wymiar_pracy' => $_POST['wymiar_pracy'] ?? '',
            'status' => $_POST['status'] ?? 'aktywne',
            'data_publikacji' => $_POST['data_publikacji'] ?: date('Y-m-d'),
            'data_waznosci' => $_POST['data_waznosci'] ?: null
        ];
        
        if (empty($data['tytul'])) {
            $error = 'Tytuł ogłoszenia jest wymagany';
        } else {
            if ($id > 0) {
                // Aktualizacja
                $stmt = $db->prepare("UPDATE ogloszenia SET 
                    tytul = ?, stanowisko = ?, lokalizacja = ?, opis = ?, wymagania = ?, oferujemy = ?,
                    wynagrodzenie_od = ?, wynagrodzenie_do = ?, typ_umowy = ?, wymiar_pracy = ?,
                    status = ?, data_publikacji = ?, data_waznosci = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?");
                $stmt->execute([
                    $data['tytul'], $data['stanowisko'], $data['lokalizacja'], $data['opis'],
                    $data['wymagania'], $data['oferujemy'], $data['wynagrodzenie_od'], $data['wynagrodzenie_do'],
                    $data['typ_umowy'], $data['wymiar_pracy'], $data['status'], $data['data_publikacji'],
                    $data['data_waznosci'], $id
                ]);
                $message = 'Ogłoszenie zostało zaktualizowane';
            } else {
                // Dodawanie
                $stmt = $db->prepare("INSERT INTO ogloszenia 
                    (tytul, stanowisko, lokalizacja, opis, wymagania, oferujemy, wynagrodzenie_od, wynagrodzenie_do,
                     typ_umowy, wymiar_pracy, status, data_publikacji, data_waznosci, created_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $data['tytul'], $data['stanowisko'], $data['lokalizacja'], $data['opis'],
                    $data['wymagania'], $data['oferujemy'], $data['wynagrodzenie_od'], $data['wynagrodzenie_do'],
                    $data['typ_umowy'], $data['wymiar_pracy'], $data['status'], $data['data_publikacji'],
                    $data['data_waznosci'], $currentUser['id']
                ]);
                $message = 'Ogłoszenie zostało dodane';
            }
            
            header("Location: ogloszenia.php?msg=" . urlencode($message));
            exit;
        }
    }
    
    // Usuwanie ogłoszenia
    if ($action === 'delete' && canDelete()) {
        $id = intval($_POST['id'] ?? 0);
        
        // Sprawdź czy są kandydaci przypisani
        $stmt = $db->prepare("SELECT COUNT(*) FROM kandydaci WHERE ogloszenie_id = ?");
        $stmt->execute([$id]);
        $count = $stmt->fetchColumn();
        
        if ($count > 0) {
            $error = "Nie można usunąć ogłoszenia - ma przypisanych $count kandydatów. Najpierw zmień ich ogłoszenie.";
        } else {
            $db->prepare("DELETE FROM ogloszenia WHERE id = ?")->execute([$id]);
            header("Location: ogloszenia.php?msg=" . urlencode('Ogłoszenie zostało usunięte'));
            exit;
        }
    }
    
    // Zmiana statusu
    if ($action === 'change_status') {
        $id = intval($_POST['id'] ?? 0);
        $newStatus = $_POST['new_status'] ?? '';
        
        if ($id && array_key_exists($newStatus, $statusy)) {
            $db->prepare("UPDATE ogloszenia SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
               ->execute([$newStatus, $id]);
        }
        
        header("Location: ogloszenia.php");
        exit;
    }
}

// Parametry filtrowania
$filter_status = $_GET['status'] ?? '';
$search = $_GET['search'] ?? '';

// Budowanie zapytania
$where = [];
$params = [];

if ($filter_status) {
    $where[] = "o.status = ?";
    $params[] = $filter_status;
}

if ($search) {
    $where[] = "(o.tytul LIKE ? OR o.stanowisko LIKE ? OR o.lokalizacja LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Pobierz ogłoszenia z liczbą kandydatów
$sql = "SELECT o.*, u.name as created_by_name,
        (SELECT COUNT(*) FROM kandydaci k WHERE k.ogloszenie_id = o.id) as liczba_kandydatow
        FROM ogloszenia o
        LEFT JOIN users u ON o.created_by = u.id
        $whereClause
        ORDER BY o.status = 'aktywne' DESC, o.created_at DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$ogloszenia = $stmt->fetchAll();

// Edytowane ogłoszenie (jeśli edycja)
$editOgloszenie = null;
if (isset($_GET['edit'])) {
    $stmt = $db->prepare("SELECT * FROM ogloszenia WHERE id = ?");
    $stmt->execute([intval($_GET['edit'])]);
    $editOgloszenie = $stmt->fetch();
}

// Komunikat z parametru
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ogłoszenia rekrutacyjne - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .kandydaci-nav { background: #7c3aed; padding: 10px 20px; margin: -20px -20px 20px -20px; display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        .kandydaci-nav a { color: rgba(255,255,255,0.85); text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.95rem; }
        .kandydaci-nav a:hover, .kandydaci-nav a.active { background: rgba(255,255,255,0.15); color: white; }
        .kandydaci-nav .nav-title { color: white; font-weight: 600; margin-right: 20px; }
        
        .stats-bar { display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap; }
        .stat-card { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); flex: 1; min-width: 150px; }
        .stat-card .value { font-size: 2rem; font-weight: 700; color: #1e40af; }
        .stat-card .label { color: #64748b; font-size: 0.9rem; }
        
        .filters { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 25px; }
        .filters-row { display: flex; gap: 15px; flex-wrap: wrap; align-items: center; }
        
        .og-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 20px; }
        .og-card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; }
        .og-card-header { padding: 20px; border-bottom: 1px solid #e2e8f0; }
        .og-card-header h3 { margin: 0 0 8px 0; font-size: 1.1rem; }
        .og-card-body { padding: 20px; }
        .og-card-footer { padding: 15px 20px; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; }
        
        .og-meta { display: flex; gap: 15px; flex-wrap: wrap; font-size: 0.85rem; color: #64748b; }
        .og-meta span { display: flex; align-items: center; gap: 5px; }
        
        .badge { display: inline-block; padding: 4px 12px; border-radius: 50px; font-size: 0.8rem; font-weight: 600; }
        
        .form-card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); margin-bottom: 25px; }
        .form-card-header { padding: 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
        .form-card-body { padding: 25px; }
        
        .form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px; }
        .form-group { margin-bottom: 0; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; color: #374151; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px 12px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 0.95rem; }
        .form-group textarea { min-height: 100px; resize: vertical; }
        
        .alert { padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; }
        .alert-error { background: #fee2e2; color: #dc2626; }
        
        .btn-row { display: flex; gap: 10px; justify-content: flex-end; margin-top: 20px; }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container">
        <nav class="kandydaci-nav">
            <span class="nav-title">👥 Rekrutacja</span>
            <a href="index.php">Lista kandydatów</a>
            <a href="dodaj.php">➕ Dodaj kandydata</a>
            <a href="ogloszenia.php" class="active">📢 Ogłoszenia</a>
            <a href="raport.php">📊 Raport</a>
        </nav>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- Formularz dodawania/edycji -->
        <div class="form-card" id="form-section">
            <div class="form-card-header">
                <h2><?= $editOgloszenie ? '✏️ Edytuj ogłoszenie' : '➕ Dodaj nowe ogłoszenie' ?></h2>
                <?php if ($editOgloszenie): ?>
                    <a href="ogloszenia.php" class="btn">✖️ Anuluj edycję</a>
                <?php endif; ?>
            </div>
            <div class="form-card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="id" value="<?= $editOgloszenie['id'] ?? '' ?>">
                    
                    <div class="form-row">
                        <div class="form-group" style="grid-column: span 2;">
                            <label for="tytul">Tytuł ogłoszenia *</label>
                            <input type="text" id="tytul" name="tytul" value="<?= htmlspecialchars($editOgloszenie['tytul'] ?? '') ?>" required placeholder="np. Pracownik produkcji - operator maszyn">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="stanowisko">Stanowisko</label>
                            <input type="text" id="stanowisko" name="stanowisko" value="<?= htmlspecialchars($editOgloszenie['stanowisko'] ?? '') ?>" placeholder="np. Operator CNC">
                        </div>
                        <div class="form-group">
                            <label for="lokalizacja">Lokalizacja</label>
                            <input type="text" id="lokalizacja" name="lokalizacja" value="<?= htmlspecialchars($editOgloszenie['lokalizacja'] ?? '') ?>" placeholder="np. Poznań, Wielkopolskie">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="typ_umowy">Typ umowy</label>
                            <select id="typ_umowy" name="typ_umowy">
                                <option value="">-- wybierz --</option>
                                <?php foreach ($typyUmowy as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($editOgloszenie['typ_umowy'] ?? '') === $key ? 'selected' : '' ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="wymiar_pracy">Wymiar pracy</label>
                            <select id="wymiar_pracy" name="wymiar_pracy">
                                <option value="">-- wybierz --</option>
                                <?php foreach ($wymiaryPracy as $key => $label): ?>
                                    <option value="<?= $key ?>" <?= ($editOgloszenie['wymiar_pracy'] ?? '') === $key ? 'selected' : '' ?>><?= $label ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="wynagrodzenie_od">Wynagrodzenie od (zł)</label>
                            <input type="number" id="wynagrodzenie_od" name="wynagrodzenie_od" step="100" value="<?= $editOgloszenie['wynagrodzenie_od'] ?? '' ?>" placeholder="np. 4500">
                        </div>
                        <div class="form-group">
                            <label for="wynagrodzenie_do">Wynagrodzenie do (zł)</label>
                            <input type="number" id="wynagrodzenie_do" name="wynagrodzenie_do" step="100" value="<?= $editOgloszenie['wynagrodzenie_do'] ?? '' ?>" placeholder="np. 6000">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="data_publikacji">Data publikacji</label>
                            <input type="date" id="data_publikacji" name="data_publikacji" value="<?= $editOgloszenie['data_publikacji'] ?? date('Y-m-d') ?>">
                        </div>
                        <div class="form-group">
                            <label for="data_waznosci">Ważne do</label>
                            <input type="date" id="data_waznosci" name="data_waznosci" value="<?= $editOgloszenie['data_waznosci'] ?? '' ?>">
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status">
                                <?php foreach ($statusy as $key => $info): ?>
                                    <option value="<?= $key ?>" <?= ($editOgloszenie['status'] ?? 'aktywne') === $key ? 'selected' : '' ?>><?= $info['icon'] ?> <?= $info['label'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="opis">Opis stanowiska</label>
                        <textarea id="opis" name="opis" placeholder="Opisz zakres obowiązków..."><?= htmlspecialchars($editOgloszenie['opis'] ?? '') ?></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="wymagania">Wymagania</label>
                            <textarea id="wymagania" name="wymagania" placeholder="Lista wymagań..."><?= htmlspecialchars($editOgloszenie['wymagania'] ?? '') ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="oferujemy">Oferujemy</label>
                            <textarea id="oferujemy" name="oferujemy" placeholder="Co oferujecie kandydatom..."><?= htmlspecialchars($editOgloszenie['oferujemy'] ?? '') ?></textarea>
                        </div>
                    </div>
                    
                    <div class="btn-row">
                        <button type="submit" class="btn btn-primary">💾 <?= $editOgloszenie ? 'Zapisz zmiany' : 'Dodaj ogłoszenie' ?></button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Filtry -->
        <div class="filters">
            <form method="GET" class="filters-row">
                <div class="form-group" style="margin: 0;">
                    <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="🔍 Szukaj ogłoszenia...">
                </div>
                <div class="form-group" style="margin: 0;">
                    <select name="status">
                        <option value="">Wszystkie statusy</option>
                        <?php foreach ($statusy as $key => $info): ?>
                            <option value="<?= $key ?>" <?= $filter_status === $key ? 'selected' : '' ?>><?= $info['icon'] ?> <?= $info['label'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="btn">Filtruj</button>
                <?php if ($search || $filter_status): ?>
                    <a href="ogloszenia.php" class="btn">Wyczyść</a>
                <?php endif; ?>
            </form>
        </div>
        
        <!-- Statystyki -->
        <div class="stats-bar">
            <div class="stat-card">
                <div class="value"><?= count(array_filter($ogloszenia, fn($o) => $o['status'] === 'aktywne')) ?></div>
                <div class="label">Aktywnych ogłoszeń</div>
            </div>
            <div class="stat-card">
                <div class="value"><?= array_sum(array_column($ogloszenia, 'liczba_kandydatow')) ?></div>
                <div class="label">Łącznie kandydatów</div>
            </div>
            <div class="stat-card">
                <div class="value"><?= count($ogloszenia) ?></div>
                <div class="label">Wszystkich ogłoszeń</div>
            </div>
        </div>
        
        <!-- Lista ogłoszeń -->
        <?php if (empty($ogloszenia)): ?>
            <div style="text-align: center; padding: 60px; color: #64748b;">
                <p style="font-size: 3rem; margin-bottom: 10px;">📢</p>
                <p>Brak ogłoszeń. Dodaj pierwsze ogłoszenie powyżej!</p>
            </div>
        <?php else: ?>
            <div class="og-grid">
                <?php foreach ($ogloszenia as $og): 
                    $statusInfo = $statusy[$og['status']] ?? $statusy['aktywne'];
                    $typUmowyLabel = $typyUmowy[$og['typ_umowy']] ?? '';
                    $wymiarLabel = $wymiaryPracy[$og['wymiar_pracy']] ?? '';
                ?>
                    <div class="og-card">
                        <div class="og-card-header">
                            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px;">
                                <h3><?= htmlspecialchars($og['tytul']) ?></h3>
                                <span class="badge" style="background: <?= $statusInfo['bg'] ?>; color: <?= $statusInfo['color'] ?>; flex-shrink: 0;">
                                    <?= $statusInfo['icon'] ?> <?= $statusInfo['label'] ?>
                                </span>
                            </div>
                            <?php if ($og['stanowisko']): ?>
                                <div style="color: #64748b; font-size: 0.9rem;"><?= htmlspecialchars($og['stanowisko']) ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="og-card-body">
                            <div class="og-meta">
                                <?php if ($og['lokalizacja']): ?>
                                    <span>📍 <?= htmlspecialchars($og['lokalizacja']) ?></span>
                                <?php endif; ?>
                                <?php if ($typUmowyLabel): ?>
                                    <span>📋 <?= $typUmowyLabel ?></span>
                                <?php endif; ?>
                                <?php if ($wymiarLabel): ?>
                                    <span>⏰ <?= $wymiarLabel ?></span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($og['wynagrodzenie_od'] || $og['wynagrodzenie_do']): ?>
                                <div style="margin-top: 15px; font-size: 1.1rem; font-weight: 600; color: #16a34a;">
                                    💰 <?= $og['wynagrodzenie_od'] ? number_format($og['wynagrodzenie_od'], 0, ',', ' ') : '?' ?> - <?= $og['wynagrodzenie_do'] ? number_format($og['wynagrodzenie_do'], 0, ',', ' ') : '?' ?> zł
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($og['opis']): ?>
                                <p style="margin-top: 15px; color: #64748b; font-size: 0.9rem; line-height: 1.5;">
                                    <?= htmlspecialchars(mb_substr($og['opis'], 0, 150)) ?><?= mb_strlen($og['opis']) > 150 ? '...' : '' ?>
                                </p>
                            <?php endif; ?>
                            
                            <div style="margin-top: 15px; display: flex; gap: 15px; font-size: 0.85rem; color: #64748b;">
                                <span>👥 <strong><?= $og['liczba_kandydatow'] ?></strong> kandydatów</span>
                                <?php if ($og['data_waznosci']): ?>
                                    <span>📅 Ważne do: <?= date('d.m.Y', strtotime($og['data_waznosci'])) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="og-card-footer">
                            <small style="color: #94a3b8;">
                                Dodano: <?= date('d.m.Y', strtotime($og['created_at'])) ?>
                                <?php if ($og['created_by_name']): ?> przez <?= htmlspecialchars($og['created_by_name']) ?><?php endif; ?>
                            </small>
                            <div style="display: flex; gap: 8px;">
                                <a href="index.php?ogloszenie=<?= $og['id'] ?>" class="btn btn-small" title="Zobacz kandydatów">👥</a>
                                <a href="ogloszenia.php?edit=<?= $og['id'] ?>#form-section" class="btn btn-small" title="Edytuj">✏️</a>
                                <?php if (canDelete()): ?>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Usunąć to ogłoszenie?')">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $og['id'] ?>">
                                        <button type="submit" class="btn btn-small btn-danger" title="Usuń">🗑️</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
