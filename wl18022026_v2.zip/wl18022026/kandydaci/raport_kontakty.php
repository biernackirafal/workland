<?php
/**
 * Moduł Kandydatów - Raport kontaktów (rozszerzony)
 * System Ewidencji Pracowników - Work Land
 * 
 * Łączy dane z dwóch źródeł:
 * 1. Zmiany statusów kandydatów (kandydaci_historia)
 * 2. Zadania/kontakty (kandydaci_zadania)
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$zadaniaTypy = getKandydatZadaniaTypy();
$zadaniaStatusy = getKandydatZadaniaStatusy();
$kandydatStatusy = getKandydatStatusy();

// Pobierz użytkowników
$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();

// Filtry
$dataOd = $_GET['data_od'] ?? date('Y-m-01');
$dataDo = $_GET['data_do'] ?? date('Y-m-d');
$rekruter = $_GET['rekruter'] ?? '';
$typKontaktu = $_GET['typ_kontaktu'] ?? ''; // all, zadania, statusy
$grupowanie = $_GET['grupowanie'] ?? 'dzien';

// Pobierz zmiany statusów z historii
$historiaWhere = ["DATE(h.created_at) BETWEEN ? AND ?", "h.pole = 'status'"];
$historiaParams = [$dataOd, $dataDo];

if ($rekruter) {
    $historiaWhere[] = "h.user_id = ?";
    $historiaParams[] = $rekruter;
}

$historiaWhereClause = implode(' AND ', $historiaWhere);

$historiaStmt = $db->prepare("
    SELECT 
        'status_change' as typ_wpisu,
        h.id,
        h.kandydat_id,
        k.imie, k.nazwisko, k.telefon, k.email, k.miejscowosc,
        DATE(h.created_at) as data_kontaktu,
        TIME(h.created_at) as godzina_kontaktu,
        h.stara_wartosc,
        h.nowa_wartosc,
        h.user_name as rekruter_nazwa,
        h.user_id,
        o.tytul as ogloszenie_tytul,
        NULL as zadanie_typ,
        NULL as zadanie_tytul,
        NULL as zadanie_status,
        NULL as zadanie_wynik
    FROM kandydaci_historia h
    JOIN kandydaci k ON h.kandydat_id = k.id
    LEFT JOIN ogloszenia o ON k.ogloszenie_id = o.id
    WHERE $historiaWhereClause
");
$historiaStmt->execute($historiaParams);
$zmianySatusow = $historiaStmt->fetchAll();

// Pobierz zadania/kontakty
$zadaniaWhere = ["z.termin_data BETWEEN ? AND ?"];
$zadaniaParams = [$dataOd, $dataDo];

if ($rekruter) {
    $zadaniaWhere[] = "z.przypisany_do = ?";
    $zadaniaParams[] = $rekruter;
}

$zadaniaWhereClause = implode(' AND ', $zadaniaWhere);

$zadaniaStmt = $db->prepare("
    SELECT 
        'zadanie' as typ_wpisu,
        z.id,
        z.kandydat_id,
        k.imie, k.nazwisko, k.telefon, k.email, k.miejscowosc,
        z.termin_data as data_kontaktu,
        z.termin_godzina as godzina_kontaktu,
        NULL as stara_wartosc,
        NULL as nowa_wartosc,
        u.name as rekruter_nazwa,
        z.przypisany_do as user_id,
        o.tytul as ogloszenie_tytul,
        z.typ as zadanie_typ,
        z.tytul as zadanie_tytul,
        z.status as zadanie_status,
        z.wynik as zadanie_wynik
    FROM kandydaci_zadania z
    JOIN kandydaci k ON z.kandydat_id = k.id
    LEFT JOIN users u ON z.przypisany_do = u.id
    LEFT JOIN ogloszenia o ON k.ogloszenie_id = o.id
    WHERE $zadaniaWhereClause
");
$zadaniaStmt->execute($zadaniaParams);
$zadania = $zadaniaStmt->fetchAll();

// Łącz dane według filtra
$kontakty = [];
if ($typKontaktu === '' || $typKontaktu === 'all' || $typKontaktu === 'statusy') {
    $kontakty = array_merge($kontakty, $zmianySatusow);
}
if ($typKontaktu === '' || $typKontaktu === 'all' || $typKontaktu === 'zadania') {
    $kontakty = array_merge($kontakty, $zadania);
}

// Sortuj według daty
usort($kontakty, function($a, $b) {
    $dateA = $a['data_kontaktu'] . ' ' . ($a['godzina_kontaktu'] ?? '00:00:00');
    $dateB = $b['data_kontaktu'] . ' ' . ($b['godzina_kontaktu'] ?? '00:00:00');
    return strcmp($dateB, $dateA); // DESC
});

// Statystyki
$statsZadania = $db->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN z.status = 'wykonane' THEN 1 ELSE 0 END) as wykonane,
        SUM(CASE WHEN z.status = 'nieodbiera' THEN 1 ELSE 0 END) as nieodbiera,
        SUM(CASE WHEN z.status = 'oddzwoni' THEN 1 ELSE 0 END) as oddzwoni,
        SUM(CASE WHEN z.status = 'zaplanowane' THEN 1 ELSE 0 END) as zaplanowane
    FROM kandydaci_zadania z
    WHERE z.termin_data BETWEEN ? AND ?
");
$statsZadania->execute([$dataOd, $dataDo]);
$statsZ = $statsZadania->fetch();

$statsHistoria = $db->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN nowa_wartosc = 'w_kontakcie' THEN 1 ELSE 0 END) as w_kontakcie,
        SUM(CASE WHEN nowa_wartosc = 'rozmowa' THEN 1 ELSE 0 END) as rozmowa,
        SUM(CASE WHEN nowa_wartosc = 'oferta' THEN 1 ELSE 0 END) as oferta,
        SUM(CASE WHEN nowa_wartosc = 'zatrudniony' THEN 1 ELSE 0 END) as zatrudniony,
        SUM(CASE WHEN nowa_wartosc = 'odrzucony' THEN 1 ELSE 0 END) as odrzucony
    FROM kandydaci_historia
    WHERE DATE(created_at) BETWEEN ? AND ? AND pole = 'status'
");
$statsHistoria->execute([$dataOd, $dataDo]);
$statsH = $statsHistoria->fetch();

// Grupowanie danych
$grouped = [];
foreach ($kontakty as $k) {
    if ($grupowanie === 'dzien') {
        $key = $k['data_kontaktu'];
    } elseif ($grupowanie === 'rekruter') {
        $key = $k['rekruter_nazwa'] ?? 'Nieprzypisane';
    } else {
        $key = $k['kandydat_id'];
    }
    $grouped[$key][] = $k;
}

// Export CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="raport_kontaktow_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    fputcsv($output, ['Data', 'Godzina', 'Typ wpisu', 'Kandydat', 'Telefon', 'Email', 'Miejscowość', 'Ogłoszenie', 'Szczegóły', 'Rekruter'], ';');
    
    foreach ($kontakty as $k) {
        if ($k['typ_wpisu'] === 'status_change') {
            $staraWartosc = $kandydatStatusy[$k['stara_wartosc']]['label'] ?? $k['stara_wartosc'];
            $nowaWartosc = $kandydatStatusy[$k['nowa_wartosc']]['label'] ?? $k['nowa_wartosc'];
            $szczegoly = "Zmiana statusu: $staraWartosc → $nowaWartosc";
            $typWpisu = 'Zmiana statusu';
        } else {
            $typInfo = $zadaniaTypy[$k['zadanie_typ']] ?? ['label' => $k['zadanie_typ']];
            $statusInfo = $zadaniaStatusy[$k['zadanie_status']] ?? ['label' => $k['zadanie_status']];
            $szczegoly = $typInfo['label'] . ': ' . $k['zadanie_tytul'] . ' (' . $statusInfo['label'] . ')';
            if ($k['zadanie_wynik']) $szczegoly .= ' - ' . $k['zadanie_wynik'];
            $typWpisu = 'Zadanie';
        }
        
        fputcsv($output, [
            date('d.m.Y', strtotime($k['data_kontaktu'])),
            $k['godzina_kontaktu'] ? substr($k['godzina_kontaktu'], 0, 5) : '',
            $typWpisu,
            $k['imie'] . ' ' . $k['nazwisko'],
            $k['telefon'],
            $k['email'],
            $k['miejscowosc'],
            $k['ogloszenie_tytul'],
            $szczegoly,
            $k['rekruter_nazwa']
        ], ';');
    }
    
    fclose($output);
    exit;
}

$printMode = isset($_GET['print']);
$hasFilters = $rekruter || $typKontaktu;
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raport kontaktów <?= $printMode ? '- Druk' : '' ?> - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #7c3aed; color: white; }
        
        header { margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        .subtitle { color: #64748b; margin: 0; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 20px; }
        
        .filters-card { background: white; padding: 18px 22px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); }
        .filters-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.8rem; color: #64748b; font-weight: 600; }
        .filter-group select, .filter-group input { padding: 10px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; min-width: 140px; }
        
        .btn { padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-secondary { background: #f1f5f9; color: #374151; }
        
        .stats-bar { display: flex; gap: 15px; flex-wrap: wrap; margin-bottom: 25px; }
        .stat-box { background: white; padding: 18px; border-radius: 10px; min-width: 110px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); text-align: center; }
        .stat-box .value { font-size: 1.8rem; font-weight: 700; }
        .stat-box .label { font-size: 0.8rem; color: #64748b; margin-top: 5px; }
        
        .day-section { margin-bottom: 25px; }
        .day-header { background: #1e293b; color: white; padding: 12px 20px; border-radius: 8px 8px 0 0; font-weight: 600; display: flex; justify-content: space-between; align-items: center; }
        .day-header .count { background: rgba(255,255,255,0.2); padding: 4px 12px; border-radius: 20px; font-size: 0.85rem; }
        
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; padding: 12px 15px; background: #f8fafc; color: #64748b; font-size: 0.8rem; font-weight: 600; text-transform: uppercase; }
        td { padding: 12px 15px; border-bottom: 1px solid #f1f5f9; }
        tr:hover { background: #f8fafc; }
        
        .badge { display: inline-block; padding: 4px 10px; border-radius: 6px; font-size: 0.75rem; font-weight: 600; }
        
        .contact-info { font-size: 0.85rem; }
        .contact-info a { color: #2563eb; text-decoration: none; }
        
        .wynik-text { max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 0.85rem; color: #64748b; }
        
        @media print {
            body { background: white !important; }
            .top-nav, .filters-card, .no-print { display: none !important; }
            .container { max-width: 100%; padding: 10px; }
            .card { box-shadow: none; border: 1px solid #ddd; page-break-inside: avoid; }
            .day-section { page-break-inside: avoid; }
            .stat-box { box-shadow: none; border: 1px solid #ddd; }
            header h1 { font-size: 1.4rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!$printMode): ?>
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../crm/">🎯 CRM</a>
                <a href="./">👥 Kandydaci</a>
                <a href="ogloszenia.php">📢 Ogłoszenia</a>
                <a href="raport.php">📊 Statystyki</a>
                <a href="raport_kontakty.php" class="active">📞 Kontakty</a>
                <a href="raport_kandydaci.php">📋 Lista</a>
            </div>
        </nav>
        <?php endif; ?>
        
        <header>
            <div>
                <h1>📞 Raport kontaktów</h1>
                <p class="subtitle">Okres: <?= date('d.m.Y', strtotime($dataOd)) ?> - <?= date('d.m.Y', strtotime($dataDo)) ?></p>
            </div>
            <div class="header-actions no-print" style="display: flex; gap: 10px;">
                <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="btn btn-success">📥 Eksport CSV</a>
                <button onclick="window.print()" class="btn btn-secondary">🖨️ Drukuj</button>
            </div>
        </header>
        
        <?php if (!$printMode): ?>
        <div class="filters-card no-print">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group">
                        <label>Od daty</label>
                        <input type="date" name="data_od" value="<?= $dataOd ?>">
                    </div>
                    <div class="filter-group">
                        <label>Do daty</label>
                        <input type="date" name="data_do" value="<?= $dataDo ?>">
                    </div>
                    <div class="filter-group">
                        <label>Rekruter</label>
                        <select name="rekruter">
                            <option value="">-- wszyscy --</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?= $u['id'] ?>" <?= $rekruter == $u['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Typ wpisu</label>
                        <select name="typ_kontaktu">
                            <option value="" <?= $typKontaktu === '' ? 'selected' : '' ?>>📋 Wszystkie</option>
                            <option value="statusy" <?= $typKontaktu === 'statusy' ? 'selected' : '' ?>>🔄 Tylko zmiany statusów</option>
                            <option value="zadania" <?= $typKontaktu === 'zadania' ? 'selected' : '' ?>>📞 Tylko zadania/telefony</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Grupowanie</label>
                        <select name="grupowanie">
                            <option value="dzien" <?= $grupowanie === 'dzien' ? 'selected' : '' ?>>📅 Wg dnia</option>
                            <option value="rekruter" <?= $grupowanie === 'rekruter' ? 'selected' : '' ?>>👤 Wg rekrutera</option>
                            <option value="kandydat" <?= $grupowanie === 'kandydat' ? 'selected' : '' ?>>👥 Wg kandydata</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">Filtruj</button>
                        <?php if ($hasFilters): ?>
                            <a href="raport_kontakty.php" class="btn btn-secondary">✕ Wyczyść</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- STATYSTYKI -->
        <div class="stats-bar">
            <div class="stat-box">
                <div class="value" style="color: #1e293b;"><?= count($kontakty) ?></div>
                <div class="label">📊 Łącznie wpisów</div>
            </div>
            <div class="stat-box" style="border-left: 3px solid #7c3aed;">
                <div class="value" style="color: #7c3aed;"><?= $statsH['total'] ?? 0 ?></div>
                <div class="label">🔄 Zmiany statusów</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #16a34a;"><?= $statsH['zatrudniony'] ?? 0 ?></div>
                <div class="label">✅ Zatrudnieni</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #dc2626;"><?= $statsH['odrzucony'] ?? 0 ?></div>
                <div class="label">❌ Odrzuceni</div>
            </div>
            <div class="stat-box" style="border-left: 3px solid #2563eb;">
                <div class="value" style="color: #2563eb;"><?= $statsZ['total'] ?? 0 ?></div>
                <div class="label">📞 Zadania</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #16a34a;"><?= $statsZ['wykonane'] ?? 0 ?></div>
                <div class="label">✅ Wykonane</div>
            </div>
        </div>
        
        <!-- LISTA POGRUPOWANA -->
        <?php if (empty($kontakty)): ?>
            <div class="card">
                <div class="card-body" style="text-align: center; padding: 40px; color: #64748b;">
                    Brak kontaktów w wybranym okresie
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($grouped as $groupKey => $items): ?>
                <div class="day-section">
                    <div class="day-header">
                        <span>
                            <?php if ($grupowanie === 'dzien'): ?>
                                📅 <?= date('d.m.Y (l)', strtotime($groupKey)) ?>
                            <?php elseif ($grupowanie === 'rekruter'): ?>
                                👤 <?= htmlspecialchars($groupKey) ?>
                            <?php else: ?>
                                👥 <?= htmlspecialchars($items[0]['imie'] . ' ' . $items[0]['nazwisko']) ?>
                            <?php endif; ?>
                        </span>
                        <span class="count"><?= count($items) ?> wpisów</span>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <?php if ($grupowanie !== 'dzien'): ?><th>Data</th><?php endif; ?>
                                <?php if ($grupowanie !== 'kandydat'): ?><th>Kandydat</th><?php endif; ?>
                                <th>Kontakt</th>
                                <th>Typ wpisu</th>
                                <th>Szczegóły</th>
                                <?php if ($grupowanie !== 'rekruter'): ?><th>Rekruter</th><?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $k): ?>
                            <tr>
                                <?php if ($grupowanie !== 'dzien'): ?>
                                <td>
                                    <strong><?= date('d.m', strtotime($k['data_kontaktu'])) ?></strong>
                                    <?php if ($k['godzina_kontaktu']): ?><br><small><?= substr($k['godzina_kontaktu'], 0, 5) ?></small><?php endif; ?>
                                </td>
                                <?php endif; ?>
                                <?php if ($grupowanie !== 'kandydat'): ?>
                                <td>
                                    <a href="karta.php?id=<?= $k['kandydat_id'] ?>" style="font-weight: 600; color: #1e293b; text-decoration: none;">
                                        <?= htmlspecialchars($k['imie'] . ' ' . $k['nazwisko']) ?>
                                    </a>
                                    <?php if ($k['ogloszenie_tytul']): ?>
                                        <br><small style="color: #7c3aed;">📢 <?= htmlspecialchars($k['ogloszenie_tytul']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>
                                <td class="contact-info">
                                    <?php if ($k['telefon']): ?>
                                        <a href="tel:<?= $k['telefon'] ?>"><?= htmlspecialchars($k['telefon']) ?></a>
                                    <?php endif; ?>
                                    <?php if ($k['email']): ?>
                                        <br><a href="mailto:<?= $k['email'] ?>"><?= htmlspecialchars($k['email']) ?></a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($k['typ_wpisu'] === 'status_change'): ?>
                                        <span class="badge" style="background: #f3e8ff; color: #7c3aed;">🔄 Zmiana statusu</span>
                                    <?php else: 
                                        $typInfo = $zadaniaTypy[$k['zadanie_typ']] ?? ['icon' => '📋', 'label' => 'Zadanie', 'color' => '#64748b'];
                                    ?>
                                        <span style="color: <?= $typInfo['color'] ?>;"><?= $typInfo['icon'] ?></span> <?= $typInfo['label'] ?>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($k['typ_wpisu'] === 'status_change'): 
                                        $staraWartosc = $kandydatStatusy[$k['stara_wartosc']] ?? ['label' => $k['stara_wartosc'] ?: 'brak', 'icon' => ''];
                                        $nowaWartosc = $kandydatStatusy[$k['nowa_wartosc']] ?? ['label' => $k['nowa_wartosc'], 'icon' => ''];
                                    ?>
                                        <span style="color: #94a3b8;"><?= $staraWartosc['icon'] ?> <?= $staraWartosc['label'] ?></span>
                                        <strong style="color: #7c3aed;"> → </strong>
                                        <span class="badge" style="background: <?= $nowaWartosc['bg'] ?? '#e2e8f0' ?>; color: <?= $nowaWartosc['color'] ?? '#1e293b' ?>;">
                                            <?= $nowaWartosc['icon'] ?> <?= $nowaWartosc['label'] ?>
                                        </span>
                                    <?php else: 
                                        $statusInfo = $zadaniaStatusy[$k['zadanie_status']] ?? ['icon' => '📋', 'label' => $k['zadanie_status'], 'bg' => '#e2e8f0', 'color' => '#1e293b'];
                                    ?>
                                        <strong><?= htmlspecialchars($k['zadanie_tytul']) ?></strong>
                                        <span class="badge" style="background: <?= $statusInfo['bg'] ?>; color: <?= $statusInfo['color'] ?>; margin-left: 8px;">
                                            <?= $statusInfo['icon'] ?> <?= $statusInfo['label'] ?>
                                        </span>
                                        <?php if ($k['zadanie_wynik']): ?>
                                            <br><small style="color: #64748b;"><?= htmlspecialchars($k['zadanie_wynik']) ?></small>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                                <?php if ($grupowanie !== 'rekruter'): ?>
                                <td><?= htmlspecialchars($k['rekruter_nazwa'] ?? '-') ?></td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        
        <div class="no-print" style="text-align: center; padding: 20px; color: #94a3b8; font-size: 0.85rem;">
            Wygenerowano: <?= date('d.m.Y H:i') ?>
        </div>
    </div>
</body>
</html>
