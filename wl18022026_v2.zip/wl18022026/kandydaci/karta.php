<?php
/**
 * Moduł Kandydatów - Karta kandydata
 * 
 * Wyświetlanie, edycja i historia zmian
 * 
 * WGRAJ DO: /kadry/kandydaci/karta.php
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$statusy = getKandydatStatusy();
$kategorieJazdy = getKategorieJazdy();
$zadaniaTypy = getKandydatZadaniaTypy();
$zadaniaStatusy = getKandydatZadaniaStatusy();

// Pobierz użytkowników
$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: index.php');
    exit;
}

// Pobierz kandydata z ogłoszeniem
$stmt = $db->prepare("SELECT k.*, u.name as dodany_przez, o.tytul as ogloszenie_tytul, o.stanowisko as ogloszenie_stanowisko 
    FROM kandydaci k 
    LEFT JOIN users u ON k.created_by = u.id 
    LEFT JOIN ogloszenia o ON k.ogloszenie_id = o.id
    WHERE k.id = ?");
$stmt->execute([$id]);
$kandydat = $stmt->fetch();

if (!$kandydat) {
    header('Location: index.php?error=notfound');
    exit;
}

// Pobierz aktywne ogłoszenia (do ewentualnej zmiany)
$ogloszenia = $db->query("SELECT id, tytul, stanowisko, lokalizacja FROM ogloszenia WHERE status = 'aktywne' ORDER BY created_at DESC")->fetchAll();

// Pobierz historię zmian
$stmt = $db->prepare("SELECT * FROM kandydaci_historia WHERE kandydat_id = ? ORDER BY created_at DESC LIMIT 50");
$stmt->execute([$id]);
$historia = $stmt->fetchAll();

// Pobierz zadania/kontakty kandydata
$stmt = $db->prepare("
    SELECT z.*, u.name as przypisany_nazwa, uc.name as utworzyl_nazwa
    FROM kandydaci_zadania z
    LEFT JOIN users u ON z.przypisany_do = u.id
    LEFT JOIN users uc ON z.created_by = uc.id
    WHERE z.kandydat_id = ?
    ORDER BY z.termin_data DESC, z.created_at DESC
");
$stmt->execute([$id]);
$zadania = $stmt->fetchAll();

$message = '';
$error = '';

// Nazwy pól do wyświetlania
$poleLabels = [
    'imie' => 'Imię',
    'nazwisko' => 'Nazwisko',
    'email' => 'Email',
    'telefon' => 'Telefon',
    'data_urodzenia' => 'Data urodzenia',
    'miejscowosc' => 'Miejscowość',
    'prawo_jazdy' => 'Prawo jazdy',
    'wozki_widlowe' => 'Wózki widłowe',
    'status' => 'Status',
    'notatki' => 'Notatki'
];

// Obsługa zadań
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Dodanie nowego zadania
    if (isset($_POST['add_task'])) {
        $tytul = trim($_POST['tytul'] ?? '');
        $typ = $_POST['typ'] ?? 'telefon';
        $terminData = $_POST['termin_data'] ?: date('Y-m-d');
        $terminGodzina = $_POST['termin_godzina'] ?: null;
        $opis = trim($_POST['opis'] ?? '');
        $przypisanyDo = intval($_POST['przypisany_do']) ?: $currentUser['id'];
        
        if ($tytul) {
            $stmt = $db->prepare("INSERT INTO kandydaci_zadania 
                (kandydat_id, typ, tytul, opis, termin_data, termin_godzina, przypisany_do, created_by) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$id, $typ, $tytul, $opis, $terminData, $terminGodzina, $przypisanyDo, $currentUser['id']]);
            
            header("Location: karta.php?id=$id&tab=kontakty&msg=task_added");
            exit;
        }
    }
    
    // Przepisanie zadania do innej osoby (zamyka stare, tworzy nowe)
    if (isset($_POST['reassign_task'])) {
        $taskId = intval($_POST['task_id']);
        $nowyPrzypisany = intval($_POST['nowy_przypisany']);
        $nowyTerminData = $_POST['nowy_termin_data'] ?: date('Y-m-d');
        $nowyTerminGodzina = $_POST['nowy_termin_godzina'] ?: null;
        $notatka = trim($_POST['notatka_przepisania'] ?? '');
        
        // Pobierz oryginalne zadanie
        $stmt = $db->prepare("SELECT * FROM kandydaci_zadania WHERE id = ? AND kandydat_id = ?");
        $stmt->execute([$taskId, $id]);
        $oldTask = $stmt->fetch();
        
        if ($oldTask && $nowyPrzypisany) {
            // Zamknij stare zadanie ze statusem "przepisane"
            $stmt = $db->prepare("UPDATE kandydaci_zadania SET 
                status = 'przepisane', 
                wynik = ?, 
                przepisane_do = ?,
                completed_at = CURRENT_TIMESTAMP 
                WHERE id = ?");
            $stmt->execute([
                $notatka ?: 'Przepisane do innej osoby',
                $nowyPrzypisany,
                $taskId
            ]);
            
            // Utwórz nowe zadanie dla nowej osoby
            $stmt = $db->prepare("INSERT INTO kandydaci_zadania 
                (kandydat_id, typ, tytul, opis, termin_data, termin_godzina, przypisany_do, created_by, przepisane_z) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $id,
                $oldTask['typ'],
                $oldTask['tytul'],
                $oldTask['opis'] . ($notatka ? "\n\n[Przepisane] $notatka" : ''),
                $nowyTerminData,
                $nowyTerminGodzina,
                $nowyPrzypisany,
                $currentUser['id'],
                $taskId
            ]);
            
            header("Location: karta.php?id=$id&tab=kontakty&msg=task_reassigned");
            exit;
        }
    }
    
    // Zakończenie zadania
    if (isset($_POST['complete_task'])) {
        $taskId = intval($_POST['task_id']);
        $wynik = trim($_POST['wynik'] ?? '');
        $nowyStatus = $_POST['nowy_status'] ?? 'wykonane';
        
        $stmt = $db->prepare("UPDATE kandydaci_zadania SET status = ?, wynik = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ? AND kandydat_id = ?");
        $stmt->execute([$nowyStatus, $wynik, $taskId, $id]);
        
        header("Location: karta.php?id=$id&tab=kontakty&msg=task_completed");
        exit;
    }
    
    // Usunięcie zadania
    if (isset($_POST['delete_task']) && canDelete()) {
        $taskId = intval($_POST['task_id']);
        $stmt = $db->prepare("DELETE FROM kandydaci_zadania WHERE id = ? AND kandydat_id = ?");
        $stmt->execute([$taskId, $id]);
        
        header("Location: karta.php?id=$id&tab=kontakty&msg=task_deleted");
        exit;
    }
}

// Obsługa edycji danych kandydata
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save'])) {
    $newData = [
        'imie' => trim($_POST['imie'] ?? ''),
        'nazwisko' => trim($_POST['nazwisko'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'telefon' => trim($_POST['telefon'] ?? ''),
        'data_urodzenia' => $_POST['data_urodzenia'] ?: null,
        'miejscowosc' => trim($_POST['miejscowosc'] ?? ''),
        'prawo_jazdy' => isset($_POST['prawo_jazdy']) ? implode(', ', $_POST['prawo_jazdy']) : '',
        'wozki_widlowe' => isset($_POST['wozki_widlowe']) ? 1 : 0,
        'status' => $_POST['status'] ?? 'nowy',
        'notatki' => trim($_POST['notatki'] ?? ''),
        'ogloszenie_id' => intval($_POST['ogloszenie_id'] ?? 0) ?: null
    ];
    
    // Walidacja
    if (empty($newData['imie']) || empty($newData['nazwisko'])) {
        $error = 'Imię i nazwisko są wymagane';
    } else {
        // Loguj zmiany
        $fieldsToCheck = ['imie', 'nazwisko', 'email', 'telefon', 'data_urodzenia', 'miejscowosc', 'prawo_jazdy', 'wozki_widlowe', 'status', 'notatki'];
        
        foreach ($fieldsToCheck as $field) {
            $oldVal = $kandydat[$field] ?? '';
            $newVal = $newData[$field] ?? '';
            
            // Konwersja dla porównania
            if ($field === 'wozki_widlowe') {
                $oldVal = $oldVal ? 'Tak' : 'Nie';
                $newVal = $newVal ? 'Tak' : 'Nie';
            }
            if ($field === 'status') {
                $oldVal = $statusy[$oldVal]['label'] ?? $oldVal;
                $newVal = $statusy[$newVal]['label'] ?? $newVal;
            }
            
            if ((string)$oldVal !== (string)$newVal) {
                logKandydatChange($db, $id, $field, $oldVal, $newVal);
            }
        }
        
        // Aktualizuj dane
        $stmt = $db->prepare("UPDATE kandydaci SET 
            imie = ?, nazwisko = ?, email = ?, telefon = ?, data_urodzenia = ?,
            miejscowosc = ?, prawo_jazdy = ?, wozki_widlowe = ?, status = ?, notatki = ?,
            ogloszenie_id = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?");
        
        $stmt->execute([
            $newData['imie'], $newData['nazwisko'], $newData['email'] ?: null, $newData['telefon'] ?: null,
            $newData['data_urodzenia'], $newData['miejscowosc'] ?: null, $newData['prawo_jazdy'] ?: null,
            $newData['wozki_widlowe'], $newData['status'], $newData['notatki'] ?: null, $newData['ogloszenie_id'], $id
        ]);
        
        $message = 'Dane zostały zapisane';
        
        // Odśwież dane
        $stmt = $db->prepare("SELECT k.*, u.name as dodany_przez FROM kandydaci k LEFT JOIN users u ON k.created_by = u.id WHERE k.id = ?");
        $stmt->execute([$id]);
        $kandydat = $stmt->fetch();
        
        // Odśwież historię
        $stmt = $db->prepare("SELECT * FROM kandydaci_historia WHERE kandydat_id = ? ORDER BY created_at DESC LIMIT 50");
        $stmt->execute([$id]);
        $historia = $stmt->fetchAll();
    }
}

// Usuwanie kandydata
if (isset($_GET['delete']) && canDelete()) {
    // Usuń plik CV
    if ($kandydat['cv_filename']) {
        $cvPath = '../data/uploads/cv/' . $kandydat['cv_filename'];
        if (file_exists($cvPath)) {
            unlink($cvPath);
        }
    }
    
    $stmt = $db->prepare("DELETE FROM kandydaci WHERE id = ?");
    $stmt->execute([$id]);
    
    logChange($db, 'DELETE', 'kandydaci', $id, "Usunięto kandydata: {$kandydat['imie']} {$kandydat['nazwisko']}");
    
    header('Location: index.php?msg=deleted');
    exit;
}

$tab = $_GET['tab'] ?? 'dane';
$statusInfo = $statusy[$kandydat['status']] ?? $statusy['nowy'];
$prawoJazdyArr = array_map('trim', explode(',', $kandydat['prawo_jazdy'] ?? ''));
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($kandydat['imie'] . ' ' . $kandydat['nazwisko']) ?> - Kandydaci</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 1100px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section img { height: 40px; }
        
        .header-card { background: white; border-radius: 12px; padding: 25px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .header-top { display: flex; justify-content: space-between; align-items: flex-start; gap: 20px; flex-wrap: wrap; }
        .kandydat-info h1 { margin: 0 0 8px 0; font-size: 1.8rem; color: #1e293b; }
        .kandydat-meta { color: #64748b; font-size: 0.9rem; display: flex; gap: 20px; flex-wrap: wrap; }
        .kandydat-meta span { display: flex; align-items: center; gap: 5px; }
        
        .status-badge { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 8px; font-weight: 600; font-size: 0.95rem; }
        
        .tabs { display: flex; gap: 5px; margin-top: 20px; border-bottom: 2px solid #e2e8f0; padding-bottom: 0; }
        .tab { padding: 12px 20px; border-radius: 8px 8px 0 0; text-decoration: none; color: #64748b; font-weight: 500; border: 2px solid transparent; border-bottom: none; margin-bottom: -2px; }
        .tab:hover { background: #f8fafc; }
        .tab.active { background: white; color: #2563eb; border-color: #e2e8f0; border-bottom-color: white; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; }
        .card-body { padding: 25px; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 600; color: #374151; margin-bottom: 6px; font-size: 0.9rem; }
        .form-group input, .form-group select, .form-group textarea { 
            width: 100%; padding: 12px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 1rem; 
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { 
            border-color: #2563eb; outline: none; 
        }
        .form-group textarea { resize: vertical; min-height: 100px; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 600px) { .form-row { grid-template-columns: 1fr; } }
        
        .checkbox-group { display: flex; flex-wrap: wrap; gap: 8px; }
        .checkbox-item { display: flex; align-items: center; gap: 5px; padding: 6px 12px; background: #f1f5f9; border-radius: 6px; cursor: pointer; font-size: 0.9rem; }
        .checkbox-item:hover { background: #e2e8f0; }
        .checkbox-item.checked { background: #dbeafe; color: #1e40af; }
        
        .toggle-switch { display: flex; align-items: center; gap: 12px; }
        .toggle-switch input[type="checkbox"] { width: 50px; height: 26px; appearance: none; background: #cbd5e1; border-radius: 13px; position: relative; cursor: pointer; }
        .toggle-switch input[type="checkbox"]::before { content: ''; position: absolute; width: 22px; height: 22px; background: white; border-radius: 50%; top: 2px; left: 2px; transition: transform 0.3s; }
        .toggle-switch input[type="checkbox"]:checked { background: #16a34a; }
        .toggle-switch input[type="checkbox"]:checked::before { transform: translateX(24px); }
        
        .btn { padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-primary:hover { background: #1d4ed8; }
        .btn-success { background: #16a34a; color: white; }
        .btn-success:hover { background: #15803d; }
        .btn-secondary { background: #f1f5f9; color: #374151; }
        .btn-danger { background: #dc2626; color: white; }
        .btn-danger:hover { background: #b91c1c; }
        
        .actions { display: flex; gap: 12px; justify-content: space-between; margin-top: 25px; padding-top: 20px; border-top: 1px solid #e2e8f0; }
        
        .alert { padding: 14px 18px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; }
        .alert-error { background: #fee2e2; color: #991b1b; }
        
        /* Historia */
        .historia-list { }
        .historia-item { display: flex; gap: 15px; padding: 15px 0; border-bottom: 1px solid #f1f5f9; }
        .historia-item:last-child { border-bottom: none; }
        .historia-icon { width: 36px; height: 36px; border-radius: 50%; background: #e0f2fe; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
        .historia-content { flex: 1; }
        .historia-content strong { color: #1e293b; }
        .historia-values { margin-top: 6px; font-size: 0.9rem; }
        .historia-old { color: #dc2626; text-decoration: line-through; }
        .historia-new { color: #16a34a; }
        .historia-meta { font-size: 0.8rem; color: #64748b; margin-top: 6px; }
        
        /* CV Preview */
        .cv-download { display: inline-flex; align-items: center; gap: 8px; padding: 12px 20px; background: #f1f5f9; border-radius: 8px; text-decoration: none; color: #374151; }
        .cv-download:hover { background: #e2e8f0; }
        
        .cv-text { max-height: 400px; overflow-y: auto; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 15px; font-family: monospace; font-size: 0.85rem; white-space: pre-wrap; line-height: 1.5; }
        
        .info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }
        .info-item { }
        .info-item label { display: block; font-size: 0.8rem; color: #64748b; margin-bottom: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
        .info-item .value { font-size: 1rem; color: #1e293b; font-weight: 500; }
        .info-item .value a { color: #2563eb; text-decoration: none; }
        
        .guid-display { font-family: monospace; font-size: 0.8rem; color: #94a3b8; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
            </div>
            <div style="display: flex; gap: 10px;">
                <a href="index.php" class="btn btn-secondary">← Lista kandydatów</a>
            </div>
        </nav>
        
        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'created'): ?>
            <div class="alert alert-success">✅ Kandydat został dodany pomyślnie</div>
        <?php endif; ?>
        
        <?php if ($message): ?>
            <div class="alert alert-success">✅ <?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <!-- NAGŁÓWEK -->
        <div class="header-card">
            <div class="header-top">
                <div class="kandydat-info">
                    <h1><?= htmlspecialchars($kandydat['imie'] . ' ' . $kandydat['nazwisko']) ?></h1>
                    <div class="kandydat-meta">
                        <?php if ($kandydat['telefon']): ?>
                            <span>📞 <a href="tel:<?= $kandydat['telefon'] ?>"><?= htmlspecialchars($kandydat['telefon']) ?></a></span>
                        <?php endif; ?>
                        <?php if ($kandydat['email']): ?>
                            <span>📧 <a href="mailto:<?= $kandydat['email'] ?>"><?= htmlspecialchars($kandydat['email']) ?></a></span>
                        <?php endif; ?>
                        <?php if ($kandydat['miejscowosc']): ?>
                            <span>📍 <?= htmlspecialchars($kandydat['miejscowosc']) ?></span>
                        <?php endif; ?>
                    </div>
                    <?php if ($kandydat['ogloszenie_tytul']): ?>
                        <div style="margin-top: 10px; padding: 8px 14px; background: #ede9fe; border-radius: 6px; display: inline-block;">
                            📢 <strong>Ogłoszenie:</strong> <?= htmlspecialchars($kandydat['ogloszenie_tytul']) ?>
                            <?php if ($kandydat['ogloszenie_stanowisko']): ?>
                                <span style="color: #64748b;"> (<?= htmlspecialchars($kandydat['ogloszenie_stanowisko']) ?>)</span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="guid-display">GUID: <?= htmlspecialchars($kandydat['guid']) ?></div>
                </div>
                <div class="status-badge" style="background: <?= $statusInfo['bg'] ?>; color: <?= $statusInfo['color'] ?>;">
                    <?= $statusInfo['icon'] ?> <?= $statusInfo['label'] ?>
                </div>
            </div>
            
            <div class="tabs">
                <a href="?id=<?= $id ?>&tab=dane" class="tab <?= $tab === 'dane' ? 'active' : '' ?>">📝 Dane</a>
                <a href="?id=<?= $id ?>&tab=kontakty" class="tab <?= $tab === 'kontakty' ? 'active' : '' ?>">📞 Kontakty</a>
                <a href="?id=<?= $id ?>&tab=cv" class="tab <?= $tab === 'cv' ? 'active' : '' ?>">📄 CV</a>
                <a href="?id=<?= $id ?>&tab=historia" class="tab <?= $tab === 'historia' ? 'active' : '' ?>">📜 Historia (<?= count($historia) ?>)</a>
            </div>
        </div>
        
        <?php if ($tab === 'dane'): ?>
        <!-- EDYCJA DANYCH -->
        <div class="card">
            <div class="card-header">
                <span>📝 Edycja danych</span>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="save" value="1">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Imię *</label>
                            <input type="text" name="imie" value="<?= htmlspecialchars($kandydat['imie']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Nazwisko *</label>
                            <input type="text" name="nazwisko" value="<?= htmlspecialchars($kandydat['nazwisko']) ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>📧 Email</label>
                            <input type="email" name="email" value="<?= htmlspecialchars($kandydat['email'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>📞 Telefon</label>
                            <input type="tel" name="telefon" value="<?= htmlspecialchars($kandydat['telefon'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>🎂 Data urodzenia</label>
                            <input type="date" name="data_urodzenia" value="<?= htmlspecialchars($kandydat['data_urodzenia'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>📍 Miejscowość</label>
                            <input type="text" name="miejscowosc" value="<?= htmlspecialchars($kandydat['miejscowosc'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>🚗 Prawo jazdy - kategorie</label>
                        <div class="checkbox-group">
                            <?php foreach ($kategorieJazdy as $kat): 
                                $checked = in_array($kat, $prawoJazdyArr);
                            ?>
                            <label class="checkbox-item <?= $checked ? 'checked' : '' ?>">
                                <input type="checkbox" name="prawo_jazdy[]" value="<?= $kat ?>" <?= $checked ? 'checked' : '' ?> 
                                       onchange="this.parentElement.classList.toggle('checked', this.checked)">
                                <?= $kat ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>🚜 Uprawnienia na wózki widłowe</label>
                        <div class="toggle-switch">
                            <input type="checkbox" name="wozki_widlowe" value="1" <?= $kandydat['wozki_widlowe'] ? 'checked' : '' ?>>
                            <span>Posiada uprawnienia</span>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status">
                                <?php foreach ($statusy as $key => $s): ?>
                                    <option value="<?= $key ?>" <?= $kandydat['status'] === $key ? 'selected' : '' ?>>
                                        <?= $s['icon'] ?> <?= $s['label'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>📢 Ogłoszenie rekrutacyjne</label>
                            <select name="ogloszenie_id">
                                <option value="">-- brak / spontaniczna aplikacja --</option>
                                <?php foreach ($ogloszenia as $og): ?>
                                    <option value="<?= $og['id'] ?>" <?= $kandydat['ogloszenie_id'] == $og['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($og['tytul']) ?><?= $og['lokalizacja'] ? ' (' . htmlspecialchars($og['lokalizacja']) . ')' : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <small><a href="ogloszenia.php" target="_blank">Zarządzaj ogłoszeniami</a></small>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>📝 Notatki</label>
                        <textarea name="notatki" rows="4"><?= htmlspecialchars($kandydat['notatki'] ?? '') ?></textarea>
                    </div>
                    
                    <div class="actions">
                        <div>
                            <?php if (canDelete()): ?>
                            <a href="?id=<?= $id ?>&delete=1" class="btn btn-danger" onclick="return confirm('Na pewno usunąć tego kandydata?')">🗑️ Usuń</a>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-success">💾 Zapisz zmiany</button>
                    </div>
                </form>
            </div>
        </div>
        
        <?php elseif ($tab === 'kontakty'): ?>
        <!-- KONTAKTY / ZADANIA -->
        <?php
        $zadaniaTypy = getKandydatZadaniaTypy();
        $zadaniaStatusy = getKandydatZadaniaStatusy();
        $users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();
        
        // Pobierz zadania tego kandydata
        $stmt = $db->prepare("
            SELECT z.*, u.name as przypisany_nazwa, uc.name as utworzyl_nazwa
            FROM kandydaci_zadania z
            LEFT JOIN users u ON z.przypisany_do = u.id
            LEFT JOIN users uc ON z.created_by = uc.id
            WHERE z.kandydat_id = ?
            ORDER BY z.termin_data DESC, z.created_at DESC
        ");
        $stmt->execute([$id]);
        $zadania = $stmt->fetchAll();
        
        // Obsługa dodania zadania
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_task'])) {
            $tytul = trim($_POST['tytul'] ?? '');
            $typ = $_POST['typ'] ?? 'telefon';
            $terminData = $_POST['termin_data'] ?: date('Y-m-d');
            $terminGodzina = $_POST['termin_godzina'] ?: null;
            $przypisanyDo = intval($_POST['przypisany_do']) ?: $currentUser['id'];
            $opis = trim($_POST['opis'] ?? '');
            
            if ($tytul) {
                $stmt = $db->prepare("INSERT INTO kandydaci_zadania 
                    (kandydat_id, typ, tytul, opis, termin_data, termin_godzina, przypisany_do, created_by) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$id, $typ, $tytul, $opis, $terminData, $terminGodzina, $przypisanyDo, $currentUser['id']]);
                header("Location: ?id=$id&tab=kontakty&msg=task_added");
                exit;
            }
        }
        
        // Obsługa zakończenia zadania
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['complete_task'])) {
            $taskId = intval($_POST['task_id']);
            $nowyStatus = $_POST['nowy_status'] ?? 'wykonane';
            $wynik = trim($_POST['wynik'] ?? '');
            
            $stmt = $db->prepare("UPDATE kandydaci_zadania SET status = ?, wynik = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ? AND kandydat_id = ?");
            $stmt->execute([$nowyStatus, $wynik, $taskId, $id]);
            header("Location: ?id=$id&tab=kontakty&msg=task_completed");
            exit;
        }
        
        // Odśwież listę po akcji
        $stmt = $db->prepare("
            SELECT z.*, u.name as przypisany_nazwa, uc.name as utworzyl_nazwa
            FROM kandydaci_zadania z
            LEFT JOIN users u ON z.przypisany_do = u.id
            LEFT JOIN users uc ON z.created_by = uc.id
            WHERE z.kandydat_id = ?
            ORDER BY z.termin_data DESC, z.created_at DESC
        ");
        $stmt->execute([$id]);
        $zadania = $stmt->fetchAll();
        
        $taskMsg = $_GET['msg'] ?? '';
        ?>
        
        <?php if ($taskMsg === 'task_added'): ?>
            <div style="background: #dcfce7; color: #166534; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px;">✅ Kontakt został zaplanowany</div>
        <?php elseif ($taskMsg === 'task_completed'): ?>
            <div style="background: #dcfce7; color: #166534; padding: 12px 20px; border-radius: 8px; margin-bottom: 20px;">✅ Zadanie zostało zaktualizowane</div>
        <?php endif; ?>
        
        <!-- Formularz dodawania -->
        <div class="card">
            <div class="card-header">
                <span>➕ Zaplanuj nowy kontakt</span>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="add_task" value="1">
                    <div class="form-row">
                        <div class="form-group">
                            <label>Typ kontaktu</label>
                            <select name="typ">
                                <?php foreach ($zadaniaTypy as $key => $t): ?>
                                    <option value="<?= $key ?>"><?= $t['icon'] ?> <?= $t['label'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Temat *</label>
                            <input type="text" name="tytul" placeholder="np. Pierwszy kontakt..." required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Data</label>
                            <input type="date" name="termin_data" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="form-group">
                            <label>Godzina</label>
                            <input type="time" name="termin_godzina">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Przypisz do</label>
                            <select name="przypisany_do">
                                <?php foreach ($users as $u): ?>
                                    <option value="<?= $u['id'] ?>" <?= $u['id'] == $currentUser['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Notatka</label>
                            <input type="text" name="opis" placeholder="Dodatkowe informacje...">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">📅 Zaplanuj kontakt</button>
                </form>
            </div>
        </div>
        
        <!-- Lista kontaktów -->
        <div class="card">
            <div class="card-header">
                <span>📋 Historia kontaktów (<?= count($zadania) ?>)</span>
            </div>
            <div class="card-body" style="padding: 0;">
                <?php if (empty($zadania)): ?>
                    <p style="color: #64748b; text-align: center; padding: 40px;">Brak zaplanowanych kontaktów</p>
                <?php else: ?>
                    <table style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: #f8fafc;">
                                <th style="padding: 12px; text-align: left; font-size: 0.8rem; color: #64748b;">Data</th>
                                <th style="padding: 12px; text-align: left; font-size: 0.8rem; color: #64748b;">Typ</th>
                                <th style="padding: 12px; text-align: left; font-size: 0.8rem; color: #64748b;">Temat</th>
                                <th style="padding: 12px; text-align: left; font-size: 0.8rem; color: #64748b;">Status</th>
                                <th style="padding: 12px; text-align: left; font-size: 0.8rem; color: #64748b;">Wynik</th>
                                <th style="padding: 12px; text-align: left; font-size: 0.8rem; color: #64748b;">Rekruter</th>
                                <th style="padding: 12px; text-align: left; font-size: 0.8rem; color: #64748b;">Akcje</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($zadania as $z): 
                                $typInfo = $zadaniaTypy[$z['typ']] ?? $zadaniaTypy['telefon'];
                                $statusInfo = $zadaniaStatusy[$z['status']] ?? $zadaniaStatusy['zaplanowane'];
                                $isOverdue = $z['status'] === 'zaplanowane' && $z['termin_data'] < date('Y-m-d');
                            ?>
                            <tr style="border-bottom: 1px solid #f1f5f9; <?= $isOverdue ? 'background: #fef2f2;' : '' ?>">
                                <td style="padding: 12px;">
                                    <strong><?= date('d.m.Y', strtotime($z['termin_data'])) ?></strong>
                                    <?php if ($z['termin_godzina']): ?>
                                        <br><small style="color: #64748b;"><?= substr($z['termin_godzina'], 0, 5) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px;">
                                    <span style="color: <?= $typInfo['color'] ?>;"><?= $typInfo['icon'] ?></span>
                                    <?= $typInfo['label'] ?>
                                </td>
                                <td style="padding: 12px;">
                                    <?= htmlspecialchars($z['tytul']) ?>
                                    <?php if ($z['opis']): ?>
                                        <br><small style="color: #64748b;"><?= htmlspecialchars($z['opis']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px;">
                                    <span class="badge" style="background: <?= $statusInfo['bg'] ?>; color: <?= $statusInfo['color'] ?>;">
                                        <?= $statusInfo['icon'] ?> <?= $statusInfo['label'] ?>
                                    </span>
                                </td>
                                <td style="padding: 12px; max-width: 200px;">
                                    <?php if ($z['wynik']): ?>
                                        <small><?= htmlspecialchars($z['wynik']) ?></small>
                                    <?php else: ?>
                                        <span style="color: #94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td style="padding: 12px;">
                                    <small><?= htmlspecialchars($z['przypisany_nazwa'] ?? '-') ?></small>
                                </td>
                                <td style="padding: 12px;">
                                    <?php if ($z['status'] === 'zaplanowane'): ?>
                                        <div style="display: flex; gap: 5px;">
                                            <button class="btn btn-small" style="padding: 5px 10px; font-size: 0.8rem; background: #dcfce7; color: #166534; border: none; border-radius: 4px; cursor: pointer;" onclick="completeTask(<?= $z['id'] ?>)" title="Zakończ">✓</button>
                                            <button class="btn btn-small" style="padding: 5px 10px; font-size: 0.8rem; background: #e0f2fe; color: #0369a1; border: none; border-radius: 4px; cursor: pointer;" onclick="reassignTask(<?= $z['id'] ?>, '<?= htmlspecialchars($z['tytul'], ENT_QUOTES) ?>')" title="Przepisz">↪️</button>
                                        </div>
                                    <?php elseif ($z['status'] === 'przepisane'): ?>
                                        <small style="color: #64748b;">przepisane</small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Modal zakończenia -->
        <div class="modal" id="modal-complete" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
            <div style="background: white; border-radius: 12px; width: 100%; max-width: 450px; margin: 20px;">
                <div style="padding: 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0;">✅ Zakończ zadanie</h3>
                    <button onclick="hideModal('modal-complete')" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #64748b;">&times;</button>
                </div>
                <form method="POST">
                    <input type="hidden" name="complete_task" value="1">
                    <input type="hidden" name="task_id" id="complete_task_id">
                    <div style="padding: 20px;">
                        <div class="form-group">
                            <label>Wynik kontaktu</label>
                            <select name="nowy_status">
                                <option value="wykonane">✅ Wykonane - rozmowa odbyła się</option>
                                <option value="nieodbiera">📵 Nie odbiera</option>
                                <option value="oddzwoni">🔄 Oddzwoni / Przełożone</option>
                                <option value="anulowane">❌ Anulowane</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Notatka z rozmowy</label>
                            <textarea name="wynik" rows="3" placeholder="Opisz przebieg rozmowy..."></textarea>
                        </div>
                    </div>
                    <div style="padding: 15px 20px; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 10px;">
                        <button type="button" class="btn" onclick="hideModal('modal-complete')">Anuluj</button>
                        <button type="submit" class="btn btn-success">💾 Zapisz</button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Modal przepisania -->
        <div class="modal" id="modal-reassign" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center;">
            <div style="background: white; border-radius: 12px; width: 100%; max-width: 500px; margin: 20px;">
                <div style="padding: 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0;">↪️ Przepisz zadanie</h3>
                    <button onclick="hideModal('modal-reassign')" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #64748b;">&times;</button>
                </div>
                <form method="POST">
                    <input type="hidden" name="reassign_task" value="1">
                    <input type="hidden" name="task_id" id="reassign_task_id">
                    <div style="padding: 20px;">
                        <p style="margin: 0 0 15px 0; color: #64748b; font-size: 0.9rem;">
                            Zadanie: <strong id="reassign_task_title"></strong>
                        </p>
                        <div class="form-group">
                            <label>Przepisz do *</label>
                            <select name="nowy_przypisany" required>
                                <option value="">-- wybierz osobę --</option>
                                <?php foreach ($users as $u): ?>
                                    <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Nowy termin (data)</label>
                                <input type="date" name="nowy_termin_data" value="<?= date('Y-m-d') ?>">
                            </div>
                            <div class="form-group">
                                <label>Godzina</label>
                                <input type="time" name="nowy_termin_godzina">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Notatka (powód przepisania)</label>
                            <textarea name="notatka_przepisania" rows="2" placeholder="Opcjonalna notatka..."></textarea>
                        </div>
                        <div style="background: #fef3c7; border-radius: 6px; padding: 12px; font-size: 0.85rem; color: #92400e;">
                            ⚠️ Obecne zadanie zostanie zamknięte ze statusem "Przepisane", a dla nowej osoby utworzone zostanie nowe zadanie.
                        </div>
                    </div>
                    <div style="padding: 15px 20px; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 10px;">
                        <button type="button" class="btn" onclick="hideModal('modal-reassign')">Anuluj</button>
                        <button type="submit" class="btn btn-primary">↪️ Przepisz</button>
                    </div>
                </form>
            </div>
        </div>
        
        <script>
        function completeTask(taskId) {
            document.getElementById('complete_task_id').value = taskId;
            document.getElementById('modal-complete').style.display = 'flex';
        }
        function reassignTask(taskId, taskTitle) {
            document.getElementById('reassign_task_id').value = taskId;
            document.getElementById('reassign_task_title').textContent = taskTitle;
            document.getElementById('modal-reassign').style.display = 'flex';
        }
        function hideModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        document.getElementById('modal-complete').addEventListener('click', function(e) {
            if (e.target === this) hideModal('modal-complete');
        });
        document.getElementById('modal-reassign').addEventListener('click', function(e) {
            if (e.target === this) hideModal('modal-reassign');
        });
        </script>
        
        <?php elseif ($tab === 'cv'): ?>
        <!-- CV -->
        <div class="card">
            <div class="card-header">
                <span>📄 CV kandydata</span>
            </div>
            <div class="card-body">
                <?php if ($kandydat['cv_filename']): ?>
                    <div style="margin-bottom: 20px;">
                        <a href="../data/uploads/cv/<?= htmlspecialchars($kandydat['cv_filename']) ?>" 
                           class="cv-download" target="_blank" download="<?= htmlspecialchars($kandydat['cv_original_name']) ?>">
                            📥 Pobierz CV: <?= htmlspecialchars($kandydat['cv_original_name']) ?>
                        </a>
                    </div>
                <?php else: ?>
                    <p style="color: #64748b;">Brak załączonego pliku CV</p>
                <?php endif; ?>
                
                <?php if ($kandydat['cv_text']): ?>
                    <h4 style="margin-top: 25px; margin-bottom: 15px;">📜 Wyekstrahowany tekst (do przeszukiwania)</h4>
                    <div class="cv-text"><?= htmlspecialchars($kandydat['cv_text']) ?></div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php elseif ($tab === 'historia'): ?>
        <!-- HISTORIA ZMIAN -->
        <div class="card">
            <div class="card-header">
                <span>📜 Historia zmian</span>
            </div>
            <div class="card-body">
                <?php if (empty($historia)): ?>
                    <p style="color: #64748b; text-align: center; padding: 30px;">Brak historii zmian</p>
                <?php else: ?>
                    <div class="historia-list">
                        <?php foreach ($historia as $h): ?>
                        <div class="historia-item">
                            <div class="historia-icon">✏️</div>
                            <div class="historia-content">
                                <strong><?= htmlspecialchars($poleLabels[$h['pole']] ?? $h['pole']) ?></strong>
                                <div class="historia-values">
                                    <?php if ($h['stara_wartosc']): ?>
                                        <span class="historia-old"><?= htmlspecialchars($h['stara_wartosc'] ?: '(puste)') ?></span>
                                        →
                                    <?php endif; ?>
                                    <span class="historia-new"><?= htmlspecialchars($h['nowa_wartosc'] ?: '(puste)') ?></span>
                                </div>
                                <div class="historia-meta">
                                    <?= htmlspecialchars($h['user_name']) ?> • <?= date('d.m.Y H:i', strtotime($h['created_at'])) ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- INFO DODATKOWE -->
        <div class="card">
            <div class="card-body">
                <div class="info-grid">
                    <div class="info-item">
                        <label>Dodano</label>
                        <div class="value"><?= date('d.m.Y H:i', strtotime($kandydat['created_at'])) ?></div>
                    </div>
                    <div class="info-item">
                        <label>Dodał</label>
                        <div class="value"><?= htmlspecialchars($kandydat['dodany_przez'] ?? 'System') ?></div>
                    </div>
                    <div class="info-item">
                        <label>Ostatnia aktualizacja</label>
                        <div class="value"><?= date('d.m.Y H:i', strtotime($kandydat['updated_at'])) ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
