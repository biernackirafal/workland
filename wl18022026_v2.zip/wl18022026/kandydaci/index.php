<?php
/**
 * Moduł Kandydatów - Dashboard i lista kandydatów
 * System Ewidencji Pracowników - Work Land
 * 
 * Z task managerem dla rekruterów
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$statusy = getKandydatStatusy();
$zadaniaTypy = getKandydatZadaniaTypy();
$zadaniaStatusy = getKandydatZadaniaStatusy();
$zadaniaPriorytety = getKandydatZadaniaPriorytety();

// Pobierz użytkowników do przypisania zadań
$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();

// Pobierz ogłoszenia do filtrowania
$ogloszenia = $db->query("SELECT id, tytul, stanowisko FROM ogloszenia ORDER BY status = 'aktywne' DESC, created_at DESC")->fetchAll();

// === OBSŁUGA ZADAŃ ===
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Szybkie dodanie zadania
    if (isset($_POST['quick_task'])) {
        $kandydatId = intval($_POST['kandydat_id']);
        $tytul = trim($_POST['tytul']);
        $terminData = $_POST['termin_data'] ?: date('Y-m-d');
        $terminGodzina = $_POST['termin_godzina'] ?: null;
        $typ = $_POST['typ'] ?? 'telefon';
        $przypisanyDo = intval($_POST['przypisany_do']) ?: $currentUser['id'];
        
        if ($kandydatId && $tytul) {
            $stmt = $db->prepare("INSERT INTO kandydaci_zadania 
                (kandydat_id, typ, tytul, termin_data, termin_godzina, przypisany_do, created_by) 
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$kandydatId, $typ, $tytul, $terminData, $terminGodzina, $przypisanyDo, $currentUser['id']]);
        }
        header('Location: index.php?msg=task_added');
        exit;
    }
    
    // Zakończenie zadania
    if (isset($_POST['complete_task'])) {
        $taskId = intval($_POST['task_id']);
        $wynik = $_POST['wynik'] ?? '';
        $nowyStatus = $_POST['nowy_status'] ?? 'wykonane';
        
        $stmt = $db->prepare("UPDATE kandydaci_zadania SET status = ?, wynik = ?, completed_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$nowyStatus, $wynik, $taskId]);
        
        header('Location: index.php?msg=task_completed');
        exit;
    }
}

// === FILTRY LISTY ===
$search = trim($_GET['search'] ?? '');
$status = $_GET['status'] ?? '';
$wozki = $_GET['wozki'] ?? '';
$prawo_jazdy = $_GET['prawo_jazdy'] ?? '';
$ogloszenie = $_GET['ogloszenie'] ?? '';

$where = ['1=1'];
$params = [];

if ($search) {
    $where[] = "(k.imie LIKE ? OR k.nazwisko LIKE ? OR k.email LIKE ? OR k.telefon LIKE ? OR k.miejscowosc LIKE ? OR k.cv_text LIKE ?)";
    $searchParam = "%$search%";
    $params = array_merge($params, [$searchParam, $searchParam, $searchParam, $searchParam, $searchParam, $searchParam]);
}

if ($status) {
    $where[] = "k.status = ?";
    $params[] = $status;
}

if ($wozki === '1') {
    $where[] = "k.wozki_widlowe = 1";
} elseif ($wozki === '0') {
    $where[] = "k.wozki_widlowe = 0";
}

if ($prawo_jazdy) {
    $where[] = "k.prawo_jazdy LIKE ?";
    $params[] = "%$prawo_jazdy%";
}

if ($ogloszenie) {
    if ($ogloszenie === 'brak') {
        $where[] = "k.ogloszenie_id IS NULL";
    } else {
        $where[] = "k.ogloszenie_id = ?";
        $params[] = intval($ogloszenie);
    }
}

$whereClause = implode(' AND ', $where);

// Paginacja
$perPage = 30;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$stmt = $db->prepare("SELECT COUNT(*) FROM kandydaci k WHERE $whereClause");
$stmt->execute($params);
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $perPage);

// Pobierz kandydatów z ogłoszeniem
$stmt = $db->prepare("
    SELECT k.*, u.name as dodany_przez, o.tytul as ogloszenie_tytul
    FROM kandydaci k
    LEFT JOIN users u ON k.created_by = u.id
    LEFT JOIN ogloszenia o ON k.ogloszenie_id = o.id
    WHERE $whereClause
    ORDER BY k.created_at DESC
    LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$kandydaci = $stmt->fetchAll();

// === DASHBOARD - ZADANIA ===
$today = date('Y-m-d');
$weekEnd = date('Y-m-d', strtotime('+7 days'));

// Zadania na dziś
$stmt = $db->prepare("
    SELECT z.*, k.imie, k.nazwisko, k.telefon, k.email, u.name as przypisany_nazwa
    FROM kandydaci_zadania z
    JOIN kandydaci k ON z.kandydat_id = k.id
    LEFT JOIN users u ON z.przypisany_do = u.id
    WHERE z.termin_data = ? AND z.status = 'zaplanowane'
    ORDER BY z.termin_godzina ASC, z.priorytet DESC
");
$stmt->execute([$today]);
$zadaniaDzis = $stmt->fetchAll();

// Zadania na ten tydzień (bez dziś)
$stmt = $db->prepare("
    SELECT z.*, k.imie, k.nazwisko, k.telefon, u.name as przypisany_nazwa
    FROM kandydaci_zadania z
    JOIN kandydaci k ON z.kandydat_id = k.id
    LEFT JOIN users u ON z.przypisany_do = u.id
    WHERE z.termin_data > ? AND z.termin_data <= ? AND z.status = 'zaplanowane'
    ORDER BY z.termin_data ASC, z.termin_godzina ASC
");
$stmt->execute([$today, $weekEnd]);
$zadaniaTydzien = $stmt->fetchAll();

// Zaległe zadania
$stmt = $db->prepare("
    SELECT z.*, k.imie, k.nazwisko, k.telefon, u.name as przypisany_nazwa
    FROM kandydaci_zadania z
    JOIN kandydaci k ON z.kandydat_id = k.id
    LEFT JOIN users u ON z.przypisany_do = u.id
    WHERE z.termin_data < ? AND z.status = 'zaplanowane'
    ORDER BY z.termin_data ASC
");
$stmt->execute([$today]);
$zadaniaZalegle = $stmt->fetchAll();

// Statystyki
$stats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'nowy' THEN 1 ELSE 0 END) as nowi,
        SUM(CASE WHEN status = 'w_kontakcie' THEN 1 ELSE 0 END) as w_kontakcie,
        SUM(CASE WHEN status = 'zatrudniony' THEN 1 ELSE 0 END) as zatrudnieni,
        SUM(CASE WHEN wozki_widlowe = 1 THEN 1 ELSE 0 END) as z_wozkami
    FROM kandydaci
")->fetch();

// Statystyki zadań
$taskStats = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'zaplanowane' AND termin_data = '$today' THEN 1 ELSE 0 END) as dzis,
        SUM(CASE WHEN status = 'zaplanowane' AND termin_data < '$today' THEN 1 ELSE 0 END) as zalegle,
        SUM(CASE WHEN status = 'wykonane' AND DATE(completed_at) = '$today' THEN 1 ELSE 0 END) as wykonane_dzis
    FROM kandydaci_zadania
")->fetch();

$hasFilters = $search || $status || $wozki !== '' || $prawo_jazdy || $ogloszenie;

// Komunikaty
$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kandydaci - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #2563eb; color: white; }
        
        header { margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        .subtitle { color: #64748b; margin: 0; }
        .header-actions { display: flex; gap: 10px; flex-wrap: wrap; }
        
        .alert { padding: 12px 20px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #86efac; }
        
        /* Dashboard */
        .dashboard { margin-bottom: 30px; }
        .dashboard-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .dashboard-header h2 { margin: 0; font-size: 1.3rem; color: #1e293b; }
        
        .dashboard-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 20px; }
        
        .task-card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; }
        .task-card-header { padding: 15px 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
        .task-card-header h3 { margin: 0; font-size: 1rem; display: flex; align-items: center; gap: 8px; }
        .task-card-header .count { background: #2563eb; color: white; padding: 2px 10px; border-radius: 50px; font-size: 0.85rem; }
        .task-card-header .count.warning { background: #dc2626; }
        .task-card-header .count.success { background: #16a34a; }
        
        .task-list { max-height: 400px; overflow-y: auto; }
        .task-item { padding: 15px 20px; border-bottom: 1px solid #f1f5f9; display: flex; gap: 12px; align-items: flex-start; }
        .task-item:hover { background: #f8fafc; }
        .task-item:last-child { border-bottom: none; }
        
        .task-icon { width: 36px; height: 36px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0; }
        .task-content { flex: 1; min-width: 0; }
        .task-title { font-weight: 600; color: #1e293b; margin-bottom: 4px; }
        .task-title a { color: inherit; text-decoration: none; }
        .task-title a:hover { color: #2563eb; }
        .task-meta { font-size: 0.8rem; color: #64748b; display: flex; gap: 12px; flex-wrap: wrap; }
        .task-meta a { color: #2563eb; }
        
        .task-actions { display: flex; gap: 5px; flex-shrink: 0; }
        .task-btn { padding: 6px 10px; border-radius: 6px; border: none; cursor: pointer; font-size: 0.85rem; }
        .task-btn-complete { background: #dcfce7; color: #166534; }
        .task-btn-complete:hover { background: #bbf7d0; }
        
        .empty-tasks { padding: 30px; text-align: center; color: #64748b; }
        
        /* Stats */
        .stats-bar { display: grid; grid-template-columns: repeat(auto-fit, minmax(130px, 1fr)); gap: 12px; margin-bottom: 20px; }
        .stat-box { background: white; padding: 15px 18px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); }
        .stat-box .value { font-size: 1.6rem; font-weight: 700; color: #1e293b; }
        .stat-box .label { font-size: 0.8rem; color: #64748b; margin-top: 3px; }
        
        /* Filters */
        .filters-card { background: white; padding: 18px 22px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); }
        .filters-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.8rem; color: #64748b; font-weight: 600; }
        .filter-group select, .filter-group input { padding: 10px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; min-width: 150px; }
        .filter-group select:focus, .filter-group input:focus { border-color: #2563eb; outline: none; }
        
        /* Table */
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; display: flex; justify-content: space-between; align-items: center; background: #f8fafc; }
        
        .badge { display: inline-flex; align-items: center; gap: 4px; padding: 4px 10px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; }
        
        table { width: 100%; border-collapse: collapse; }
        th { padding: 12px 10px; text-align: left; background: #f1f5f9; font-weight: 700; font-size: 0.75rem; color: #475569; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e2e8f0; }
        td { padding: 12px 10px; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; }
        tr:hover { background: #f8fafc; }
        
        .kandydat-nazwa { font-weight: 600; color: #1e293b; }
        .kandydat-nazwa a { color: inherit; text-decoration: none; }
        .kandydat-nazwa a:hover { color: #2563eb; }
        .kandydat-meta { font-size: 0.8rem; color: #64748b; margin-top: 3px; }
        
        .mono { font-family: 'SF Mono', Monaco, monospace; font-size: 0.85rem; }
        .text-muted { color: #94a3b8; }
        
        .wozki-badge { display: inline-flex; align-items: center; gap: 3px; padding: 3px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: 600; }
        .wozki-badge.tak { background: #dcfce7; color: #166534; }
        .wozki-badge.nie { background: #f1f5f9; color: #64748b; }
        
        .btn { padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-primary:hover { background: #1d4ed8; }
        .btn-success { background: #16a34a; color: white; }
        .btn-success:hover { background: #15803d; }
        .btn-sm { padding: 6px 12px; font-size: 0.85rem; }
        
        .pagination { display: flex; gap: 5px; justify-content: center; margin-top: 20px; flex-wrap: wrap; }
        .pagination a, .pagination span { padding: 8px 14px; border: 1px solid #e2e8f0; border-radius: 6px; text-decoration: none; color: #374151; }
        .pagination a:hover { background: #f1f5f9; }
        .pagination .active { background: #2563eb; color: white; border-color: #2563eb; }
        
        .empty-state { text-align: center; padding: 60px 20px; color: #64748b; }
        .empty-state .icon { font-size: 3rem; margin-bottom: 15px; }
        
        /* Modal */
        .modal { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
        .modal.active { display: flex; }
        .modal-content { background: white; border-radius: 12px; width: 100%; max-width: 500px; max-height: 90vh; overflow-y: auto; margin: 20px; }
        .modal-header { padding: 20px; border-bottom: 1px solid #e2e8f0; display: flex; justify-content: space-between; align-items: center; }
        .modal-header h3 { margin: 0; }
        .modal-close { background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #64748b; }
        .modal-body { padding: 20px; }
        .modal-footer { padding: 15px 20px; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 10px; }
        
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; font-size: 0.9rem; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px 12px; border: 2px solid #e2e8f0; border-radius: 6px; font-size: 0.95rem; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #2563eb; outline: none; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        
        @media (max-width: 768px) {
            .dashboard-grid { grid-template-columns: 1fr; }
            .filters-row { flex-direction: column; }
            .filter-group { width: 100%; }
            .filter-group select, .filter-group input { width: 100%; }
            table { font-size: 0.85rem; }
            th, td { padding: 8px 6px; }
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?= sanitize($currentUser['name']) ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../crm/">🎯 CRM</a>
                <a href="./" class="active">👥 Kandydaci</a>
                <a href="ogloszenia.php">📢 Ogłoszenia</a>
                <a href="raport.php">📊 Raport</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <div>
                <h1>👥 Kandydaci</h1>
                <p class="subtitle">Rekrutacja i zarządzanie kontaktami</p>
            </div>
            <div class="header-actions">
                <a href="dodaj.php" class="btn btn-success">📄 Dodaj CV</a>
                <button class="btn btn-primary" onclick="showModal('modal-task')">➕ Zaplanuj kontakt</button>
            </div>
        </header>
        
        <?php if ($msg === 'task_added'): ?>
            <div class="alert alert-success">✅ Kontakt został zaplanowany</div>
        <?php elseif ($msg === 'task_completed'): ?>
            <div class="alert alert-success">✅ Zadanie zostało zaktualizowane</div>
        <?php endif; ?>
        
        <!-- === DASHBOARD REKRUTERA === -->
        <div class="dashboard">
            <div class="dashboard-header">
                <h2>📅 Panel zadań</h2>
            </div>
            
            <div class="stats-bar">
                <div class="stat-box">
                    <div class="value" style="color: #2563eb;"><?= $taskStats['dzis'] ?></div>
                    <div class="label">📞 Na dziś</div>
                </div>
                <div class="stat-box">
                    <div class="value" style="color: #dc2626;"><?= $taskStats['zalegle'] ?></div>
                    <div class="label">⚠️ Zaległe</div>
                </div>
                <div class="stat-box">
                    <div class="value" style="color: #16a34a;"><?= $taskStats['wykonane_dzis'] ?></div>
                    <div class="label">✅ Wykonane dziś</div>
                </div>
                <div class="stat-box">
                    <div class="value" style="color: #0891b2;"><?= $stats['nowi'] ?></div>
                    <div class="label">📥 Nowi kandydaci</div>
                </div>
                <div class="stat-box">
                    <div class="value" style="color: #7c3aed;"><?= $stats['w_kontakcie'] ?></div>
                    <div class="label">📞 W kontakcie</div>
                </div>
            </div>
            
            <div class="dashboard-grid">
                <!-- Zaległe -->
                <?php if (!empty($zadaniaZalegle)): ?>
                <div class="task-card" style="border-left: 4px solid #dc2626;">
                    <div class="task-card-header">
                        <h3>⚠️ Zaległe kontakty</h3>
                        <span class="count warning"><?= count($zadaniaZalegle) ?></span>
                    </div>
                    <div class="task-list">
                        <?php foreach ($zadaniaZalegle as $z): 
                            $typInfo = $zadaniaTypy[$z['typ']] ?? $zadaniaTypy['telefon'];
                        ?>
                        <div class="task-item">
                            <div class="task-icon" style="background: <?= $typInfo['color'] ?>20; color: <?= $typInfo['color'] ?>;">
                                <?= $typInfo['icon'] ?>
                            </div>
                            <div class="task-content">
                                <div class="task-title">
                                    <a href="karta.php?id=<?= $z['kandydat_id'] ?>"><?= htmlspecialchars($z['imie'] . ' ' . $z['nazwisko']) ?></a>
                                </div>
                                <div class="task-meta">
                                    <?php if ($z['telefon']): ?><a href="tel:<?= $z['telefon'] ?>"><?= htmlspecialchars($z['telefon']) ?></a><?php endif; ?>
                                    <span>📅 <?= date('d.m', strtotime($z['termin_data'])) ?></span>
                                    <span><?= htmlspecialchars($z['tytul']) ?></span>
                                </div>
                            </div>
                            <div class="task-actions">
                                <button class="task-btn task-btn-complete" onclick="completeTask(<?= $z['id'] ?>)">✓</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Na dziś -->
                <div class="task-card" style="border-left: 4px solid #2563eb;">
                    <div class="task-card-header">
                        <h3>📞 Do obdzwonienia dziś</h3>
                        <span class="count"><?= count($zadaniaDzis) ?></span>
                    </div>
                    <div class="task-list">
                        <?php if (empty($zadaniaDzis)): ?>
                            <div class="empty-tasks">
                                <p>🎉 Brak zaplanowanych kontaktów na dziś</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($zadaniaDzis as $z): 
                                $typInfo = $zadaniaTypy[$z['typ']] ?? $zadaniaTypy['telefon'];
                            ?>
                            <div class="task-item">
                                <div class="task-icon" style="background: <?= $typInfo['color'] ?>20; color: <?= $typInfo['color'] ?>;">
                                    <?= $typInfo['icon'] ?>
                                </div>
                                <div class="task-content">
                                    <div class="task-title">
                                        <a href="karta.php?id=<?= $z['kandydat_id'] ?>"><?= htmlspecialchars($z['imie'] . ' ' . $z['nazwisko']) ?></a>
                                    </div>
                                    <div class="task-meta">
                                        <?php if ($z['telefon']): ?><a href="tel:<?= $z['telefon'] ?>"><?= htmlspecialchars($z['telefon']) ?></a><?php endif; ?>
                                        <?php if ($z['termin_godzina']): ?><span>🕐 <?= substr($z['termin_godzina'], 0, 5) ?></span><?php endif; ?>
                                        <span><?= htmlspecialchars($z['tytul']) ?></span>
                                    </div>
                                </div>
                                <div class="task-actions">
                                    <button class="task-btn task-btn-complete" onclick="completeTask(<?= $z['id'] ?>)">✓</button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Ten tydzień -->
                <div class="task-card" style="border-left: 4px solid #7c3aed;">
                    <div class="task-card-header">
                        <h3>📅 Ten tydzień</h3>
                        <span class="count" style="background: #7c3aed;"><?= count($zadaniaTydzien) ?></span>
                    </div>
                    <div class="task-list">
                        <?php if (empty($zadaniaTydzien)): ?>
                            <div class="empty-tasks">
                                <p>Brak zaplanowanych kontaktów w tym tygodniu</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($zadaniaTydzien as $z): 
                                $typInfo = $zadaniaTypy[$z['typ']] ?? $zadaniaTypy['telefon'];
                                $dayName = ['Nd', 'Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So'][date('w', strtotime($z['termin_data']))];
                            ?>
                            <div class="task-item">
                                <div class="task-icon" style="background: <?= $typInfo['color'] ?>20; color: <?= $typInfo['color'] ?>;">
                                    <?= $typInfo['icon'] ?>
                                </div>
                                <div class="task-content">
                                    <div class="task-title">
                                        <a href="karta.php?id=<?= $z['kandydat_id'] ?>"><?= htmlspecialchars($z['imie'] . ' ' . $z['nazwisko']) ?></a>
                                    </div>
                                    <div class="task-meta">
                                        <span>📅 <?= $dayName ?>, <?= date('d.m', strtotime($z['termin_data'])) ?></span>
                                        <span><?= htmlspecialchars($z['tytul']) ?></span>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- === STATYSTYKI KANDYDATÓW === -->
        <div class="stats-bar">
            <div class="stat-box">
                <div class="value"><?= number_format($stats['total']) ?></div>
                <div class="label">👥 Łącznie</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #16a34a;"><?= number_format($stats['zatrudnieni']) ?></div>
                <div class="label">✅ Zatrudnieni</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #d97706;"><?= number_format($stats['z_wozkami']) ?></div>
                <div class="label">🚜 Z wózkami</div>
            </div>
        </div>
        
        <!-- === FILTRY === -->
        <div class="filters-card">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group" style="flex: 1; min-width: 200px;">
                        <label>🔍 Szukaj</label>
                        <input type="text" name="search" placeholder="Imię, nazwisko, email, tekst CV..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">-- Wszystkie --</option>
                            <?php foreach ($statusy as $key => $s): ?>
                                <option value="<?= $key ?>" <?= $status === $key ? 'selected' : '' ?>><?= $s['icon'] ?> <?= $s['label'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>🚜 Wózki widłowe</label>
                        <select name="wozki">
                            <option value="">-- Wszystkie --</option>
                            <option value="1" <?= $wozki === '1' ? 'selected' : '' ?>>✅ Tak</option>
                            <option value="0" <?= $wozki === '0' ? 'selected' : '' ?>>❌ Nie</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>🚗 Prawo jazdy</label>
                        <select name="prawo_jazdy">
                            <option value="">-- Wszystkie --</option>
                            <?php foreach (getKategorieJazdy() as $kat): ?>
                                <option value="<?= $kat ?>" <?= $prawo_jazdy === $kat ? 'selected' : '' ?>><?= $kat ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>📢 Ogłoszenie</label>
                        <select name="ogloszenie">
                            <option value="">-- Wszystkie --</option>
                            <option value="brak" <?= $ogloszenie === 'brak' ? 'selected' : '' ?>>🚫 Bez ogłoszenia</option>
                            <?php foreach ($ogloszenia as $og): ?>
                                <option value="<?= $og['id'] ?>" <?= $ogloszenie == $og['id'] ? 'selected' : '' ?>><?= htmlspecialchars($og['tytul']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">Filtruj</button>
                        <?php if ($hasFilters): ?>
                            <a href="index.php" class="btn" style="background: #f1f5f9; color: #374151;">✕ Wyczyść</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- === LISTA KANDYDATÓW === -->
        <div class="card">
            <div class="card-header">
                <span>Znaleziono: <strong><?= $total ?></strong> kandydatów</span>
            </div>
            
            <?php if (empty($kandydaci)): ?>
                <div class="empty-state">
                    <div class="icon">👥</div>
                    <p>Brak kandydatów spełniających kryteria</p>
                    <a href="dodaj.php" class="btn btn-success" style="margin-top: 15px;">📄 Dodaj pierwsze CV</a>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th style="width: 22%;">Kandydat</th>
                            <th style="width: 14%;">Kontakt</th>
                            <th style="width: 10%;">Miejscowość</th>
                            <th style="width: 10%;">Prawo jazdy</th>
                            <th style="width: 8%;">Wózki</th>
                            <th style="width: 12%;">Status</th>
                            <th style="width: 12%;">Dodano</th>
                            <th style="width: 12%;">Akcje</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($kandydaci as $k): 
                            $statusInfo = $statusy[$k['status']] ?? $statusy['nowy'];
                        ?>
                        <tr>
                            <td>
                                <div class="kandydat-nazwa">
                                    <a href="karta.php?id=<?= $k['id'] ?>">
                                        <?= htmlspecialchars($k['imie'] . ' ' . $k['nazwisko']) ?>
                                    </a>
                                </div>
                                <?php if ($k['data_urodzenia']): ?>
                                <div class="kandydat-meta">
                                    🎂 <?= formatDate($k['data_urodzenia']) ?>
                                    <?php 
                                    $wiek = floor((time() - strtotime($k['data_urodzenia'])) / (365.25 * 24 * 60 * 60));
                                    echo "($wiek lat)";
                                    ?>
                                </div>
                                <?php endif; ?>
                                <?php if ($k['ogloszenie_tytul']): ?>
                                <div class="kandydat-meta" style="color: #7c3aed;">
                                    📢 <?= htmlspecialchars($k['ogloszenie_tytul']) ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($k['telefon']): ?>
                                    <div><a href="tel:<?= $k['telefon'] ?>" class="mono"><?= htmlspecialchars($k['telefon']) ?></a></div>
                                <?php endif; ?>
                                <?php if ($k['email']): ?>
                                    <div style="font-size: 0.8rem;"><a href="mailto:<?= $k['email'] ?>"><?= htmlspecialchars($k['email']) ?></a></div>
                                <?php endif; ?>
                                <?php if (!$k['telefon'] && !$k['email']): ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($k['miejscowosc'] ?: '-') ?></td>
                            <td>
                                <?php if ($k['prawo_jazdy']): ?>
                                    <span class="mono"><?= htmlspecialchars($k['prawo_jazdy']) ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($k['wozki_widlowe']): ?>
                                    <span class="wozki-badge tak">🚜 Tak</span>
                                <?php else: ?>
                                    <span class="wozki-badge nie">Nie</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge" style="background: <?= $statusInfo['bg'] ?>; color: <?= $statusInfo['color'] ?>;">
                                    <?= $statusInfo['icon'] ?> <?= $statusInfo['label'] ?>
                                </span>
                            </td>
                            <td>
                                <div><?= date('d.m.Y', strtotime($k['created_at'])) ?></div>
                                <div style="font-size: 0.75rem; color: #64748b;"><?= htmlspecialchars($k['dodany_przez'] ?? 'System') ?></div>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-primary" onclick="quickTask(<?= $k['id'] ?>, '<?= htmlspecialchars($k['imie'] . ' ' . $k['nazwisko'], ENT_QUOTES) ?>')">📞</button>
                                <a href="karta.php?id=<?= $k['id'] ?>" class="btn btn-sm">👁️</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
        
        <!-- PAGINACJA -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>">← Poprz.</a>
            <?php endif; ?>
            
            <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            
            <?php if ($page < $totalPages): ?>
                <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>">Nast. →</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- MODAL: Nowe zadanie -->
    <div class="modal" id="modal-task">
        <div class="modal-content">
            <div class="modal-header">
                <h3>📞 Zaplanuj kontakt</h3>
                <button class="modal-close" onclick="hideModal('modal-task')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="quick_task" value="1">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Kandydat *</label>
                        <select name="kandydat_id" id="task_kandydat" required>
                            <option value="">-- Wybierz --</option>
                            <?php 
                            $allKandydaci = $db->query("SELECT id, imie, nazwisko FROM kandydaci WHERE status NOT IN ('zatrudniony', 'odrzucony') ORDER BY nazwisko")->fetchAll();
                            foreach ($allKandydaci as $kand): ?>
                                <option value="<?= $kand['id'] ?>"><?= htmlspecialchars($kand['imie'] . ' ' . $kand['nazwisko']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Typ kontaktu</label>
                        <select name="typ">
                            <?php foreach ($zadaniaTypy as $key => $t): ?>
                                <option value="<?= $key ?>"><?= $t['icon'] ?> <?= $t['label'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Temat / notatka *</label>
                        <input type="text" name="tytul" id="task_tytul" placeholder="np. Pierwszy kontakt, Ustalenie terminu rozmowy..." required>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Data</label>
                            <input type="date" name="termin_data" value="<?= date('Y-m-d') ?>">
                        </div>
                        <div class="form-group">
                            <label>Godzina</label>
                            <input type="time" name="termin_godzina">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Przypisz do</label>
                        <select name="przypisany_do">
                            <?php foreach ($users as $u): ?>
                                <option value="<?= $u['id'] ?>" <?= $u['id'] == $currentUser['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="hideModal('modal-task')">Anuluj</button>
                    <button type="submit" class="btn btn-primary">📅 Zaplanuj</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- MODAL: Zakończ zadanie -->
    <div class="modal" id="modal-complete">
        <div class="modal-content">
            <div class="modal-header">
                <h3>✅ Zakończ zadanie</h3>
                <button class="modal-close" onclick="hideModal('modal-complete')">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="complete_task" value="1">
                <input type="hidden" name="task_id" id="complete_task_id">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Wynik kontaktu</label>
                        <select name="nowy_status">
                            <option value="wykonane">✅ Wykonane - rozmowa odbyła się</option>
                            <option value="nieodbiera">📵 Nie odbiera</option>
                            <option value="oddzwoni">🔄 Oddzwoni / Przełożone</option>
                            <option value="anulowane">❌ Anulowane</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Notatka z rozmowy</label>
                        <textarea name="wynik" rows="4" placeholder="Opisz przebieg rozmowy, ustalenia..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="hideModal('modal-complete')">Anuluj</button>
                    <button type="submit" class="btn btn-success">💾 Zapisz</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
    function showModal(id) { document.getElementById(id).classList.add('active'); }
    function hideModal(id) { document.getElementById(id).classList.remove('active'); }
    
    function quickTask(kandydatId, nazwa) {
        document.getElementById('task_kandydat').value = kandydatId;
        document.getElementById('task_tytul').value = 'Kontakt z: ' + nazwa;
        showModal('modal-task');
    }
    
    function completeTask(taskId) {
        document.getElementById('complete_task_id').value = taskId;
        showModal('modal-complete');
    }
    
    // Zamknij modal klikając poza nim
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) hideModal(this.id);
        });
    });
    </script>
</body>
</html>
