<?php
/**
 * Moduł Kandydatów - Raport listy kandydatów
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$statusy = getKandydatStatusy();
$kategorieJazdy = getKategorieJazdy();

// Pobierz użytkowników
$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();

// Pobierz ogłoszenia
$ogloszenia = $db->query("SELECT id, tytul FROM ogloszenia ORDER BY status = 'aktywne' DESC, created_at DESC")->fetchAll();

// Filtry
$search = trim($_GET['search'] ?? '');
$status = $_GET['status'] ?? '';
$ogloszenie = $_GET['ogloszenie'] ?? '';
$wozki = $_GET['wozki'] ?? '';
$prawoJazdy = $_GET['prawo_jazdy'] ?? '';
$dataOd = $_GET['data_od'] ?? '';
$dataDo = $_GET['data_do'] ?? '';
$rekruter = $_GET['rekruter'] ?? '';
$sortBy = $_GET['sort'] ?? 'created_at';
$sortDir = $_GET['dir'] ?? 'DESC';

// Buduj zapytanie
$where = ['1=1'];
$params = [];

if ($search) {
    $where[] = "(k.imie LIKE ? OR k.nazwisko LIKE ? OR k.email LIKE ? OR k.telefon LIKE ? OR k.miejscowosc LIKE ?)";
    $searchParam = "%$search%";
    $params = array_merge($params, [$searchParam, $searchParam, $searchParam, $searchParam, $searchParam]);
}

if ($status) {
    $where[] = "k.status = ?";
    $params[] = $status;
}

if ($ogloszenie) {
    if ($ogloszenie === 'brak') {
        $where[] = "k.ogloszenie_id IS NULL";
    } else {
        $where[] = "k.ogloszenie_id = ?";
        $params[] = intval($ogloszenie);
    }
}

if ($wozki === '1') {
    $where[] = "k.wozki_widlowe = 1";
} elseif ($wozki === '0') {
    $where[] = "k.wozki_widlowe = 0";
}

if ($prawoJazdy) {
    $where[] = "k.prawo_jazdy LIKE ?";
    $params[] = "%$prawoJazdy%";
}

if ($dataOd) {
    $where[] = "DATE(k.created_at) >= ?";
    $params[] = $dataOd;
}

if ($dataDo) {
    $where[] = "DATE(k.created_at) <= ?";
    $params[] = $dataDo;
}

if ($rekruter) {
    $where[] = "k.created_by = ?";
    $params[] = $rekruter;
}

$whereClause = implode(' AND ', $where);

// Dozwolone kolumny sortowania
$allowedSorts = ['created_at', 'nazwisko', 'status', 'miejscowosc', 'updated_at'];
$sortBy = in_array($sortBy, $allowedSorts) ? $sortBy : 'created_at';
$sortDir = strtoupper($sortDir) === 'ASC' ? 'ASC' : 'DESC';

// Pobierz kandydatów
$stmt = $db->prepare("
    SELECT k.*, 
           u.name as dodany_przez,
           o.tytul as ogloszenie_tytul,
           (SELECT COUNT(*) FROM kandydaci_zadania z WHERE z.kandydat_id = k.id) as liczba_kontaktow,
           (SELECT MAX(z.termin_data) FROM kandydaci_zadania z WHERE z.kandydat_id = k.id) as ostatni_kontakt
    FROM kandydaci k
    LEFT JOIN users u ON k.created_by = u.id
    LEFT JOIN ogloszenia o ON k.ogloszenie_id = o.id
    WHERE $whereClause
    ORDER BY k.$sortBy $sortDir
");
$stmt->execute($params);
$kandydaci = $stmt->fetchAll();

// Statystyki
$statsQuery = $db->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'nowy' THEN 1 ELSE 0 END) as nowi,
        SUM(CASE WHEN status = 'w_kontakcie' THEN 1 ELSE 0 END) as w_kontakcie,
        SUM(CASE WHEN status = 'rozmowa' THEN 1 ELSE 0 END) as rozmowa,
        SUM(CASE WHEN status = 'oferta' THEN 1 ELSE 0 END) as oferta,
        SUM(CASE WHEN status = 'zatrudniony' THEN 1 ELSE 0 END) as zatrudnieni,
        SUM(CASE WHEN status = 'odrzucony' THEN 1 ELSE 0 END) as odrzuceni,
        SUM(CASE WHEN wozki_widlowe = 1 THEN 1 ELSE 0 END) as z_wozkami
    FROM kandydaci
");
$stats = $statsQuery->fetch();

// Export CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="lista_kandydatow_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    fputcsv($output, [
        'ID', 'Imię', 'Nazwisko', 'Email', 'Telefon', 'Data urodzenia', 'Miejscowość',
        'Prawo jazdy', 'Wózki widłowe', 'Status', 'Ogłoszenie', 'Liczba kontaktów',
        'Ostatni kontakt', 'Notatki', 'Dodano', 'Dodał'
    ], ';');
    
    foreach ($kandydaci as $k) {
        $statusInfo = $statusy[$k['status']] ?? ['label' => $k['status']];
        
        fputcsv($output, [
            $k['id'],
            $k['imie'],
            $k['nazwisko'],
            $k['email'],
            $k['telefon'],
            $k['data_urodzenia'] ? date('d.m.Y', strtotime($k['data_urodzenia'])) : '',
            $k['miejscowosc'],
            $k['prawo_jazdy'],
            $k['wozki_widlowe'] ? 'Tak' : 'Nie',
            $statusInfo['label'],
            $k['ogloszenie_tytul'],
            $k['liczba_kontaktow'],
            $k['ostatni_kontakt'] ? date('d.m.Y', strtotime($k['ostatni_kontakt'])) : '',
            $k['notatki'],
            date('d.m.Y', strtotime($k['created_at'])),
            $k['dodany_przez']
        ], ';');
    }
    
    fclose($output);
    exit;
}

// Export Excel-ready (HTML table)
if (isset($_GET['export']) && $_GET['export'] === 'excel') {
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="lista_kandydatow_' . date('Y-m-d') . '.xls"');
    
    echo '<html><head><meta charset="utf-8"></head><body>';
    echo '<table border="1">';
    echo '<tr><th>ID</th><th>Imię</th><th>Nazwisko</th><th>Email</th><th>Telefon</th><th>Miejscowość</th><th>Prawo jazdy</th><th>Wózki</th><th>Status</th><th>Ogłoszenie</th><th>Kontakty</th><th>Ostatni kontakt</th><th>Dodano</th></tr>';
    
    foreach ($kandydaci as $k) {
        $statusInfo = $statusy[$k['status']] ?? ['label' => $k['status']];
        echo '<tr>';
        echo '<td>' . $k['id'] . '</td>';
        echo '<td>' . htmlspecialchars($k['imie']) . '</td>';
        echo '<td>' . htmlspecialchars($k['nazwisko']) . '</td>';
        echo '<td>' . htmlspecialchars($k['email']) . '</td>';
        echo '<td>' . htmlspecialchars($k['telefon']) . '</td>';
        echo '<td>' . htmlspecialchars($k['miejscowosc']) . '</td>';
        echo '<td>' . htmlspecialchars($k['prawo_jazdy']) . '</td>';
        echo '<td>' . ($k['wozki_widlowe'] ? 'Tak' : 'Nie') . '</td>';
        echo '<td>' . $statusInfo['label'] . '</td>';
        echo '<td>' . htmlspecialchars($k['ogloszenie_tytul']) . '</td>';
        echo '<td>' . $k['liczba_kontaktow'] . '</td>';
        echo '<td>' . ($k['ostatni_kontakt'] ? date('d.m.Y', strtotime($k['ostatni_kontakt'])) : '-') . '</td>';
        echo '<td>' . date('d.m.Y', strtotime($k['created_at'])) . '</td>';
        echo '</tr>';
    }
    
    echo '</table></body></html>';
    exit;
}

$printMode = isset($_GET['print']);
$hasFilters = $search || $status || $ogloszenie || $wozki !== '' || $prawoJazdy || $dataOd || $dataDo || $rekruter;

// Funkcja sortowania
function sortUrl($column) {
    global $sortBy, $sortDir;
    $newDir = ($sortBy === $column && $sortDir === 'ASC') ? 'DESC' : 'ASC';
    $params = array_merge($_GET, ['sort' => $column, 'dir' => $newDir]);
    return '?' . http_build_query($params);
}

function sortIcon($column) {
    global $sortBy, $sortDir;
    if ($sortBy !== $column) return '';
    return $sortDir === 'ASC' ? ' ↑' : ' ↓';
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista kandydatów <?= $printMode ? '- Druk' : '' ?> - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 1600px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #7c3aed; color: white; }
        
        header { margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        .subtitle { color: #64748b; margin: 0; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; display: flex; justify-content: space-between; align-items: center; }
        
        .filters-card { background: white; padding: 18px 22px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); }
        .filters-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.8rem; color: #64748b; font-weight: 600; }
        .filter-group select, .filter-group input { padding: 10px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; min-width: 130px; }
        
        .btn { padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-success { background: #16a34a; color: white; }
        .btn-secondary { background: #f1f5f9; color: #374151; }
        
        .stats-bar { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 25px; }
        .stat-box { background: white; padding: 15px; border-radius: 10px; min-width: 100px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); text-align: center; }
        .stat-box .value { font-size: 1.5rem; font-weight: 700; }
        .stat-box .label { font-size: 0.75rem; color: #64748b; margin-top: 4px; }
        
        table { width: 100%; border-collapse: collapse; font-size: 0.9rem; }
        th { text-align: left; padding: 12px 10px; background: #f8fafc; color: #64748b; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; white-space: nowrap; }
        th a { color: #64748b; text-decoration: none; }
        th a:hover { color: #2563eb; }
        td { padding: 10px; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        tr:hover { background: #f8fafc; }
        
        .badge { display: inline-block; padding: 3px 8px; border-radius: 5px; font-size: 0.7rem; font-weight: 600; }
        
        .kandydat-link { color: #1e293b; font-weight: 600; text-decoration: none; }
        .kandydat-link:hover { color: #2563eb; }
        
        .contact-info { font-size: 0.8rem; }
        .contact-info a { color: #2563eb; text-decoration: none; }
        
        .mono { font-family: monospace; font-size: 0.85rem; }
        
        .wozki-tak { background: #dcfce7; color: #166534; padding: 2px 8px; border-radius: 4px; font-size: 0.75rem; }
        .wozki-nie { color: #94a3b8; font-size: 0.75rem; }
        
        .export-buttons { display: flex; gap: 8px; }
        
        @media print {
            body { background: white !important; font-size: 10pt; }
            .top-nav, .filters-card, .no-print, .export-buttons { display: none !important; }
            .container { max-width: 100%; padding: 5px; }
            .card { box-shadow: none; border: 1px solid #ddd; }
            .stat-box { box-shadow: none; border: 1px solid #ddd; padding: 8px; min-width: 80px; }
            .stat-box .value { font-size: 1.2rem; }
            table { font-size: 8pt; }
            th, td { padding: 5px 4px; }
            header h1 { font-size: 1.2rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!$printMode): ?>
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../crm/">🎯 CRM</a>
                <a href="./">👥 Kandydaci</a>
                <a href="ogloszenia.php">📢 Ogłoszenia</a>
                <a href="raport.php">📊 Statystyki</a>
                <a href="raport_kontakty.php">📞 Kontakty</a>
                <a href="raport_kandydaci.php" class="active">📋 Lista</a>
            </div>
        </nav>
        <?php endif; ?>
        
        <header>
            <div>
                <h1>📋 Lista kandydatów</h1>
                <p class="subtitle">Znaleziono: <?= count($kandydaci) ?> kandydatów<?= $hasFilters ? ' (filtrowanie aktywne)' : '' ?></p>
            </div>
            <div class="header-actions no-print export-buttons">
                <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="btn btn-success">📥 CSV</a>
                <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'excel'])) ?>" class="btn btn-success">📊 Excel</a>
                <button onclick="window.print()" class="btn btn-secondary">🖨️ Drukuj</button>
            </div>
        </header>
        
        <?php if (!$printMode): ?>
        <div class="filters-card no-print">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group">
                        <label>🔍 Szukaj</label>
                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="imię, nazwisko, email...">
                    </div>
                    <div class="filter-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">-- wszystkie --</option>
                            <?php foreach ($statusy as $key => $s): ?>
                                <option value="<?= $key ?>" <?= $status === $key ? 'selected' : '' ?>><?= $s['icon'] ?> <?= $s['label'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Ogłoszenie</label>
                        <select name="ogloszenie">
                            <option value="">-- wszystkie --</option>
                            <option value="brak" <?= $ogloszenie === 'brak' ? 'selected' : '' ?>>🚫 Bez ogłoszenia</option>
                            <?php foreach ($ogloszenia as $og): ?>
                                <option value="<?= $og['id'] ?>" <?= $ogloszenie == $og['id'] ? 'selected' : '' ?>><?= htmlspecialchars($og['tytul']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Wózki widłowe</label>
                        <select name="wozki">
                            <option value="">-- wszystkie --</option>
                            <option value="1" <?= $wozki === '1' ? 'selected' : '' ?>>✅ Tak</option>
                            <option value="0" <?= $wozki === '0' ? 'selected' : '' ?>>❌ Nie</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Prawo jazdy</label>
                        <select name="prawo_jazdy">
                            <option value="">-- wszystkie --</option>
                            <?php foreach ($kategorieJazdy as $kat): ?>
                                <option value="<?= $kat ?>" <?= $prawoJazdy === $kat ? 'selected' : '' ?>><?= $kat ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Dodano od</label>
                        <input type="date" name="data_od" value="<?= $dataOd ?>">
                    </div>
                    <div class="filter-group">
                        <label>Dodano do</label>
                        <input type="date" name="data_do" value="<?= $dataDo ?>">
                    </div>
                    <div class="filter-group">
                        <label>Dodał</label>
                        <select name="rekruter">
                            <option value="">-- wszyscy --</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?= $u['id'] ?>" <?= $rekruter == $u['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">Filtruj</button>
                        <?php if ($hasFilters): ?>
                            <a href="raport_kandydaci.php" class="btn btn-secondary">✕</a>
                        <?php endif; ?>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>
        
        <!-- STATYSTYKI -->
        <div class="stats-bar">
            <div class="stat-box">
                <div class="value" style="color: #1e293b;"><?= $stats['total'] ?></div>
                <div class="label">Łącznie</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #0891b2;"><?= $stats['nowi'] ?></div>
                <div class="label">📥 Nowi</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #2563eb;"><?= $stats['w_kontakcie'] ?></div>
                <div class="label">📞 W kontakcie</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #7c3aed;"><?= $stats['rozmowa'] ?></div>
                <div class="label">🗣️ Rozmowa</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #d97706;"><?= $stats['oferta'] ?></div>
                <div class="label">📋 Oferta</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #16a34a;"><?= $stats['zatrudnieni'] ?></div>
                <div class="label">✅ Zatrudnieni</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #dc2626;"><?= $stats['odrzuceni'] ?></div>
                <div class="label">❌ Odrzuceni</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #059669;"><?= $stats['z_wozkami'] ?></div>
                <div class="label">🚜 Z wózkami</div>
            </div>
        </div>
        
        <!-- LISTA KANDYDATÓW -->
        <div class="card">
            <div class="card-header">
                <span>📋 Lista kandydatów (<?= count($kandydaci) ?>)</span>
            </div>
            
            <?php if (empty($kandydaci)): ?>
                <div style="padding: 40px; text-align: center; color: #64748b;">
                    Brak kandydatów spełniających kryteria
                </div>
            <?php else: ?>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th><a href="<?= sortUrl('nazwisko') ?>">Kandydat<?= sortIcon('nazwisko') ?></a></th>
                                <th>Kontakt</th>
                                <th><a href="<?= sortUrl('miejscowosc') ?>">Miejscowość<?= sortIcon('miejscowosc') ?></a></th>
                                <th>Prawo jazdy</th>
                                <th>Wózki</th>
                                <th><a href="<?= sortUrl('status') ?>">Status<?= sortIcon('status') ?></a></th>
                                <th>Ogłoszenie</th>
                                <th>Kontakty</th>
                                <th><a href="<?= sortUrl('created_at') ?>">Dodano<?= sortIcon('created_at') ?></a></th>
                                <th class="no-print">Akcje</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($kandydaci as $k): 
                                $statusInfo = $statusy[$k['status']] ?? $statusy['nowy'];
                            ?>
                            <tr>
                                <td>
                                    <a href="karta.php?id=<?= $k['id'] ?>" class="kandydat-link">
                                        <?= htmlspecialchars($k['imie'] . ' ' . $k['nazwisko']) ?>
                                    </a>
                                    <?php if ($k['data_urodzenia']): ?>
                                        <br><small style="color: #64748b;">🎂 <?= date('d.m.Y', strtotime($k['data_urodzenia'])) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="contact-info">
                                    <?php if ($k['telefon']): ?>
                                        <a href="tel:<?= $k['telefon'] ?>" class="mono"><?= htmlspecialchars($k['telefon']) ?></a>
                                    <?php endif; ?>
                                    <?php if ($k['email']): ?>
                                        <br><a href="mailto:<?= $k['email'] ?>"><?= htmlspecialchars($k['email']) ?></a>
                                    <?php endif; ?>
                                </td>
                                <td><?= htmlspecialchars($k['miejscowosc'] ?: '-') ?></td>
                                <td class="mono"><?= htmlspecialchars($k['prawo_jazdy'] ?: '-') ?></td>
                                <td>
                                    <?php if ($k['wozki_widlowe']): ?>
                                        <span class="wozki-tak">🚜 Tak</span>
                                    <?php else: ?>
                                        <span class="wozki-nie">Nie</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="badge" style="background: <?= $statusInfo['bg'] ?>; color: <?= $statusInfo['color'] ?>;">
                                        <?= $statusInfo['icon'] ?> <?= $statusInfo['label'] ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($k['ogloszenie_tytul']): ?>
                                        <small style="color: #7c3aed;"><?= htmlspecialchars($k['ogloszenie_tytul']) ?></small>
                                    <?php else: ?>
                                        <span style="color: #94a3b8;">-</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: center;">
                                    <strong><?= $k['liczba_kontaktow'] ?></strong>
                                    <?php if ($k['ostatni_kontakt']): ?>
                                        <br><small style="color: #64748b;"><?= date('d.m', strtotime($k['ostatni_kontakt'])) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?= date('d.m.Y', strtotime($k['created_at'])) ?>
                                    <?php if ($k['dodany_przez']): ?>
                                        <br><small style="color: #64748b;"><?= htmlspecialchars($k['dodany_przez']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td class="no-print">
                                    <a href="karta.php?id=<?= $k['id'] ?>" class="btn btn-secondary" style="padding: 5px 10px; font-size: 0.8rem;">👁️</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="no-print" style="text-align: center; padding: 20px; color: #94a3b8; font-size: 0.85rem;">
            Wygenerowano: <?= date('d.m.Y H:i') ?>
        </div>
    </div>
</body>
</html>
