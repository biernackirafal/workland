<?php
/**
 * Moduł Kandydatów - Raport kontaktów
 * System Ewidencji Pracowników - Work Land
 */

require_once '../includes/db.php';
$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$zadaniaTypy = getKandydatZadaniaTypy();
$zadaniaStatusy = getKandydatZadaniaStatusy();

// Pobierz użytkowników
$users = $db->query("SELECT id, name FROM users WHERE active = 1 ORDER BY name")->fetchAll();

// Filtry
$dataOd = $_GET['data_od'] ?? date('Y-m-01'); // Domyślnie początek miesiąca
$dataDo = $_GET['data_do'] ?? date('Y-m-d');
$rekruter = $_GET['rekruter'] ?? '';
$statusFilter = $_GET['status'] ?? '';
$typFilter = $_GET['typ'] ?? '';

// Buduj zapytanie
$where = ["z.termin_data BETWEEN ? AND ?"];
$params = [$dataOd, $dataDo];

if ($rekruter) {
    $where[] = "z.przypisany_do = ?";
    $params[] = $rekruter;
}

if ($statusFilter) {
    $where[] = "z.status = ?";
    $params[] = $statusFilter;
}

if ($typFilter) {
    $where[] = "z.typ = ?";
    $params[] = $typFilter;
}

$whereClause = implode(' AND ', $where);

// Pobierz kontakty
$stmt = $db->prepare("
    SELECT z.*, 
           k.imie, k.nazwisko, k.telefon, k.email, k.status as kandydat_status,
           u.name as rekruter_nazwa,
           uc.name as utworzyl_nazwa
    FROM kandydaci_zadania z
    JOIN kandydaci k ON z.kandydat_id = k.id
    LEFT JOIN users u ON z.przypisany_do = u.id
    LEFT JOIN users uc ON z.created_by = uc.id
    WHERE $whereClause
    ORDER BY z.termin_data DESC, z.termin_godzina DESC
");
$stmt->execute($params);
$kontakty = $stmt->fetchAll();

// Statystyki ogólne
$statsQuery = $db->prepare("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN z.status = 'wykonane' THEN 1 ELSE 0 END) as wykonane,
        SUM(CASE WHEN z.status = 'nieodbiera' THEN 1 ELSE 0 END) as nieodbiera,
        SUM(CASE WHEN z.status = 'oddzwoni' THEN 1 ELSE 0 END) as oddzwoni,
        SUM(CASE WHEN z.status = 'zaplanowane' THEN 1 ELSE 0 END) as zaplanowane,
        SUM(CASE WHEN z.status = 'anulowane' THEN 1 ELSE 0 END) as anulowane
    FROM kandydaci_zadania z
    WHERE z.termin_data BETWEEN ? AND ?
");
$statsQuery->execute([$dataOd, $dataDo]);
$stats = $statsQuery->fetch();

// Statystyki per rekruter
$statsPerRekruter = $db->prepare("
    SELECT 
        u.name as rekruter,
        COUNT(*) as total,
        SUM(CASE WHEN z.status = 'wykonane' THEN 1 ELSE 0 END) as wykonane,
        SUM(CASE WHEN z.status = 'nieodbiera' THEN 1 ELSE 0 END) as nieodbiera,
        SUM(CASE WHEN z.status = 'oddzwoni' THEN 1 ELSE 0 END) as oddzwoni
    FROM kandydaci_zadania z
    JOIN users u ON z.przypisany_do = u.id
    WHERE z.termin_data BETWEEN ? AND ?
    GROUP BY z.przypisany_do
    ORDER BY total DESC
");
$statsPerRekruter->execute([$dataOd, $dataDo]);
$rekruterStats = $statsPerRekruter->fetchAll();

// Statystyki per typ
$statsPerTyp = $db->prepare("
    SELECT 
        z.typ,
        COUNT(*) as total,
        SUM(CASE WHEN z.status = 'wykonane' THEN 1 ELSE 0 END) as wykonane
    FROM kandydaci_zadania z
    WHERE z.termin_data BETWEEN ? AND ?
    GROUP BY z.typ
    ORDER BY total DESC
");
$statsPerTyp->execute([$dataOd, $dataDo]);
$typStats = $statsPerTyp->fetchAll();

// Export CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="raport_kontaktow_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM dla UTF-8
    
    fputcsv($output, ['Data', 'Godzina', 'Kandydat', 'Telefon', 'Typ', 'Temat', 'Status', 'Wynik/Notatka', 'Rekruter'], ';');
    
    foreach ($kontakty as $k) {
        $statusInfo = $zadaniaStatusy[$k['status']] ?? ['label' => $k['status']];
        $typInfo = $zadaniaTypy[$k['typ']] ?? ['label' => $k['typ']];
        
        fputcsv($output, [
            date('d.m.Y', strtotime($k['termin_data'])),
            $k['termin_godzina'] ? substr($k['termin_godzina'], 0, 5) : '',
            $k['imie'] . ' ' . $k['nazwisko'],
            $k['telefon'],
            $typInfo['label'],
            $k['tytul'],
            $statusInfo['label'],
            $k['wynik'],
            $k['rekruter_nazwa']
        ], ';');
    }
    
    fclose($output);
    exit;
}

$hasFilters = $rekruter || $statusFilter || $typFilter;
$kandydatStatusy = getKandydatStatusy();
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raport kontaktów - Kandydaci - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        .nav-links { display: flex; gap: 8px; flex-wrap: wrap; }
        .nav-links a { padding: 8px 14px; border-radius: 6px; text-decoration: none; color: #475569; font-size: 0.9rem; }
        .nav-links a:hover { background: #f1f5f9; }
        .nav-links a.active { background: #2563eb; color: white; }
        
        header { margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
        header h1 { margin: 0 0 5px 0; font-size: 1.8rem; color: #1e293b; }
        .subtitle { color: #64748b; margin: 0; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 20px; }
        
        .filters-card { background: white; padding: 18px 22px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); }
        .filters-row { display: flex; gap: 12px; flex-wrap: wrap; align-items: flex-end; }
        .filter-group { display: flex; flex-direction: column; gap: 5px; }
        .filter-group label { font-size: 0.8rem; color: #64748b; font-weight: 600; }
        .filter-group select, .filter-group input { padding: 10px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; min-width: 150px; }
        .filter-group select:focus, .filter-group input:focus { border-color: #2563eb; outline: none; }
        
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 15px; margin-bottom: 25px; }
        .stat-box { background: white; padding: 18px 20px; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.05); text-align: center; }
        .stat-box .value { font-size: 2rem; font-weight: 700; }
        .stat-box .label { font-size: 0.85rem; color: #64748b; margin-top: 5px; }
        
        .stats-table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .stats-table th, .stats-table td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
        .stats-table th { background: #f8fafc; font-weight: 600; font-size: 0.85rem; color: #475569; }
        .stats-table tr:hover { background: #f8fafc; }
        
        .badge { display: inline-flex; align-items: center; gap: 4px; padding: 4px 10px; border-radius: 50px; font-size: 0.75rem; font-weight: 600; }
        
        table.main-table { width: 100%; border-collapse: collapse; }
        table.main-table th { padding: 12px 10px; text-align: left; background: #f1f5f9; font-weight: 700; font-size: 0.75rem; color: #475569; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #e2e8f0; }
        table.main-table td { padding: 12px 10px; border-bottom: 1px solid #f1f5f9; font-size: 0.9rem; }
        table.main-table tr:hover { background: #f8fafc; }
        
        .btn { padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 500; font-size: 0.9rem; display: inline-flex; align-items: center; gap: 6px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-primary:hover { background: #1d4ed8; }
        .btn-success { background: #16a34a; color: white; }
        .btn-success:hover { background: #15803d; }
        
        .wynik-text { font-size: 0.85rem; color: #475569; max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        
        .row-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        
        @media (max-width: 768px) {
            .filters-row { flex-direction: column; }
            .filter-group { width: 100%; }
            .row-grid { grid-template-columns: 1fr; }
            table { font-size: 0.85rem; }
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
                <div class="user-info">👤 <?= sanitize($currentUser['name']) ?></div>
            </div>
            <div class="nav-links">
                <a href="../index.php">📋 Pracownicy</a>
                <a href="../crm/">🎯 CRM</a>
                <a href="./">👥 Kandydaci</a>
                <a href="raport.php" class="active">📊 Raport</a>
                <a href="../logout.php">🚪 Wyloguj</a>
            </div>
        </nav>
        
        <header>
            <div>
                <h1>📊 Raport kontaktów</h1>
                <p class="subtitle">Analiza obdzwonienia kandydatów</p>
            </div>
            <div>
                <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'csv'])) ?>" class="btn btn-success">📥 Eksport CSV</a>
            </div>
        </header>
        
        <!-- FILTRY -->
        <div class="filters-card">
            <form method="GET">
                <div class="filters-row">
                    <div class="filter-group">
                        <label>📅 Od daty</label>
                        <input type="date" name="data_od" value="<?= $dataOd ?>">
                    </div>
                    <div class="filter-group">
                        <label>📅 Do daty</label>
                        <input type="date" name="data_do" value="<?= $dataDo ?>">
                    </div>
                    <div class="filter-group">
                        <label>👤 Rekruter</label>
                        <select name="rekruter">
                            <option value="">-- Wszyscy --</option>
                            <?php foreach ($users as $u): ?>
                                <option value="<?= $u['id'] ?>" <?= $rekruter == $u['id'] ? 'selected' : '' ?>><?= htmlspecialchars($u['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="">-- Wszystkie --</option>
                            <?php foreach ($zadaniaStatusy as $key => $s): ?>
                                <option value="<?= $key ?>" <?= $statusFilter === $key ? 'selected' : '' ?>><?= $s['icon'] ?> <?= $s['label'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label>Typ</label>
                        <select name="typ">
                            <option value="">-- Wszystkie --</option>
                            <?php foreach ($zadaniaTypy as $key => $t): ?>
                                <option value="<?= $key ?>" <?= $typFilter === $key ? 'selected' : '' ?>><?= $t['icon'] ?> <?= $t['label'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="filter-group">
                        <button type="submit" class="btn btn-primary">📊 Generuj</button>
                    </div>
                </div>
            </form>
        </div>
        
        <!-- STATYSTYKI GŁÓWNE -->
        <div class="stats-grid">
            <div class="stat-box">
                <div class="value" style="color: #1e293b;"><?= $stats['total'] ?></div>
                <div class="label">📋 Łącznie kontaktów</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #16a34a;"><?= $stats['wykonane'] ?></div>
                <div class="label">✅ Wykonane</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #d97706;"><?= $stats['nieodbiera'] ?></div>
                <div class="label">📵 Nie odbiera</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #7c3aed;"><?= $stats['oddzwoni'] ?></div>
                <div class="label">🔄 Oddzwoni</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #2563eb;"><?= $stats['zaplanowane'] ?></div>
                <div class="label">📅 Zaplanowane</div>
            </div>
            <div class="stat-box">
                <div class="value" style="color: #dc2626;"><?= $stats['anulowane'] ?></div>
                <div class="label">❌ Anulowane</div>
            </div>
        </div>
        
        <!-- STATYSTYKI SZCZEGÓŁOWE -->
        <div class="row-grid">
            <!-- Per rekruter -->
            <div class="card">
                <div class="card-header">👥 Statystyki per rekruter</div>
                <div class="card-body">
                    <?php if (empty($rekruterStats)): ?>
                        <p style="color: #64748b; text-align: center;">Brak danych</p>
                    <?php else: ?>
                        <table class="stats-table">
                            <thead>
                                <tr>
                                    <th>Rekruter</th>
                                    <th>Łącznie</th>
                                    <th>Wykonane</th>
                                    <th>Nie odbiera</th>
                                    <th>Skuteczność</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rekruterStats as $rs): 
                                    $skutecznosc = $rs['total'] > 0 ? round(($rs['wykonane'] / $rs['total']) * 100) : 0;
                                ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($rs['rekruter']) ?></strong></td>
                                    <td><?= $rs['total'] ?></td>
                                    <td style="color: #16a34a;"><?= $rs['wykonane'] ?></td>
                                    <td style="color: #d97706;"><?= $rs['nieodbiera'] ?></td>
                                    <td>
                                        <span class="badge" style="background: <?= $skutecznosc >= 70 ? '#dcfce7' : ($skutecznosc >= 40 ? '#fef3c7' : '#fee2e2') ?>; color: <?= $skutecznosc >= 70 ? '#166534' : ($skutecznosc >= 40 ? '#92400e' : '#991b1b') ?>;">
                                            <?= $skutecznosc ?>%
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Per typ -->
            <div class="card">
                <div class="card-header">📋 Statystyki per typ kontaktu</div>
                <div class="card-body">
                    <?php if (empty($typStats)): ?>
                        <p style="color: #64748b; text-align: center;">Brak danych</p>
                    <?php else: ?>
                        <table class="stats-table">
                            <thead>
                                <tr>
                                    <th>Typ</th>
                                    <th>Łącznie</th>
                                    <th>Wykonane</th>
                                    <th>Skuteczność</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($typStats as $ts): 
                                    $typInfo = $zadaniaTypy[$ts['typ']] ?? ['icon' => '📋', 'label' => $ts['typ']];
                                    $skutecznosc = $ts['total'] > 0 ? round(($ts['wykonane'] / $ts['total']) * 100) : 0;
                                ?>
                                <tr>
                                    <td><?= $typInfo['icon'] ?> <?= $typInfo['label'] ?></td>
                                    <td><?= $ts['total'] ?></td>
                                    <td style="color: #16a34a;"><?= $ts['wykonane'] ?></td>
                                    <td><?= $skutecznosc ?>%</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- LISTA KONTAKTÓW -->
        <div class="card">
            <div class="card-header">
                📋 Lista kontaktów (<?= count($kontakty) ?>)
            </div>
            
            <?php if (empty($kontakty)): ?>
                <div style="padding: 40px; text-align: center; color: #64748b;">
                    Brak kontaktów w wybranym okresie
                </div>
            <?php else: ?>
                <table class="main-table">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Kandydat</th>
                            <th>Telefon</th>
                            <th>Typ</th>
                            <th>Temat</th>
                            <th>Status</th>
                            <th>Wynik</th>
                            <th>Rekruter</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($kontakty as $k): 
                            $statusInfo = $zadaniaStatusy[$k['status']] ?? $zadaniaStatusy['zaplanowane'];
                            $typInfo = $zadaniaTypy[$k['typ']] ?? $zadaniaTypy['telefon'];
                            $kandydatStatus = $kandydatStatusy[$k['kandydat_status']] ?? null;
                        ?>
                        <tr>
                            <td>
                                <strong><?= date('d.m.Y', strtotime($k['termin_data'])) ?></strong>
                                <?php if ($k['termin_godzina']): ?>
                                    <br><small style="color: #64748b;"><?= substr($k['termin_godzina'], 0, 5) ?></small>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="karta.php?id=<?= $k['kandydat_id'] ?>" style="color: #1e293b; font-weight: 600; text-decoration: none;">
                                    <?= htmlspecialchars($k['imie'] . ' ' . $k['nazwisko']) ?>
                                </a>
                                <?php if ($kandydatStatus): ?>
                                    <br><span class="badge" style="background: <?= $kandydatStatus['bg'] ?>; color: <?= $kandydatStatus['color'] ?>; font-size: 0.7rem;"><?= $kandydatStatus['icon'] ?> <?= $kandydatStatus['label'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($k['telefon']): ?>
                                    <a href="tel:<?= $k['telefon'] ?>" style="font-family: monospace;"><?= htmlspecialchars($k['telefon']) ?></a>
                                <?php else: ?>
                                    <span style="color: #94a3b8;">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span style="color: <?= $typInfo['color'] ?>;"><?= $typInfo['icon'] ?></span>
                                <?= $typInfo['label'] ?>
                            </td>
                            <td><?= htmlspecialchars($k['tytul']) ?></td>
                            <td>
                                <span class="badge" style="background: <?= $statusInfo['bg'] ?>; color: <?= $statusInfo['color'] ?>;">
                                    <?= $statusInfo['icon'] ?> <?= $statusInfo['label'] ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($k['wynik']): ?>
                                    <div class="wynik-text" title="<?= htmlspecialchars($k['wynik']) ?>"><?= htmlspecialchars($k['wynik']) ?></div>
                                <?php else: ?>
                                    <span style="color: #94a3b8;">-</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($k['rekruter_nazwa'] ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
