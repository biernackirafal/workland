<?php
/**
 * Moduł Kandydatów - Dodawanie CV
 * 
 * Upload pliku CV (PDF, DOC, DOCX, RTF) z automatyczną ekstrakcją danych
 * 
 * WGRAJ DO: /kadry/kandydaci/dodaj.php
 */

require_once '../includes/db.php';
require_once 'CVParser.php';

$db = initDatabase();
requireLogin();

$currentUser = getCurrentUser();
$statusy = getKandydatStatusy();
$kategorieJazdy = getKategorieJazdy();

// Pobierz aktywne ogłoszenia
$ogloszenia = $db->query("SELECT id, tytul, stanowisko, lokalizacja FROM ogloszenia WHERE status = 'aktywne' ORDER BY created_at DESC")->fetchAll();

$message = '';
$error = '';
$extracted = null;
$tempFile = null;

// Obsługa uploadu CV
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['cv_file'])) {
    $file = $_FILES['cv_file'];
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        // Obsługiwane formaty: PDF, DOC, DOCX, RTF
        $allowedTypes = [
            'application/pdf',
            'application/msword',  // .doc
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
            'application/rtf',     // .rtf
            'text/rtf',            // .rtf (alternatywny MIME)
            'application/x-rtf'    // .rtf (alternatywny MIME)
        ];
        
        // Sprawdź też po rozszerzeniu (niektóre serwery źle rozpoznają MIME)
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowedExtensions = ['pdf', 'doc', 'docx', 'rtf'];
        
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        
        if (in_array($mimeType, $allowedTypes) || in_array($extension, $allowedExtensions)) {
            try {
                // Parsuj CV (przekaż oryginalną nazwę dla wykrycia formatu)
                $parser = new CVParser();
                $extracted = $parser->parseFile($file['tmp_name'], $file['name']);
                
                // Zachowaj plik tymczasowo z oryginalnym rozszerzeniem
                $tempName = uniqid('cv_') . '.' . $extension;
                $tempPath = '../data/uploads/cv/' . $tempName;
                
                if (!is_dir('../data/uploads/cv')) {
                    mkdir('../data/uploads/cv', 0755, true);
                }
                
                move_uploaded_file($file['tmp_name'], $tempPath);
                
                // Zapisz wszystko w sesji - plik I wyekstrahowane dane
                $_SESSION['temp_cv'] = [
                    'path' => $tempPath,
                    'original_name' => $file['name'],
                    'temp_name' => $tempName,
                    'extracted' => $extracted  // <-- WAŻNE: zapisz dane w sesji
                ];
                
                $message = 'Dane wyekstrahowane z CV. Sprawdź i uzupełnij poniżej.';
                
            } catch (Exception $e) {
                $error = 'Błąd parsowania CV: ' . $e->getMessage();
            }
        } else {
            $error = 'Dozwolone formaty: PDF, DOC, DOCX, RTF (otrzymano: ' . $mimeType . ')';
        }
    } else {
        $error = 'Błąd podczas uploadu pliku';
    }
}

// Odczytaj dane z sesji jeśli istnieją (np. po odświeżeniu strony)
if (!$extracted && isset($_SESSION['temp_cv']['extracted'])) {
    $extracted = $_SESSION['temp_cv']['extracted'];
}

// Zapisanie kandydata
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_kandydat'])) {
    $data = [
        'imie' => trim($_POST['imie'] ?? ''),
        'nazwisko' => trim($_POST['nazwisko'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'telefon' => trim($_POST['telefon'] ?? ''),
        'data_urodzenia' => $_POST['data_urodzenia'] ?? null,
        'miejscowosc' => trim($_POST['miejscowosc'] ?? ''),
        'prawo_jazdy' => isset($_POST['prawo_jazdy']) ? implode(', ', $_POST['prawo_jazdy']) : '',
        'wozki_widlowe' => isset($_POST['wozki_widlowe']) ? 1 : 0,
        'status' => $_POST['status'] ?? 'nowy',
        'notatki' => trim($_POST['notatki'] ?? ''),
        'cv_text' => $_POST['cv_text'] ?? '',
        'ogloszenie_id' => intval($_POST['ogloszenie_id'] ?? 0) ?: null
    ];
    
    // Obsługa pliku CV
    $cvFilename = null;
    $cvOriginalName = null;
    
    if (isset($_SESSION['temp_cv'])) {
        $cvFilename = $_SESSION['temp_cv']['temp_name'];
        $cvOriginalName = $_SESSION['temp_cv']['original_name'];
        unset($_SESSION['temp_cv']);
    }
    
    // Walidacja
    if (empty($data['imie']) || empty($data['nazwisko'])) {
        $error = 'Imię i nazwisko są wymagane';
    } else {
        $guid = generateGuid();
        
        $stmt = $db->prepare("INSERT INTO kandydaci 
            (guid, imie, nazwisko, email, telefon, data_urodzenia, miejscowosc, prawo_jazdy, wozki_widlowe, status, notatki, cv_filename, cv_original_name, cv_text, ogloszenie_id, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->execute([
            $guid,
            $data['imie'],
            $data['nazwisko'],
            $data['email'] ?: null,
            $data['telefon'] ?: null,
            $data['data_urodzenia'] ?: null,
            $data['miejscowosc'] ?: null,
            $data['prawo_jazdy'] ?: null,
            $data['wozki_widlowe'],
            $data['status'],
            $data['notatki'] ?: null,
            $cvFilename,
            $cvOriginalName,
            $data['cv_text'] ?: null,
            $data['ogloszenie_id'],
            $currentUser['id']
        ]);
        
        $newId = $db->lastInsertId();
        
        logChange($db, 'CREATE', 'kandydaci', $newId, "Dodano kandydata: {$data['imie']} {$data['nazwisko']}");
        
        header("Location: karta.php?id=$newId&msg=created");
        exit;
    }
}

// Wyczyść tymczasowe CV jeśli anulowano
if (isset($_GET['cancel']) && isset($_SESSION['temp_cv'])) {
    if (file_exists($_SESSION['temp_cv']['path'])) {
        unlink($_SESSION['temp_cv']['path']);
    }
    unset($_SESSION['temp_cv']);
    header('Location: dodaj.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj CV - Kandydaci - Work Land</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        * { box-sizing: border-box; }
        body { background: #f1f5f9; margin: 0; font-family: 'Segoe UI', system-ui, sans-serif; }
        
        .container { max-width: 900px; margin: 0 auto; padding: 20px; }
        
        .top-nav { display: flex; justify-content: space-between; align-items: center; background: white; padding: 12px 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .logo-section { display: flex; align-items: center; gap: 15px; }
        .logo-section img { height: 40px; }
        
        .card { background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 20px; }
        .card-header { padding: 16px 20px; border-bottom: 1px solid #e2e8f0; font-weight: 600; background: #f8fafc; }
        .card-body { padding: 25px; }
        
        .upload-zone { border: 3px dashed #cbd5e1; border-radius: 12px; padding: 50px 30px; text-align: center; cursor: pointer; transition: all 0.3s; background: #f8fafc; }
        .upload-zone:hover { border-color: #2563eb; background: #eff6ff; }
        .upload-zone.dragover { border-color: #16a34a; background: #f0fdf4; }
        .upload-zone .icon { font-size: 3rem; margin-bottom: 15px; }
        .upload-zone h3 { margin: 0 0 10px 0; color: #1e293b; }
        .upload-zone p { margin: 0; color: #64748b; }
        .upload-zone input[type="file"] { display: none; }
        
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; font-weight: 600; color: #374151; margin-bottom: 6px; font-size: 0.9rem; }
        .form-group input, .form-group select, .form-group textarea { 
            width: 100%; padding: 12px 14px; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 1rem; 
            transition: border-color 0.2s;
        }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { 
            border-color: #2563eb; outline: none; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }
        .form-group textarea { resize: vertical; min-height: 100px; }
        .form-group small { color: #64748b; font-size: 0.8rem; margin-top: 4px; display: block; }
        
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        @media (max-width: 600px) { .form-row { grid-template-columns: 1fr; } }
        
        .checkbox-group { display: flex; flex-wrap: wrap; gap: 10px; }
        .checkbox-item { display: flex; align-items: center; gap: 6px; padding: 8px 14px; background: #f1f5f9; border-radius: 6px; cursor: pointer; transition: background 0.2s; }
        .checkbox-item:hover { background: #e2e8f0; }
        .checkbox-item input { margin: 0; }
        .checkbox-item.checked { background: #dbeafe; color: #1e40af; }
        
        .toggle-switch { display: flex; align-items: center; gap: 12px; }
        .toggle-switch input[type="checkbox"] { width: 50px; height: 26px; appearance: none; background: #cbd5e1; border-radius: 13px; position: relative; cursor: pointer; transition: background 0.3s; }
        .toggle-switch input[type="checkbox"]::before { content: ''; position: absolute; width: 22px; height: 22px; background: white; border-radius: 50%; top: 2px; left: 2px; transition: transform 0.3s; box-shadow: 0 2px 4px rgba(0,0,0,0.2); }
        .toggle-switch input[type="checkbox"]:checked { background: #16a34a; }
        .toggle-switch input[type="checkbox"]:checked::before { transform: translateX(24px); }
        
        .btn { padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 1rem; display: inline-flex; align-items: center; gap: 8px; border: none; cursor: pointer; }
        .btn-primary { background: #2563eb; color: white; }
        .btn-primary:hover { background: #1d4ed8; }
        .btn-success { background: #16a34a; color: white; }
        .btn-success:hover { background: #15803d; }
        .btn-secondary { background: #f1f5f9; color: #374151; }
        .btn-secondary:hover { background: #e2e8f0; }
        
        .actions { display: flex; gap: 12px; justify-content: flex-end; margin-top: 25px; padding-top: 20px; border-top: 1px solid #e2e8f0; }
        
        .alert { padding: 14px 18px; border-radius: 8px; margin-bottom: 20px; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }
        .alert-info { background: #dbeafe; color: #1e40af; border: 1px solid #bfdbfe; }
        
        .extracted-preview { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 15px; margin-bottom: 20px; }
        .extracted-preview h4 { margin: 0 0 10px 0; color: #166534; }
        .extracted-preview .file-info { font-size: 0.9rem; color: #15803d; }
        
        .cv-text-preview { max-height: 200px; overflow-y: auto; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 12px; font-family: monospace; font-size: 0.85rem; white-space: pre-wrap; }
    </style>
</head>
<body>
    <div class="container">
        <nav class="top-nav">
            <div class="logo-section">
                <a href="../index.php"><img src="../assets/logo.png" alt="Work Land"></a>
            </div>
            <a href="index.php" class="btn btn-secondary">← Wróć do listy</a>
        </nav>
        
        <?php if ($error): ?>
            <div class="alert alert-error">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        
        <?php if ($message): ?>
            <div class="alert alert-success">✅ <?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        
        <?php if (!$extracted && !isset($_SESSION['temp_cv'])): ?>
        <!-- KROK 1: UPLOAD CV -->
        <div class="card">
            <div class="card-header">📄 Krok 1: Wgraj CV</div>
            <div class="card-body">
                <form method="POST" enctype="multipart/form-data" id="uploadForm">
                    <div class="upload-zone" id="dropZone" onclick="document.getElementById('cv_file').click()">
                        <div class="icon">📄</div>
                        <h3>Przeciągnij plik CV tutaj</h3>
                        <p>lub kliknij aby wybrać plik</p>
                        <input type="file" name="cv_file" id="cv_file" accept=".pdf,.doc,.docx,.rtf,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/rtf">
                    </div>
                    <p style="text-align: center; margin-top: 15px; color: #64748b; font-size: 0.9rem;">
                        Obsługiwane formaty: PDF, DOC, DOCX, RTF
                    </p>
                </form>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">✍️ Lub dodaj ręcznie</div>
            <div class="card-body">
                <p style="color: #64748b; margin: 0;">
                    Możesz też <a href="?manual=1" style="color: #2563eb;">pominąć upload</a> i wprowadzić dane ręcznie.
                </p>
            </div>
        </div>
        
        <?php else: ?>
        <!-- KROK 2: WERYFIKACJA I UZUPEŁNIENIE DANYCH -->
        <div class="card">
            <div class="card-header">✏️ Krok 2: Zweryfikuj i uzupełnij dane</div>
            <div class="card-body">
                
                <?php if (isset($_SESSION['temp_cv'])): ?>
                <div class="extracted-preview">
                    <h4>📄 Wczytane CV</h4>
                    <div class="file-info">
                        <?= htmlspecialchars($_SESSION['temp_cv']['original_name']) ?>
                        <a href="?cancel=1" style="margin-left: 15px; color: #dc2626; font-size: 0.85rem;">🔄 Wgraj inne CV</a>
                    </div>
                </div>
                <?php endif; ?>
                
                <form method="POST">
                    <input type="hidden" name="save_kandydat" value="1">
                    <input type="hidden" name="cv_text" value="<?= htmlspecialchars($extracted['raw_text'] ?? '') ?>">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Imię *</label>
                            <input type="text" name="imie" value="<?= htmlspecialchars($extracted['imie'] ?? '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Nazwisko *</label>
                            <input type="text" name="nazwisko" value="<?= htmlspecialchars($extracted['nazwisko'] ?? '') ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>📧 Email</label>
                            <input type="email" name="email" value="<?= htmlspecialchars($extracted['email'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>📞 Telefon</label>
                            <input type="tel" name="telefon" value="<?= htmlspecialchars($extracted['telefon'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>🎂 Data urodzenia</label>
                            <input type="date" name="data_urodzenia" value="<?= htmlspecialchars($extracted['data_urodzenia'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label>📍 Miejscowość</label>
                            <input type="text" name="miejscowosc" value="<?= htmlspecialchars($extracted['miejscowosc'] ?? '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>🚗 Prawo jazdy - kategorie</label>
                        <div class="checkbox-group">
                            <?php 
                            $extractedKategorie = array_map('trim', explode(',', $extracted['prawo_jazdy'] ?? ''));
                            foreach ($kategorieJazdy as $kat): 
                                $checked = in_array($kat, $extractedKategorie);
                            ?>
                            <label class="checkbox-item <?= $checked ? 'checked' : '' ?>">
                                <input type="checkbox" name="prawo_jazdy[]" value="<?= $kat ?>" <?= $checked ? 'checked' : '' ?> onchange="this.parentElement.classList.toggle('checked', this.checked)">
                                <?= $kat ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>🚜 Uprawnienia na wózki widłowe</label>
                        <div class="toggle-switch">
                            <input type="checkbox" name="wozki_widlowe" value="1" <?= ($extracted['wozki_widlowe'] ?? 0) ? 'checked' : '' ?>>
                            <span>Posiada uprawnienia</span>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status">
                                <?php foreach ($statusy as $key => $s): ?>
                                    <option value="<?= $key ?>" <?= $key === 'nowy' ? 'selected' : '' ?>><?= $s['icon'] ?> <?= $s['label'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>📢 W odpowiedzi na ogłoszenie</label>
                            <select name="ogloszenie_id">
                                <option value="">-- brak / spontaniczna aplikacja --</option>
                                <?php foreach ($ogloszenia as $og): ?>
                                    <option value="<?= $og['id'] ?>"><?= htmlspecialchars($og['tytul']) ?><?= $og['lokalizacja'] ? ' (' . htmlspecialchars($og['lokalizacja']) . ')' : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (empty($ogloszenia)): ?>
                                <small><a href="ogloszenia.php">+ Dodaj ogłoszenie</a></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>📝 Notatki</label>
                        <textarea name="notatki" placeholder="Dodatkowe uwagi o kandydacie..."></textarea>
                    </div>
                    
                    <?php if (!empty($extracted['raw_text'])): ?>
                    <div class="form-group">
                        <label>📄 Wyekstrahowany tekst CV (do przeszukiwania)</label>
                        <div class="cv-text-preview"><?= htmlspecialchars(substr($extracted['raw_text'], 0, 2000)) ?>...</div>
                        <small>Tekst jest zapisywany w bazie i umożliwia wyszukiwanie pełnotekstowe.</small>
                    </div>
                    <?php endif; ?>
                    
                    <div class="actions">
                        <a href="?cancel=1" class="btn btn-secondary">✕ Anuluj</a>
                        <button type="submit" class="btn btn-success">💾 Zapisz kandydata</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
        
        <?php if (isset($_GET['manual'])): ?>
        <!-- RĘCZNE DODAWANIE -->
        <div class="card">
            <div class="card-header">✍️ Dodaj kandydata ręcznie</div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="save_kandydat" value="1">
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Imię *</label>
                            <input type="text" name="imie" required>
                        </div>
                        <div class="form-group">
                            <label>Nazwisko *</label>
                            <input type="text" name="nazwisko" required>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>📧 Email</label>
                            <input type="email" name="email">
                        </div>
                        <div class="form-group">
                            <label>📞 Telefon</label>
                            <input type="tel" name="telefon">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>🎂 Data urodzenia</label>
                            <input type="date" name="data_urodzenia">
                        </div>
                        <div class="form-group">
                            <label>📍 Miejscowość</label>
                            <input type="text" name="miejscowosc">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>🚗 Prawo jazdy - kategorie</label>
                        <div class="checkbox-group">
                            <?php foreach ($kategorieJazdy as $kat): ?>
                            <label class="checkbox-item">
                                <input type="checkbox" name="prawo_jazdy[]" value="<?= $kat ?>" onchange="this.parentElement.classList.toggle('checked', this.checked)">
                                <?= $kat ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>🚜 Uprawnienia na wózki widłowe</label>
                        <div class="toggle-switch">
                            <input type="checkbox" name="wozki_widlowe" value="1">
                            <span>Posiada uprawnienia</span>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status">
                                <?php foreach ($statusy as $key => $s): ?>
                                    <option value="<?= $key ?>" <?= $key === 'nowy' ? 'selected' : '' ?>><?= $s['icon'] ?> <?= $s['label'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>📢 W odpowiedzi na ogłoszenie</label>
                            <select name="ogloszenie_id">
                                <option value="">-- brak / spontaniczna aplikacja --</option>
                                <?php foreach ($ogloszenia as $og): ?>
                                    <option value="<?= $og['id'] ?>"><?= htmlspecialchars($og['tytul']) ?><?= $og['lokalizacja'] ? ' (' . htmlspecialchars($og['lokalizacja']) . ')' : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (empty($ogloszenia)): ?>
                                <small><a href="ogloszenia.php">+ Dodaj ogłoszenie</a></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>📝 Notatki</label>
                        <textarea name="notatki" placeholder="Dodatkowe uwagi o kandydacie..."></textarea>
                    </div>
                    
                    <div class="actions">
                        <a href="dodaj.php" class="btn btn-secondary">← Wróć</a>
                        <button type="submit" class="btn btn-success">💾 Zapisz kandydata</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
    
    <script>
    // Drag & drop
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('cv_file');
    const form = document.getElementById('uploadForm');
    
    if (dropZone) {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });
        
        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, () => dropZone.classList.add('dragover'));
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, () => dropZone.classList.remove('dragover'));
        });
        
        dropZone.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                form.submit();
            }
        });
        
        fileInput.addEventListener('change', () => {
            if (fileInput.files.length > 0) {
                form.submit();
            }
        });
    }
    </script>
</body>
</html>
