<?php
/**
 * Generator karty pracownika do DOCX
 * System Ewidencji Pracowników - Work Land
 */

require_once 'includes/db.php';

$db = initDatabase();
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$id) {
    header('Location: index.php');
    exit;
}

// Pobierz dane pracownika
$stmt = $db->prepare("SELECT * FROM pracownicy WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch();

if (!$p) {
    header('Location: index.php');
    exit;
}

// Pobierz aktualne oddelegowanie
$stmt = $db->prepare("SELECT o.*, k.nazwa as klient_nazwa FROM oddelegowania o 
    LEFT JOIN klienci k ON o.klient_id = k.id 
    WHERE o.pracownik_id = ? AND o.active = 1 
    ORDER BY o.data_od DESC LIMIT 1");
$stmt->execute([$id]);
$oddelegowanie = $stmt->fetch();

// Pobierz urlopy
$stmt = $db->prepare("SELECT * FROM urlopy WHERE pracownik_id = ? ORDER BY data_od DESC");
$stmt->execute([$id]);
$urlopy = $stmt->fetchAll();

// Formatowanie daty
function fd($date) {
    if (empty($date)) return '-';
    return date('d.m.Y', strtotime($date));
}

// Tworzenie pliku JS do generacji DOCX
$jsFile = '/tmp/generate_docx_' . uniqid() . '.js';
$outputFile = '/tmp/karta_' . $p['kod'] . '_' . date('Ymd_His') . '.docx';

// Przygotowanie danych do JS
$urlopyText = '';
if (!empty($urlopy)) {
    foreach ($urlopy as $u) {
        $urlopyText .= $u['typ'] . ': ' . fd($u['data_od']) . ' - ' . fd($u['data_do']) . '\n';
    }
} else {
    $urlopyText = 'Brak zarejestrowanych urlopów';
}

$uprawnienia = [];
if (!empty($p['prawo_jazdy'])) $uprawnienia[] = 'Prawo jazdy: ' . $p['prawo_jazdy'];
if (!empty($p['wozek_widlowy'])) $uprawnienia[] = 'Wózek widłowy: Tak';
if (!empty($p['wysoki_sklad'])) $uprawnienia[] = 'Wysoki skład: Tak';
$uprawnieniaText = !empty($uprawnienia) ? implode(', ', $uprawnienia) : 'Brak';

$jsContent = <<<JS
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, 
        AlignmentType, BorderStyle, WidthType, ShadingType, Header, Footer, PageNumber } = require('docx');
const fs = require('fs');

const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" };
const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };

function makeRow(label, value) {
    return new TableRow({
        children: [
            new TableCell({
                borders: cellBorders,
                width: { size: 3500, type: WidthType.DXA },
                shading: { fill: "F1F5F9", type: ShadingType.CLEAR },
                children: [new Paragraph({ 
                    children: [new TextRun({ text: label, bold: true, size: 22, font: "Arial" })]
                })]
            }),
            new TableCell({
                borders: cellBorders,
                width: { size: 5860, type: WidthType.DXA },
                children: [new Paragraph({ 
                    children: [new TextRun({ text: value || "-", size: 22, font: "Arial" })]
                })]
            })
        ]
    });
}

function makeSectionHeader(title) {
    return new Paragraph({
        spacing: { before: 300, after: 100 },
        children: [new TextRun({ text: title, bold: true, size: 26, font: "Arial", color: "2563EB" })]
    });
}

const doc = new Document({
    styles: {
        default: { document: { run: { font: "Arial", size: 22 } } }
    },
    sections: [{
        properties: {
            page: { margin: { top: 720, right: 720, bottom: 720, left: 720 } }
        },
        headers: {
            default: new Header({ children: [new Paragraph({ 
                alignment: AlignmentType.RIGHT,
                children: [new TextRun({ text: "Work Land - Karta Pracownika", size: 18, color: "999999", font: "Arial" })]
            })] })
        },
        footers: {
            default: new Footer({ children: [new Paragraph({ 
                alignment: AlignmentType.CENTER,
                children: [
                    new TextRun({ text: "Wygenerowano: " + new Date().toLocaleDateString('pl-PL') + " | Strona ", size: 18, color: "999999", font: "Arial" }),
                    new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "999999", font: "Arial" }),
                    new TextRun({ text: " z ", size: 18, color: "999999", font: "Arial" }),
                    new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18, color: "999999", font: "Arial" })
                ]
            })] })
        },
        children: [
            // Nagłówek
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { after: 100 },
                children: [new TextRun({ text: "KARTA PRACOWNIKA", bold: true, size: 36, font: "Arial" })]
            }),
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { after: 300 },
                children: [new TextRun({ text: "${addslashes($p['kod'])}", bold: true, size: 28, font: "Arial", color: "2563EB" })]
            }),
            
            // Imię i nazwisko
            new Paragraph({
                alignment: AlignmentType.CENTER,
                spacing: { after: 400 },
                children: [new TextRun({ text: "${addslashes($p['imie'])} ${addslashes($p['nazwisko'])}", bold: true, size: 32, font: "Arial" })]
            }),
            
            // Dane podstawowe
            makeSectionHeader("📋 Dane podstawowe"),
            new Table({
                columnWidths: [3500, 5860],
                rows: [
                    makeRow("Narodowość", "${addslashes($p['narodowosc'])}"),
                    makeRow("Data urodzenia", "${fd($p['data_urodzenia'])}"),
                    makeRow("PESEL", "${addslashes($p['pesel'])}"),
                    makeRow("NIP", "${addslashes($p['nip'])}"),
                    makeRow("Dokument tożsamości", "${addslashes($p['dokument_tozsamosci'])}"),
                    makeRow("Telefon", "${addslashes($p['telefon'])}"),
                    makeRow("Adres", "${addslashes(str_replace(["\r", "\n"], ' ', $p['adres']))}")
                ]
            }),
            
            // Zatrudnienie
            makeSectionHeader("💼 Zatrudnienie"),
            new Table({
                columnWidths: [3500, 5860],
                rows: [
                    makeRow("Data przyjęcia", "${fd($p['data_przyjecia'])}"),
                    makeRow("Data zwolnienia", "${fd($p['data_zwolnienia'])}"),
                    makeRow("Stanowisko", "${addslashes($p['stanowisko'])}"),
                    makeRow("Forma umowy", "${addslashes($p['forma_umowy'])}"),
                    makeRow("Wymiar czasu pracy", "${addslashes($p['wymiar_czasu_pracy'])}"),
                    makeRow("Stawka wynagrodzenia", "${$p['stawka_wynagrodzenia'] ? number_format($p['stawka_wynagrodzenia'], 2, ',', ' ') . ' zł' : '-'}")
                ]
            }),
            
            // Oddelegowanie
            makeSectionHeader("🏢 Oddelegowanie"),
            new Table({
                columnWidths: [3500, 5860],
                rows: [
                    makeRow("Aktualny klient", "${$oddelegowanie ? addslashes($oddelegowanie['klient_nazwa']) : 'Brak'}"),
                    makeRow("Stanowisko u klienta", "${$oddelegowanie ? addslashes($oddelegowanie['stanowisko']) : '-'}"),
                    makeRow("Od", "${$oddelegowanie ? fd($oddelegowanie['data_od']) : '-'}"),
                    makeRow("Do", "${$oddelegowanie && $oddelegowanie['data_do'] ? fd($oddelegowanie['data_do']) : 'bezterminowo'}")
                ]
            }),
            
            // Dokumenty i terminy
            makeSectionHeader("📅 Dokumenty i terminy"),
            new Table({
                columnWidths: [3500, 5860],
                rows: [
                    makeRow("Zezwolenie na pracę do", "${fd($p['zezwolenie_do'])}"),
                    makeRow("Data zakończenia pobytu", "${fd($p['data_zakonczenia_pobytu'])}"),
                    makeRow("Badania lekarskie do", "${fd($p['badania_lekarskie'])}"),
                    makeRow("Szkolenie BHP do", "${fd($p['szkolenie_bhp'])}")
                ]
            }),
            
            // Kwalifikacje
            makeSectionHeader("🎓 Kwalifikacje i uprawnienia"),
            new Table({
                columnWidths: [3500, 5860],
                rows: [
                    makeRow("Prawo jazdy", "${addslashes($p['prawo_jazdy']) ?: 'Brak'}"),
                    makeRow("Wózek widłowy", "${!empty($p['wozek_widlowy']) ? 'Tak' : 'Nie'}"),
                    makeRow("Wysoki skład", "${!empty($p['wysoki_sklad']) ? 'Tak' : 'Nie'}"),
                    makeRow("Grupa inwalidzka", "${addslashes($p['grupa_inwalidzka']) ?: 'Brak'}")
                ]
            }),
            
            // Konto bankowe
            makeSectionHeader("🏦 Dane bankowe"),
            new Table({
                columnWidths: [3500, 5860],
                rows: [
                    makeRow("Numer konta", "${addslashes($p['konto_bankowe']) ?: '-'}")
                ]
            }),
            
            // Uwagi
            makeSectionHeader("📝 Uwagi"),
            new Paragraph({
                spacing: { before: 100 },
                children: [new TextRun({ text: "${addslashes(str_replace(["\r", "\n"], ' ', $p['uwagi'])) ?: 'Brak uwag'}", size: 22, font: "Arial" })]
            })
        ]
    }]
});

Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync("${$outputFile}", buffer);
    console.log("OK");
}).catch(err => {
    console.error("ERROR: " + err.message);
    process.exit(1);
});
JS;

file_put_contents($jsFile, $jsContent);

// Uruchom generację
$output = shell_exec("cd /tmp && node " . escapeshellarg($jsFile) . " 2>&1");

if (strpos($output, 'OK') !== false && file_exists($outputFile)) {
    // Wyślij plik
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment; filename="Karta_' . $p['kod'] . '_' . $p['nazwisko'] . '.docx"');
    header('Content-Length: ' . filesize($outputFile));
    header('Cache-Control: no-cache');
    
    readfile($outputFile);
    
    // Usuń pliki tymczasowe
    unlink($jsFile);
    unlink($outputFile);
    exit;
} else {
    // Błąd - pokaż komunikat
    unlink($jsFile);
    echo "Błąd generowania dokumentu: " . htmlspecialchars($output);
    echo "<br><a href='view.php?id=$id'>Wróć do karty pracownika</a>";
}
